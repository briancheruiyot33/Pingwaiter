Hello friend,
How are your<?php /**PATH C:\xampp\htdocs\Werabe University Project\Werabe University Project\resources\views\mail\hello.blade.php ENDPATH**/ ?>