<?php $__env->startSection('title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="app-content content">
        <section id="responsive-datatable">
            <div class="row">
                <div class="col-12">
                    <!-- Your HTML content goes here -->
                    <div class="card">
                        <div class="card-header border-bottom">
                            <h3 class="card-title">Employee Schedules</h3>

                            <button type="button" class="btn btn-gradient-info btn-sm add">Add</button>

                        </div>
                        <div class="card-datatable">
                            <div style="width:98%; margin-left:1%;">
                                <div class="table-responsive">

                                    <table id="laravel-datatable-category"
                                        class="display table-bordered table-striped table-hover dt-responsive mb-0 dataTable no-footer"
                                        style="width: 100%;" role="grid" aria-describedby="laravel-datatable-user">

                                        <thead>
                                            <tr role="row">
                                                <th nowrap>#</th>
                                                <th nowrap>Employee Name</th>
                                                <th nowrap>Type</th>
                                                <th nowrap>In Time</th>
                                                <th nowrap>Out Time</th>
                                                <th nowrap>Working Days</th>
                                                <th nowrap>Current Status</th>
                                                <th nowrap>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody></tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- BEGIN: Category Add modal  -->
        <div class="modal fade text-left" id="inlineForm" data-keyboard="false" data-backdrop="static" tabindex="-1"
            role="dialog" aria-labelledby="categorylbl" aria-hidden="true" style="overflow-y: scroll;">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="categorylbl">Add Schedule</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                            onclick="closeModal()">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form id="Register">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="edit_id" id="edit_id">
                        <div class="modal-body">
                            <label strong style="font-size: 16px;">Select Employee</label><label
                                style="color: red; font-size:16px;">*</label>
                            <div class="form-group">
                                <select class="custom-select browser-default select2" name="user_id" id="user_id"
                                    onchange="removeUserValidation()">
                                    <option value=""></option>
                                    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($role->name == 'doctor'): ?>
                                                <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?> | Doctor</option>
                                            <?php endif; ?>
                                            <?php if($role->name == 'register'): ?>
                                                <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?> | Receiption
                                                </option>
                                            <?php endif; ?>
                                            <?php if($role->name == 'labratory'): ?>
                                                <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?> | Labratory</option>
                                            <?php endif; ?>
                                            <?php if($role->name == 'pharmacy'): ?>
                                                <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?> | Pharmacy</option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                                <span class="text-danger">
                                    <strong id="user-error"></strong>
                                </span>
                            </div>
                            <label>In-Time:</label>
                            <div class="form-group">
                                <input type="text" name="in_time" id="in_time" class="form-control">

                                <span class="text-danger">
                                    <strong id="in_time-error"></strong>
                                </span>
                            </div>
                            <label>Out-Time:</label>
                            <div class="form-group">
                                <input type="text" name="out_time" id="out_time" class="form-control timepicker">
                                <span class="text-danger">
                                    <strong id="out_time-error"></strong>
                                </span>
                            </div>
                            <label>Working Day:</label>
                            <div class="form-group">
                                <select name="working_day[]" id="working_day" class="custom-select browser-default"
                                    multiple="" required="">
                                    <option>Sunday</option>
                                    <option>Monday</option>
                                    <option>Tuesday</option>
                                    <option>Wednesday</option>
                                    <option>Thursday</option>
                                    <option>Friday</option>
                                    <option>Saturday</option>
                                </select>
                                <span class="text-danger">
                                    <strong id="working_day-error"></strong>
                                </span>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button id="savenewbutton" type="button" class="btn btn-info">Save &
                                New</button>
                            <button id="savebutton" type="button" class="btn btn-info">Save & Close</button>
                            <button id="closebutton" type="button" class="btn btn-danger" onclick="closeModal()"
                                data-dismiss="modal">Close</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- BEGIN: Info modal -->
    <div class="modal fade text-left" id="infoModal" data-keyboard="false" data-backdrop="static" tabindex="-1"
        role="dialog" aria-labelledby="myModalLabel133" aria-hidden="true" style="overflow-y: scroll;">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Schedule Information</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="regionform">
                    <input type="hidden" class="_token">
                    <div class="modal-body">
                        <table style="width: 100%;">
                            <tbody>
                                <tr>
                                    <td style="width: 40%">
                                        <label style="font-size: 14px;">User Name: </label>
                                    </td>
                                    <td style="width: 60%">
                                        <label id="user_info" style="font-size: 14px; font-weight: bold;"></label>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 40%">
                                        <label style="font-size: 14px;">In Time: </label>
                                    </td>
                                    <td style="width: 60%">
                                        <label id="in_time_info" style="font-size: 14px; font-weight: bold;"></label>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 40%">
                                        <label style="font-size: 14px;">Out Time: </label>
                                    </td>
                                    <td style="width: 60%">
                                        <label id="out_time_info" style="font-size: 14px; font-weight: bold;"></label>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 40%">
                                        <label style="font-size: 14px;">Working Day: </label>
                                    </td>
                                    <td style="width: 60%">
                                        <label id="working_day_info" style="font-size: 14px; font-weight: bold;"></label>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="2">
                                        <div class="divider newext">
                                            <div class="divider-text">Action Information</div>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label style="font-size: 14px;">Created By</label>
                                    </td>
                                    <td>
                                        <label id="createdby_info" style="font-size: 14px; font-weight: bold;"></label>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label style="font-size: 14px;">Created Date</label>
                                    </td>
                                    <td>
                                        <label id="createdat_info" style="font-size: 14px; font-weight: bold;"></label>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label style="font-size: 14px;">Last Edited By</label>
                                    </td>
                                    <td>
                                        <label id="updatedby_info" style="font-size: 14px; font-weight: bold;"></label>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 30%">
                                        <label style="font-size: 14px;">Last Edited Date</label>
                                    </td>
                                    <td style="width: 70%">
                                        <label id="updatedat_info" style="font-size: 14px; font-weight: bold;"></label>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="modal-footer">
                        <button id="closebuttonk" type="button"
                            class="btn btn-danger waves-effect waves-float waves-light"
                            data-dismiss="modal">Close</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <div class="modal fade" id="DeleteModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Delete Category Data</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                        onclick="closeModalWithClearValidation()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" style="background-color:#e74a3b">
                    <label strong style="font-size: 16px;font-weight:bold;color:white;">Do you really want to
                        delete this category?</label>
                    <input type="hidden" id="deleteing_id">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-info delete_category">Delete</button>
                    <button id="closebutton" type="button" class="btn btn-danger"
                        onclick="closeModalWithClearValidation()" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#in_time').timepicker({
                timeFormat: 'h:i A', // Customize the time format as needed
                interval: 30, // Interval in minutes
                minTime: '6:00am', // Minimum time
                maxTime: '11:00pm', // Maximum time
                defaultTime: '8:00am', // Default time
                startTime: '6:00am', // Start time for the dropdown
                dynamic: false,
                dropdown: true,
                scrollbar: true
            });
            $('#out_time').timepicker({
                timeFormat: 'h:i A', // Customize the time format as needed
                interval: 30, // Interval in minutes
                minTime: '6:00am', // Minimum time
                maxTime: '11:00pm', // Maximum time
                defaultTime: '8:00am', // Default time
                startTime: '6:00am', // Start time for the dropdown
                dynamic: false,
                dropdown: true,
                scrollbar: true
            });
        });
    </script>
    <script>
        var errorcolor = "#ffcccc";
        $(function() {
            cardSection = $('#page-block');
        });
        /* BEGIN: Display zone table using yajra datatable */
        $(document).ready(function() {

            $('#working_day').val(null).trigger('change');
            $('#working_day').select2({
                placeholder: 'Select days',
            });
            var ctable = $('#laravel-datatable-category').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                searchHighlight: true,
                dom: 'lBfrtip', // Add l before B to include lengthMenu
                buttons: [{
                    extend: 'copy',
                    title: 'Your Title Here' // Title for the 'copy' button
                }],
                lengthMenu: [
                    [10, 25, 50, 500, -1],
                    [10, 25, 50, 500, "All"]
                ],
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: '/getschedules',
                    type: 'DELETE',
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'user',
                        name: 'user'
                    },
                    {
                        data: 'role',
                        name: 'role'
                    },
                    {
                        data: 'in_time',
                        name: 'in_time'
                    },
                    {
                        data: 'out_time',
                        name: 'out_time'
                    },
                    {
                        data: 'working_day',
                        name: 'working_day'
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return data.status == '0' ?
                                '<i class="fa fa-circle text-danger"> Out of Duty</i>' :
                                ' <i class="fa fa-check-circle text-success"> On Duty</i>';
                        },
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return '<div class="btn-group dropleft"><button type="button" class="btn btn-sm dropdown-toffle hide-arrow" data-toggle="dropdown" arial-haspopup="true" arial-expanded="false"><i class="fa fa-ellipsis-v"></i></button><div class = "dropdown-menu" > ' +
                                ' <a  class ="dropdown-item productInfo" title="show" onclick = "scheduleInfoFn(' +
                                data
                                .id +
                                ')"><i class="fa fa-info"></i><span> Info </span></a>' +
                                '<a class = "dropdown-item categoryEdit" onclick = "categoryEditFn(' +
                                data
                                .id +
                                ')" id = "dteditbtn" title = "Open schedule update page" data - id = "' +
                                data.id +
                                '"><i class="fa fa-edit"></i><span> Edit </span></a>' +
                                '</div></div> ';
                        },
                        orderable: false,
                        searchable: false
                    }
                ],
                "fnRowCallback": function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                    $(nRow).find('td:eq(2)').css({
                        "color": "orange",
                        "font-weight": "bold",
                        "text-shadow": "1px 1px 10px #4CAF50"
                    });
                }
            });
            /* End: Yajra data table*/
            $('#laravel-datatable-crud tbody').on('click', 'tr', function() {
                if ($(this).hasClass('selected')) {
                    $(this).removeClass('selected');
                } else {
                    $('tr.selected').removeClass('selected');
                    $(this).addClass('selected');
                }
            });

            $('#status').select2({
                minimumResultsForSearch: -1
            });
        });
        ctable.on('draw', function() {
            var body = $(ctable.table().body());
            body.unhighlight();
            body.highlight(ctable.search());
        })
    </script>
    <script>
        $('.add').click(function() {
            $('#edit_id').val('');
            $('#categorylbl').html('Add Schedule');
            $('#in_time').val('');
            $('#out_time').val('');
            $('#working_day').val(null).trigger('change');
            $('#user_id').val('');
            $('#user-error').html('');
            $('#in_time-error').html('');
            $('#out_time-error').html('');
            $('#working_day-error').html('');
            $('#user_id').select2({
                placeholder: "Select Employee here",
            });

            $('#savenewbutton').css('display', 'flex');
            $('#savebutton').html('Save & Close');
            $('#savenewbutton').html('Save & New');
            $('#inlineForm').modal('show');
        });
        $('#savebutton').click(function() {
            var categoryForm = $('#Register');
            var formData = categoryForm.serialize();
            var id = $('#edit_id').val();
            $.ajax({
                url: '/createupdateschedule/' + id,
                type: 'post',
                data: formData,
                beforeSend: function() {
                    cardSection.block({
                        message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                        css: {
                            backgroundColor: 'transparent',
                            color: '#fff',
                            border: '0'
                        },
                        overlayCSS: {
                            opacity: 0.5
                        }
                    });
                    if (id != "" && id != null) {
                        $('#savebutton').text('Updating...');
                        $('#savebutton').prop("disabled", true);
                    } else {
                        $('#savebutton').text('Saving...');
                        $('#savebutton').prop("disabled", true);
                    }

                },
                complete: function() {
                    cardSection.block({
                        message: '',
                        timeout: 1,
                        css: {
                            backgroundColor: '',
                            color: '',
                            border: ''
                        },
                    });
                },
                success: function(data) {
                    if (data.errors) {
                        if (data.errors.user_id) {
                            $('#user-error').html(data.errors.user_id[0]);
                        }
                        if (data.errors.in_time) {
                            $('#in_time-error').html(data.errors.in_time[0]);
                        }
                        if (data.errors.out_time) {
                            $('#out_time-error').html(data.errors.out_time[0]);
                        }
                        if (data.errors.working_day) {
                            $('#working_day-error').html(data.errors.working_day[0]);
                        }
                        if (id != "" && id != null) {
                            $('#savebutton').text('Update');
                        } else {
                            $('#savebutton').text('Save & Close');
                        }
                        alert_toast('Check your input?', 'error');
                        $('#savebutton').prop("disabled", false);
                    } else if (data.success) {
                        alert_toast(data.success, 'success');
                        var cTable = $('#laravel-datatable-category').dataTable();
                        cTable.fnDraw(false);
                        $('#savebutton').html('Save & Close');
                        $('#savebutton').prop("disabled", false);
                        $('#inlineForm').modal('hide');
                    }
                }

            });
        });

        $('#savenewbutton').click(function() {
            var categoryForm = $('#Register');
            var formData = categoryForm.serialize();
            var id = $('#edit_id').val();
            $.ajax({
                url: '/createupdateschedule/' + id,
                type: 'post',
                data: formData,
                beforeSend: function() {
                    cardSection.block({
                        message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                        css: {
                            backgroundColor: 'transparent',
                            color: '#fff',
                            border: '0'
                        },
                        overlayCSS: {
                            opacity: 0.5
                        }
                    });
                    $('#savenewbutton').text('Saving...');
                    $('#savenewbutton').prop("disabled", true);
                },
                complete: function() {
                    cardSection.block({
                        message: '',
                        timeout: 1,
                        css: {
                            backgroundColor: '',
                            color: '',
                            border: ''
                        },
                    });
                },
                success: function(data) {
                    if (data.errors) {
                        if (data.errors.user_id) {
                            $('#user-error').html(data.errors.user_id[0]);
                        }
                        if (data.errors.in_time) {
                            $('#in_time-error').html(data.errors.in_time[0]);
                        }
                        if (data.errors.out_time) {
                            $('#out_time-error').html(data.errors.out_time[0]);
                        }
                        if (data.errors.working_day) {
                            $('#working_day-error').html(data.errors.working_day[0]);
                        }
                        $('#savenewbutton').text('Save & New');
                        $('#savenewbutton').prop("disabled", false);
                    } else if (data.success) {
                        alert_toast(data.success, 'success');
                        var cTable = $('#laravel-datatable-category').dataTable();
                        cTable.fnDraw(false);
                        $('#savenewbutton').html('Save & New');
                        $('#in_time').val('');
                        $('#out_time').val('');
                        $('#working_day').val(null).trigger('change');
                        $('#user_id').val('');
                        $('#user-error').html('');
                        $('#in_time-error').html('');
                        $('#out_time-error').html('');
                        $('#working_day-error').html('');
                        $('#savenewbutton').prop("disabled", false);
                        $('#inlineForm').modal('show');
                    }
                }

            });
        });

        function categoryEditFn(record_id) {
            $('#edit_id').val(record_id);
            $('#categorylbl').html('Edit Schedule');
            $('#savenewbutton').css('display', 'none');
            $('#savebutton').html('Update');
            $.get('/editschedule/' + record_id, function(data) {
                $('#user_id').val(data.schedule.user_id).trigger('change');
                $('#in_time').val(data.schedule.in_time);
                $('#out_time').val(data.schedule.out_time);
                $('#working_day').val(data.schedule.working_day).trigger('change');
            });
            $('#inlineForm').modal('show');
        }

        function scheduleInfoFn(record_id) {
            $('#user_info').html('');
            $('#in_time_info').html('');
            $('#out_time_info').html('');
            $('#working_day_info').html('');
            $('#createdat_info').html('');
            $('#createdby_info').html('');
            $('#updatedat_info').html('');
            $('#updatedby_info').html('');
            $.get("/showschedule" + '/' + record_id, function(data) {
                if (data.schedule) {
                    $("#user_info").html(data.schedule.user.name);
                    $("#in_time_info").html(data.schedule.in_time);
                    $("#out_time_info").html(data.schedule.out_time);
                    $("#working_day_info").html(data.schedule.working_day);
                    //$('#createdby_info').html(data.cr.username);
                    //$('#updatedby_info').html(data.ur.username);
                    $('#createdat_info').html(data.crdate);

                    if (data.ur !== "") {
                        $('#updatedat_info').html(data.upgdate);
                    }

                }
            });
            $('#infoModal').modal('show');
        }

        function categoryDeleteFn(record_id) {
            $('#deleteing_id').val(record_id);
            $('#DeleteModal').modal('show');
        }
        $('.delete_category').click(function() {
            var delete_id = $('#deleteing_id').val();
            $.ajax({
                url: '/deletecategory/' + delete_id,
                type: 'get',
                beforeSend: function() {
                    $('.delete_category').text('Deleteing...');
                },
                success: function(data) {
                    if (data.errors) {
                        $('.delete_category').text('Delete');
                        alert_toast('an error occured', 'error');
                    } else if (data.success) {
                        $('.delete_category').text('Delete');
                        alert_toast(data.success, 'succes')
                        var cTable = $('#laravel-datatable-category').dataTable();
                        cTable.fnDraw(false);
                        $('#DeleteModal').modal('hide');
                    }
                }
            });
        });
    </script>
    <script>
        function removeNameValidation() {
            $('#name-error').html('');
        }

        function removeStatusValidation() {
            $('#status-error').html('');
        }

        function removeUserValidation() {

        }

        function closeModal() {
            $('#edit_id').val('');
            $('#name-error').html('');
            $('#status-error').html('');
            $('#name').val('');
            $('#status').val('').trigger('change');
            $('#savenewbutton').css('display', 'flex');
            $('#savebutton').html('Save & Close');
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Werabe University Project\Werabe University Project\resources\views\schedule\index.blade.php ENDPATH**/ ?>