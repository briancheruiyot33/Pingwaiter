<?php $__env->startSection('title', 'Dashboard -/ change password'); ?>
<?php $__env->startSection('content'); ?>
    <div class="app-content content">
        <form id="passwordForm">
            <?php echo e(csrf_field()); ?>

            <div>
                <label>Current Password</label>
                <input name="current_password" id="current_password" type="password" class="form-control"
                    autocomplete="current-password" onkeyup="removeCurrent()" required>
                <span style="color: red" id="current-error"></span>
            </div>
            &nbsp;
            <div>
                <label>New Password</label>
                <input name="password" type="password" id="new_password" class="form-control" onkeyup="removeNew()"
                    required>
                <span style="color: red" id="new-error"></span>
            </div>
            &nbsp;
            <div>
                <label for="update_password_password_confirmation">Confirm Password</label>
                <input id="confirm_password" name="password_confirmation" type="password"
                    class="form-control"onkeyup="removeConfirm()" required>
                <span style="color: red" id="confirm-error"></span>
            </div>
            &nbsp;
            <div class="flex items-center gap-4">
                <button class="btn btn-primary" id="change_password" type="button">Change & Save</button>

            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $('#change_password').click(function() {
            var passwordForm = $('#passwordForm');
            var formData = passwordForm.serialize();
            $.ajax({
                url: '/changePassword',
                type: 'post',
                data: formData,
                beforeSend: function() {
                    $('#change_password').html('changing...');
                },
                success: function(data) {
                    if (data.current_errors) {
                        $('#change_password').text('Change & Save');
                        $('#current-error').html(data.current_errors);
                        $('#current_password').val('');
                        $('#new_password').val('');
                        $('#confirm_password').val('');
                        alert_toast(data.current_errors, 'error');
                    } else if (data.errors) {
                        if (data.errors.current_password) {
                            $('#current-error').html(data.errors.current_password[0]);
                        }
                        if (data.errors.password) {
                            $('#new-error').html(data.errors.password[0]);
                        }
                        $('#current_password').val('');
                        $('#new_password').val('');
                        $('#confirm_password').val('');
                        $('#change_password').text('Change & Save');
                        alert_toast('An error occured!', 'error');
                    } else if (data.success) {
                        $('#current_password').val('');
                        $('#new_password').val('');
                        $('#confirm_password').val('');
                        alert_toast(data.success, 'success');
                        $('#change_password').html('Change & Save');
                    }
                }

            });
        });

        function removeCurrent() {
            $('#current-error').html('')
        }

        function removeNew() {
            $('#new-error').html('')
        }

        function removeConfirm() {
            $('#confirm-error').html('')
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Werabe University Project\Werabe University Project\resources\views\profile\change_password.blade.php ENDPATH**/ ?>