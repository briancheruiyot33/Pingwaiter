<?php $__env->startSection('content'); ?>
    <div class="app-content content">
        <section id="responsive-datatable" style="font-size: 11px;">
            <div id="success_message" style="padding: 13px 20px;"></div>
            <div class="row">
                <div class="col-12">
                    <!-- Your HTML content goes here -->
                    <div class="card">
                        <div class="card-header border-bottom">
                            <h3 class="card-title">Completed Requests</h3>


                        </div>
                        <div class="card-datatable">
                            <div style="width:98%; margin-left:1%;">
                                <div class="table-responsive">

                                    <table id="laravel-datatable-campus"
                                        class="display table-bordered table-striped table-hover dt-responsive mb-0 dataTable no-footer"
                                        style="width: 100%;" role="grid" aria-describedby="laravel-datatable-crud_info">
                                        <thead>

                                            <tr role="row">
                                                <th style="width:7%;">#</th>
                                                <th>Expired Date</th>
                                                <th>Batch No</th>
                                                <th>Item Name</th>
                                                <th>Category</th>
                                                <th>Type</th>
                                                <th>UoM</th>
                                                <th>Requested From</th>
                                                <th>Requested By</th>
                                                <th>Quantity</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody></tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        var state = false;

        function viewCode() {
            state = !state;
            if (state === true) {
                $('#clickcode').html('click to hide code');
                $('#viewcode').css({
                    "background": "white",
                    "color": "black",
                })
            } else {
                $('#clickcode').html('click to show code');
                $('#viewcode').css({
                    "background": "gray",
                    "color": "gray",
                })
            }
        }
        var errorcolor = "#ffcccc";
        $(function() {
            cardSection = $('#page-block');
        });
        /* BEGIN: Display zone table using yajra datatable */
        $(document).ready(function() {
            var ctable = $('#laravel-datatable-campus').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                searchHighlight: true,
                dom: 'lBfrtip', // Add l before B to include lengthMenu
                buttons: [{
                        extend: 'copy',
                        title: 'Stock', // Title for the 'copy' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,
                                9
                            ] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'csv',
                        title: 'Stock', // Title for the 'csv' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,
                                9
                            ] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'excel',
                        title: 'Stock', // Title for the 'excel' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,
                                9
                            ] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'pdf',
                        title: 'Stock',
                        orientation: 'landscape', // Set orientation: 'landscape' or 'portrait'
                        pageSize: 'A4', // Set page size
                        customize: function(doc) {
                            // Customize header, footer, and body style
                            doc.styles.tableHeader = {
                                fillColor: '#4CAF50',
                                color: 'white',
                                alignment: 'center'
                            };
                            doc.styles.title = {
                                fontSize: 14,
                                alignment: 'center'
                            };
                            doc.defaultStyle.fontSize = 10; // Change default font size
                            doc.content[1].table.widths = '*'.repeat(doc.content[1].table.body[0]
                                .length).split(''); // Automatically adjust column widths
                            doc.pageMargins = [10, 10, 10, 10]; // Adjust page margins
                            doc.pageSize = 'A4'; // Ensure the page size is A4
                            doc.content[1].layout = {
                                hLineWidth: function(i, node) {
                                    return (i === 0 || i === node.table.body.length) ? 2 :
                                        1;
                                },
                                vLineWidth: function(i, node) {
                                    return (i === 0 || i === node.table.widths.length) ? 2 :
                                        1;
                                },
                                hLineColor: function(i, node) {
                                    return (i === 0 || i === node.table.body.length) ?
                                        'black' : 'gray';
                                },
                                vLineColor: function(i, node) {
                                    return (i === 0 || i === node.table.widths.length) ?
                                        'black' : 'gray';
                                },
                                paddingLeft: function(i, node) {
                                    return 4;
                                },
                                paddingRight: function(i, node) {
                                    return 4;
                                },
                                paddingTop: function(i, node) {
                                    return 2;
                                },
                                paddingBottom: function(i, node) {
                                    return 2;
                                },
                            };
                        },
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,
                                9
                            ] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'print',
                        title: 'Stock',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,
                                9
                            ] // Indexes of the columns you want to include
                        }
                    }
                ],
                lengthMenu: [
                    [10, 25, 50, 500, -1],
                    [10, 25, 50, 500, "All"]
                ],
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: '/getpharmacyrequest/' + 3,
                    type: 'DELETE',
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'store.expired_date',
                        name: 'store.expired_date',
                    },
                    {
                        data: 'store.seriel_number',
                        name: 'store.seriel_number',
                    },
                    {
                        data: 'store.product.item_name',
                        name: 'store.product.item_name'
                    },
                    {
                        data: 'store.product.category.name',
                        name: 'store.product.category.name'
                    },
                    {
                        data: 'item_type',
                        name: 'item_type'
                    },
                    {
                        data: 'unit',
                        name: 'unit'
                    },
                    {
                        data: 'request_from',
                        name: 'request_from'
                    },
                    {
                        data: 'user.name',
                        name: 'user.name'
                    },
                    {
                        data: 'quantity',
                        name: 'quantity'
                    },
                    {
                        data: 'status',
                        name: 'status'
                    },
                ],
                "fnRowCallback": function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                    if (aData.status == "3") {
                        $(nRow).find('td:eq(10)').html('Completed');
                        $(nRow).find('td:eq(10)').css({
                            "color": "rgb(100, 200,150)",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #f44336"
                        });
                    }
                }
            });
            ctable.on('draw', function() {
                var body = $(ctable.table().body());
                body.unhighlight();
                body.highlight(ctable.search());
            })
        });
    </script>
    <script></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Werabe University Project\Werabe University Project\resources\views\pharmacy-request\done.blade.php ENDPATH**/ ?>