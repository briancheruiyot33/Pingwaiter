<?php $__env->startSection('content'); ?>
    <div class="app-content content">
        <section id="responsive-datatable">
            <div class="bg-light p-4 rounded">
                <h1>Update role</h1>
                <div class="lead">
                    Edit role and manage permissions.
                </div>

                <div class="container mt-4">

                    <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <strong>Whoops!</strong> There were some problems with your input.<br><br>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="<?php echo e(route('roles.update', $role->id)); ?>">
                        <?php echo method_field('patch'); ?>
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="name" class="form-label">Name</label>
                            <input value="<?php echo e($role->name); ?>" type="text" class="form-control" name="name"
                                placeholder="Name" required>
                        </div>

                        <label for="permissions" class="form-label">Assign Permissions</label>
                        
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_admin')): ?>
                            <div class="card shadow mb-2">
                                <!-- Card Header - Accordion -->
                                <a href="#collapseCardExample" class="d-block card-header py-1" data-toggle="collapse"
                                    role="button" aria-controls="collapseCardExample">
                                    <h6 class="m-0 font-weight-bold text-primary">Roles Table Permission</h6>
                                </a>
                                <!-- Card Content - Collapse -->
                                <div class="collapse" id="collapseCardExample">
                                    <div class="card-body">
                                        <table class="table table-striped">
                                            <thead>
                                                <th scope="col" width="1%"><input type="checkbox" name="all_permission1">
                                                </th>
                                                <th scope="col" width="20%">Select All</th>
                                            </thead>
                                            <!-- Collapsable Card Example -->

                                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($permission->role_table == 'roles' || $permission->role_table == 'permissions'): ?>
                                                    <tr>
                                                        <td>
                                                            <input type="checkbox" name="permission[<?php echo e($permission->name); ?>]"
                                                                value="<?php echo e($permission->name); ?>" class='permission1'
                                                                <?php echo e(in_array($permission->name, $rolePermissions) ? 'checked' : ''); ?>>
                                                        </td>
                                                        <td><?php echo e($permission->name); ?></td>
                                                    </tr>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="card shadow mb-2">
                                <!-- Card Header - Accordion -->
                                <a href="#collapseCardExample1" class="d-block card-header py-1" data-toggle="collapse"
                                    role="button" aria-controls="collapseCardExample1">
                                    <h6 class="m-0 font-weight-bold text-primary">Users Table Permission</h6>
                                </a>
                                <!-- Card Content - Collapse -->
                                <div class="collapse" id="collapseCardExample1">
                                    <div class="card-body">
                                        <table class="table table-striped">
                                            <thead>
                                                <th scope="col" width="1%"><input type="checkbox" name="all_permission2">
                                                </th>
                                                <th scope="col" width="20%">Select all</th>
                                            </thead>
                                            <!-- Collapsable Card Example -->

                                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($permission->role_table == 'users'): ?>
                                                    <tr>
                                                        <td>
                                                            <input type="checkbox" name="permission[<?php echo e($permission->name); ?>]"
                                                                value="<?php echo e($permission->name); ?>" class='permission2'
                                                                <?php echo e(in_array($permission->name, $rolePermissions) ? 'checked' : ''); ?>>
                                                        </td>
                                                        <td><?php echo e($permission->name); ?></td>
                                                    </tr>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="card shadow mb-2">
                                <!-- Card Header - Accordion -->
                                <a href="#collapseCardExample2" class="d-block card-header py-1" data-toggle="collapse"
                                    role="button" aria-controls="collapseCardExample2">
                                    <h6 class="m-0 font-weight-bold text-primary">Category Table Permissions</h6>
                                </a>
                                <!-- Card Content - Collapse -->
                                <div class="collapse" id="collapseCardExample2">
                                    <div class="card-body">
                                        <table class="table table-striped">
                                            <thead>
                                                <th scope="col" width="1%"><input type="checkbox" name="all_permission3">
                                                </th>
                                                <th scope="col" width="20%">Select all</th>
                                            </thead>
                                            <!-- Collapsable Card Example -->

                                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($permission->role_table == 'categories'): ?>
                                                    <tr>
                                                        <td>
                                                            <input type="checkbox" name="permission[<?php echo e($permission->name); ?>]"
                                                                value="<?php echo e($permission->name); ?>" class='permission3'
                                                                <?php echo e(in_array($permission->name, $rolePermissions) ? 'checked' : ''); ?>>
                                                        </td>
                                                        <td><?php echo e($permission->name); ?></td>
                                                    </tr>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="card shadow mb-2">
                                <!-- Card Header - Accordion -->
                                <a href="#collapseCardExample3" class="d-block card-header py-1" data-toggle="collapse"
                                    role="button" aria-controls="collapseCardExample3">
                                    <h6 class="m-0 font-weight-bold text-primary">Unit Table Permissions</h6>
                                </a>
                                <!-- Card Content - Collapse -->
                                <div class="collapse" id="collapseCardExample3">
                                    <div class="card-body">
                                        <table class="table table-striped">
                                            <thead>
                                                <th scope="col" width="1%"><input type="checkbox" name="all_permission4">
                                                </th>
                                                <th scope="col" width="20%">Select all</th>
                                            </thead>
                                            <!-- Collapsable Card Example -->

                                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($permission->role_table == 'units'): ?>
                                                    <tr>
                                                        <td>
                                                            <input type="checkbox" name="permission[<?php echo e($permission->name); ?>]"
                                                                value="<?php echo e($permission->name); ?>" class='permission4'
                                                                <?php echo e(in_array($permission->name, $rolePermissions) ? 'checked' : ''); ?>>
                                                        </td>
                                                        <td><?php echo e($permission->name); ?></td>
                                                    </tr>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                    </div>
                                </div>
                            </div>

                            <div class="card shadow mb-2">
                                <!-- Card Header - Accordion -->
                                <a href="#collapseCardExample4" class="d-block card-header py-1" data-toggle="collapse"
                                    role="button" aria-controls="collapseCardExample4">
                                    <h6 class="m-0 font-weight-bold text-primary">Quality Table Permissions</h6>
                                </a>
                                <!-- Card Content - Collapse -->
                                <div class="collapse" id="collapseCardExample4">
                                    <div class="card-body">
                                        <table class="table table-striped">
                                            <thead>
                                                <th scope="col" width="1%"><input type="checkbox"
                                                        name="all_permission5">
                                                </th>
                                                <th scope="col" width="20%">Select all</th>
                                            </thead>
                                            <!-- Collapsable Card Example -->

                                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($permission->role_table == 'qualities'): ?>
                                                    <tr>
                                                        <td>
                                                            <input type="checkbox" name="permission[<?php echo e($permission->name); ?>]"
                                                                value="<?php echo e($permission->name); ?>" class='permission5'
                                                                <?php echo e(in_array($permission->name, $rolePermissions) ? 'checked' : ''); ?>>
                                                        </td>
                                                        <td><?php echo e($permission->name); ?></td>
                                                    </tr>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="card shadow mb-2">
                                <!-- Card Header - Accordion -->
                                <a href="#collapseCardExample5" class="d-block card-header py-1" data-toggle="collapse"
                                    role="button" aria-controls="collapseCardExample5">
                                    <h6 class="m-0 font-weight-bold text-primary">Student Table Permissions</h6>
                                </a>
                                <!-- Card Content - Collapse -->
                                <div class="collapse" id="collapseCardExample5">
                                    <div class="card-body">
                                        <table class="table table-striped">
                                            <thead>
                                                <th scope="col" width="1%"><input type="checkbox"
                                                        name="all_permission6">
                                                </th>
                                                <th scope="col" width="20%">Select all</th>
                                            </thead>
                                            <!-- Collapsable Card Example -->

                                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($permission->role_table == 'students'): ?>
                                                    <tr>
                                                        <td>
                                                            <input type="checkbox" name="permission[<?php echo e($permission->name); ?>]"
                                                                value="<?php echo e($permission->name); ?>" class='permission6'
                                                                <?php echo e(in_array($permission->name, $rolePermissions) ? 'checked' : ''); ?>>
                                                        </td>
                                                        <td><?php echo e($permission->name); ?></td>
                                                    </tr>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="card shadow mb-2">
                                <!-- Card Header - Accordion -->
                                <a href="#collapseCardExample6" class="d-block card-header py-1" data-toggle="collapse"
                                    role="button" aria-controls="collapseCardExample6">
                                    <h6 class="m-0 font-weight-bold text-primary">Product Table Permissions</h6>
                                </a>
                                <!-- Card Content - Collapse -->
                                <div class="collapse" id="collapseCardExample6">
                                    <div class="card-body">
                                        <table class="table table-striped">
                                            <thead>
                                                <th scope="col" width="1%"><input type="checkbox"
                                                        name="all_permission7">
                                                </th>
                                                <th scope="col" width="20%">Select all</th>
                                            </thead>
                                            <!-- Collapsable Card Example -->

                                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($permission->role_table == 'products'): ?>
                                                    <tr>
                                                        <td>
                                                            <input type="checkbox" name="permission[<?php echo e($permission->name); ?>]"
                                                                value="<?php echo e($permission->name); ?>" class='permission7'
                                                                <?php echo e(in_array($permission->name, $rolePermissions) ? 'checked' : ''); ?>>
                                                        </td>
                                                        <td><?php echo e($permission->name); ?></td>
                                                    </tr>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                    </div>
                                </div>
                            </div>

                            <div class="card shadow mb-2">
                                <!-- Card Header - Accordion -->
                                <a href="#collapseCardExample7" class="d-block card-header py-1" data-toggle="collapse"
                                    role="button" aria-controls="collapseCardExample7">
                                    <h6 class="m-0 font-weight-bold text-primary">Room Table Permissions</h6>
                                </a>
                                <!-- Card Content - Collapse -->
                                <div class="collapse" id="collapseCardExample7">
                                    <div class="card-body">
                                        <table class="table table-striped">
                                            <thead>
                                                <th scope="col" width="1%"><input type="checkbox"
                                                        name="all_permission8">
                                                </th>
                                                <th scope="col" width="20%">Select all</th>
                                            </thead>
                                            <!-- Collapsable Card Example -->

                                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($permission->role_table == 'rooms'): ?>
                                                    <tr>
                                                        <td>
                                                            <input type="checkbox" name="permission[<?php echo e($permission->name); ?>]"
                                                                value="<?php echo e($permission->name); ?>" class='permission8'
                                                                <?php echo e(in_array($permission->name, $rolePermissions) ? 'checked' : ''); ?>>
                                                        </td>
                                                        <td><?php echo e($permission->name); ?></td>
                                                    </tr>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="card shadow mb-2">
                                <!-- Card Header - Accordion -->
                                <a href="#collapseCardExample8" class="d-block card-header py-1" data-toggle="collapse"
                                    role="button" aria-controls="collapseCardExample8">
                                    <h6 class="m-0 font-weight-bold text-primary">Campus store Table Permissions</h6>
                                </a>
                                <!-- Card Content - Collapse -->
                                <div class="collapse" id="collapseCardExample8">
                                    <div class="card-body">
                                        <table class="table table-striped">
                                            <thead>
                                                <th scope="col" width="1%"><input type="checkbox"
                                                        name="all_permission9">
                                                </th>
                                                <th scope="col" width="20%">Select all</th>
                                            </thead>
                                            <!-- Collapsable Card Example -->

                                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($permission->role_table == 'campus'): ?>
                                                    <tr>
                                                        <td>
                                                            <input type="checkbox" name="permission[<?php echo e($permission->name); ?>]"
                                                                value="<?php echo e($permission->name); ?>" class='permission9'
                                                                <?php echo e(in_array($permission->name, $rolePermissions) ? 'checked' : ''); ?>>
                                                        </td>
                                                        <td><?php echo e($permission->name); ?></td>
                                                    </tr>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="card shadow mb-2">
                                <!-- Card Header - Accordion -->
                                <a href="#collapseCardExample9" class="d-block card-header py-1" data-toggle="collapse"
                                    role="button" aria-controls="collapseCardExample9">
                                    <h6 class="m-0 font-weight-bold text-primary">Clinic store Table Permissions</h6>
                                </a>
                                <!-- Card Content - Collapse -->
                                <div class="collapse" id="collapseCardExample9">
                                    <div class="card-body">
                                        <table class="table table-striped">
                                            <thead>
                                                <th scope="col" width="1%"><input type="checkbox"
                                                        name="all_permission10">
                                                </th>
                                                <th scope="col" width="20%">Select all</th>
                                            </thead>
                                            <!-- Collapsable Card Example -->

                                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($permission->role_table == 'clinic'): ?>
                                                    <tr>
                                                        <td>
                                                            <input type="checkbox" name="permission[<?php echo e($permission->name); ?>]"
                                                                value="<?php echo e($permission->name); ?>" class='permission10'
                                                                <?php echo e(in_array($permission->name, $rolePermissions) ? 'checked' : ''); ?>>
                                                        </td>
                                                        <td><?php echo e($permission->name); ?></td>
                                                    </tr>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="card shadow mb-2">
                                <!-- Card Header - Accordion -->
                                <a href="#collapseCardExample10" class="d-block card-header py-1" data-toggle="collapse"
                                    role="button" aria-controls="collapseCardExample10">
                                    <h6 class="m-0 font-weight-bold text-primary">Stock Table Permissions</h6>
                                </a>
                                <!-- Card Content - Collapse -->
                                <div class="collapse" id="collapseCardExample10">
                                    <div class="card-body">
                                        <table class="table table-striped">
                                            <thead>
                                                <th scope="col" width="1%"><input type="checkbox"
                                                        name="all_permission11">
                                                </th>
                                                <th scope="col" width="20%">Select all</th>
                                            </thead>
                                            <!-- Collapsable Card Example -->

                                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($permission->role_table == 'stock'): ?>
                                                    <tr>
                                                        <td>
                                                            <input type="checkbox" name="permission[<?php echo e($permission->name); ?>]"
                                                                value="<?php echo e($permission->name); ?>" class='permission11'
                                                                <?php echo e(in_array($permission->name, $rolePermissions) ? 'checked' : ''); ?>>
                                                        </td>
                                                        <td><?php echo e($permission->name); ?></td>
                                                    </tr>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="card shadow mb-2">
                                <!-- Card Header - Accordion -->
                                <a href="#collapseCardExample11" class="d-block card-header py-1" data-toggle="collapse"
                                    role="button" aria-controls="collapseCardExample11">
                                    <h6 class="m-0 font-weight-bold text-primary">Patient Table Permissions</h6>
                                </a>
                                <!-- Card Content - Collapse -->
                                <div class="collapse" id="collapseCardExample11">
                                    <div class="card-body">
                                        <table class="table table-striped">
                                            <thead>
                                                <th scope="col" width="1%"><input type="checkbox"
                                                        name="all_permission12">
                                                </th>
                                                <th scope="col" width="20%">Select all</th>
                                            </thead>
                                            <!-- Collapsable Card Example -->

                                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($permission->role_table == 'patient'): ?>
                                                    <tr>
                                                        <td>
                                                            <input type="checkbox" name="permission[<?php echo e($permission->name); ?>]"
                                                                value="<?php echo e($permission->name); ?>" class='permission12'
                                                                <?php echo e(in_array($permission->name, $rolePermissions) ? 'checked' : ''); ?>>
                                                        </td>
                                                        <td><?php echo e($permission->name); ?></td>
                                                    </tr>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="card shadow mb-2">
                                <!-- Card Header - Accordion -->
                                <a href="#collapseCardExample12" class="d-block card-header py-1" data-toggle="collapse"
                                    role="button" aria-controls="collapseCardExample12">
                                    <h6 class="m-0 font-weight-bold text-primary">Emergency Table Permissions</h6>
                                </a>
                                <!-- Card Content - Collapse -->
                                <div class="collapse" id="collapseCardExample12">
                                    <div class="card-body">
                                        <table class="table table-striped">
                                            <thead>
                                                <th scope="col" width="1%"><input type="checkbox"
                                                        name="all_permission13">
                                                </th>
                                                <th scope="col" width="20%">Select all</th>
                                            </thead>
                                            <!-- Collapsable Card Example -->

                                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($permission->role_table == 'emergency'): ?>
                                                    <tr>
                                                        <td>
                                                            <input type="checkbox" name="permission[<?php echo e($permission->name); ?>]"
                                                                value="<?php echo e($permission->name); ?>" class='permission13'
                                                                <?php echo e(in_array($permission->name, $rolePermissions) ? 'checked' : ''); ?>>
                                                        </td>
                                                        <td><?php echo e($permission->name); ?></td>
                                                    </tr>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="card shadow mb-2">
                                <!-- Card Header - Accordion -->
                                <a href="#collapseCardExample13" class="d-block card-header py-1" data-toggle="collapse"
                                    role="button" aria-controls="collapseCardExample13">
                                    <h6 class="m-0 font-weight-bold text-primary">Support Student Table Permissions</h6>
                                </a>
                                <!-- Card Content - Collapse -->
                                <div class="collapse" id="collapseCardExample13">
                                    <div class="card-body">
                                        <table class="table table-striped">
                                            <thead>
                                                <th scope="col" width="1%"><input type="checkbox"
                                                        name="all_permission14">
                                                </th>
                                                <th scope="col" width="20%">Select all</th>
                                            </thead>
                                            <!-- Collapsable Card Example -->

                                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($permission->role_table == 'support'): ?>
                                                    <tr>
                                                        <td>
                                                            <input type="checkbox" name="permission[<?php echo e($permission->name); ?>]"
                                                                value="<?php echo e($permission->name); ?>" class='permission14'
                                                                <?php echo e(in_array($permission->name, $rolePermissions) ? 'checked' : ''); ?>>
                                                        </td>
                                                        <td><?php echo e($permission->name); ?></td>
                                                    </tr>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="card shadow mb-2">
                                <!-- Card Header - Accordion -->
                                <a href="#collapseCardExample14" class="d-block card-header py-1" data-toggle="collapse"
                                    role="button" aria-controls="collapseCardExample14">
                                    <h6 class="m-0 font-weight-bold text-primary">Staff Table Permissions</h6>
                                </a>
                                <!-- Card Content - Collapse -->
                                <div class="collapse" id="collapseCardExample14">
                                    <div class="card-body">
                                        <table class="table table-striped">
                                            <thead>
                                                <th scope="col" width="1%"><input type="checkbox"
                                                        name="all_permission15">
                                                </th>
                                                <th scope="col" width="20%">Select all</th>
                                            </thead>
                                            <!-- Collapsable Card Example -->

                                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($permission->role_table == 'staff'): ?>
                                                    <tr>
                                                        <td>
                                                            <input type="checkbox" name="permission[<?php echo e($permission->name); ?>]"
                                                                value="<?php echo e($permission->name); ?>" class='permission15'
                                                                <?php echo e(in_array($permission->name, $rolePermissions) ? 'checked' : ''); ?>>
                                                        </td>
                                                        <td><?php echo e($permission->name); ?></td>
                                                    </tr>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="card shadow mb-2">
                                <!-- Card Header - Accordion -->
                                <a href="#collapseCardExample15" class="d-block card-header py-1" data-toggle="collapse"
                                    role="button" aria-controls="collapseCardExample15">
                                    <h6 class="m-0 font-weight-bold text-primary">Patient Appointment Table Permissions</h6>
                                </a>
                                <!-- Card Content - Collapse -->
                                <div class="collapse" id="collapseCardExample15">
                                    <div class="card-body">
                                        <table class="table table-striped">
                                            <thead>
                                                <th scope="col" width="1%"><input type="checkbox"
                                                        name="all_permission16">
                                                </th>
                                                <th scope="col" width="20%">Select all</th>
                                            </thead>
                                            <!-- Collapsable Card Example -->

                                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($permission->role_table == 'appointment'): ?>
                                                    <tr>
                                                        <td>
                                                            <input type="checkbox" name="permission[<?php echo e($permission->name); ?>]"
                                                                value="<?php echo e($permission->name); ?>" class='permission16'
                                                                <?php echo e(in_array($permission->name, $rolePermissions) ? 'checked' : ''); ?>>
                                                        </td>
                                                        <td><?php echo e($permission->name); ?></td>
                                                    </tr>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                    </div>
                                </div>
                            </div>

                            <div class="card shadow mb-2">
                                <!-- Card Header - Accordion -->
                                <a href="#collapseCardExample16" class="d-block card-header py-1" data-toggle="collapse"
                                    role="button" aria-controls="collapseCardExample16">
                                    <h6 class="m-0 font-weight-bold text-primary">Schedule Table Permissions</h6>
                                </a>
                                <!-- Card Content - Collapse -->
                                <div class="collapse" id="collapseCardExample16">
                                    <div class="card-body">
                                        <table class="table table-striped">
                                            <thead>
                                                <th scope="col" width="1%"><input type="checkbox"
                                                        name="all_permission17">
                                                </th>
                                                <th scope="col" width="20%">Select all</th>
                                            </thead>
                                            <!-- Collapsable Card Example -->

                                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($permission->role_table == 'schedule'): ?>
                                                    <tr>
                                                        <td>
                                                            <input type="checkbox" name="permission[<?php echo e($permission->name); ?>]"
                                                                value="<?php echo e($permission->name); ?>" class='permission17'
                                                                <?php echo e(in_array($permission->name, $rolePermissions) ? 'checked' : ''); ?>>
                                                        </td>
                                                        <td><?php echo e($permission->name); ?></td>
                                                    </tr>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="card shadow mb-2">
                                <!-- Card Header - Accordion -->
                                <a href="#collapseCardExample17" class="d-block card-header py-1" data-toggle="collapse"
                                    role="button" aria-controls="collapseCardExample17">
                                    <h6 class="m-0 font-weight-bold text-primary">System Setting Table Permissions</h6>
                                </a>
                                <!-- Card Content - Collapse -->
                                <div class="collapse" id="collapseCardExample17">
                                    <div class="card-body">
                                        <table class="table table-striped">
                                            <thead>
                                                <th scope="col" width="1%"><input type="checkbox"
                                                        name="all_permission18">
                                                </th>
                                                <th scope="col" width="20%">Select all</th>
                                            </thead>
                                            <!-- Collapsable Card Example -->

                                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($permission->role_table == 'syatem_setting'): ?>
                                                    <tr>
                                                        <td>
                                                            <input type="checkbox" name="permission[<?php echo e($permission->name); ?>]"
                                                                value="<?php echo e($permission->name); ?>" class='permission16'
                                                                <?php echo e(in_array($permission->name, $rolePermissions) ? 'checked' : ''); ?>>
                                                        </td>
                                                        <td><?php echo e($permission->name); ?></td>
                                                    </tr>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dorm_admin')): ?>
                            <div class="card shadow mb-2">
                                <!-- Card Header - Accordion -->
                                <a href="#collapseCardExample" class="d-block card-header py-1" data-toggle="collapse"
                                    role="button" aria-controls="collapseCardExample">
                                    <h6 class="m-0 font-weight-bold text-primary">Roles Table Permission</h6>
                                </a>
                                <!-- Card Content - Collapse -->
                                <div class="collapse" id="collapseCardExample">
                                    <div class="card-body">
                                        <table class="table table-striped">
                                            <thead>
                                                <th scope="col" width="1%"><input type="checkbox"
                                                        name="all_permission1">
                                                </th>
                                                <th scope="col" width="20%">Select All</th>
                                            </thead>
                                            <!-- Collapsable Card Example -->

                                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($permission->role_table == 'roles' || $permission->role_table == 'permissions'): ?>
                                                    <tr>
                                                        <td>
                                                            <input type="checkbox" name="permission[<?php echo e($permission->name); ?>]"
                                                                value="<?php echo e($permission->name); ?>" class='permission1'
                                                                <?php echo e(in_array($permission->name, $rolePermissions) ? 'checked' : ''); ?>>
                                                        </td>
                                                        <td><?php echo e($permission->name); ?></td>
                                                    </tr>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="card shadow mb-2">
                                <!-- Card Header - Accordion -->
                                <a href="#collapseCardExample1" class="d-block card-header py-1" data-toggle="collapse"
                                    role="button" aria-controls="collapseCardExample1">
                                    <h6 class="m-0 font-weight-bold text-primary">Users Table Permission</h6>
                                </a>
                                <!-- Card Content - Collapse -->
                                <div class="collapse" id="collapseCardExample1">
                                    <div class="card-body">
                                        <table class="table table-striped">
                                            <thead>
                                                <th scope="col" width="1%"><input type="checkbox"
                                                        name="all_permission2">
                                                </th>
                                                <th scope="col" width="20%">Select all</th>
                                            </thead>
                                            <!-- Collapsable Card Example -->

                                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($permission->role_table == 'users'): ?>
                                                    <tr>
                                                        <td>
                                                            <input type="checkbox" name="permission[<?php echo e($permission->name); ?>]"
                                                                value="<?php echo e($permission->name); ?>" class='permission2'
                                                                <?php echo e(in_array($permission->name, $rolePermissions) ? 'checked' : ''); ?>>
                                                        </td>
                                                        <td><?php echo e($permission->name); ?></td>
                                                    </tr>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="card shadow mb-2">
                                <!-- Card Header - Accordion -->
                                <a href="#collapseCardExample17" class="d-block card-header py-1" data-toggle="collapse"
                                    role="button" aria-controls="collapseCardExample17">
                                    <h6 class="m-0 font-weight-bold text-primary">System Setting Table Permissions</h6>
                                </a>
                                <!-- Card Content - Collapse -->
                                <div class="collapse" id="collapseCardExample17">
                                    <div class="card-body">
                                        <table class="table table-striped">
                                            <thead>
                                                <th scope="col" width="1%"><input type="checkbox"
                                                        name="all_permission18">
                                                </th>
                                                <th scope="col" width="20%">Select all</th>
                                            </thead>
                                            <!-- Collapsable Card Example -->

                                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($permission->role_table == 'syatem_setting'): ?>
                                                    <tr>
                                                        <td>
                                                            <input type="checkbox" name="permission[<?php echo e($permission->name); ?>]"
                                                                value="<?php echo e($permission->name); ?>" class='permission16'
                                                                <?php echo e(in_array($permission->name, $rolePermissions) ? 'checked' : ''); ?>>
                                                        </td>
                                                        <td><?php echo e($permission->name); ?></td>
                                                    </tr>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                    </div>
                                </div>
                            </div>

                            <div class="card shadow mb-2">
                                <!-- Card Header - Accordion -->
                                <a href="#collapseCardExampleblock" class="d-block card-header py-1" data-toggle="collapse"
                                    role="button" aria-controls="collapseCardExampleblock">
                                    <h6 class="m-0 font-weight-bold text-primary">Blocks Table Permissions</h6>
                                </a>
                                <!-- Card Content - Collapse -->
                                <div class="collapse" id="collapseCardExampleblock">
                                    <div class="card-body">
                                        <table class="table table-striped">
                                            <thead>
                                                <th scope="col" width="1%"><input type="checkbox"
                                                        name="all_permissionblock">
                                                </th>
                                                <th scope="col" width="20%">Select all</th>
                                            </thead>
                                            <!-- Collapsable Card Example -->

                                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($permission->role_table == 'blocks'): ?>
                                                    <tr>
                                                        <td>
                                                            <input type="checkbox" name="permission[<?php echo e($permission->name); ?>]"
                                                                value="<?php echo e($permission->name); ?>" class='permissionblock'
                                                                <?php echo e(in_array($permission->name, $rolePermissions) ? 'checked' : ''); ?>>
                                                        </td>
                                                        <td><?php echo e($permission->name); ?></td>
                                                    </tr>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="card shadow mb-2">
                                <!-- Card Header - Accordion -->
                                <a href="#collapseCardExampledorm" class="d-block card-header py-1" data-toggle="collapse"
                                    role="button" aria-controls="collapseCardExampledorm">
                                    <h6 class="m-0 font-weight-bold text-primary">Dorms Table Permissions</h6>
                                </a>
                                <!-- Card Content - Collapse -->
                                <div class="collapse" id="collapseCardExampledorm">
                                    <div class="card-body">
                                        <table class="table table-striped">
                                            <thead>
                                                <th scope="col" width="1%"><input type="checkbox"
                                                        name="all_permissiondorm">
                                                </th>
                                                <th scope="col" width="20%">Select all</th>
                                            </thead>
                                            <!-- Collapsable Card Example -->

                                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($permission->role_table == 'dorms'): ?>
                                                    <tr>
                                                        <td>
                                                            <input type="checkbox" name="permission[<?php echo e($permission->name); ?>]"
                                                                value="<?php echo e($permission->name); ?>" class='permissiondorm'
                                                                <?php echo e(in_array($permission->name, $rolePermissions) ? 'checked' : ''); ?>>
                                                        </td>
                                                        <td><?php echo e($permission->name); ?></td>
                                                    </tr>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="card shadow mb-2">
                                <!-- Card Header - Accordion -->
                                <a href="#collapseCardExampledormstudent" class="d-block card-header py-1"
                                    data-toggle="collapse" role="button" aria-controls="collapseCardExampledormstudent">
                                    <h6 class="m-0 font-weight-bold text-primary">Students Table Permissions</h6>
                                </a>
                                <!-- Card Content - Collapse -->
                                <div class="collapse" id="collapseCardExampledormstudent">
                                    <div class="card-body">
                                        <table class="table table-striped">
                                            <thead>
                                                <th scope="col" width="1%"><input type="checkbox"
                                                        name="all_permissiondormstudent">
                                                </th>
                                                <th scope="col" width="20%">Select all</th>
                                            </thead>
                                            <!-- Collapsable Card Example -->

                                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($permission->role_table == 'dormstudents'): ?>
                                                    <tr>
                                                        <td>
                                                            <input type="checkbox" name="permission[<?php echo e($permission->name); ?>]"
                                                                value="<?php echo e($permission->name); ?>" class='permissiondormstudent'
                                                                <?php echo e(in_array($permission->name, $rolePermissions) ? 'checked' : ''); ?>>
                                                        </td>
                                                        <td><?php echo e($permission->name); ?></td>
                                                    </tr>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="card shadow mb-2">
                                <!-- Card Header - Accordion -->
                                <a href="#collapseCardExampleservice" class="d-block card-header py-1" data-toggle="collapse"
                                    role="button" aria-controls="collapseCardExampleservice">
                                    <h6 class="m-0 font-weight-bold text-primary">Services Table Permissions</h6>
                                </a>
                                <!-- Card Content - Collapse -->
                                <div class="collapse" id="collapseCardExampleservice">
                                    <div class="card-body">
                                        <table class="table table-striped">
                                            <thead>
                                                <th scope="col" width="1%"><input type="checkbox"
                                                        name="all_permissionservice">
                                                </th>
                                                <th scope="col" width="20%">Select all</th>
                                            </thead>
                                            <!-- Collapsable Card Example -->

                                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($permission->role_table == 'services'): ?>
                                                    <tr>
                                                        <td>
                                                            <input type="checkbox" name="permission[<?php echo e($permission->name); ?>]"
                                                                value="<?php echo e($permission->name); ?>" class='permissionservice'
                                                                <?php echo e(in_array($permission->name, $rolePermissions) ? 'checked' : ''); ?>>
                                                        </td>
                                                        <td><?php echo e($permission->name); ?></td>
                                                    </tr>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                        <button class="btn btn-primary">Save changes</button>
                        <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-default">Back</a>
                    </form>
                </div>

            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
        $(document).ready(function() {
            $('[name="all_permission1"]').on('click', function() {

                if ($(this).is(':checked')) {
                    $.each($('.permission1'), function() {
                        $(this).prop('checked', true);
                    });
                } else {
                    $.each($('.permission1'), function() {
                        $(this).prop('checked', false);
                    });
                }

            });
            $('[name="all_permission2"]').on('click', function() {

                if ($(this).is(':checked')) {
                    $.each($('.permission2'), function() {
                        $(this).prop('checked', true);
                    });
                } else {
                    $.each($('.permission2'), function() {
                        $(this).prop('checked', false);
                    });
                }

            });
            $('[name="all_permission3"]').on('click', function() {

                if ($(this).is(':checked')) {
                    $.each($('.permission3'), function() {
                        $(this).prop('checked', true);
                    });
                } else {
                    $.each($('.permission3'), function() {
                        $(this).prop('checked', false);
                    });
                }

            });
            $('[name="all_permission4"]').on('click', function() {

                if ($(this).is(':checked')) {
                    $.each($('.permission4'), function() {
                        $(this).prop('checked', true);
                    });
                } else {
                    $.each($('.permission4'), function() {
                        $(this).prop('checked', false);
                    });
                }

            });
            $('[name="all_permission5"]').on('click', function() {

                if ($(this).is(':checked')) {
                    $.each($('.permission5'), function() {
                        $(this).prop('checked', true);
                    });
                } else {
                    $.each($('.permission5'), function() {
                        $(this).prop('checked', false);
                    });
                }

            });
            $('[name="all_permission6"]').on('click', function() {

                if ($(this).is(':checked')) {
                    $.each($('.permission6'), function() {
                        $(this).prop('checked', true);
                    });
                } else {
                    $.each($('.permission6'), function() {
                        $(this).prop('checked', false);
                    });
                }

            });
            $('[name="all_permission7"]').on('click', function() {

                if ($(this).is(':checked')) {
                    $.each($('.permission7'), function() {
                        $(this).prop('checked', true);
                    });
                } else {
                    $.each($('.permission7'), function() {
                        $(this).prop('checked', false);
                    });
                }

            });
            $('[name="all_permission8"]').on('click', function() {

                if ($(this).is(':checked')) {
                    $.each($('.permission8'), function() {
                        $(this).prop('checked', true);
                    });
                } else {
                    $.each($('.permission8'), function() {
                        $(this).prop('checked', false);
                    });
                }

            });
            $('[name="all_permission9"]').on('click', function() {

                if ($(this).is(':checked')) {
                    $.each($('.permission9'), function() {
                        $(this).prop('checked', true);
                    });
                } else {
                    $.each($('.permission9'), function() {
                        $(this).prop('checked', false);
                    });
                }

            });
            $('[name="all_permission10"]').on('click', function() {

                if ($(this).is(':checked')) {
                    $.each($('.permission10'), function() {
                        $(this).prop('checked', true);
                    });
                } else {
                    $.each($('.permission10'), function() {
                        $(this).prop('checked', false);
                    });
                }

            });
            $('[name="all_permission11"]').on('click', function() {

                if ($(this).is(':checked')) {
                    $.each($('.permission11'), function() {
                        $(this).prop('checked', true);
                    });
                } else {
                    $.each($('.permission11'), function() {
                        $(this).prop('checked', false);
                    });
                }

            });
            $('[name="all_permission12"]').on('click', function() {

                if ($(this).is(':checked')) {
                    $.each($('.permission12'), function() {
                        $(this).prop('checked', true);
                    });
                } else {
                    $.each($('.permission12'), function() {
                        $(this).prop('checked', false);
                    });
                }

            });
            $('[name="all_permission13"]').on('click', function() {

                if ($(this).is(':checked')) {
                    $.each($('.permission13'), function() {
                        $(this).prop('checked', true);
                    });
                } else {
                    $.each($('.permission13'), function() {
                        $(this).prop('checked', false);
                    });
                }

            });
            $('[name="all_permission14"]').on('click', function() {

                if ($(this).is(':checked')) {
                    $.each($('.permission14'), function() {
                        $(this).prop('checked', true);
                    });
                } else {
                    $.each($('.permission14'), function() {
                        $(this).prop('checked', false);
                    });
                }

            });
            $('[name="all_permission15"]').on('click', function() {

                if ($(this).is(':checked')) {
                    $.each($('.permission15'), function() {
                        $(this).prop('checked', true);
                    });
                } else {
                    $.each($('.permission15'), function() {
                        $(this).prop('checked', false);
                    });
                }

            });
            $('[name="all_permission16"]').on('click', function() {

                if ($(this).is(':checked')) {
                    $.each($('.permission16'), function() {
                        $(this).prop('checked', true);
                    });
                } else {
                    $.each($('.permission16'), function() {
                        $(this).prop('checked', false);
                    });
                }

            });
            $('[name="all_permission17"]').on('click', function() {

                if ($(this).is(':checked')) {
                    $.each($('.permission17'), function() {
                        $(this).prop('checked', true);
                    });
                } else {
                    $.each($('.permission17'), function() {
                        $(this).prop('checked', false);
                    });
                }

            });
            $('[name="all_permission18"]').on('click', function() {

                if ($(this).is(':checked')) {
                    $.each($('.permission18'), function() {
                        $(this).prop('checked', true);
                    });
                } else {
                    $.each($('.permission18'), function() {
                        $(this).prop('checked', false);
                    });
                }

            });
            $('[name="all_permissionblock"]').on('click', function() {

                if ($(this).is(':checked')) {
                    $.each($('.permissionblock'), function() {
                        $(this).prop('checked', true);
                    });
                } else {
                    $.each($('.permissionblock'), function() {
                        $(this).prop('checked', false);
                    });
                }

            });
            $('[name="all_permissiondorm"]').on('click', function() {

                if ($(this).is(':checked')) {
                    $.each($('.permissiondorm'), function() {
                        $(this).prop('checked', true);
                    });
                } else {
                    $.each($('.permissiondorm'), function() {
                        $(this).prop('checked', false);
                    });
                }

            });
            $('[name="all_permissiondormstudent"]').on('click', function() {

                if ($(this).is(':checked')) {
                    $.each($('.permissiondormstudent'), function() {
                        $(this).prop('checked', true);
                    });
                } else {
                    $.each($('.permissiondormstudent'), function() {
                        $(this).prop('checked', false);
                    });
                }

            });
            $('[name="all_permissionservice"]').on('click', function() {

                if ($(this).is(':checked')) {
                    $.each($('.permissionservice'), function() {
                        $(this).prop('checked', true);
                    });
                } else {
                    $.each($('.permissionservice'), function() {
                        $(this).prop('checked', false);
                    });
                }

            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Werabe University Project\Werabe University Project\resources\views/roles/edit.blade.php ENDPATH**/ ?>