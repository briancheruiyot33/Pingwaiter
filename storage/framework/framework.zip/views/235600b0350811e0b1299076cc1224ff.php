<?php $__env->startSection('title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="app-content content">
        <section id="responsive-datatable">
            <div class="card w-50" style="margin: auto;min-height: 75vh; max-height: 75vh; ">
                <div class="card-header w-100 text-center bg-primary text-white justify-content-center">Ask any question
                </div>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dorm_admin')): ?>
                    <div class="card-body" style="margin: 10px; overflow-y: scroll">
                        <?php if($ch == '1'): ?>
                            <?php $__currentLoopData = $chat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($chat->state == 0): ?>
                                    <div class="row" style="justify-content: space-between;">
                                        <p class="bg-success"
                                            style="text-align: left; color: white; padding: 10px 20px; border-radius: 10px; max-width: 70%">
                                            <?php echo e($chat->message); ?></p>
                                        <p></p>
                                    </div>
                                <?php else: ?>
                                    <div class="row" style="justify-content: space-between;">
                                        <p></p>
                                        <p
                                            style="text-align: right; max-width: 70%; background: rgb(240,240,240); padding: 10px 20px; border-radius: 10px;">
                                            <?php echo e($chat->message); ?></p>

                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="row" href="<?php echo e(url('userchat/35')); ?>"
                                    style="justify-content: space-between; padding: 5px 10px; border-radius: 5px; background: rgb(240,240,240); margin-bottom: 10px;">
                                    <div class="row" style="padding: 10px; margin-top: 5px;">
                                        <img src="<?php echo url('uploads/dorm.jpg'); ?>" class="round" alt="photo" width="40"
                                            height="40">
                                        <div style="display: block; margin-left: 10px;">
                                            <h6 style="font-weight: 800"><?php echo e($user->send->name); ?></h6>

                                            <?php $__currentLoopData = $user->send->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <span class="badge bg-primary"><?php echo e($role->name); ?></span>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                    <p style="margin-top: 23px;">
                                        <span>
                                        </span>
                                    </p>

                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <div class="card-body" style="margin: 10px; overflow-y: scroll">
                        <?php $__currentLoopData = $chat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($chat->state == 0): ?>
                                <div class="row" style="justify-content: space-between;">
                                    <p class="bg-success"
                                        style="text-align: left; color: white; padding: 10px 20px; border-radius: 10px; max-width: 70%">
                                        <?php echo e($chat->message); ?></p>
                                    <p></p>
                                </div>
                            <?php else: ?>
                                <div class="row" style="justify-content: space-between;">
                                    <p></p>
                                    <p
                                        style="text-align: right; max-width: 70%; background: rgb(240,240,240); padding: 10px 20px; border-radius: 10px;">
                                        <?php echo e($chat->message); ?></p>

                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="card-footer bg-secondary">
                        <div class="row" style="display: flex;">
                            <input type="text" placeholder="Write message here" name="message" id="message"
                                class="form-control col-md-9">
                            <button class="btn btn-success col-md-3" id="send">Send</button>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </section>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        var errorcolor = "#ffcccc";
        $(function() {
            cardSection = $('#page-block');
        });
        $(".collapse").collapse('show');
        $('#send').click(function() {
            $.get('/sendmessage/' + $('#message').val(), function(data) {
                if (data.success) {
                    $('#message').val('')
                    window.location = '/ask_question';
                } else {
                    $('#message').val('')
                    window.location = '/ask_question'
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Werabe University Project\Werabe University Project\resources\views/dormitory/ask_question1.blade.php ENDPATH**/ ?>