<?php $__env->startSection('title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="app-content content">
        <section id="responsive-datatable">
            <div class="row">
                <div class="col-12">
                    <!-- Your HTML content goes here -->
                    <div class="card">
                        <div class="card-header border-bottom">
                            <h3 class="card-title">Items Detail</h3>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('support_admin')): ?>
                                <div class="col-md-4 float-end" id="daterangein">
                                    <div class="float-end"
                                        style="padding: 5px 10px; text-align: center; background: #fff; width: 100%; curson: pointer; border: 1px solid #ccc; margin: 10px -20px;">
                                        <i class="fa fa-calendar"></i>&nbsp;
                                        <span></span><i class="fa fa-caret-down"></i>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('support_staff')): ?>
                                <button type="button" class="btn btn-gradient-info btn-sm withdraw"
                                    onclick="withdrawFn()">Withdraw</button>
                            <?php endif; ?>

                        </div>
                        <div class="card-datatable">
                            <div style="width:98%; margin-left:1%;">
                                <div class="table-responsive">

                                    <table id="laravel-datatable-category"
                                        class="display table-bordered table-striped table-hover dt-responsive mb-0 dataTable no-footer"
                                        style="width: 100%;" role="grid" aria-describedby="laravel-datatable-user">

                                        <thead>
                                            <tr role="row">
                                                <th scope="col" width="1%">#</th>
                                                <th nowrap>Item Name</th>
                                                <th nowrap>Received</th>
                                                <th nowrap>Issued</th>
                                                <th nowrap>Balance</th>
                                                <th nowrap>View Received</th>
                                                <th nowrap>View Withdraw</th>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('support_admin')): ?>
                                                    <th nowrap>Receive Item</th>
                                                <?php endif; ?>
                                            </tr>
                                        </thead>
                                        <tbody></tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- BEGIN: Item  detail modal  -->
        <div class="modal fade text-left" id="detailForm" data-keyboard="false" data-backdrop="static" tabindex="-1"
            role="dialog" aria-labelledby="categorylbl" aria-hidden="true" style="overflow-y: scroll;">
            <div class="modal-dialog modal-xl" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="itemlbl">Items</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                            onclick="closeModal()">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <input type="hidden" id="detail_id">
                    <div class="card-datatable">
                        <div style="width:98%; margin-left:1%;">
                            <div class="table-responsive">

                                <table id="laravel-datatable-items"
                                    class="display table-bordered table-striped table-hover dt-responsive mb-0 dataTable no-footer"
                                    style="width: 100%;" role="grid" aria-describedby="laravel-datatable-user">

                                    <thead>
                                        <tr role="row">
                                            <th scope="col" width="1%">#</th>
                                            <th nowrap>Received Date</th>
                                            <th nowrap>Received By</th>
                                            <th nowrap>Item Name</th>
                                            <th nowrap>quantity</th>
                                        </tr>
                                    </thead>
                                    <tbody></tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- BEGIN: Item  detail modal  -->
    <div class="modal fade text-left" id="withdrawDetailModal" data-keyboard="false" data-backdrop="static" tabindex="-1"
        role="dialog" aria-labelledby="withdrawdetail" aria-hidden="true" style="overflow-y: scroll;">
        <div class="modal-dialog modal-xl" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="withdraw detail">Withdraw detail</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="closeModal()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="card-datatable">
                    <div style="width:98%; margin-left:1%;">
                        <div class="table-responsive">

                            <table id="laravel-datatable-withdraw"
                                class="display table-bordered table-striped table-hover dt-responsive mb-0 dataTable no-footer"
                                style="width: 100%;" role="grid" aria-describedby="laravel-datatable-withdraw">

                                <thead>
                                    <tr role="row">
                                        <th scope="col" width="1%">#</th>
                                        <th nowrap>Withdraw Date</th>
                                        <th nowrap>Withdraw By</th>
                                        <th nowrap>Received By</th>
                                        <th nowrap>Student Id</th>
                                        <th nowrap>Item Name</th>
                                        <th nowrap>quantity</th>
                                    </tr>
                                </thead>
                                <tbody></tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- BEGIN: Item  detail modal  -->
    <div class="modal fade text-left" id="receiveForm" data-keyboard="false" data-backdrop="static" tabindex="-1"
        role="dialog" aria-labelledby="categorylbl" aria-hidden="true" style="overflow-y: scroll;">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="itemlbl">Receive Items</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                        onclick="closeModal()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <label strong>Quantity</label>
                    <input type="number" class="form-control" name="quantity" value="0" id="quantity">
                    <input type="hidden" id="receive_id" name="receive_id">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-info receive_item">Submit</button>
                    <button id="closebutton" type="button" class="btn btn-danger"
                        onclick="closeModalWithClearValidation()" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    
    <div class="modal fade text-left" id="withdrawModal" data-keyboard="false" data-backdrop="static" tabindex="-1"
        role="dialog" aria-labelledby="lbl" aria-hidden="true" style="overflow-y: scroll;">
        <div class="modal-dialog modal-xl" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="withdrawlbl">Withdraw</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                        onclick="closeModal()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="form-withdraw">
                        <?php echo e(csrf_field()); ?>

                        <div class="row">
                            <div class="col-md-3">
                                <label strong style="font-size: 16px;">Select Student Id</label><label
                                    style="color: red; font-size:16px;">*</label>
                                <div class="form-group">
                                    <select class="custom-select browser-default select2" name="student_id"
                                        id="student_id" onchange="removeStudentValidation()">
                                        <option value=""></option>

                                        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($student->id); ?>"><?php echo e($student->student_id); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <span class="text-danger">
                                        <strong id="student-error"></strong>
                                    </span>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <label strong style="font-size: 16px;">Authenticate student</label><label
                                    style="color: red; font-size:16px;">*</label>
                                <div class="form-group">
                                    <input type="password" name="password" id="password" class="form-control"
                                        placeholder="write identification password" onkeyup="removePasswordValidation()">
                                    <span class="text-danger">
                                        <strong id="password-error"></strong>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-xl-12 col-lg-12">
                                <div class="table-responsive">
                                    <table id="dynamicTable" class="mb-0 rtable  dt-responsive" style="width: 100%">
                                        <thead>
                                            <tr>
                                                <th style="width: 3%; text-align: center;">#</th>

                                                <th style="width: 20%; text-align: center;">
                                                    Item name<b style="color: red;"> *</b>
                                                </th>
                                                <th style="width: 80%; text-align: center;">
                                                    Quantity
                                                    <b style="color: red;"> *</b>
                                                </th>
                                                <th style="width: 3%"></th>
                                            </tr>
                                        </thead>
                                        <tbody></tbody>
                                    </table>
                                    <span class="text-danger">
                                        <strong id="table-error"></strong>
                                    </span>
                                    <table style="width: 100%">
                                        <tbody>
                                            <tr>
                                                <td colspan="2">
                                                    <button type="button" name="adds" id="adds"
                                                        class="btn btn-success btn-sm waves-effect waves-float waves-light"><i
                                                            class="fa fa-plus" arial-hidden="true"></i> Add
                                                        New </button>
                                                </td>
                                                <td></td>
                                            <tr class="totalrownumber">

                                                <td style="text-align: right;">
                                                    <label strong style="font-size: 16px;">No. of Items: </label>
                                                </td>
                                                <td style="text-align: right; width: 2%;">
                                                    <label id="numberofItemsLbl" strong
                                                        style="font-size: 16px; font-weight: bold;">0</label>
                                                </td>
                                            </tr>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button id="withdraw" type="button"
                        class="btn btn-info waves-effect waves-float waves-light">Save</button>
                    <button id="closebutton" type="button" class="btn btn-danger" onclick="closeModal()"
                        data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    
    <div class="modal fade" id="sureModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Withdraw Item</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                        onclick="closeModalWithClearValidation()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <label>Do you really want to
                        withdraw this item?</label>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-info sure">Yes</button>
                    <button id="closebutton" type="button" class="btn btn-danger"
                        onclick="closeModalWithClearValidation()" data-dismiss="modal">No</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        var start_date = moment().subtract(1, 'M');
        var end_date = moment();
        var start = start_date.format('MMMM D, YYYY');
        var end = end_date.format('MMMM D, YYYY');
        $('#daterangein span').html(start_date.format('MMMM D, YYYY') + '-' + end_date.format('MMMM D, YYYY'));
        $('#daterangein').daterangepicker({
            startDate: start_date,
            endDate: end_date
        }, function(start_date, end_date) {
            $('#daterangein span').html(start_date.format('MMMM D, YYYY') + '-' + end_date.format('MMMM D, YYYY'));
            var cTable = $('#laravel-datatable-in').dataTable();
            cTable.fnDraw(false);
            start = start_date.format('MMMM D, YYYY');
            end = end_date.format('MMMM D, YYYY');
        });
        var errorcolor = "#ffcccc";
        $(function() {
            cardSection = $('#page-block');
        });
        /* BEGIN: Display zone table using yajra datatable */
        $(document).ready(function() {
            var ctable = $('#laravel-datatable-category').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                dom: 'lBfrtip', // Add l before B to include lengthMenu
                buttons: [{
                        extend: 'copy',
                        title: 'Item Stock Details', // Title for the 'copy' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'csv',
                        title: 'Item Stock Details', // Title for the 'csv' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'excel',
                        title: 'Item Stock Details', // Title for the 'excel' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'pdf',
                        title: 'Item Stock Details', // Title for the 'pdf' button
                        orientation: 'landscape', // Set orientation: 'landscape' or 'portrait'
                        pageSize: 'A4', // Set page size
                        customize: function(doc) {
                            // Customize header, footer, and body style
                            doc.styles.tableHeader = {
                                fillColor: '#4CAF50',
                                color: 'white',
                                alignment: 'center'
                            };
                            doc.styles.title = {
                                fontSize: 14,
                                alignment: 'center'
                            };
                            doc.defaultStyle.fontSize = 10; // Change default font size
                            doc.content[1].table.widths = '*'.repeat(doc.content[1].table.body[0]
                                .length).split(''); // Automatically adjust column widths
                            doc.pageMargins = [10, 10, 10, 10]; // Adjust page margins
                            doc.pageSize = 'A4'; // Ensure the page size is A4
                            doc.content[1].layout = {
                                hLineWidth: function(i, node) {
                                    return (i === 0 || i === node.table.body.length) ? 2 :
                                        1;
                                },
                                vLineWidth: function(i, node) {
                                    return (i === 0 || i === node.table.widths.length) ? 2 :
                                        1;
                                },
                                hLineColor: function(i, node) {
                                    return (i === 0 || i === node.table.body.length) ?
                                        'black' : 'gray';
                                },
                                vLineColor: function(i, node) {
                                    return (i === 0 || i === node.table.widths.length) ?
                                        'black' : 'gray';
                                },
                                paddingLeft: function(i, node) {
                                    return 4;
                                },
                                paddingRight: function(i, node) {
                                    return 4;
                                },
                                paddingTop: function(i, node) {
                                    return 2;
                                },
                                paddingBottom: function(i, node) {
                                    return 2;
                                },
                            };
                        },
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'print',
                        title: 'Item Stock Details',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4] // Indexes of the columns you want to include
                        }
                    }
                ],
                lengthMenu: [
                    [10, 25, 50, 500, -1],
                    [10, 25, 50, 500, "All"]
                ],
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: '/getreceiveditems',
                    type: 'DELETE',
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'item_name',
                        name: 'item_name'
                    },
                    {
                        data: 'received',
                        name: 'received'
                    },
                    {
                        data: 'issued',
                        name: 'issued'
                    },
                    {
                        data: 'balance',
                        name: 'balance'
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return ' <a class="btn btn-info" style="padding: 5px 5px; width: 100%;" onclick="detailFn(' +
                                data.id +
                                ')" id="dtinfobtn" title="Open item information page" data-id = "' +
                                data.id +
                                '"><span> View Detail </span></a>';
                        },
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return ' <a class="btn btn-danger" style="padding: 5px 5px; width: 100%;" onclick="withdrawdetailFn(' +
                                data.id +
                                ')" id="dtinfobtn" title="Withdraw information page" data-id = "' +
                                data.id +
                                '"><span> View withdraw </span></a>';
                        },
                        orderable: false,
                        searchable: false
                    },
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('support_admin')): ?>
                        {
                            data: null,
                            render: function(data, type, full, meta) {
                                return ' <a class="btn btn-warning" style="padding: 5px 5px; width: 100%;" onclick="receiveFn(' +
                                    data.id +
                                    ')" id="dtinfobtn" title="Open clinic information page" data-id = "' +
                                    data.id +
                                    '"><span> Receive Item </span></a>';
                            },
                            orderable: false,
                            searchable: false
                        }
                    <?php endif; ?>
                ],
            });
            /* End: Yajra data table*/
            $('#laravel-datatable-crud tbody').on('click', 'tr', function() {
                if ($(this).hasClass('selected')) {
                    $(this).removeClass('selected');
                } else {
                    $('tr.selected').removeClass('selected');
                    $(this).addClass('selected');
                }
            });

            $('#status').select2({
                minimumResultsForSearch: -1
            });
        });
    </script>
    <script>
        $('.add').click(function() {
            $('#item_name').val('');
            $('#status').val('Active').trigger('change');
            $('#name-error').html('');
            $('#status-error').html('');
            $('#savenewbutton').css('display', 'flex');
            $('#savebutton').html('Save & Close');
            $('#savenewbutton').html('Save & New');
            $('#inlineForm').modal('show');
        });


        function detailFn(record_id) {
            $('#detail_id').val(record_id);
            $('#detailForm').modal('show');
            $('#laravel-datatable-items').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                dom: 'lBfrtip', // Add l before B to include lengthMenu
                buttons: [{
                    extend: 'copy',
                    title: 'Your Title Here' // Title for the 'copy' button
                }],
                lengthMenu: [
                    [10, 25, 50, 500, -1],
                    [10, 25, 50, 500, "All"]
                ],
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: '/itemdetail/' + $('#detail_id').val(),
                    type: 'DELETE',
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'created_at',
                        name: 'created_at'
                    },
                    {
                        data: 'user.name',
                        name: 'user.name'
                    },
                    {
                        data: 'item.item_name',
                        name: 'item.item_name'
                    },
                    {
                        data: 'quantity',
                        name: 'quantity'
                    },
                ],
            });
        }

        function withdrawdetailFn(record_id) {
            $('#withdrawDetailModal').modal('show');
            $('#laravel-datatable-withdraw').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                dom: 'lBfrtip', // Add l before B to include lengthMenu
                buttons: [{
                    extend: 'copy',
                    title: 'Your Title Here' // Title for the 'copy' button
                }],
                lengthMenu: [
                    [10, 25, 50, 500, -1],
                    [10, 25, 50, 500, "All"]
                ],
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: '/withdrawdetail/' + record_id,
                    type: 'DELETE',
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'created_at',
                        name: 'created_at'
                    },
                    {
                        data: 'user.name',
                        name: 'user.name'
                    },
                    {
                        data: 'student.full_name',
                        name: 'student.full_name'
                    },
                    {
                        data: 'student.student_id',
                        name: 'student.student_id'
                    },
                    {
                        data: 'item.item_name',
                        name: 'item.item_name'
                    },
                    {
                        data: 'quantity',
                        name: 'quantity'
                    },
                ],
            });
        }

        function receiveFn(record_id) {
            $('#receiveForm').modal('show');
            $('#receive_id').val(record_id);
            /*$('#savenewbutton').css('display', 'none');
            $('#savebutton').html('Update');
            $.get('/edititem/' + record_id, function(data) {
                $('#name').val(data.category.name);
                $('#status').val(data.category.status).trigger('change');
            });
            $('#inlineForm').modal('show');*/
        }
        $('.receive_item').click(function() {
            var check = prompt('Are you sure? write yes in space provided');
            if (check == 'yes') {
                receiveItem();
            }
        })
        var i = 0,
            m = 0,
            j = 0;
        /* BEGIN: Add woreda button */
        $("#adds").click(function() {
            $('#table-error').html('');
            var lastrowcount = $('#dynamicTable tr:last').find('td').eq(1).find('input').val();
            ++i;
            ++m;
            ++j;
            $("#dynamicTable > tbody").append('<tr id="rowind' + m +
                '"><td style="font-weight:bold;width:3%;text-align:center;">' + j + '</td>' +
                '<td style="display:none;"><input type="hidden" name="product[' + m + '][vals]" id="vals' + m +
                '" class="vals form-control" readonly="true" style="font-weight:bold;" value="' + m +
                '"/></td>' +
                '<td style="display:none;"><input type="hidden" name="product[' + m +
                '][id]" id="id' +
                m +
                '" class="vals form-control" readonly="true" style="font-weight:bold;" value=""/></td>' +
                '<td style="width: 13%; padd"><select class="custom-select browser-default select2 product" name="product[' +
                m +
                '][item_id]" id="item_id' +
                m +
                '" onclick="prfn(this)" onblur="checkPrFn(this)"><option value=""></option></select></td>' +
                '<td style="width:13%; padd"><input type="number" name="product[' + m +
                '][quantity]" placeholder="Write quantity here..." onkeypress="return Validatedescription(event);" onkeyup="checkDscFn()" id="quantity' +
                m +
                '" class="description form-control numeral-mask" onclick="dscfn(this)" onblur="checkDscFn(this)"/></td>' +
                '<td style="width:3%;text-align:center;"><button type="button" id="removebtn' + m +
                '" class="btn btn-light btn-sm remove-tr" style="color:#ea5455;background-color:#FFFFFF;border-color:#FFFFFF"><i class="fa fa-times fa-lg" aria-hidden="true"></i></button></td></tr>'
            );

            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                $('#item_id' + m).append(
                    '<option value="<?php echo e($item->id); ?>"><?php echo e($item->item_name); ?></option>'
                );
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            $('#item_id' + m).select2({
                placeholder: "Select item here",
            });
            renumberRows();
        });

        $(document).on('click', '.remove-tr', function() {
            id = $(this).val();
            $(this).parents('tr').remove();
            renumberRows();
            --i;
            --j;
        });

        function renumberRows() {
            var ind;
            $('#dynamicTable > tbody tr').each(function(index, el) {
                $(this).children('td').first().text(index += 1);
                $('#numberofItemsLbl').html(index);
                ind = index;
            });
            if (ind == 0) {
                $('.totalrownumber').hide();
            } else {
                $('.totalrownumber').hide();
            }
        }

        function receiveItem() {
            $('.receive_item').html('submiting...');
            var id = $('#receive_id').val();
            var quantity = $('#quantity').val();
            $.get('/receiveitem/' + id + '/' + quantity, function(data) {
                if (data.success) {
                    $('.receive_item').html('Submit');
                    toastrMessage('success', 'success', data.success);
                    var fTable = $('#laravel-datatable-category').dataTable();
                    fTable.fnDraw(false);
                    $('#receiveForm').modal('hide');
                    $('#receive_id').val('');
                    $('#quantity').val('0');
                } else if (data.errors) {
                    $('.receive_item').html('Submit');
                    toastrMessage('error', 'error', data.errors);
                } else {
                    $('.receive_item').html('Submit');
                }
            });
        }

        function withdrawFn() {
            $('#student_id').select2({
                placeholder: "Select Student here",
            });
            $('#withdrawModal').modal('show');
        }
        $('#withdraw').click(function() {
            $('#withdrawModal').modal('show');
            withdrawItem();
        });

        function withdrawItem() {
            var withdrawData = $('#form-withdraw');
            var formData = withdrawData.serialize();
            $.ajax({
                url: '/withdrawitem',
                type: 'post',
                data: formData,
                beforeSend: function() {
                    cardSection.block({
                        message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                        css: {
                            backgroundColor: 'transparent',
                            color: '#fff',
                            border: '0'
                        },
                        overlayCSS: {
                            opacity: 0.5
                        }
                    });
                    $('#withdraw').text('Submiting...');
                    $('#withdraw').prop("disabled", true);
                },
                complete: function() {
                    cardSection.block({
                        message: '',
                        timeout: 1,
                        css: {
                            backgroundColor: '',
                            color: '',
                            border: ''
                        },
                    });
                },

                success: function(data) {
                    if (data.message) {
                        alert_toast(data.message, 'success');
                        $('#withdraw').html('Submit');
                        $('#withdraw').prop("disabled", false);
                    }
                    if (data.errors) {
                        if (data.errors.student_id) {
                            $('#student-error').html(data.errors.student_id[0]);
                            $('#withdraw').html('Submit');
                            $('#withdraw').prop("disabled", false);
                        }
                        if (data.errors.password) {
                            $('#password-error').html(data.errors.password[0]);
                            $('#withdraw').html('Submit');
                            $('#withdraw').prop("disabled", false);
                        }
                    } else if (data.errors1) {
                        var item = "";
                        var quantity = "";
                        for (var k = 1; k <= m; k++) {
                            item = ($('#item_id' + k)).val();
                            quantity = ($('#quantity' + k)).val();

                            if (($('#item_id' + k).val()) != undefined) {
                                if (item == "" || item == null) {
                                    $('#item_id' + k).css("background", errorcolor);
                                }
                            }
                            if (($('#quantity' + k).val()) != undefined) {
                                if (quantity == "" || quantity == null) {
                                    $('#quantity' + k).css("background", errorcolor);
                                }
                            }
                        }
                        $('#withdraw').html('Submit');
                        $('#withdraw').prop("disabled", false);
                        alert_toast(data.errors,
                            "error");
                    } else if (data.item_error) {
                        alert_toast(data.item_error,
                            "error");
                        $('#table-error').html(data.item_error)
                        $('#withdraw').html('Submit');
                        $('#withdraw').prop("disabled", false);
                    } else if (data.credential_error) {
                        alert_toast(data.credential_error,
                            "error");
                        $('#password').val('');
                        $('#password-error').html(data.credential_error)
                        $('#withdraw').html('Submit');
                        $('#withdraw').prop("disabled", false);
                    } else if (data.success) {
                        alert_toast('Items withdrawn successfully!', 'success');
                        $('#withdrawModal').modal('hide');
                        var rnTable = $('#laravel-datatable-category').dataTable();
                        rnTable.fnDraw(false);
                        $('#withdraw').html('Submit');
                        $('#withdraw').prop("disabled", false);
                    } else {
                        $('#withdraw').html('Submit');
                        $('#withdraw').prop("disabled", false);
                    }
                }
            });
        }

        function categoryDeleteFn(record_id) {
            $('#deleteing_id').val(record_id);
            $('#DeleteModal').modal('show');
        }
        $('.delete_category').click(function() {
            var delete_id = $('#deleteing_id').val();
            $.ajax({
                url: '/deletecategory/' + delete_id,
                type: 'get',
                beforeSend: function() {
                    $('.delete_category').text('Deleteing...');
                },
                success: function(data) {
                    if (data.errors) {
                        $('.delete_category').text('Delete');
                        alert_toast('an error occured', 'error');
                    } else if (data.success) {
                        $('.delete_category').text('Delete');
                        alert_toast(data.success, 'succes')
                        var cTable = $('#laravel-datatable-category').dataTable();
                        cTable.fnDraw(false);
                        $('#DeleteModal').modal('hide');
                    }
                }
            });
        });
    </script>
    <script>
        function removeStudentValidation() {
            $('#student-error').html('');
        }

        function removePasswordValidation() {
            $('#password-error').html('');
        }

        function closeModal() {
            $('#student-error').html('');
            $('#password-error').html('');
            $('#password').val('');
            $('#student_id').val('').trigger('change');
            $('#savenewbutton').css('display', 'flex');
            $('#savebutton').html('Save & Close');
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Werabe University Project\Werabe University Project\resources\views\support\received_items.blade.php ENDPATH**/ ?>