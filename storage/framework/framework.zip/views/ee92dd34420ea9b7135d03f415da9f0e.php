<!-- BEGIN: Campus Store Show Information Modal -->
<div class="modal fade" id="informationModal" data-keyboard="false" data-backdrop="static" tabindex="-1" role="dialog"
    aria-labelledby="myModalLabel35" aria-hidden="true" style="overflow-y: scroll;">
    <div class="modal-dialog modal-xl" role="document" style="font-size: 11px;">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Campus Store Information</h4>
                <div class="row">
                    <div style="text-align: right" id="statusdisplay"></div>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">×</span></button>
                </div>
            </div>
            <form id="InformationForm">
                <input type="hidden" name="_token" value="bEE2UUJ5zm8YDMuIHSOQT8ZRMeUGaxv9eDaOVNb1">
                <div class="modal-body">
                    <section id="input-mask-wrapper">
                        <div class="col-xl-12">
                            <div class="row">
                                <div class="col-md-3 col-sm-12">
                                    <div class="card">
                                        <div class="card-header">
                                            <h4 class="card-title">Basic Information</h4>
                                            <div class="heading-elements">
                                                <ul class="list-inline mb-0">

                                                </ul>
                                            </div>
                                        </div>
                                        <div class="card-content collapse show">
                                            <div class="card-body">
                                                <div class="row">
                                                    <table style="width: 100%;">
                                                        <tbody>

                                                            <tr>
                                                                <td><label strong="" style="font-size: 14px;">SKU:
                                                                    </label>
                                                                </td>
                                                                <td><label id="sku_info" strong=""
                                                                        style="font-size:14px;font-weight:bold;"></label>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td><label strong=""
                                                                        style="font-size: 14px;">Created Date:
                                                                    </label>
                                                                </td>
                                                                <td><label id="date_created_info" strong=""
                                                                        style="font-size:14px;font-weight:bold;"></label>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td><label strong=""
                                                                        style="font-size: 14px;">Receiption
                                                                        Name: </label>
                                                                </td>
                                                                <td><label id="receiption_info" strong=""
                                                                        style="font-size:14px;font-weight:bold;"></label>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td><label strong=""
                                                                        style="font-size: 14px;">Supplier
                                                                        Name: </label>
                                                                </td>
                                                                <td><label id="supplier_info" strong=""
                                                                        style="font-size:14px;font-weight:bold;"></label>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td style="width: 43%"><label strong=""
                                                                        style="font-size: 14px;">Item No</label>
                                                                </td>
                                                                <td style="width: 57%"><label id="incoming_info"
                                                                        strong=""
                                                                        style="font-size:14px;font-weight:bold;"></label>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                                <div class="divider newext">
                                                    <div class="divider-text">Action Information</div>
                                                </div>
                                                <div class="row">
                                                    <table style="width: 100%;">
                                                        <tbody>
                                                            <tr>
                                                                <td style="width: 35%"><label strong=""
                                                                        style="font-size: 14px;">Created
                                                                        By</label></td>
                                                                <td style="width: 65%"><label id="created_by"
                                                                        strong=""
                                                                        style="font-size:14px;font-weight:bold;"></label>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td><label strong=""
                                                                        style="font-size: 14px;">Created
                                                                        Date</label></td>
                                                                <td><label id="created_at" strong=""
                                                                        style="font-size:14px;font-weight:bold;"></label>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td><label strong="" style="font-size: 14px;">Last
                                                                        Edited
                                                                        By</label></td>
                                                                <td><label id="updated_by" strong=""
                                                                        style="font-size:14px;font-weight:bold;"></label>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td><label strong="" style="font-size: 14px;">Last
                                                                        Edited
                                                                        Date</label></td>
                                                                <td><label id="updated_at" strong=""
                                                                        style="font-size:14px;font-weight:bold;"></label>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-9 col-sm-12">
                                    <div class="card">
                                        <div class="card-header">
                                            <h4 class="card-title">Product Information</h4>
                                            <div class="heading-elements">
                                                <ul class="list-inline mb-0">

                                                </ul>
                                            </div>
                                        </div>
                                        <div class="card-content collapse show">
                                            <div class="card-body">
                                                <table id="productdetailtbl"
                                                    class="display table-bordered table-striped table-hover dt-responsive mb-0"
                                                    style="width: 100%; max-width: 100%; overflow-x: scroll;">
                                                    <thead>
                                                        <tr>
                                                            <th style="width: 0%;">#</th>
                                                            <th nowrap>Expired Date</th>
                                                            <th>Remaining Exp Days</th>
                                                            <th nowrap>Batch No</th>
                                                            <th nowrap>Product</th>
                                                            <th nowrap>Category</th>
                                                            <th nowrap>Unit</th>
                                                            <th nowrap>Quantity</th>
                                                            <th nowrap>Action</th>
                                                        </tr>
                                                    </thead>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
                <div class="modal-footer">

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_clinic')): ?>
                        <p id="clickcode">Click to show the code</p>
                        <div id ="viewcode" onclick="viewCode()"
                            style="padding: 12px; border-radius: 5px; background: gray; color: gray;">There no
                            authentication code yet
                        </div>
                    <?php endif; ?>
                    <p class="btn btn-default" id="state" style="color: blue;"></p>
                    <button id="closebuttonk" type="button"
                        class="btn btn-danger waves-effect waves-float waves-light"
                        data-dismiss="modal">Close</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- BEGIN: Info modal -->
<div class="modal fade text-left" id="infoModal" data-keyboard="false" data-backdrop="static" tabindex="-1"
    role="dialog" aria-labelledby="myModalLabel133" aria-hidden="true" style="overflow-y: scroll;">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">Product Information</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="regionform">
                <input type="hidden" class="_token">
                <div class="modal-body">
                    <table style="width: 100%;">
                        <tbody>
                            <tr>
                                <td style="width: 40%">
                                    <label style="font-size: 14px;">Serial Number: </label>
                                </td>
                                <td style="width: 60%">
                                    <label id="seriel_info" style="font-size: 14px; font-weight: bold;"></label>

                                </td>
                                &nbsp;
                            </tr>
                            <tr>
                                <td style="width: 40%">
                                    <label style="font-size: 14px;">Expired Date: </label>
                                </td>
                                <td style="width: 60%">
                                    <label id="expired_info" style="font-size: 14px; font-weight: bold;"></label>

                                </td>
                            </tr>
                            <tr>
                                <td style="width: 40%">
                                    <label style="font-size: 14px;">Product Name: </label>
                                </td>
                                <td style="width: 60%">
                                    <label id="product_info" style="font-size: 14px; font-weight: bold;"></label>

                                </td>
                            </tr>
                            <tr>
                                <td style="width: 40%">
                                    <label style="font-size: 14px;">Category: </label>
                                </td>
                                <td style="width: 60%">
                                    <label id="category_info" style="font-size: 14px; font-weight: bold;"></label>

                                </td>
                            </tr>
                            <tr>
                                <td style="width: 40%">
                                    <label style="font-size: 14px;">UoN(Unit of measurement): </label>
                                </td>
                                <td style="width: 60%">
                                    <label id="unit_info" style="font-size: 14px; font-weight: bold;"></label>

                                </td>
                            </tr>
                            <tr>
                                <td style="width: 40%">
                                    <label style="font-size: 14px;">Remaining expire date: </label>
                                </td>
                                <td style="width: 60%">
                                    <label id="remaining_info"
                                        style="font-size: 14px; font-weight: bold; background: orange; border-radius: 10px; color: white; padding: 5px 10px"></label>

                                </td>
                            </tr>
                            <tr>
                                <td style="width: 40%">
                                    <label style="font-size: 14px;">Quality Checker: </label>
                                </td>
                                <td style="width: 60%">
                                    <label id="quality_info" style="font-size: 14px; font-weight: bold;"></label>

                                </td>
                            </tr>
                            <tr>
                                <td style="width: 40%">
                                    <label style="font-size: 14px;">Voucher No: </label>
                                </td>
                                <td style="width: 60%">
                                    <label id="voucher_info" style="font-size: 14px; font-weight: bold;"></label>

                                </td>
                            </tr>
                            <tr>
                                <td style="width: 40%">
                                    <label style="font-size: 14px;">Capacity: </label>
                                </td>
                                <td style="width: 60%">
                                    <label id="capacity_info" style="font-size: 14px; font-weight: bold;"></label>

                                </td>
                            </tr>
                            <td>
                                <label style="font-size: 14px;">Quantity: </label>
                            </td>
                            <td>
                                <label id="quantity_info" style="font-size: 14px; font-weight: bold;"></label>

                            </td>
                            </tr>
                            <tr>
                                <td style="width: 40%">
                                    <label style="font-size: 14px;">Unit Price: </label>
                                </td>
                                <td style="width: 60%">
                                    <label id="unitprice_info" style="font-size: 14px; font-weight: bold;"></label>

                                </td>
                            </tr>
                            <tr>
                                <td style="width: 40%">
                                    <label style="font-size: 14px;">Total Price: </label>
                                </td>
                                <td style="width: 60%">
                                    <label id="total_info" style="font-size: 14px; font-weight: bold;"></label>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="modal-footer">
                    <button id="closebuttonk" type="button"
                        class="btn btn-danger waves-effect waves-float waves-light"
                        data-dismiss="modal">Close</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Werabe University Project\Werabe University Project\resources\views\campus-request\comman.blade.php ENDPATH**/ ?>