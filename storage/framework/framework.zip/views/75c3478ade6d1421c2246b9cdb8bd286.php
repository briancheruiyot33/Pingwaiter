<?php $__env->startSection('content'); ?>
    <div class="app-content content">
        <section id="responsive-datatable">
            <div id="success_message" style="padding: 13px 20px;"></div>
            <div class="row">
                <div class="col-12">
                    <!-- Your HTML content goes here -->
                    <div class="card">
                        <div class="card-header border-bottom">
                            <h3 class="card-title">Clinic Store</h3>

                        </div>
                        <div class="card-datatable">
                            <div style="width:98%; margin-left:1%;">
                                <div class="table-responsive">

                                    <table id="laravel-datatable-campus"
                                        class="display table-bordered table-striped table-hover dt-responsive mb-0 dataTable no-footer"
                                        style="width: 100%;" role="grid" aria-describedby="laravel-datatable-crud_info">
                                        <thead>

                                            <tr role="row">
                                                <th style="width:1%;" rowspan="2">#</th>
                                                <th nowrap rowspan="2">Item Name</th>
                                                <th nowrap rowspan="2">Category</th>
                                                <th nowrap rowspan="2">Unit</th>
                                                <th nowrap colspan="4" style="text-align: center;">Quantity</th>
                                                <th style="width: 5%;" rowspan="2">Action</th>
                                            </tr>
                                            <tr>
                                                <th nowrap>Received</th>
                                                <th nowrap>Issued</th>
                                                <th nowrap>Loss/Adj</th>
                                                <th nowrap>Balance</th>
                                            </tr>
                                        </thead>
                                        <tbody></tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- BEGIN: Campus Store Show Information Modal -->
            <div class="modal fade" id="inlineForm" data-keyboard="false" data-backdrop="static" tabindex="-1"
                role="dialog" aria-labelledby="myModalLabel35" aria-hidden="true" style="overflow-y: scroll;">
                <div class="modal-dialog modal-xl" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title">Clinic Store Information</h4>
                            <div class="row">
                                <div style="text-align: right" id="statusdisplay"></div>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                                    onclick="closeModal()"><span aria-hidden="true">×</span></button>
                            </div>
                        </div>
                        <form id="InformationForm">
                            <input type="hidden" name="_token" value="bEE2UUJ5zm8YDMuIHSOQT8ZRMeUGaxv9eDaOVNb1">
                            <div class="modal-body">
                                <section id="input-mask-wrapper">
                                    <div class="col-md-12">
                                        <table id="productdetailtbl"
                                            class="display table-bordered table-striped table-hover dt-responsive mb-0"
                                            style="width: 100%; max-width: 100%; overflow-x: scroll;">
                                            <thead>
                                                <tr>
                                                    <th rowspan="2">#</th>
                                                    <th nowrap rowspan="2">Date Received</th>
                                                    <th nowrap rowspan="2">Received From</th>
                                                    <th nowrap rowspan="2">Received By</th>
                                                    <th nowrap rowspan="2">Item Name</th>
                                                    <th nowrap colspan="4" style="text-align: center;">Quantity</th>
                                                    <th nowrap rowspan="2">Batch No</th>
                                                    <th nowrap rowspan="2">Expired Date</th>
                                                    <th rowspan="2">Remaining Exp Days</th>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_clinic')): ?>
                                                        <th nowrap rowspan="2">Dispose</th>
                                                    <?php endif; ?>
                                                </tr>
                                                <tr>
                                                    <th nowrap>Received</th>
                                                    <th nowrap>Issued</th>
                                                    <th nowrap>Loss</th>
                                                    <th nowrap>Balance</th>
                                                </tr>
                                            </thead>
                                        </table>
                                    </div>
                                </section>
                            </div>
                            <div class="modal-footer">
                                <button id="closebuttonk" type="button"
                                    class="btn btn-danger waves-effect waves-float waves-light" data-dismiss="modal"
                                    onclick="closeModal()">Close</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- BEGIN: Disposed modal  -->
            <div class="modal fade text-left" id="disposedModal" data-keyboard="false" data-backdrop="static" tabindex="-1"
                role="dialog" aria-labelledby="disposedlbl" aria-hidden="true" style="overflow-y: scroll;">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="appointbl">Dispose Items</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                                onclick="closeDisposedModal()">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form id="disposed-form">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="disposed_store" id="disposed_store">
                            <div class="modal-body">
                                <label strong style="font-size: 16px;">Disposed quantity</label><label
                                    style="color: red; font-size:16px;">*</label>
                                <div class="form-group">
                                    <input type="number" name="disposed_quantity" id="disposed_quantity"
                                        placeholder="write Disposed quantity here..." class="form-control"
                                        onkeyup="removeDisposedQuantity()">
                                    <span class="text-danger">
                                        <strong id="disposed-quantity-error"></strong>
                                    </span>
                                </div>
                                <label strong style="font-size: 16px;">Type</label><label
                                    style="color: red; font-size:16px;">*</label>
                                <div class="form-group">
                                    <select name="disposed_type" id="disposed_type" class="form-control">
                                        <option value="">Select Type</option>
                                        <option value="used">Used</option>
                                        <option value="disposed">Disposed</option>
                                    </select>
                                    <span class="text-danger">
                                        <strong id="disposed_type-quantity-error"></strong>
                                    </span>
                                </div>
                                <label strong style="font-size: 16px;">Reason</label><label
                                    style="color: red; font-size:16px;">*</label>
                                <div class="form-group">
                                    <textarea name="reason" id="reason" placeholder="write reason here..." class="form-control"
                                        onkeyup="removeReason()"></textarea>
                                    <span class="text-danger">
                                        <strong id="reason-error"></strong>
                                    </span>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button id="disposebutton" type="button" class="btn btn-info">Submit</button>
                                <button id="closebutton" type="button" class="btn btn-danger"
                                    onclick="closeDisposedModal()" data-dismiss="modal">Close</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        var errorcolor = "#ffcccc";
        $(function() {
            cardSection = $('#page-block');
        });

        function closeModal() {
            var rTable = $('#laravel-datatable-campus').dataTable();
            rTable.fnDraw(false);
        }
        /* BEGIN: Display zone table using yajra datatable */
        $(document).ready(function() {
            var ctable = $('#laravel-datatable-campus').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                searchHighlight: true,
                dom: 'lBfrtip', // Add l before B to include lengthMenu
                buttons: [{
                        extend: 'copy',
                        title: 'Your Title Here' // Title for the 'copy' button
                    },
                    {
                        extend: 'csv',
                        title: 'Your Title Here' // Title for the 'csv' button
                    },
                    {
                        extend: 'excel',
                        title: 'Your Title Here' // Title for the 'excel' button
                    },
                    {
                        extend: 'pdf',
                        title: 'Your Title Here' // Title for the 'pdf' button
                    },
                    {
                        extend: 'print',
                        title: 'Yout title here'
                    }
                ],
                lengthMenu: [
                    [10, 25, 50, 500, -1],
                    [10, 25, 50, 500, "All"]
                ],
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: '/getproductpharmacy',
                    type: 'DELETE',
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'product.item_name',
                        name: 'product.item_name'
                    },
                    {
                        data: 'product.category.name',
                        name: 'product.category.name'
                    },
                    {
                        data: 'unit',
                        name: 'unit'
                    },
                    {
                        data: 'total_received',
                        name: 'total_received'
                    },
                    {
                        data: 'withdraw_quantity',
                        name: 'withdraw_quantity'
                    },
                    {
                        data: 'disposed_quantity',
                        name: 'disposed_quantity'
                    },
                    {
                        data: 'available_quantity',
                        name: 'available_quantity'
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return ' <a class="btn btn-success" style="padding: 5px 5px; width: 100%;" onclick="productFn(' +
                                data.product.id +
                                ')" id="dtinfobtn" title="Open clinic information page" data-id = "' +
                                data.product.id +
                                '"><span> Detail </span></a>';
                        },
                        orderable: false,
                        searchable: false
                    }
                ],
            });
            ctable.on('draw', function() {
                var body = $(ctable.table().body());
                body.unhighlight();
                body.highlight(ctable.search());
            })
        });
    </script>
    <script>
        var nowDate = moment();
        nowDate = nowDate.format('YYYY-MM-DD');
        var diff = 0;

        function productFn(record_id) {
            $(".collapse").collapse('show');
            $('#inlineForm').modal('show');
            $('#productdetailtbl').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                searchHighlight: true,
                dom: 'lBfrtip', // Add l before B to include lengthMenu
                buttons: [{
                        extend: 'copy',
                        title: 'Your Title Here' // Title for the 'copy' button
                    },
                    {
                        extend: 'csv',
                        title: 'Your Title Here' // Title for the 'csv' button
                    },
                    {
                        extend: 'excel',
                        title: 'Your Title Here' // Title for the 'excel' button
                    },
                    {
                        extend: 'pdf',
                        title: 'Your Title Here' // Title for the 'pdf' button
                    },
                    {
                        extend: 'print',
                        title: 'Yout title here'
                    }
                ],
                lengthMenu: [
                    [10, 25, 50, 500, -1],
                    [10, 25, 50, 500, "All"]
                ],
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                scrollY: '55vh',
                scrollX: true,
                scrollCollapse: true,
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: '/getpharmacy/' + record_id,
                    type: 'DELETE',
                    dataType: "json",
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },

                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'received_date',
                        name: 'received_date',
                    },
                    {
                        data: 'campusstore.user.name',
                        name: 'campusstore.user.name',
                    },
                    {
                        data: 'campusstore.receiver.name',
                        name: 'campusstore.receiver.name',
                    },
                    {
                        data: 'product.item_name',
                        name: 'product.item_name',
                    },
                    {
                        data: 'total_received',
                        name: 'total_received'
                    },
                    {
                        data: 'withdraw_quantity',
                        name: 'withdraw_quantity'
                    },
                    {
                        data: 'disposed_quantity',
                        name: 'disposed_quantity'
                    },
                    {
                        data: 'available_quantity',
                        name: 'available_quantity'
                    },
                    {
                        data: 'seriel_number',
                        name: 'seriel_number',
                    },
                    {
                        data: 'expired_date',
                        name: 'expired_date',
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return '<p class="rem"></p>';
                        },
                        orderable: true,
                        searchable: true
                    },
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_clinic')): ?>
                        {
                            data: null,
                            render: function(data, type, full, meta) {
                                return ' <p class="dispose">No Balance</p><a class="btn btn-success disp" style="padding: 5px 5px; width: 100%;" onclick="checkdispose(' +
                                    data.id +
                                    ')" id="dtinfobtn" title="disopse products" data-id = "' +
                                    data.id +
                                    '"><span> Disposed </span></a>';
                            },
                            orderable: false,
                            searchable: false
                        }
                    <?php endif; ?>
                ],
                "fnRowCallback": function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                    if (parseFloat(aData.available_quantity) == '0') {
                        $(nRow).find('.dispose').css({
                            "display": "flex",
                            "color": "red",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #4CAF50"
                        });
                        $(nRow).find('.disp').css({
                            "display": "none"
                        });
                    } else {
                        $(nRow).find('.disp').css({
                            "display": "flex"
                        });
                        $(nRow).find('.dispose').css({
                            "display": "none"
                        });
                    }
                    if (aData.product.item_expiration_status == '1') {
                        diff = calculateRemainingDays(aData.expired_date);
                        if (diff > 0) {
                            $(nRow).find('.rem').html(diff);
                        } else if (diff === 0) {
                            $(nRow).find('.rem').html("Product expires today.");
                        } else {
                            $(nRow).find('.rem').html("Product has expired.");
                        }
                    } else {
                        $(nRow).find('.rem').html('None');
                    }

                }
            });
        }

        function calculateRemainingDays(expireDate) {
            // Parse the expiration date string to Date object
            const expiryDate = new Date(expireDate);

            // Get current date
            const currentDate = new Date();

            // Calculate difference in milliseconds
            const differenceMs = expiryDate.getTime() - currentDate.getTime();
            // Convert milliseconds to days
            const remainingDays = Math.ceil(differenceMs / (1000 * 60 * 60 * 24));
            return remainingDays;


        }

        function checkdispose(record_id) {
            $('#disposed_store').val(record_id);
            $('#disposedModal').modal('show');
        }

        $('#disposebutton').click(function() {
            var disposedData = $('#disposed-form');
            var formData = disposedData.serialize();
            $.ajax({
                url: '/disposeProduct',
                type: 'post',
                data: formData,
                beforeSend: function() {
                    cardSection.block({
                        message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                        css: {
                            backgroundColor: 'transparent',
                            color: '#fff',
                            border: '0'
                        },
                        overlayCSS: {
                            opacity: 0.5
                        }
                    });
                    $('#disposebutton').text('removing...');
                    $('#disposebutton').prop("disabled", true);
                },
                complete: function() {
                    cardSection.block({
                        message: '',
                        timeout: 1,
                        css: {
                            backgroundColor: '',
                            color: '',
                            border: ''
                        },
                    });
                },

                success: function(data) {
                    if (data.quantity_error) {
                        $('#disposebutton').html('Dispose');
                        $('#disposebutton').prop("disabled", false);
                        alert_toast(data.quantity_error,
                            "error");
                        $('#disposed_quantity').val('');
                        $('#disposed-quantity-error').html('Must less available quantity')
                    } else if (data.errors) {
                        if (data.errors.disposed_quantity) {
                            $('#disposed-quantity-error').html(data.errors.disposed_quantity[0])
                        }
                        if (data.errors.reason) {
                            $('#reason-error').html(data.errors.reason[0])
                        }
                        if (data.errors.disposed_type) {
                            $('#disposed_type-error').html(data.errors.disposed_type[0])
                        }
                        $('#disposebutton').html('Submit');
                        $('#disposebutton').prop("disabled", false);
                        alert_toast("An error occured!",
                            "error");
                    } else if (data.success) {
                        $('#disposedModal').modal('hide');
                        $('#disposed_store').val('');
                        $('#disposed_quantity').val('');
                        $('#reason').val('');
                        $('#disposebutton').html('Submit');
                        $('#disposebutton').prop("disabled", false);
                        alert_toast('Item disposed Sucessfully!', 'success');
                        var aTable = $('#productdetailtbl').dataTable();
                        aTable.fnDraw(false);
                    } else {
                        alert('new error')
                        $('#disposebutton').html('Submit');
                        $('#disposebutton').prop("disabled", false);
                    }
                }
            });


            /* $.get('disposePharmacyProduct/' + record_id, function(data) {
                 if (data.success) {
                     toastrMessage('success', 'success', 'Product disposed successfully!');
                     var dTable = $('#productdetailtbl').dataTable();
                     dTable.fnDraw(false);
                 } else {
                     toastrMessage('error', 'error', 'An Error Occured!');
                 }
             });*/
        });


        function removeDisposedQuantity() {
            $('#disposed-quantity-error').html('');
        }

        function removeReason() {
            $('#reason-error').html('');
        }

        function closeDisposedModal() {
            $('#reason-error').html('');
            $('#disposed-quantity-error').html('');
            $('#disposed_quantity').val('');
            $('#reason').val('');
            $('#disposed_store').val('');
        }

        function sendRequest(record_id) {
            var quantity = $('.quantity' + record_id + '').val();
            $('.request' + record_id + '').html('requesting...');
            $.ajax({
                url: "/requestPharmacy/" + record_id + "/" + quantity,
                type: 'get',
                success: function(data) {
                    if (data.errors) {
                        $('.request' + record_id + '').html('Request');
                        alert_toast(data.errors, 'error');
                    }
                    if (data.success) {
                        $('.request' + record_id + '').html('Request');
                        alert_toast(data.success, 'success');
                        $('#inlineForm').modal('hide');
                        var rTable = $('#laravel-datatable-campus').dataTable();
                        rTable.fnDraw(false);
                    }
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Werabe University Project\Werabe University Project\resources\views\clinics\clinic3.blade.php ENDPATH**/ ?>