<!DOCTYPE html>
<html lang="en" data-textdirection="ltr">
<!-- BEGIN: Head-->

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0,user-scalable=0,minimal-ui">
    <meta name="description"
        content="Werabe University admin is super flexible, powerful, clean &amp; modern responsive bootstrap 4 admin template with unlimited possibilities.">
    <meta name="keywords"
        content="admin template, Werabe University admin template, dashboard template, flat admin template, responsive admin template, web app">
    <meta name="author" content="PIXINVENT">
    <title>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('support_admin')): ?>
            Student Support System
        <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('support_staff')): ?>
            Student Support System
        <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dorm_admin')): ?>
            Dorm Information Management System
        <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('proctor')): ?>
            Dorm Information Management System
        <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('coordinator')): ?>
            Dorm Information Management System
        <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('finance')): ?>
            Dorm Information Management System
        <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('management')): ?>
            Dorm Information Management System
        <?php else: ?>
            Clinic Information Management system
        <?php endif; ?>

    </title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="apple-touch-icon" href="<?php echo url('uploads/logo.png'); ?>">
    <link rel="shortcut icon" href="<?php echo url('uploads/logo.png'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/vendors/css/vendors.min.css')); ?>">
    
    <!-- BEGIN: Theme CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/css/bootstrap.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/css/bootstrap-extended.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/css/colors.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/css/components.css')); ?>">
    

    
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('admin_assets/select2.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/css/core/menu/menu-types/vertical-menu.css')); ?>">
    
    
    <!-- BEGIN: Page CSS-->
    <link rel="stylesheet" type="text/css"
        href="<?php echo e(asset('app-assets/css/plugins/extensions/ext-component-toastr.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/fontawesome/css/fontawesome.min.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/fontawesome/css/all.min.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('app-assets/toaster/toastr.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/timepicker.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/timepicker.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/style.css')); ?>">

    

    <!--toast-->
    <!-- Include DataTables CSS -->
    


    <!-- BEGIN: Custom CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <!-- Custom styles for this template-->
    <!-- <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css"> -->
    <!-- Tempusdominus Bootstrap 4 -->
    <?php if(auth()->guard()->check()): ?>
        <link rel="stylesheet" href="<?php echo e(asset('plugins/select2/css/select2.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">
        <script src="<?php echo e(asset('dist/js/script.js')); ?>"></script> 

        <script src="<?php echo e(asset('plugins/toastr/toastr.min.js')); ?>"></script>
    <?php else: ?>
        

    <?php endif; ?>
    <!-- END: Custom CSS-->
    <!-- BEGIN: Yajra table css-->
    <style>
        .input-group-prepend {
            flex-direction: column;
        }

        .dropdown-menu {
            left: -1px;
            right: auto;
        }

        .toast-success {
            background-color: rgb(28, 98, 20);
            /* Success color */
            color: #fff;
            /* Set to your desired text color */
            border: 1px solid rgb(28, 98, 20);
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
            text-shadow: 1px 1px 1px rgba(0, 0, 0, 0.5);
        }

        /* Override background color for error toast */
        .toast-error {
            background-color: rgb(50, 10, 10);
            /* Error color */
            color: #fff;
            /* Set to your desired text color */
            border: 1px solid rgb(70, 10, 10);
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
            text-shadow: 1px 1px 1px rgba(0, 0, 0, 0.5);
        }

        /* Custom styles for time input */
        .dataTables_filter {
            float: right;
            margin-right: 10px;
            display: flex;
            /* Optional: Add margin to separate it from the table */
        }

        .dt-buttons {
            text-align: center;
            margin-bottom: 10px;
            /* Add margin to separate it from the table */
        }

        .dataTables_length {
            position: absolute;
            padding-top: 36px;
            margin-left: 10px;
            /* Adjust z-index as needed */
        }

        /* Custom CSS to add margin for the search label */
        .dataTables_filter label {
            margin-right: 10px;
            /* Add margin to the right of the label */
        }

        /* Custom CSS to move the pagination to the right */
        .dataTables_wrapper .dataTables_paginate {
            float: right;
            margin-top: -40px;
        }

        .styled-time-input {
            width: 100%;
            padding: 0.375rem 0.75rem;
            font-size: 1rem;
            line-height: 1.5;
            color: #495057;
            background-color: #fff;
            background-clip: padding-box;
            border: 1px solid #ced4da;
            border-radius: 0.25rem;
            transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
        }

        .c1 {
            display: flex;
            justify-content: space-between;
            padding: 3px;
        }

        .c1 tr td {
            justify-content: space-between;
        }

        .c1 p {
            display: flex;
        }
    </style>


    <!-- END: Yajra table css -->

</head>
<!-- END: Head-->

<!-- BEGIN: Body-->


<body class="vertical-layout vertical-menu-modern  navbar-floating footer-static " data-open="click"
    data-menu="vertical-menu-modern" data-col="" id="page-block">
    <?php if(auth()->guard()->check()): ?>
        <!-- BEGIN: Header-->
        <nav class="header-navbar navbar navbar-expand-lg align-items-center floating-nav navbar-light navbar-shadow"
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dorm_admin')): ?> style="background: #b4b7bd;" <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('proctor')): ?> style="background: #b4b7bd;"<?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('coordinator')): ?> style="background: #b4b7bd;"<?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('finance')): ?> style="background: #b4b7bd;"<?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('management')): ?> style="background: #b4b7bd;" <?php endif; ?>>
            <div class="navbar-container d-flex content">
                <div class="bookmark-wrapper d-flex align-items-center">
                    <ul class="nav navbar-nav d-xl-none">
                        <li class="nav-item"><a class="nav-link menu-toggle" href="javascript:void(0);"><i class="ficon"
                                    data-feather="menu"></i></a></li>
                    </ul>
                    <ul class="nav navbar-nav bookmark-icons">
                        
                    </ul>
                    <ul class="nav navbar-nav">
                        <li class="nav-item d-none d-lg-block"><a class="nav-link bookmark-star"><i
                                    class="ficon text-warning" data-feather="star"></i></a>
                            <div class="bookmark-input search-input">
                                <div class="bookmark-input-icon"><i data-feather="search"></i></div>
                                <input class="form-control input" type="text" placeholder="Werabe University"
                                    tabindex="0" data-search="search">
                                <ul class="search-list search-list-bookmark"></ul>
                            </div>
                        </li>
                        <li class="nav-item d-none d-lg-block">
                            <h3>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('support_admin')): ?>
                                    <span id="support_title"></span>
                                <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('support_staff')): ?>
                                    <span id="support_title"></span>
                                <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dorm_admin')): ?>
                                    <span id="dorm_title"></span>
                                <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('proctor')): ?>
                                    <span id="dorm_title"></span>
                                <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('coordinator')): ?>
                                    <span id="dorm_title"></span>
                                <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('finance')): ?>
                                    <span id="dorm_title"></span>
                                <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('management')): ?>
                                    <span id="dorm_title"></span>
                                <?php else: ?>
                                    <span id="clinic_title"></span>
                                <?php endif; ?>
                            </h3>
                        </li>
                    </ul>
                </div>
                <ul class="nav navbar-nav align-items-center ml-auto">
                    <li class="nav-item dropdown dropdown-language">
                        <select class="nav-link dropdown-toggle" aria-labelledby="dropdown-flag" id="languageSwitcher"
                            onchange="changeLanguage()">
                            <option class="dropdown-item" value="en"
                                <?php echo e(app()->getLocale() == 'en' ? 'selected' : ''); ?>><i class="flag-icon flag-icon-us"></i>
                                English</option>
                            <option value="am" <?php echo e(app()->getLocale() == 'am' ? 'selected' : ''); ?>><i
                                    class="flag-icon flag-icon-et"></i> Amharic</option>
                        </select>
                        

                    </li>
                    <li class="nav-item dropdown dropdown-notification mr-25"><a class="nav-link"
                            href="javascript:void(0);" data-toggle="dropdown"><i class="ficon"
                                data-feather="bell"></i><span
                                class="badge badge-pill badge-danger badge-up note">0</span></a>
                        <ul class="dropdown-menu dropdown-menu-media dropdown-menu-right">
                            <li class="dropdown-menu-header">
                                <div class="dropdown-header d-flex">
                                    <h4 class="notification-title mb-0 mr-auto">Notifications</h4>
                                    <div class="badge badge-pill badge-light-primary"><span class="note">0</span> New
                                    </div>
                                </div>
                            </li>
                            <li class="scrollable-container media-list">
                                <a class="d-flex"
                                    href="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_campus')): ?> <?php echo e(url('request/2')); ?> <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_clinic')): ?> <?php echo e(url('pharmacy-request/1')); ?><?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_clinic_leader')): ?> <?php echo e(url('campusStore')); ?><?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_doctor')): ?> <?php echo e(url('patient_doctor')); ?><?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_pharmacy')): ?> <?php echo e(url('patient_pharmacy')); ?><?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_labratory')): ?> <?php echo e(url('patient_labratory')); ?> <?php endif; ?>"
                                    id="pending">
                                    <div class="media d-flex align-items-start">
                                        <div class="media-left">
                                            <div class="avatar bg-light-danger">
                                                <div class="avatar-content">
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_clinic_leader')): ?>
                                                        CLINIC
                                                    <?php else: ?>
                                                        PEN
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="media-body">
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_campus')): ?>
                                                <p class="media-heading"><span class="font-weight-bolder">New
                                                        pending message</span>&nbsp;received</p><small
                                                    class="notification-text"> You
                                                    have <span id="note_pending">0</span> unread messages</small>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_clinic')): ?>
                                                <p class="media-heading"><span class="font-weight-bolder">New
                                                        pending message</span>&nbsp;received</p><small
                                                    class="notification-text"> You
                                                    have <span id="note_pending">0</span> unread messages</small>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_doctor')): ?>
                                                <p class="media-heading"><span class="font-weight-bolder">New
                                                        patient </span>&nbsp;received</p><small class="notification-text"> You
                                                    have <span id="note_pending">0</span> unread messages</small>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_pharmacy')): ?>
                                                <p class="media-heading"><span class="font-weight-bolder">New
                                                        patient </span>&nbsp;received</p><small class="notification-text"> You
                                                    have <span id="note_pending">0</span> unread messages</small>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_labratory')): ?>
                                                <p class="media-heading"><span class="font-weight-bolder">New
                                                        patient </span>&nbsp;received</p><small class="notification-text"> You
                                                    have <span id="note_pending">0</span> unread messages</small>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_clinic_leader')): ?>
                                                <p class="media-heading"><span class="font-weight-bolder">New
                                                        clinic pending message</span>&nbsp;received</p><small
                                                    class="notification-text"> You
                                                    have <span id="note_pending">0</span> unread messages</small>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </a>
                                <a class="d-flex"
                                    href="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_campus')): ?> <?php echo e(url('request/3')); ?> <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_clinic')): ?> <?php echo e(url('pharmacy-request/2')); ?><?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_clinic_leader')): ?> <?php echo e(url('list-all-request')); ?> <?php endif; ?>"
                                    id="delivery">
                                    <div class="media d-flex align-items-start">
                                        <div class="media-left">
                                            <div class="avatar bg-light-danger">
                                                <div class="avatar-content">
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_clinic_leader')): ?>
                                                        STAFF
                                                    <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_campus')): ?>
                                                        RFD
                                                    <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_clinic')): ?>
                                                        RFD
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="media-body">
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_campus')): ?>
                                                <p class="media-heading"><span class="font-weight-bolder" id="delivery">New
                                                        ready for delivery message</span>&nbsp;received</p><small
                                                    class="notification-text"> You
                                                    have <span id="note_delivery">0</span> unread messages</small>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_clinic')): ?>
                                                <p class="media-heading"><span class="font-weight-bolder" id="delivery">New
                                                        ready for delivery message</span>&nbsp;received</p><small
                                                    class="notification-text"> You
                                                    have <span id="note_delivery">0</span> unread messages</small>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_clinic_leader')): ?>
                                                <p class="media-heading"><span class="font-weight-bolder" id="delivery">New
                                                        staff pending message</span>&nbsp;received</p><small
                                                    class="notification-text"> You
                                                    have <span id="note_delivery">0</span> unread messages</small>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </a>
                                </a>
                            </li>
                            <li class="dropdown-menu-footer"><a class="btn btn-primary btn-block"
                                    href="javascript:void(0)">Read all
                                    notifications</a></li>
                        </ul>
                    </li>
                    <li class="nav-item dropdown dropdown-user"><a class="nav-link dropdown-toggle dropdown-user-link"
                            id="dropdown-user" href="javascript:void(0);" data-toggle="dropdown" aria-haspopup="true"
                            aria-expanded="false">
                            <div class="user-nav d-sm-flex d-none"><span
                                    class="user-name font-weight-bolder"><?php echo e(auth()->user()->name); ?></span><span
                                    class="user-status">
                                    <?php $__currentLoopData = auth()->user()->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="badge bg-primary"><?php echo e($role->name); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </span></div><span class="avatar"><img class="round" src="<?php echo url('uploads/1.png'); ?>"
                                    alt="avatar" height="40" width="40"><span class=""
                                    id="check-status"></span></span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdown-user"><a
                                class="dropdown-item" href="<?php echo e(url('profile')); ?>"><i class="mr-50"
                                    data-feather="user"></i>

                                Profile</a><a class="dropdown-item" href="<?php echo e(url('change_password')); ?>"><i
                                    class="mr-50" data-feather="key"></i>

                                Change Password</a>
                            <a class="dropdown-item" href="<?php echo e(url('logout')); ?>"><i class="mr-50"
                                    data-feather="power"></i>
                                Logout</a>
                        </div>
                    </li>
                </ul>
            </div>
        </nav>
        <ul class="main-search-list-defaultlist-other-list d-none">
            <li class="auto-suggestion justify-content-between"><a
                    class="d-flex align-items-center justify-content-between w-100 py-50">
                    <div class="d-flex justify-content-start"><span class="mr-75"
                            data-feather="alert-circle"></span><span>No results found.</span></div>
                </a></li>
        </ul>
        <!-- END: Header-->


        <!-- BEGIN: Main Menu-->
        <div class="main-menu menu-fixed menu-light menu-accordion menu-shadow" data-scroll-to-active="true"
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dorm_admin')): ?> style="background: #161d31"; <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('proctor')): ?> style="background: #161d31"<?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('coordinator')): ?> style="background: #161d31"<?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('management')): ?> style="background: #161d31" <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('finance')): ?> style="background: #161d31" <?php endif; ?>>
            <div class="navbar-header">
                <ul class="nav navbar-nav flex-row">
                    <li class="nav-item mr-auto"><a class="navbar-brand" href="<?php echo e(url('/dashboard')); ?>">

                            <img src="<?php echo url('uploads/logo.png'); ?>" alt="" id="cimg"
                                class="img-fluid img-thumbnail" width="40" height="35">

                            <h3 class="brand-text">WRU-<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('support_admin')): ?>
                                    <span id="support_short_title"></span>
                                <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('support_staff')): ?>
                                    <span id="support_short_title"></span>
                                <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dorm_admin')): ?>
                                    <span id="dorm_short_title"></span>
                                <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('proctor')): ?>
                                    <span id="dorm_short_title"></span>
                                <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('coordinator')): ?>
                                    <span id="dorm_short_title"></span>
                                <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('finance')): ?>
                                    <span id="dorm_short_title"></span>
                                <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('management')): ?>
                                    <span id="dorm_short_title"></span>
                                <?php else: ?>
                                    <span id="clinic_short_title"></span>
                                <?php endif; ?>
                            </h3>
                        </a></li>
                    <li class="nav-item nav-toggle"><a class="nav-link modern-nav-toggle pr-0" data-toggle="collapse"
                            style="padding-top: 8px;"><i class="d-block d-xl-none text-primary toggle-icon font-medium-4"
                                data-feather="x"></i><i
                                class="d-none d-xl-block collapse-toggle-icon font-medium-4  text-primary"
                                data-feather="disc" data-ticon="disc"></i></a></li>
                </ul>
            </div>
            <div class="shadow-bottom"></div>
            <div class="main-menu-content">
                <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation"
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dorm_admin')): ?> style="background: #161d31;"; <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('proctor')): ?> style="background: #161d31;"; <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('coordinator')): ?> style="background: #161d31;"; <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('management')): ?> style="background: #161d31;"; <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('finance')): ?> style="background: #161d31;"; <?php endif; ?>>

                    <li class=" navigation-header"
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dorm_admin')): ?> style="color: white;"; <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('proctor')): ?> style="color: white;"; <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('coordinator')): ?> style="color: white;"; <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('management')): ?> style="color: white;"; <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('finance')): ?> style="color: white;"; <?php endif; ?>>
                        <span data-i18n="Apps &amp; Pages"><?php echo e(__('layout.apps')); ?> &amp;
                            <?php echo e(__('layout.pages')); ?></span><i data-feather="more-horizontal"></i>
                    </li>

                    <!-- Nav Item - Dashboard -->
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('dashboard')); ?>"
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dorm_admin')): ?> style="color: white;"; <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('proctor')): ?> style="color: white;"; <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('proctor')): ?> style="color: white;"; <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('coordinator')): ?> style="color: white;"; <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('management')): ?> style="color: white;"; <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('finance')): ?> style="color: white;"; <?php endif; ?>>
                            <i class="fas fa-fw fa-tachometer-alt"></i>
                            <span><?php echo e(__('layout.dashboard')); ?></span></a>
                    </li>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_admin')): ?>
                        <li class=" nav-item"><a class="d-flex align-items-center" href="#"><i
                                    data-feather="align-justify"></i><span class="menu-title text-truncate"
                                    data-i18n="clicni"> Registry</span></a>
                            <ul class="menu-content">
                                <li><a class="d-flex align-items-center" href="<?php echo e(url('product')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="campus">Items</span></a>
                                </li>
                                <li><a class="d-flex align-items-center" href="<?php echo e(url('category')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="campus">Category</span></a>
                                </li>
                                <li><a class="d-flex align-items-center" href="<?php echo e(url('room')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="campus">Room</span></a>
                                </li>

                                <li><a class="d-flex align-items-center" href="<?php echo e(url('unit')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="campus">UoM</span></a>
                                </li>
                                

                                <li><a class="d-flex align-items-center" href="<?php echo e(url('quality_checker')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="campus">Quality Checker</span></a>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item"><a class="d-flex align-items-center" href="<?php echo e(url('students')); ?>"><i
                                    data-feather="users"></i><span class="menu-item text-truncate"
                                    data-i18n="campus">Students</span></a>
                        </li>
                        <li class=" nav-item"><a class="d-flex align-items-center" href="#"><i
                                    data-feather="users"></i><span class="menu-title text-truncate"
                                    data-i18n="account">Account</span></a>
                            <ul class="menu-content">
                                <li><a class="d-flex align-items-center" href="<?php echo e(url('users')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="users">Users</span></a>
                                </li>
                                <li><a class="d-flex align-items-center" href="<?php echo e(url('roles')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="roles">Roles</span></a>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item"><a class="d-flex align-items-center" href="<?php echo e(url('settings')); ?>"><i
                                    data-feather="settings"></i><span class="menu-item text-truncate"
                                    data-i18n="campus">System
                                    Setting</span></a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_campus')): ?>
                        
                        <li class="nav-item"><a class="d-flex align-items-center" href="<?php echo e(url('campusStore')); ?>"><i
                                    data-feather="briefcase"></i><span class="menu-item text-truncate"
                                    data-i18n="campus">Campus
                                    Store</span></a>
                        </li>
                        <li class=" nav-item"><a class="d-flex align-items-center" href="#"><i
                                    data-feather="inbox"></i><span class="menu-title text-truncate"
                                    data-i18n="clicni">Request</span></a>
                            <ul class="menu-content">
                                <li><a class="d-flex align-items-center" href="<?php echo e(url('list-all')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="campus">List All</span></a>
                                </li>
                                <li><a class="d-flex align-items-center" href="<?php echo e(url('request/2')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="campus">Pending</span></a>
                                </li>
                                <li><a class="d-flex align-items-center" href="<?php echo e(url('request/3')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="campus">Out of Delivery</span></a>
                                </li>
                                <li><a class="d-flex align-items-center" href="<?php echo e(url('request/4')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="campus">Done</span></a>
                                </li>
                            </ul>
                        </li>
                        

                        <li class=" nav-item"><a class="d-flex align-items-center" href="#"><i
                                    data-feather="file"></i><span class="menu-title text-truncate"
                                    data-i18n="account">Report</span></a>
                            <ul class="menu-content">
                                <li><a class="d-flex align-items-center" href="<?php echo e(url('general-campus-report')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="users">General Report</span></a>
                                </li>
                                <li><a class="d-flex align-items-center" href="<?php echo e(url('report-campus')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="roles">Specific
                                            Report</span></a>
                                </li>
                            </ul>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_register')): ?>
                        <li class="nav-item"><a class="d-flex align-items-center" href="<?php echo e(url('studentsregister')); ?>"><i
                                    data-feather="users"></i><span class="menu-item text-truncate"
                                    data-i18n="campus">Patients</span></a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_doctor')): ?>
                        <li class="nav-item"><a class="d-flex align-items-center" href="<?php echo e(url('patient_doctor')); ?>"><i
                                    data-feather="users"></i><span class="menu-item text-truncate"
                                    data-i18n="campus">Patients</span></a>
                        </li>
                        <li class="nav-item"><a class="d-flex align-items-center" href="<?php echo e(url('emergency_patient')); ?>"><i
                                    data-feather="users"></i><span class="menu-item text-truncate"
                                    data-i18n="campus">Emergency Patients</span></a>
                        </li>
                        <li class="nav-item"><a class="d-flex align-items-center" href="<?php echo e(url('appointments')); ?>"><i
                                    data-feather="clock"></i><span class="menu-item text-truncate"
                                    data-i18n="campus">Appointments</span></a>
                        </li>
                        <li class="nav-item"><a class="d-flex align-items-center" href="<?php echo e(url('clinicStock')); ?>"><i
                                    data-feather="briefcase"></i><span class="menu-item text-truncate"
                                    data-i18n="campus">Clinic
                                    Store</span></a>
                        </li>

                        <li class=" nav-item"><a class="d-flex align-items-center" href="#"><i
                                    data-feather="send"></i><span class="menu-title text-truncate"
                                    data-i18n="clicni">Request</span></a>
                            <ul class="menu-content">
                                <li><a class="d-flex align-items-center" href="<?php echo e(url('list-all-request')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="campus">List All</span></a>
                                </li>
                                <li><a class="d-flex align-items-center" href="<?php echo e(url('pharmacy-request/1')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="campus">Pending</span></a>
                                </li>
                                <li><a class="d-flex align-items-center" href="<?php echo e(url('pharmacy-request/2')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="campus">Out of Delivery</span></a>
                                </li>
                                <li><a class="d-flex align-items-center" href="<?php echo e(url('pharmacy-request/3')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="campus">Done</span></a>
                                </li>
                                <li><a class="d-flex align-items-center" href="<?php echo e(url('pharmacy-request/4')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="campus">Rejected</span></a>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item"><a class="d-flex align-items-center" href="<?php echo e(url('stock')); ?>"><i
                                    data-feather="briefcase"></i><span class="menu-item text-truncate"
                                    data-i18n="campus">Stock</span></a>
                        </li>
                        <li class=" nav-item"><a class="d-flex align-items-center" href="#"><i
                                    data-feather="file"></i><span class="menu-title text-truncate"
                                    data-i18n="account">Report</span></a>
                            <ul class="menu-content">
                                <li><a class="d-flex align-items-center" href="<?php echo e(url('general-stock-report')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="users">General Report</span></a>
                                </li>
                                <li><a class="d-flex align-items-center" href="<?php echo e(url('report-stock')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="roles">Specific
                                            Report</span></a>
                                </li>
                            </ul>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_clinic')): ?>
                        <li class="nav-item"><a class="d-flex align-items-center" href="<?php echo e(url('campusStore')); ?>"><i
                                    data-feather="briefcase"></i><span class="menu-item text-truncate"
                                    data-i18n="campus">Campus
                                    Store</span></a>
                        </li>
                        <li class=" nav-item"><a class="d-flex align-items-center" href="#"><i
                                    data-feather="send"></i><span class="menu-title text-truncate"
                                    data-i18n="clicni">Your-Request</span></a>
                            <ul class="menu-content">
                                <li><a class="d-flex align-items-center" href="<?php echo e(url('list-all')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="campus">List All</span></a>
                                </li>
                                <li><a class="d-flex align-items-center" href="<?php echo e(url('request/2')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="campus">Pending</span></a>
                                </li>
                                <li><a class="d-flex align-items-center" href="<?php echo e(url('request/3')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="campus">Out of Delivery</span></a>
                                </li>
                                <li><a class="d-flex align-items-center" href="<?php echo e(url('request/4')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="campus">Done</span></a>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item"><a class="d-flex align-items-center" href="<?php echo e(url('clinic')); ?>"><i
                                    data-feather="briefcase"></i><span class="menu-item text-truncate"
                                    data-i18n="campus">Clinic
                                    Store</span></a>
                        </li>

                        <li class=" nav-item"><a class="d-flex align-items-center" href="#"><i
                                    data-feather="inbox"></i><span class="menu-title text-truncate"
                                    data-i18n="clicni">Received-Request</span></a>
                            <ul class="menu-content">
                                <li><a class="d-flex align-items-center" href="<?php echo e(url('list-all-request')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="campus">List All</span></a>
                                </li>
                                <li><a class="d-flex align-items-center" href="<?php echo e(url('pharmacy-request/1')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="campus">Pending</span></a>
                                </li>
                                <li><a class="d-flex align-items-center" href="<?php echo e(url('pharmacy-request/2')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="campus">Out of Delivery</span></a>
                                </li>
                                <li><a class="d-flex align-items-center" href="<?php echo e(url('pharmacy-request/3')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="campus">Done</span></a>
                                </li>
                                <li><a class="d-flex align-items-center" href="<?php echo e(url('pharmacy-request/4')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="campus">Rejected</span></a>
                                </li>
                            </ul>
                        </li>
                        <li class=" nav-item"><a class="d-flex align-items-center" href="#"><i
                                    data-feather="file"></i><span class="menu-title text-truncate"
                                    data-i18n="account">Report</span></a>
                            <ul class="menu-content">
                                <li><a class="d-flex align-items-center" href="<?php echo e(url('general-clinic-report')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="users">General Report</span></a>
                                </li>
                                <li><a class="d-flex align-items-center" href="<?php echo e(url('specific-clinic-report')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="roles">Specific
                                            Report</span></a>
                                </li>
                            </ul>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_clinic_leader')): ?>
                        <li class="nav-item"><a class="d-flex align-items-center" href="<?php echo e(url('schedule')); ?>"><i
                                    data-feather="briefcase"></i><span class="menu-item text-truncate"
                                    data-i18n="schedule">Employee Schedule</span></a>
                        </li>
                        <li class="nav-item"><a class="d-flex align-items-center" href="<?php echo e(url('campusStore')); ?>"><i
                                    data-feather="inbox"></i><span class="menu-item text-truncate" data-i18n="campus">Clinic
                                    Request</span></a>
                        </li>
                        <li class="nav-item"><a class="d-flex align-items-center" href="<?php echo e(url('list-all-request')); ?>"><i
                                    data-feather="inbox"></i><span class="menu-item text-truncate" data-i18n="campus">Staff
                                    Request</span></a>
                        </li>
                        <li class="nav-item"><a class="d-flex align-items-center" href="<?php echo e(url('clinic')); ?>"><i
                                    data-feather="briefcase"></i><span class="menu-item text-truncate"
                                    data-i18n="campus">Clinic
                                    Stock</span></a>
                        </li>
                        <li class="nav-item"><a class="d-flex align-items-center" href="<?php echo e(url('staffStock')); ?>"><i
                                    data-feather="briefcase"></i><span class="menu-item text-truncate"
                                    data-i18n="campus">Staff
                                    Stock</span></a>
                        </li>

                        <li class=" nav-item"><a class="d-flex align-items-center" href="#"><i
                                    data-feather="file"></i><span class="menu-title text-truncate"
                                    data-i18n="account">Report</span></a>
                            <ul class="menu-content">
                                <li><a class="d-flex align-items-center" href="<?php echo e(url('specific-clinic-report')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="users">Clinic Report</span></a>
                                </li>
                                <li><a class="d-flex align-items-center" href="<?php echo e(url('report-stock')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="roles">Staff
                                            Report</span></a>
                                </li>
                                <li><a class="d-flex align-items-center" href="<?php echo e(url('report-patient')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="roles">Patient
                                            Report</span></a>
                                </li>

                                <li class="nav-item"><a class="d-flex align-items-center"
                                        href="<?php echo e(url('emergency_patient')); ?>"><i data-feather="circle"></i><span
                                            class="menu-item text-truncate" data-i18n="campus">Emergency Patients</span></a>
                                </li>
                            </ul>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_pharmacy')): ?>
                        <li class="nav-item"><a class="d-flex align-items-center" href="<?php echo e(url('patient_pharmacy')); ?>"><i
                                    data-feather="users"></i><span class="menu-item text-truncate"
                                    data-i18n="campus">Patients</span></a>
                        </li>
                        <li class="nav-item"><a class="d-flex align-items-center" href="<?php echo e(url('emergency_patient')); ?>"><i
                                    data-feather="users"></i><span class="menu-item text-truncate"
                                    data-i18n="campus">Emergency Patients</span></a>
                        </li>
                        <li class="nav-item"><a class="d-flex align-items-center" href="<?php echo e(url('clinicStock')); ?>"><i
                                    data-feather="briefcase"></i><span class="menu-item text-truncate"
                                    data-i18n="campus">Clinic
                                    Store</span></a>
                        </li>

                        <li class=" nav-item"><a class="d-flex align-items-center" href="#"><i
                                    data-feather="send"></i><span class="menu-title text-truncate"
                                    data-i18n="clicni">Request</span></a>
                            <ul class="menu-content">
                                <li><a class="d-flex align-items-center" href="<?php echo e(url('list-all-request')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="campus">List All</span></a>
                                </li>
                                <li><a class="d-flex align-items-center" href="<?php echo e(url('pharmacy-request/1')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="campus">Pending</span></a>
                                </li>
                                <li><a class="d-flex align-items-center" href="<?php echo e(url('pharmacy-request/2')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="campus">Out of Delivery</span></a>
                                </li>
                                <li><a class="d-flex align-items-center" href="<?php echo e(url('pharmacy-request/3')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="campus">Done</span></a>
                                </li>
                                <li><a class="d-flex align-items-center" href="<?php echo e(url('pharmacy-request/4')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="campus">Rejected</span></a>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item"><a class="d-flex align-items-center" href="<?php echo e(url('stock')); ?>"><i
                                    data-feather="briefcase"></i><span class="menu-item text-truncate"
                                    data-i18n="campus">Stock</span></a>
                        </li>
                        <li class=" nav-item"><a class="d-flex align-items-center" href="#"><i
                                    data-feather="file"></i><span class="menu-title text-truncate"
                                    data-i18n="account">Report</span></a>
                            <ul class="menu-content">
                                <li><a class="d-flex align-items-center" href="<?php echo e(url('general-stock-report')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="users">General Report</span></a>
                                </li>
                                <li><a class="d-flex align-items-center" href="<?php echo e(url('report-stock')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="roles">Specific
                                            Report</span></a>
                                </li>
                            </ul>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_labratory')): ?>
                        <li class="nav-item"><a class="d-flex align-items-center" href="<?php echo e(url('patient_labratory')); ?>"><i
                                    data-feather="users"></i><span class="menu-item text-truncate"
                                    data-i18n="campus">Patients</span></a>
                        </li>
                        <li class="nav-item"><a class="d-flex align-items-center" href="<?php echo e(url('emergency_patient')); ?>"><i
                                    data-feather="users"></i><span class="menu-item text-truncate"
                                    data-i18n="campus">Emergency Patients</span></a>
                        </li>
                        <li class="nav-item"><a class="d-flex align-items-center" href="<?php echo e(url('clinicStock')); ?>"><i
                                    data-feather="briefcase"></i><span class="menu-item text-truncate"
                                    data-i18n="campus">Clinic
                                    Store</span></a>
                        </li>

                        <li class=" nav-item"><a class="d-flex align-items-center" href="#"><i
                                    data-feather="send"></i><span class="menu-title text-truncate"
                                    data-i18n="clicni">Request</span></a>
                            <ul class="menu-content">
                                <li><a class="d-flex align-items-center" href="<?php echo e(url('list-all-request')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="campus">List All</span></a>
                                </li>
                                <li><a class="d-flex align-items-center" href="<?php echo e(url('pharmacy-request/1')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="campus">Pending</span></a>
                                </li>
                                <li><a class="d-flex align-items-center" href="<?php echo e(url('pharmacy-request/2')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="campus">Out of Delivery</span></a>
                                </li>
                                <li><a class="d-flex align-items-center" href="<?php echo e(url('pharmacy-request/3')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="campus">Done</span></a>
                                </li>
                                <li><a class="d-flex align-items-center" href="<?php echo e(url('pharmacy-request/4')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="campus">Rejected</span></a>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item"><a class="d-flex align-items-center" href="<?php echo e(url('stock')); ?>"><i
                                    data-feather="briefcase"></i><span class="menu-item text-truncate"
                                    data-i18n="campus">Stock</span></a>
                        </li>
                        <li class=" nav-item"><a class="d-flex align-items-center" href="#"><i
                                    data-feather="file"></i><span class="menu-title text-truncate"
                                    data-i18n="account">Report</span></a>
                            <ul class="menu-content">
                                <li><a class="d-flex align-items-center" href="<?php echo e(url('general-stock-report')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="users">General Report</span></a>
                                </li>
                                <li><a class="d-flex align-items-center" href="<?php echo e(url('report-stock')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="roles">Specific
                                            Report</span></a>
                                </li>
                            </ul>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('support_admin')): ?>
                        <li class=" nav-item"><a class="d-flex align-items-center" href="#"><i
                                    data-feather="align-justify"></i><span class="menu-title text-truncate"
                                    data-i18n="clicni"> Registry</span></a>
                            <ul class="menu-content">
                                <li><a class="d-flex align-items-center" href="<?php echo e(url('items')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="campus">Items</span></a>
                                </li>

                                <li><a class="d-flex align-items-center" href="<?php echo e(url('support_students')); ?>"><i
                                            data-feather="circle"></i><span class="menu-item text-truncate"
                                            data-i18n="campus">Students</span></a>
                                </li>

                            </ul>
                        </li>
                        <li class="nav-item"><a class="d-flex align-items-center" href="<?php echo e(url('support_items')); ?>"><i
                                    data-feather="box"></i><span class="menu-item text-truncate" data-i18n="campus">Received
                                    Items</span></a>
                        </li>
                        <li class=" nav-item"><a class="d-flex align-items-center" href="<?php echo e(url('report-support')); ?>"><i
                                    data-feather="file"></i><span class="menu-title text-truncate"
                                    data-i18n="account">Report</span></a>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('support_staff')): ?>
                        <li class="nav-item"><a class="d-flex align-items-center" href="<?php echo e(url('support_items')); ?>"><i
                                    data-feather="box"></i><span class="menu-item text-truncate"
                                    data-i18n="campus">Items</span></a>
                        </li>

                        <li class=" nav-item"><a class="d-flex align-items-center" href="<?php echo e(url('report-support')); ?>"><i
                                    data-feather="file"></i><span class="menu-title text-truncate"
                                    data-i18n="account">Report</span></a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dorm_admin')): ?>
                        <li class="nav-item"><a class="d-flex align-items-center"
                                href="<?php echo e(url('blocks')); ?>"<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dorm_admin')): ?> style="color: white;" <?php endif; ?>><i
                                    data-feather="home"></i><span class="menu-item text-truncate"
                                    data-i18n="campus"><?php echo e(__('layout.blocks')); ?></span></a>
                        </li>
                        <li class="nav-item"><a class="d-flex align-items-center"
                                href="<?php echo e(url('dorms')); ?>"<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dorm_admin')): ?> style="color: white;" <?php endif; ?>><i
                                    data-feather="home"></i><span class="menu-item text-truncate" data-i18n="campus">Manage
                                    Dorms</span></a>
                        </li>
                        <li class="nav-item"><a class="d-flex align-items-center"
                                href="<?php echo e(url('dorm_students')); ?>"<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dorm_admin')): ?> style="color: white;" <?php endif; ?>><i
                                    data-feather="users"></i><span class="menu-item text-truncate"
                                    data-i18n="campus"><?php echo e(__('layout.students')); ?></span></a>
                        </li>
                        <li class="nav-item"><a class="d-flex align-items-center"
                                href="<?php echo e(url('dorm_services')); ?>"<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dorm_admin')): ?> style="color: white;" <?php endif; ?>><i
                                    data-feather="map-pin"></i><span class="menu-item text-truncate"
                                    data-i18n="campus">Services</span></a>
                        </li>
                        <li class=" nav-item"><a
                                class="d-flex align-items-center"<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dorm_admin')): ?> style="background: #161d31;" <?php endif; ?>
                                href="#"><i data-feather="users" style="color: white;"></i><span
                                    class="menu-title text-truncate" data-i18n="account"
                                    style="color: white;">Account</span></a>
                            <ul class="menu-content">
                                <li><a class="d-flex align-items-center"<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dorm_admin')): ?> style="color: white;" <?php endif; ?>
                                        href="<?php echo e(url('users')); ?>"><i data-feather="circle"></i><span
                                            class="menu-item text-truncate" data-i18n="users">Users</span></a>
                                </li>
                                <li><a class="d-flex align-items-center"<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dorm_admin')): ?> style="color: white;" <?php endif; ?>
                                        href="<?php echo e(url('roles')); ?>"><i data-feather="circle"></i><span
                                            class="menu-item text-truncate" data-i18n="roles">Roles</span></a>
                                </li>

                            </ul>
                        </li>
                        <hr>
                        <li class=" navigation-header"
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dorm_admin')): ?> style="color: white;"; <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dormitory_staff')): ?> style="background: #161d31;"; <?php endif; ?>>
                            <span data-i18n="Apps &amp; Pages">System Information</span><i data-feather="more-horizontal"></i>
                        </li>
                        <li><a class="d-flex align-items-center" style="color: white;" href="usage"><i
                                    data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="roles">How to
                                    Use</span></a>
                        </li>
                        <li><a class="d-flex align-items-center" style="color: white;" href="ask_question"><i
                                    data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="roles">Ask
                                    Question</span></a>
                        </li>
                        <li><a class="d-flex align-items-center"<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dorm_admin')): ?> style="color: rgb(85, 31, 235);" <?php endif; ?>
                                href="https://wru.edu.et" target="blanck"><span class="menu-item text-truncate"
                                    data-i18n="roles">Werabe
                                    University</span></a>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('finance')): ?>
                        <li class="nav-item"><a class="d-flex align-items-center" href="<?php echo e(url('service_payment')); ?>"
                                style="color: white;"><i data-feather="map-pin"></i><span class="menu-item text-truncate"
                                    data-i18n="campus">Payment Request</span></a>
                        </li>
                        <hr>
                        <li class=" navigation-header" style="background: #161d31;";>
                            <span data-i18n="Apps &amp; Pages">System Information</span><i data-feather="more-horizontal"></i>
                        </li>
                        <li><a class="d-flex align-items-center" style="color: white;" href=""><i
                                    data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="roles">How to
                                    Use</span></a>
                        </li>
                        <li><a class="d-flex align-items-center" style="color: white;" href=""><i
                                    data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="roles">Ask
                                    Question</span></a>
                        </li>
                        <li><a class="d-flex align-items-center" style="color: rgb(85, 31, 235);" href="https://wru.edu.et"
                                target="blanck"><span class="menu-item text-truncate" data-i18n="roles">Werabe
                                    University</span></a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('proctor')): ?>
                        <li class="nav-item"><a class="d-flex align-items-center" href="<?php echo e(url('dorms')); ?>"
                                style="color: white;"><i data-feather="home"></i><span class="menu-item text-truncate"
                                    data-i18n="campus">Manage
                                    Dorms</span></a>
                        </li>
                        <li class="nav-item"><a class="d-flex align-items-center" href="<?php echo e(url('dorm_services')); ?>"
                                style="color: white;"><i data-feather="map-pin"></i><span class="menu-item text-truncate"
                                    data-i18n="campus">Services</span></a>
                        </li>
                        <li class="nav-item"><a class="d-flex align-items-center" href="<?php echo e(url('dorm_students')); ?>"
                                style="color: white;"><i data-feather="users"></i><span class="menu-item text-truncate"
                                    data-i18n="campus"><?php echo e(__('layout.students')); ?></span></a>
                        </li>
                        <hr>
                        <li class=" navigation-header" style="color: white;";>
                            <span data-i18n="Apps &amp; Pages">System Information</span><i data-feather="more-horizontal"></i>
                        </li>
                        <li><a class="d-flex align-items-center" style="color: white;" href="usage"><i
                                    data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="roles">How to
                                    Use</span></a>
                        </li>
                        <li><a class="d-flex align-items-center" style="color: white;" href="ask_question"><i
                                    data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="roles">Ask
                                    Question</span></a>
                        </li>
                        <li><a class="d-flex align-items-center" style="color: rgb(85, 31, 235);" href="https://wru.edu.et"
                                target="blanck"><span class="menu-item text-truncate" data-i18n="roles">Werabe
                                    University</span></a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('coordinator')): ?>
                        <li class="nav-item"><a class="d-flex align-items-center" href="<?php echo e(url('blocks')); ?>"
                                style="color: white;"><i data-feather="home"></i><span class="menu-item text-truncate"
                                    data-i18n="campus">Blocks</span></a>
                        </li>
                        <li class="nav-item"><a class="d-flex align-items-center" href="<?php echo e(url('dorms')); ?>"
                                style="color: white;"><i data-feather="home"></i><span class="menu-item text-truncate"
                                    data-i18n="campus">
                                    Dorms</span></a>
                        </li>
                        <li class="nav-item"><a class="d-flex align-items-center" href="<?php echo e(url('dorm_services')); ?>"
                                style="color: white;"><i data-feather="map-pin"></i><span class="menu-item text-truncate"
                                    data-i18n="campus">Services</span></a>
                        </li>
                        <li class="nav-item"><a class="d-flex align-items-center" href="<?php echo e(url('dorm_students')); ?>"
                                style="color: white;"><i data-feather="users"></i><span class="menu-item text-truncate"
                                    data-i18n="campus"><?php echo e(__('layout.students')); ?></span></a>
                        </li>
                        <li class="nav-item"><a class="d-flex align-items-center" href="<?php echo e(url('users')); ?>"
                                style="color: white;"><i data-feather="circle"></i><span class="menu-item text-truncate"
                                    data-i18n="campus">Manage Proctor</span></a>
                        </li>
                        <hr>
                        <li class=" navigation-header" style="color: white;";>
                            <span data-i18n="Apps &amp; Pages">System Information</span><i data-feather="more-horizontal"></i>
                        </li>
                        <li><a class="d-flex align-items-center" style="color: white;" href="usage"><i
                                    data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="roles">How to
                                    Use</span></a>
                        </li>
                        <li><a class="d-flex align-items-center" style="color: white;" href="ask_question"><i
                                    data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="roles">Ask
                                    Question</span></a>
                        </li>
                        <li><a class="d-flex align-items-center" style="color: rgb(85, 31, 235);" href="https://wru.edu.et"
                                target="blanck"><span class="menu-item text-truncate" data-i18n="roles">Werabe
                                    University</span></a>
                        </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('management')): ?>
                        <li class="nav-item"><a class="d-flex align-items-center" href="<?php echo e(url('blocks')); ?>"
                                style="color: white;"><i data-feather="home"></i><span class="menu-item text-truncate"
                                    data-i18n="campus"><?php echo e(__('layout.blocks')); ?></span></a>
                        </li>
                        <li class="nav-item"><a class="d-flex align-items-center" href="<?php echo e(url('dorms')); ?>"
                                style="color: white;"><i data-feather="home"></i><span class="menu-item text-truncate"
                                    data-i18n="campus">Manage
                                    Dorms</span></a>
                        </li>
                        <li class="nav-item"><a class="d-flex align-items-center" href="<?php echo e(url('dorm_students')); ?>"
                                style="color: white;"><i data-feather="users"></i><span class="menu-item text-truncate"
                                    data-i18n="campus"><?php echo e(__('layout.students')); ?></span></a>
                        </li>
                        <li class="nav-item"><a class="d-flex align-items-center" href="<?php echo e(url('dorm_services')); ?>"
                                style="color: white;"><i data-feather="map-pin"></i><span class="menu-item text-truncate"
                                    data-i18n="campus">Services</span></a>
                        </li>
                        <li class="nav-item"><a class="d-flex align-items-center" href="<?php echo e(url('service_payment')); ?>"
                                style="color: white;"><i data-feather="circle"></i><span class="menu-item text-truncate"
                                    data-i18n="campus">Service Payment</span></a>
                        </li>
                        <hr>
                        <li class=" navigation-header" style="color: white;";>
                            <span data-i18n="Apps &amp; Pages">System Information</span><i
                                data-feather="more-horizontal"></i>
                        </li>
                        <li><a class="d-flex align-items-center" style="color: white;" href="usage"><i
                                    data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="roles">How
                                    to
                                    Use</span></a>
                        </li>
                        <li><a class="d-flex align-items-center" style="color: white;" href="ask_question"><i
                                    data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="roles">Ask
                                    Question</span></a>
                        </li>
                        <li><a class="d-flex align-items-center" style="color: rgb(85, 31, 235);"
                                href="https://wru.edu.et" target="blanck"><span class="menu-item text-truncate"
                                    data-i18n="roles">Werabe
                                    University</span></a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
        <!-- END: Main Menu-->

        <!-- BEGIN: Content-->
        <div id="main-content">
            <?php echo $__env->yieldContent('content'); ?>;
        </div>
        <!-- END: Content-->

        <div class="sidenav-overlay"></div>
        <div class="drag-target"></div>

        <!-- BEGIN: Footer-->
        <footer class="footer footer-static footer-light fixed-bottom">
            <p class="clearfix mb-0"><span class="float-md-left d-block d-md-inline-block mt-25">COPYRIGHT &copy;
                    2024<a class="ml-25" href="https://wru.edu.et" target="_blank">Werabe
                        University</a><span class="d-none d-sm-inline-block">, All rights
                        Reserved</span></span><span class="float-md-right d-none d-md-block">Made By <span><a
                            href="mailto:mekiermena72@gmail.com">Meki Ermena(+251925139032)</a></p>
        </footer>
        <button class="btn btn-primary btn-icon scroll-top" type="button"><i data-feather="arrow-up"></i></button>
        <!-- END: Footer-->
    <?php else: ?>
        <div>
            <?php echo $__env->yieldContent('auth_content'); ?>;
        </div>
    <?php endif; ?>
    <script src="/js/app.js"></script>
    
    <!-- BEGIN: Vendor JS-->
    <script src="<?php echo e(asset('app-assets/vendors/js/vendors.min.js')); ?>"></script>
    <!-- BEGIN Vendor JS-->
    <!-- BEGIN: Page Vendor JS-->
    
    <script src="<?php echo e(asset('customjs/sweetalert2.all.min.js')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/toaster/toastr.js')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/vendors/js/charts/apexcharts.min.js')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/vendors/js/extensions/toastr.min.js')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/vendors/js/forms/spinner/jquery.bootstrap-touchspin.js')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/js/dataTables.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/js/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/js/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/js/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/js/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/js/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/js/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/timepicker.js')); ?>"></script>
    

    <!-- END: Page Vendor JS-->

    <!-- BEGIN: Theme JS-->
    <script src="<?php echo e(asset('app-assets/js/core/app-menu.js')); ?>"></script>
    <script src="<?php echo e(asset('app-assets/js/core/app.js')); ?>"></script>
    <!-- END: Theme JS-->

    <!--End Load Custom Javascripts-->
    <script type="text/javascript" src="<?php echo e(asset('customjs/moment.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('customjs/moment.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('customjs/daterangepicker.min.js')); ?>"></script>
    

    <script type="text/javascript" src="<?php echo e(asset('customjs/quill.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('customjs/jquery-ui.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('customjs/jquery.highlight.js')); ?>"></script>
    

    <script type="text/javascript" src="<?php echo e(asset('customjs/dateandtime.js')); ?>"></script>

    <script type="text/javascript" src="<?php echo e(asset('app-assets/js/scripts/forms/pickers/form-pickers.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('customjs/datetimepicker.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/clockpicker.js')); ?>"></script>

    <!-- Page level plugins -->
    <script src="<?php echo e(asset('admin_assets/vendor/chart.js/Chart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_assets/js/demo/chart-area-demo.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_assets/js/demo/chart-pie-demo.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            $('.clockpicker').clockpicker({
                donetext: 'Done', // Text for the "Done" button
                autoclose: true, // Close the picker when clicking outside
                twelvehour: true, // Use 24-hour format
            });
        });
    </script>


    
    
    <!-- BEGIN: Page JS-->
    

    <script type="text/javascript"
        src="https://cdn.datatables.net/plug-ins/1.11.6/features/searchHighlight/dataTables.searchHighlight.min.js">
    </script>

    <link rel="stylesheet" href="<?php echo e(asset('assets/datepicker.css')); ?>">
    <script src="<?php echo e(asset('assets/datepicker.min.js')); ?>"></script>
    
    <!-- END: Yajra table JS   -->

    <script type="text/javascript">
        $(function() {
            cardSection = $('#page-block');
        });

        $(window).on('load', function() {
            if (feather) {
                feather.replace({
                    width: 14,
                    height: 14
                });
            }
        });

        function changeLanguage() {
            var locale = document.getElementById('languageSwitcher').value;
            $.get('/lang/' + locale, function(data) {
                if (data.success) {
                    location.reload();
                }
            });
        }

        function closemodal() {
            $('#expirenotice').modal('hide');
        }
    </script>
    <script>
        function toastrMessage($type, $message, $info) {
            toastr[$type]($message, $info, {
                "closeButton": true,
                "debug": true,
                "newestOnTop": true,
                "progressBar": true,
                "positionClass": "toast-top-center",
                "preventDuplicates": true,
                "preventOpenDuplicates": true,
                "onclick": null,
                "showDuration": "3000",
                "hideDuration": "1000",
                "timeOut": "10000",
                "extendedTimeOut": "10000",
                "showEasing": "easeOutBounce",
                "hideEasing": "easeInBack",
                "showMethod": "fadeIn",
                "hideMethod": "fadeOut"
            });
        }
        $('#check-status').removeClass('avatar-status-offline');
        $('#check-status').addClass('avatar-status-online');
        $.get('/gettitle', function(data) {
            if (data.system) {
                $('#clinic_title').html(data.system.clinic_system_name);
                $('#support_title').html(data.system.support_system_name);
                $('#clinic_short_title').html(data.system.clinic_system_short_name);
                $('#support_short_title').html(data.system.support_system_short_name);
                $('#dorm_title').html(data.system.dorm_system_name);
                $('#dorm_short_title').html(data.system.dorm_system_short_name);
            }
        });
        $.get('/check-status', function(data) {
            if (data.online) {
                $('#check-status').removeClass('avatar-status-offline');
                $('#check-status').addClass("avatar-status-online");
            } else if (data.offline) {
                $('#check-status').removeClass("avatar-status-online");
                $('#check-status').addClass("avatar-status-offline");
            } else {
                $('#check-status').removeClass('avatar-status-online');
                $('#check-status').addClass('avatar-status-offline');
            }
        })
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_campus')): ?>
            $.get('/campus-notification', function(data) {
                if (data.counts) {
                    $('.note').html(data.counts);
                    $('#note_pending').html(data.pending);
                    $('#note_delivery').html(data.delivery);
                }
            })
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_clinic_leader')): ?>
            $.get('/leader-notification', function(data) {
                if (data.success) {
                    $('.note').html(data.all_request);
                    $('#note_pending').html(data.clinic);
                    $('#note_delivery').html(data.staff);
                }
            })
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_clinic')): ?>
            $.get('/clinic-notification', function(data) {
                if (data.counts) {
                    $('.note').html(data.counts);
                    $('#note_pending').html(data.pending);
                    $('#note_delivery').html(data.delivery);
                }
            })
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_doctor')): ?>
            $.get('/doctor-notification', function(data) {
                if (data.count) {
                    $('.note').html(data.count);
                    $('#note_pending').html(data.count);
                }
            })
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_pharmacy')): ?>
            $.get('/pharmacy-notification', function(data) {
                if (data.pending) {
                    $('.note').html(data.pending);
                    $('#note_pending').html(data.pending);
                }
            })
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_labratory')): ?>
            $.get('/labratory-notification', function(data) {
                if (data.count) {
                    $('.note').html(data.count);
                    $('#note_pending').html(data.count);
                }
            })
        <?php endif; ?>
    </script>
    <script src="<?php echo e(asset('admin_assets/select2.js')); ?>"></script>
    
    <div style="display: none">
        <?php echo $__env->yieldContent('scripts'); ?>
    </div>
</body>
<!-- END: Body-->

</html>
<?php /**PATH C:\xampp\htdocs\Werabe University Project\Werabe University Project\resources\views/layouts/app.blade.php ENDPATH**/ ?>