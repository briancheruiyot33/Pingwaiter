<?php $__env->startSection('title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="app-content content">
        <section id="responsive-datatable">
            <div class="row">
                <div class="col-12">
                    <?php $__currentLoopData = $system; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $system): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!-- Your HTML content goes here -->
                        <div class="card">
                            <div class="card-header"
                                style="justify-content: center; background:rgb(42, 179, 88); color:
                            white; font-size: 20px;">
                                Clinic System Setting
                            </div>
                            <br>
                            <div class="card-body">
                                <div class="form-group">
                                    <label style="padding-left: 10px;">Clinic System Name</label>
                                    <input type="text" name="clinic_name" class="form-control"
                                        placeholder="Write Clinic system name here"
                                        value="<?php echo e($system->clinic_system_name); ?>" id="clinic_name">
                                </div>
                                <div class="form-group">
                                    <label style="padding-left: 10px;">Clinic System Short Name</label>
                                    <input type="text" name="clinic_short_name" class="form-control"
                                        placeholder="Write Clinic system short name here"
                                        value="<?php echo e($system->clinic_system_short_name); ?>" id="clinic_short_name">
                                </div>

                                <br>
                                <button class="btn btn-success" id="clinic_button">Save & Change</button>
                            </div>

                        </div>
                        <div class="card">
                            <div class="card-header"
                                style="justify-content: center; border: 1px solid blue; background: rgb(57, 57, 214); color: white; font-size: 20px; margin-bottomg: 10px;">
                                Support
                                System Setting</div>
                            <hr>
                            <div class="card-body">
                                <div class="form-group">
                                    <label style="padding-left: 10px;">Support System Name</label>
                                    <input type="text" name="support_name" class="form-control"
                                        placeholder="Write Support system name here"
                                        value="<?php echo e($system->support_system_name); ?>" id="support_name">
                                </div>
                                <div class="form-group">
                                    <label style="padding-left: 10px;">Support System Short Name</label>
                                    <input type="text" name="support_short_name" class="form-control"
                                        placeholder="Write Support System Short Name here"
                                        value="<?php echo e($system->support_system_short_name); ?>" id="support_short_name">
                                </div>
                                <button class="btn btn-success text-center" id="support_button">Save & Change</button>
                            </div>

                        </div>

                        <div class="card">
                            <div class="card-header"
                                style="justify-content: center; border: 1px solid blue; background: rgb(57, 57, 214); color: white; font-size: 20px; margin-bottomg: 10px;">
                                Dorm
                                System Setting</div>
                            <hr>
                            <div class="card-body">
                                <div class="form-group">
                                    <label style="padding-left: 10px;">Dorm System Name</label>
                                    <input type="text" name="dorm_name" class="form-control"
                                        placeholder="Write Dorm system name here" value="<?php echo e($system->dorm_system_name); ?>"
                                        id="dorm_name">
                                </div>
                                <div class="form-group">
                                    <label style="padding-left: 10px;">Dorm System Short Name</label>
                                    <input type="text" name="dorm_short_name" class="form-control"
                                        placeholder="Write Dorm System Short Name here"
                                        value="<?php echo e($system->dorm_system_short_name); ?>" id="dorm_short_name">
                                </div>
                                <button class="btn btn-success text-center" id="dorm_button">Save & Change</button>
                            </div>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $('#clinic_button').click(function() {
            $.get('/change_clinic_setting/' + $('#clinic_name').val() + '/' + $('#clinic_short_name')
                .val(),
                function(data) {
                    if (data.success) {
                        alert_toast(data.success, 'success')
                    } else {
                        alert_toast(data.error, 'error')
                    }
                });
        });

        $('#support_button').click(function() {
            $.get('/change_support_setting/' + $('#support_name').val() + '/' + $(
                    '#support_short_name')
                .val(),
                function(data) {
                    if (data.success) {
                        alert_toast(data.success, 'success')
                    } else {
                        alert_toast(data.error, 'error')
                    }
                });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Werabe University Project\Werabe University Project\resources\views\settings.blade.php ENDPATH**/ ?>