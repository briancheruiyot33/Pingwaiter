<?php $__env->startSection('title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="app-content content">
        <section id="responsive-datatable">
            <div class="row">
                <div class="col-12">
                    <!-- Your HTML content goes here -->
                    <div class="card">
                        <div class="card-header border-bottom">
                            <h3 class="card-title">Patients</h3>


                        </div>
                        <div class="card-datatable">
                            <div style="width:98%; margin-left:1%;">
                                <div class="table-responsive">

                                    <table id="laravel-datatable-patient"
                                        class="display table-bordered table-striped table-hover dt-responsive mb-0 dataTable no-footer"
                                        style="width: 100%;" role="grid" aria-describedby="laravel-datatable-user">

                                        <thead>
                                            <tr role="row">
                                                <th scope="col" width="1%">#</th>
                                                <th nowrap="1">Full Name</th>
                                                <th nowrap="1">Student Id</th>
                                                <th nowrap="1">Sex</th>
                                                <th nowrap="1">Phone</th>
                                                <th nowrap="1">Age</th>
                                                <th nowrap="1">State</th>
                                                <th nowrap="1">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody></tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- BEGIN: Category Add modal  -->
        <div class="modal fade text-left" id="inlineForm" data-keyboard="false" data-backdrop="static" tabindex="-1"
            role="dialog" aria-labelledby="patientlbl" aria-hidden="true" style="overflow-y: scroll;">
            <div class="modal-dialog modal-xl" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="patientlbl">Add patient</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                            onclick="closeModal()">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form id="Register">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="edit_id" id="edit_id">
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-md-4">
                                    <label strong style="font-size: 16px;">Full Name</label><label
                                        style="color: red; font-size:16px;">*</label>
                                    <div class="form-group">
                                        <input type="text" placeholder="Write Patient Name here" class="form-control"
                                            name="full_name" id='full_name' autofocus onkeyup="removeNameValidation()" />
                                        <span class="text-danger">
                                            <strong id="full_name-error"></strong>
                                        </span>
                                    </div>

                                </div>
                                <div class="col-md-4">
                                    <label strong style="font-size: 16px;">Student ID</label><label
                                        style="color: red; font-size:16px;">*</label>
                                    <div class="form-group">
                                        <input type="text" placeholder="Write Student Id here" class="form-control"
                                            name="student_id" id='student_id' autofocus onkeyup="removeNameValidation()" />
                                        <span class="text-danger">
                                            <strong id="student_id-error"></strong>
                                        </span>
                                    </div>

                                </div>
                                <div class="col-md-4">
                                    <label strong style="font-size: 16px;">Address</label><label
                                        style="color: red; font-size:16px;"></label>
                                    <div class="form-group">
                                        <input type="text" placeholder="Write Category Name here" class="form-control"
                                            name="address" id='address' autofocus onkeyup="removeaddressValidation()" />
                                        <span class="text-danger">
                                            <strong id="address-error"></strong>
                                        </span>
                                    </div>

                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <label strong style="font-size: 16px;">Age</label><label
                                        style="color: red; font-size:16px;"></label>
                                    <div class="form-group">
                                        <input type="number" placeholder="Write Age here" class="form-control"
                                            name="age" id='age' autofocus onkeyup="removeageValidation()" />
                                        <span class="text-danger">
                                            <strong id="age-error"></strong>
                                        </span>
                                    </div>

                                </div>
                                <div class="col-md-4">
                                    <label strong style="font-size: 16px;">Phone</label><label
                                        style="color: red; font-size:16px;"></label>
                                    <div class="form-group">
                                        <input type="text" placeholder="Write Phone here" class="form-control"
                                            name="phone" id='phone' autofocus onkeyup="removeNameValidation()" />
                                        <span class="text-danger">
                                            <strong id="phone-error"></strong>
                                        </span>
                                    </div>

                                </div>
                                <div class="col-md-4">
                                    <label strong style="font-size: 16px;">Department</label><label
                                        style="color: red; font-size:16px;"></label>
                                    <div class="form-group">
                                        <input type="text" placeholder="Write Department here" class="form-control"
                                            name="department" id='department' autofocus
                                            onkeyup="removedepartmentValidation()" />
                                        <span class="text-danger">
                                            <strong id="department-error"></strong>
                                        </span>
                                    </div>

                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <label strong style="font-size: 16px;">Sex</label><label
                                        style="color: red; font-size:16px;"></label>

                                    <div class="form-group">
                                        <div>
                                            <select class="custom-select browser-default select2" name="sex"
                                                id="sex" onchange="removeSexValidation()">
                                                <option value=""></option>
                                                <option value="Male">Male</option>
                                                <option value="Female">Female</option>
                                            </select>
                                            <span class="text-danger">
                                                <strong id="sex-error"></strong>
                                            </span>
                                        </div>
                                    </div>

                                </div>
                                <div class="col-md-4">
                                    <label strong style="font-size: 16px;">Entry Year</label><label
                                        style="color: red; font-size:16px;">*</label>
                                    <div class="form-group">
                                        <div>
                                            <select class="custom-select browser-default select2" name="entry_year"
                                                id="entry_year" onchange="removeStatusValidation()">
                                                <option value=""></option>
                                                <option value="2013">2013</option>
                                                <option value="2014">2014</option>
                                                <option value="2015">2015</option>
                                                <option value="2016">2016</option>
                                                <option value="2017">2017</option>
                                                <option value="2018">2018</option>
                                                <option value="2019">2019</option>
                                                <option value="2020">2020</option>
                                            </select>
                                            <span class="text-danger">
                                                <strong id="entry_year-error"></strong>
                                            </span>
                                        </div>
                                    </div>

                                </div>
                                <div class="col-md-4">
                                    <label strong style="font-size: 16px;">Status</label><label
                                        style="color: red; font-size:16px;">*</label>
                                    <div class="form-group">
                                        <div>
                                            <select class="custom-select browser-default select2" name="status"
                                                id="status" onchange="removeStatusValidation()">
                                                <option value="Active">Active</option>
                                                <option value="Inactive">Inactive</option>
                                            </select>
                                            <span class="text-danger">
                                                <strong id="status-error"></strong>
                                            </span>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button id="savenewbutton" type="button" class="btn btn-info">Save &
                                New</button>
                            <button id="savebutton" type="button" class="btn btn-info">Save & Close</button>
                            <button id="closebutton" type="button" class="btn btn-danger" onclick="closeModal()"
                                data-dismiss="modal">Close</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <div class="modal fade" id="adviceModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="example">Send no where:</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                        onclick="closeModalWithClearValidation()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <div>
                            <div class="row">
                                <div class="form-group col-md-12">
                                    <label for="">Remark</label>
                                    <textarea name="remark" id="remark" class="form-control"></textarea>
                                </div>

                            </div>
                        </div>
                    </div>
                    <input type="hidden" id="remark_id">
                </div>
                <div class="modal-footer">
                    <button class="btn btn-primary" id="remark-button">Submit</button>
                    <button id="closebutton" type="button" class="btn btn-default"
                        onclick="closeModalWithClearValidation()" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    
    
    <div class="modal fade text-left" id="labratoryModal" data-keyboard="false" data-backdrop="static" tabindex="-1"
        role="dialog" aria-labelledby="lbl" aria-hidden="true" style="overflow-y: scroll;">
        <div class="modal-dialog modal-xl" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="pharmacylbl">Werabe University Student Clinic
                        LABORATORY REQUEST</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                        onclick="closeModal()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>FULL NAME:</label>
                                <input type="text" name="fname" id="fullname" class="form-control" readonly>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>AGE:</label>
                                <input type="number" name="age" id="new_age" readonly class="form-control">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Gender:</label>
                                <input type="text" name="gender" id="new_sex" readonly class="form-control">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>USER ID:</label>
                                <input type="text" name="student_id" id="stud_id" class="form-control" readonly>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Name of Prescriber's </label>
                                <input type="text" name="pname" id="pname" readonly class="form-control">
                            </div>
                        </div>
                    </div>
                    <form id="labratory-form">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="labratory_id" id="labratory_id">
                        <input type="hidden" name="lab_id" id="lab_id">
                        <div class="t1">
                            <table border="1px" class="ttt w-100">
                                <tr>
                                    <th>STOOL</th>
                                    <th>UNINALYSIS</th>
                                    <th colspan="2">HEAMATOLOGY</th>
                                    <th colspan="2">SEROLOGY</th>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="c1">APP <input type="checkbox" name="app" id="app"
                                                class="c2">
                                        </div>
                                    </td>
                                    <td>
                                        <div class="c1">color<input type="checkbox" id="color" name="color"
                                                class="c2">
                                        </div>
                                    </td>
                                    <td colspan="2">
                                        <div class="c1">Hg <p><input type="text" name="hg"
                                                    class="form-control">Mg/di</p>
                                        </div>
                                    </td>
                                    <td rowspan="3" align="center">Widal <br>& <br>Weil Flex</td>
                                    <td>
                                        <div class="c1">'O'<input type="checkbox" name="o" id="o"
                                                class="c2">
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="c1">Cons<input type="checkbox" name="cons" id="cons"
                                                class="c2">
                                        </div>
                                    </td>
                                    <td>
                                        <div class="c1">Leucocyte<input type="checkbox" name="leurcocyte"
                                                id="leurcocyte" class="c2"></div>
                                    </td>
                                    <td colspan="2">
                                        <div class="c1">Hct<p><input type="number" name="hct"
                                                    class="form-control">%</p>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="c1">'H'<input type="checkbox" name="h" id="h"
                                                class="c2">
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="c1">OIP<input type="checkbox" name="oip" id="oip"
                                                class="c2">
                                        </div>
                                    </td>
                                    <td>
                                        <div class="c1">nitrite<input type="checkbox" name="nitrate" id="nitrate"
                                                class="c2">
                                        </div>
                                    </td>
                                    <td colspan="2">
                                        <div class="c1">WBC<p><input type="text" name="wbc1"
                                                    class="form-control">Mm3</p>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="c1">'Ox'<input type="checkbox" name="ox" id="ox"
                                                class="c2">
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td rowspan="10"></td>
                                    <td>
                                        <div class="c1">Urobilinogen<input type="checkbox" name="urobilinogen"
                                                id="urobilinogen" class="c2"></div>
                                    </td>
                                    <td rowspan="5" class="bottom" align="center">Diff Count</td>
                                    <td>
                                        <div class="c1">Netrophils<p><input type="number" name="netrophils"
                                                    class="form-control">%
                                            </p>
                                        </div>
                                    </td>
                                    <td colspan="2">
                                        <div class="c1">RPR<input type="checkbox" name="rbr" id="rbr"
                                                class="c2">
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="c1">Protein<input type="checkbox" name="protein" id="protein"
                                                class="c2">
                                        </div>
                                    </td>
                                    <td>
                                        <div class="c1">Basophils<p><input type="number" name="basophils"
                                                    class="form-control">%
                                            </p>
                                        </div>
                                    </td>
                                    <td colspan="2">
                                        <div class="c1">Rheumatoid factor<input type="checkbox" name="theumatoid"
                                                id="theumatoid" class="c2"></div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="c1">PH<input type="checkbox" name="ph" id="ph"
                                                class="c2">
                                        </div>
                                    </td>
                                    <td>
                                        <div class="c1">Eosinophils<p><input type="number" name="eosinophils"
                                                    class="form-control">%</p>
                                        </div>
                                    </td>
                                    <td colspan="2">
                                        <div class="c1">HCG<input type="checkbox" name="hcg" id="hcg"
                                                class="c2">
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="c1">Blood<input type="checkbox" name="blood" id="blood"
                                                class="c2">
                                        </div>
                                    </td>
                                    <td>
                                        <div class="c1">Monocytes<p><input type="number" name="monocytes"
                                                    class="form-control">%</p>
                                        </div>
                                    </td>
                                    <td colspan="2">
                                        <div class="c1">FBC/RBS<input type="checkbox" name="fbc" id="fbc"
                                                class="c2">
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="c1">Spec. gravity<input type="checkbox" name="spec"
                                                id="spec" class="c2"></div>
                                    </td>
                                    <td>
                                        <div class="c1">Lymphocyted<p><input type="number" name="lymphocyted"
                                                    class="form-control">%</p>
                                        </div>
                                    </td>
                                    <td colspan="2">
                                        <div class="c1">Bactreglology<input type="checkbox" name="bactreglology"
                                                id="bactreglology" class="c2"></div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="c1">Ketones<input type="checkbox" name="ketones" id="ketones"
                                                class="c2">
                                        </div>
                                    </td>
                                    <td colspan="2">
                                        <div class="c1">ESR<p><input type="text" name="esr"
                                                    class="form-control">mm/hr</p>
                                        </div>
                                    </td>
                                    <td colspan="2">
                                        <div class="c1">Gram stan<input type="checkbox" name="gram_stan"
                                                id="gram_stan" class="c2"></div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="c1">Bilirubin<input type="checkbox" name="bilirubin"
                                                id="bilirubin" class="c2"></div>
                                    </td>
                                    <td colspan="2">
                                        <div class="c1">Blood Film<input type="checkbox" name="blood_film"
                                                id="blood_film" class="c2"></div>
                                    </td>
                                    <td colspan="2">
                                        <div class="c1">A+B<input type="checkbox" name="ab" id="ab"
                                                class="c2">
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="c1">Glucose<input type="checkbox" name="glucose" id="glucose"
                                                class="c2">
                                        </div>
                                    </td>
                                    <td colspan="2">
                                        <div class="c1">IMUNOHEAMATOLOGY<input type="checkbox" name="imunohematology"
                                                id="imunohematology" class="c2"></div>
                                    </td>
                                    <td colspan="2">
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="c1">RBC/HPF<input type="checkbox" name="rbc" id="rbc"
                                                class="c2">
                                        </div>
                                    </td>
                                    <td colspan="2">
                                        <div class="c1">BLOOD group & RH<input type="checkbox" name="blood_group"
                                                id="blood_group" class="c2"></div>
                                    </td>
                                    <td colspan="2"></td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="c1">WBC/HPF<input type="checkbox" name="wbc" id="wbc"
                                                class="c2"></div>
                                    </td>
                                    <td colspan="2"></td>
                                    <td colspan="2"></td>
                                </tr>

                                <tr>
                                    <td colspan="6">
                                        <div class="c1">
                                            <textarea class="form-control" name="other" id="other" placeholder="No description" readonly></textarea>
                                            <textarea class="form-control" name="other_lab" id="other_lab" placeholder="Lab result"></textarea>
                                        </div>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button id="savelabratory" type="button"
                        class="btn btn-info waves-effect waves-float waves-light">Save</button>
                    <button id="closebutton" type="button" class="btn btn-danger" onclick="closeModal()"
                        data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        var current_date = moment();
        var current_date = current_date.format('MMMM D, YYYY');
        $('#date').val(current_date);
        var errorcolor = "#ffcccc";
        $(function() {
            cardSection = $('#page-block');
        });
        /* BEGIN: Display zone table using yajra datatable */
        $(document).ready(function() {
            var ctable = $('#laravel-datatable-patient').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                searchHighlight: true,
                dom: 'lBfrtip', // Add l before B to include lengthMenu
                buttons: [{
                        extend: 'copy',
                        title: 'Your Title Here' // Title for the 'copy' button
                    },
                    {
                        extend: 'csv',
                        title: 'Your Title Here' // Title for the 'csv' button
                    },
                    {
                        extend: 'excel',
                        title: 'Your Title Here' // Title for the 'excel' button
                    },
                    {
                        extend: 'pdf',
                        title: 'Your Title Here' // Title for the 'pdf' button
                    },
                    {
                        extend: 'print',
                        title: 'Yout title here'
                    }
                ],
                lengthMenu: [
                    [10, 25, 50, 500, -1],
                    [10, 25, 50, 500, "All"]
                ],
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: '/getpatientslabratory',
                    type: 'DELETE',
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'student.full_name',
                        name: 'student.full_name'
                    },
                    {
                        data: 'student.student_id',
                        name: 'student.student_id'
                    },
                    {
                        data: 'student.sex',
                        name: 'student.sex'
                    },
                    {
                        data: 'student.phone',
                        name: 'student.phone'
                    },
                    {
                        data: 'student.age',
                        name: 'student.age'
                    },
                    {
                        data: 'state',
                        name: 'state'
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return '<a class = "btn btn-success lab" onclick = "sendLabratory(' +
                                data
                                .id +
                                ')"><span>Detail</span></a>';
                        },
                        orderable: false,
                        searchable: false
                    }
                ],
                "fnRowCallback": function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                    if (aData.state == "5") {
                        $(nRow).find('td:eq(6)').html('Pending');
                        $(nRow).find('td:eq(6)').css({
                            "color": "blue",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #4CAF50"
                        });
                    }
                }
            });
            /* End: Yajra data table*/
            $('#laravel-datatable-patient tbody').on('click', 'tr', function() {
                if ($(this).hasClass('selected')) {
                    $(this).removeClass('selected');
                } else {
                    $('tr.selected').removeClass('selected');
                    $(this).addClass('selected');
                }
            });

            $('#status').select2({
                minimumResultsForSearch: -1
            });
        });
        ctable.on('draw', function() {
            var body = $(ctable.table().body());
            body.unhighlight();
            body.highlight(ctable.search());
        })

        function viewHistoryFn(record_id) {
            $('#historyModal').modal('show');
        }
    </script>
    <script>
        function sendLabratory(record_id) {
            $('#labratoryModal').modal('show');
            $.get('/getLabratory/' + record_id, function(data) {
                if (data.patient) {
                    $('#fullname').val(data.patient.student.full_name);
                    $('#stud_id').val(data.patient.student.student_id);
                    $('#new_sex').val(data.patient.student.sex);
                    $('#new_age').val(data.patient.student.age);
                    $('#pname').val(data.patient.user.name);
                    $('#lab_id').val(record_id);
                }
                if (data.labratory) {
                    $('#other').val(data.labratory.other);
                    $('#labratory_id').val(data.labratory.id);
                    data.labratory.app == 'on' ? $('#app').prop('checked', true) : $('#app').prop('checked', false);
                    data.labratory.cons == 'on' ? $('#cons').prop('checked', true) : $('#cons').prop('checked',
                        false);
                    data.labratory.oip == 'on' ? $('#oip').prop('checked', true) : $('#oip').prop('checked', false);
                    data.labratory.color == 'on' ? $('#color').prop('checked', true) : $('#color').prop('checked',
                        false);
                    data.labratory.leurcocyte == 'on' ? $('#leurcocyte').prop('checked', true) : $('#leurcocyte')
                        .prop('checked', false);
                    data.labratory.blood == 'on' ? $('#blood').prop('checked', true) : $('#blood')
                        .prop('checked', false);
                    data.labratory.nitrate == 'on' ? $('#nitrate').prop('checked', true) : $('#nitrate')
                        .prop('checked', false);
                    data.labratory.urobilinogen == 'on' ? $('#urobilinogen').prop('checked', true) : $(
                            '#urobilinogen')
                        .prop('checked', false);
                    data.labratory.protein == 'on' ? $('#protein').prop('checked', true) : $('#protein')
                        .prop('checked', false);
                    data.labratory.ph == 'on' ? $('#ph').prop('checked', true) : $('#ph')
                        .prop('checked', false);
                    data.labratory.spec == 'on' ? $('#spec').prop('checked', true) : $('#spec')
                        .prop('checked', false);
                    data.labratory.ketones == 'on' ? $('#ketones').prop('checked', true) : $('#ketones')
                        .prop('checked', false);
                    data.labratory.bilirubin == 'on' ? $('#bilirubin').prop('checked', true) : $('#bilirubin')
                        .prop('checked', false);
                    data.labratory.glucose == 'on' ? $('#glucose').prop('checked', true) : $('#glucose')
                        .prop('checked', false);
                    data.labratory.rbc == 'on' ? $('#rbc').prop('checked', true) : $('#rbc')
                        .prop('checked', false);
                    data.labratory.wbc == 'on' ? $('#wbc').prop('checked', true) : $('#wbc')
                        .prop('checked', false);
                    data.labratory.blood_film == 'on' ? $('#blood_film').prop('checked', true) : $('#blood_film')
                        .prop('checked', false);
                    data.labratory.imunohematology == 'on' ? $('#imunohematology').prop('checked', true) : $(
                            '#imunohematology')
                        .prop('checked', false);
                    data.labratory.blood_group == 'on' ? $('#blood_group').prop('checked', true) : $('#blood_group')
                        .prop('checked', false);
                    data.labratory.o == 'on' ? $('#o').prop('checked', true) : $('#o')
                        .prop('checked', false);
                    data.labratory.h == 'on' ? $('#h').prop('checked', true) : $('#h')
                        .prop('checked', false);
                    data.labratory.ox == 'on' ? $('#ox').prop('checked', true) : $('#ox')
                        .prop('checked', false);
                    data.labratory.rbr == 'on' ? $('#rbr').prop('checked', true) : $('#rbr')
                        .prop('checked', false);
                    data.labratory.theumatoid == 'on' ? $('#theumatoid').prop('checked', true) : $('#theumatoid')
                        .prop('checked', false);
                    data.labratory.hcg == 'on' ? $('#hcg').prop('checked', true) : $('#hcg')
                        .prop('checked', false);
                    data.labratory.fbc == 'on' ? $('#fbc').prop('checked', true) : $('#fbc')
                        .prop('checked', false);
                    data.labratory.bactreglology == 'on' ? $('#bactreglology').prop('checked', true) : $(
                            '#bactreglology')
                        .prop('checked', false);
                    data.labratory.gram_stan == 'on' ? $('#gram_stan').prop('checked', true) : $(
                            '#gram_stan')
                        .prop('checked', false);
                    data.labratory.ab == 'on' ? $('#ab').prop('checked', true) : $(
                            '#ab')
                        .prop('checked', false);
                }
            });
        }
        var i = 0,
            m = 0,
            j = 0;
        /* BEGIN: Add woreda button */
        $("#adds").click(function() {
            $('#table-error').html('');
            var lastrowcount = $('#dynamicTable tr:last').find('td').eq(1).find('input').val();
            ++i;
            ++m;
            ++j;
            $("#dynamicTable > tbody").append('<tr id="rowind' + m +
                '"><td style="font-weight:bold;width:3%;text-align:center;">' + j + '</td>' +
                '<td style="display:none;"><input type="hidden" name="product[' + m + '][vals]" id="vals' + m +
                '" class="vals form-control" readonly="true" style="font-weight:bold;" value="' + m +
                '"/></td>' +
                '<td style="display:none;"><input type="hidden" name="product[' + m +
                '][id]" id="id' +
                m +
                '" class="vals form-control" readonly="true" style="font-weight:bold;" value=""/></td>' +
                '<td style="width: 13%; padd"><select class="custom-select browser-default select2 product" name="product[' +
                m +
                '][product_id]" id="product' +
                m +
                '" onclick="prfn(this)" onblur="checkPrFn(this)"></select></td>' +
                '<td style="width:13%; padd"><input type="text" name="product[' + m +
                '][description]" placeholder="Write here..." onkeypress="return Validatedescription(event);" onkeyup="checkDscFn()" id="description' +
                m +
                '" class="description form-control numeral-mask" onclick="dscfn(this)" onblur="checkDscFn(this)"/></td>' +
                '<td style="width:3%;text-align:center;"><button type="button" id="removebtn' + m +
                '" class="btn btn-light btn-sm remove-tr" style="color:#ea5455;background-color:#FFFFFF;border-color:#FFFFFF"><i class="fa fa-times fa-lg" aria-hidden="true"></i></button></td></tr>'
            );

            $('#product' + m).select2({
                placeholder: "Select Product here",
            });
            $.get('/getplist', function(data) {
                $.each(data.product, function(key, value) {
                    $('#product' + m).append('<option value="' + value.id + '">' + value
                        .product.product +
                        ' | ' + value.product.category.name +
                        ' | ' + value.product.type.name +
                        ' | ' + value.product.unit.name + '</option>');
                });
            });
            renumberRows();
        });

        function sendFn(record_id) {
            $('#send_id').val(record_id);
            $('#sendModal').modal('show');
        }
        $('.send').click(function() {
            var send_id = $('#send_id').val();
            $.ajax({
                url: '/sendpatient/' + send_id,
                type: 'get',
                beforeSend: function() {
                    $('.send').text('Sending...');
                },
                success: function(data) {
                    if (data.errors) {
                        $('.send').text('Send');
                        alert_toast('an error occured', 'error');
                    } else if (data.success) {
                        $('.send').text('Send');
                        alert_toast(data.success, 'success')
                        var cTable = $('#laravel-datatable-patient').dataTable();
                        cTable.fnDraw(false);
                        $('#sendModal').modal('hide');
                    }
                }
            });
        });
        $('#savepharmacy').click(function() {
            var pharmacyData = $('#form-pharmacy');
            var formData = pharmacyData.serialize();
            $.ajax({
                url: '/pharmacystore',
                type: 'post',
                data: formData,
                beforeSend: function() {
                    cardSection.block({
                        message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                        css: {
                            backgroundColor: 'transparent',
                            color: '#fff',
                            border: '0'
                        },
                        overlayCSS: {
                            opacity: 0.5
                        }
                    });
                    $('#savepharmacy').text('Saving...');
                    $('#savepharmacy').prop("disabled", true);
                },
                complete: function() {
                    cardSection.block({
                        message: '',
                        timeout: 1,
                        css: {
                            backgroundColor: '',
                            color: '',
                            border: ''
                        },
                    });
                },

                success: function(data) {
                    if (data.errors) {
                        var product = "";
                        var description = "";
                        for (var k = 1; k <= m; k++) {
                            product = ($('#product_id' + k)).val();
                            description = ($('#description' + k)).val();

                            if (($('#product_id' + k).val()) != undefined) {
                                if (product_id == "" || product_id == null) {
                                    $('#product_id' + k).css("background", errorcolor);
                                }
                            }
                            if (($('#description' + k).val()) != undefined) {
                                if (description == "" || description == null) {
                                    $('#description' + k).css("background", errorcolor);
                                }
                            }
                        }
                        $('#savepharmacy').html('Save');
                        $('#savepharmacy').prop("disabled", false);
                        alert_toast("Please fill all highlighted required fields pitch",
                            "error");
                    } else if (data.success) {
                        alert_toast('Patient send to pharmacy successfully!', 'success');
                        $('#pharmacyModal').modal('hide');
                        var pTable = $('#laravel-datatable-campus').dataTable();
                        pTable.fnDraw(false);
                        $('#savepharmacy').html('Save');
                        $('#savepharmacy').prop("disabled", false);
                    } else {
                        alert('new error')
                        $('#savepharmacy').html('Save');
                        $('#savepharmacy').prop("disabled", false);
                    }
                }
            });
        });
        $('#savelabratory').click(function() {
            var labratoryData = $('#labratory-form');
            var formData = labratoryData.serialize();
            $.ajax({
                url: '/labratorystoreresult',
                type: 'post',
                data: formData,
                beforeSend: function() {
                    cardSection.block({
                        message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                        css: {
                            backgroundColor: 'transparent',
                            color: '#fff',
                            border: '0'
                        },
                        overlayCSS: {
                            opacity: 0.5
                        }
                    });
                    $('#savelabratory').text('Saving...');
                    $('#savelabratory').prop("disabled", true);
                },
                complete: function() {
                    cardSection.block({
                        message: '',
                        timeout: 1,
                        css: {
                            backgroundColor: '',
                            color: '',
                            border: ''
                        },
                    });
                },

                success: function(data) {
                    if (data.errors) {
                        $('#savelabratory').html('Save');
                        $('#savelabratory').prop("disabled", false);
                        alert_toast("Please fill all highlighted required fields pitch",
                            "error");
                    } else if (data.success) {
                        alert_toast('Patient send to labratory successfully!', 'success');
                        $('#labratoryModal').modal('hide');
                        var pTable = $('#laravel-datatable-patient').dataTable();
                        pTable.fnDraw(false);
                        $('#savelabratory').html('Save');
                        $('#savelabratory').prop("disabled", false);
                    } else {
                        alert('new error')
                        $('#savelabratory').html('Save');
                        $('#savelabratory').prop("disabled", false);
                    }
                }
            });
        });
    </script>
    <script>
        function removeNameValidation() {
            $('#name-error').html('');
        }

        function removeStatusValidation() {
            $('#status-error').html('');
        }

        function closeModal() {
            $('#name-error').html('');
            $('#status-error').html('');
            $('#name').val('');
            $('#status').val('').trigger('change');
            $('#savenewbutton').css('display', 'flex');
            $('#savebutton').html('Save & Close');
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Werabe University Project\Werabe University Project\resources\views\patients\labratory.blade.php ENDPATH**/ ?>