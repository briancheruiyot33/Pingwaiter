<?php $__env->startSection('content'); ?>
    <div class="app-content content">
        <section id="responsive-datatable">
            <div class="bg-light p-4 rounded">
                <h1>Roles</h1>
                <div class="card">
                    <div class="card-header" style="display: flex; justify-content: space-between;">
                        <div class="lead">
                            Manage your roles here.
                        </div>
                        <h4>
                            <a href="<?php echo e(route('roles.create')); ?>" class="btn btn-primary btn-sm float-right">Add role</a>
                        </h4>
                        
                    </div>


                    <table class="table table-bordered" id="dataTable">
                        <tr>
                            <th width="1%">No</th>
                            <th>Name</th>
                            <th width="3%" colspan="3">Action</th>
                        </tr>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dorm_admin')): ?>
                                <?php if(
                                    $role->name == 'dorm_admin' ||
                                        $role->name == 'proctor' ||
                                        $role->name == 'dorm_management' ||
                                        $role->name == 'dorm_coordinator' ||
                                        $role->name == 'finance'): ?>
                                    <tr>
                                        <td><?php echo e(++$key); ?></td>
                                        <td><?php echo e($role->name); ?></td>
                                        <td>
                                            <a class="btn btn-info btn-sm" href="<?php echo e(route('roles.show', $role->id)); ?>">Show</a>
                                        </td>
                                        <td>
                                            <a class="btn btn-primary btn-sm"
                                                href="<?php echo e(route('roles.edit', $role->id)); ?>">Edit</a>
                                        </td>
                                        

                                    </tr>
                                <?php endif; ?>
                            <?php else: ?>
                                <tr>
                                    <td><?php echo e(++$key); ?></td>
                                    <td><?php echo e($role->name); ?></td>
                                    <td>
                                        <a class="btn btn-info btn-sm" href="<?php echo e(route('roles.show', $role->id)); ?>">Show</a>
                                    </td>
                                    <td>
                                        <a class="btn btn-primary btn-sm" href="<?php echo e(route('roles.edit', $role->id)); ?>">Edit</a>
                                    </td>
                                    

                                </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
                


            </div>
            <!-- BEGIN: instructor Add modal  -->
            

            


        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).on('click', '.roleModal', function() {
            $.ajax({
                url: '/create-role',
                type: 'get',
                success: function(data) {
                    $('#userlist').find("dd").remove();
                    $('#studentlist').find("dd").remove();
                    $('#streamlist').find("dd").remove();
                    $.each(data.permissions, function(key, value) {
                        //alert(data.userRole)
                        var text = value.name;
                        text = text.replace(".", " ");
                        if (value.role_table == "users") {
                            var list = '<dd><input type="checkbox" name="permission[' + value
                                .name +
                                ']" value="' + value.name +
                                '" class="permission"><span style="margin-left: 10px;">' +
                                text +
                                '</span></dd>';
                            $('#userlist').append(list);
                        } else if (value.role_table == "students") {
                            var list = '<dd><input type="checkbox" name="permission[' + value
                                .name +
                                ']" value="' + value.name +
                                '" class="permission"><span style="margin-left: 10px;">' +
                                text +
                                '</span></dd>';
                            $('#studentlist').append(list);
                        } else if (value.role_table == "streams") {
                            var list = '<dd><input type="checkbox" name="permission[' + value
                                .name +
                                ']" value="' + value.name +
                                '" class="permission"><span style="margin-left: 10px;">' +
                                text +
                                '</span></dd>';
                            $('#streamlist').append(list);
                        }

                    });
                }
            });
            $('#roleForm').modal('show');
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Werabe University Project\Werabe University Project\resources\views\roles\index.blade.php ENDPATH**/ ?>