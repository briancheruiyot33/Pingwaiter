<?php $__env->startSection('content'); ?>
    <div class="app-content content">
        <section id="responsive-datatable" style="font-size: 12px;">
            <div id="success_message" style="padding: 13px 20px;"></div>
            <div class="row">
                <div class="col-12">
                    <!-- Your HTML content goes here -->
                    <div class="card">
                        <div class="card-header border-bottom">
                            <h3 class="card-title">Property Received</h3>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_campus')): ?>
                                <button class="col-md-2 float-right btn btn-primary btn-sm" id="new_receiving"><i
                                        class="fa fa-plus"></i> New
                                    Receiving</button>
                            <?php endif; ?>

                        </div>
                        <div class="card-datatable">
                            <div style="width:98%; margin-left:1%;">
                                <div class="table-responsive">

                                    <table id="laravel-datatable-campus"
                                        class="display table-bordered table-striped table-hover dt-responsive mb-0 dataTable no-footer"
                                        style="width: 100%;" role="grid" aria-describedby="laravel-datatable-crud_info">
                                        <thead>
                                            <tr role="row">
                                                <th style="width:7%;">#</th>
                                                <th>Date Received</th>
                                                <th>SKU</th>
                                                <th>Supplier Name</th>
                                                <th>Receiption Name</th>
                                                <th>Item No</th>
                                                <th>Status</th>
                                                <th style="width:5%;">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody></tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="modal fade text-left" id="receivingForm" data-keyboard="false" data-backdrop="static" tabindex="-1"
                role="document" aria-labelledby="receivingtitlelb" aria-hidden="true"
                style="overflow-y: scroll; display: none;" data-select2-id="inlineForm" arial-hidden="true">
                <div class="modal-dialog modal-xl" role="document" data-select2-id="15">
                    <div class="modal-content" data-select2-id="14">
                        <div class="modal-header">
                            <h4 class="modal-title" id="campustitlelbl">Receiving New Product</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                                onclick="closeRegisterModal()">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form id="Register" data-select2-id="Register">
                            <?php echo e(csrf_field()); ?>


                            <div class="modal-body" data-select2-id="13">
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="">SKU:</label><label style="color: red;"> *</label>
                                            <input type="text" name="SKU" id="SKU" class="form-control"
                                                onkeyup="skuUp()" readonly><span class="text-danger">
                                                <strong id="sku-error"></strong>
                                            </span>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="">Date Created:</label><label style="color: red;"> *</label>
                                            <input type="text" name="date_created" id="date_created" class="form-control"
                                                readonly><span class="text-danger">
                                                <strong id="date-error"></strong>
                                            </span>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Receiption Name</label><label style="color: red;">*</label>
                                            <input type="text" class="form-control" name="receiption" id="receiption"
                                                onkeyup="removeReceiptionValidation()">
                                            <span class="text-danger">
                                                <strong id="receiption-error"></strong>
                                            </span>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Supplier Name</label><label style="color: red;">*</label>
                                            <input type="text" class="form-control" name="supplier" id="supplier"
                                                onkeyup="removeSupplierValidation()">
                                            <span class="text-danger">
                                                <strong id="supplier-error"></strong>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Item Number</label>
                                            <input type="text" value="0" name="item_no" id="item"
                                                class="form-control" readonly>
                                        </div>
                                    </div>
                                </div>
                                <div class="divider">
                                    <div class="divider-text">Add New Product</div>
                                </div>
                                
                                <div class="col-md-12" style="margin-top: 10px; color: white" id="card">

                                </div>

                                <div class="row">
                                    <div class="col-xl-12 col-lg-12">
                                        <div class="table-responsive">
                                            
                                            <span class="text-danger">
                                                <strong id="table-error"></strong>
                                            </span>
                                            <table style="width: 100%">
                                                <tbody>
                                                    <tr>
                                                        <td colspan="2">
                                                            <button type="button" name="adds" id="adds"
                                                                class="btn btn-success btn-sm waves-effect waves-float waves-light"><i
                                                                    class="fa fa-plus" arial-hidden="true"></i> Add
                                                                New </button>
                                                        </td>
                                                        <td></td>
                                                    <tr class="totalrownumber">
                                                        <td style="text-align: right;">
                                                            <label strong style="font-size: 16px;">No. of Items: </label>
                                                        </td>
                                                        <td style="text-align: right; width: 2%;">
                                                            <label id="numberofItemsLbl" strong
                                                                style="font-size: 16px; font-weight: bold;">0</label>
                                                        </td>
                                                    </tr>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <input type="hidden" name="campusId" placeholder class="form-control" id="campusId"
                                    readonly="true" value>
                                <input type="hidden" name="operationtypes" placeholder class="form-control"
                                    id="operationtypes" readonly="true">

                                <button id="savebutton" type="button"
                                    class="btn btn-info waves-effect waves-float waves-light">Save</button>
                                <button id="closebutton" type="button" class="btn btn-danger"
                                    onclick="closeRegisterModal()" data-dismiss="modal">Close</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- BEGIN: Campus Store Show Information Modal -->
            <div class="modal fade" id="informationModal" data-keyboard="false" data-backdrop="static" tabindex="-1"
                role="dialog" aria-labelledby="myModalLabel35" aria-hidden="true" style="overflow-y: scroll;">
                <div class="modal-dialog modal-xl" role="document" style="font-size: 11px;">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title">Campus Store Information</h4>
                            <div class="row">
                                <div style="text-align: right" id="statusdisplay"></div>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                        aria-hidden="true">×</span></button>
                            </div>
                        </div>
                        <form id="InformationForm">
                            <input type="hidden" name="_token" value="bEE2UUJ5zm8YDMuIHSOQT8ZRMeUGaxv9eDaOVNb1">
                            <div class="modal-body">
                                <section id="input-mask-wrapper">
                                    <div class="col-xl-12">
                                        <div class="row">
                                            <div class="col-md-3 col-sm-12">
                                                <div class="card">
                                                    <div class="card-header">
                                                        <h4 class="card-title">Basic Information</h4>
                                                        <div class="heading-elements">
                                                            <ul class="list-inline mb-0">

                                                            </ul>
                                                        </div>
                                                    </div>
                                                    <div class="card-content collapse show">
                                                        <div class="card-body">
                                                            <div class="row">
                                                                <table style="width: 100%;">
                                                                    <tbody>

                                                                        <tr>
                                                                            <td><label strong=""
                                                                                    style="font-size: 14px;">SKU: </label>
                                                                            </td>
                                                                            <td><label id="sku_info" strong=""
                                                                                    style="font-size:14px;font-weight:bold;"></label>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><label strong=""
                                                                                    style="font-size: 14px;">Created Date:
                                                                                </label>
                                                                            </td>
                                                                            <td><label id="date_created_info"
                                                                                    strong=""
                                                                                    style="font-size:14px;font-weight:bold;"></label>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><label strong=""
                                                                                    style="font-size: 14px;">Receiption
                                                                                    Name: </label>
                                                                            </td>
                                                                            <td><label id="receiption_info" strong=""
                                                                                    style="font-size:14px;font-weight:bold;"></label>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><label strong=""
                                                                                    style="font-size: 14px;">Supplier
                                                                                    Name: </label>
                                                                            </td>
                                                                            <td><label id="supplier_info" strong=""
                                                                                    style="font-size:14px;font-weight:bold;"></label>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="width: 43%"><label strong=""
                                                                                    style="font-size: 14px;">Item
                                                                                    No</label>
                                                                            </td>
                                                                            <td style="width: 57%"><label
                                                                                    id="incoming_info" strong=""
                                                                                    style="font-size:14px;font-weight:bold;"></label>
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                            <div class="divider newext">
                                                                <div class="divider-text">Action Information</div>
                                                            </div>
                                                            <div class="row">
                                                                <table style="width: 100%;">
                                                                    <tbody>
                                                                        <tr>
                                                                            <td style="width: 35%"><label strong=""
                                                                                    style="font-size: 14px;">Created
                                                                                    By</label></td>
                                                                            <td style="width: 65%"><label id="created_by"
                                                                                    strong=""
                                                                                    style="font-size:14px;font-weight:bold;"></label>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><label strong=""
                                                                                    style="font-size: 14px;">Created
                                                                                    Date</label></td>
                                                                            <td><label id="created_at" strong=""
                                                                                    style="font-size:14px;font-weight:bold;"></label>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><label strong=""
                                                                                    style="font-size: 14px;">Last Edited
                                                                                    By</label></td>
                                                                            <td><label id="updated_by" strong=""
                                                                                    style="font-size:14px;font-weight:bold;"></label>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td><label strong=""
                                                                                    style="font-size: 14px;">Last Edited
                                                                                    Date</label></td>
                                                                            <td><label id="updated_at" strong=""
                                                                                    style="font-size:14px;font-weight:bold;"></label>
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-9 col-sm-12">
                                                <div class="card">
                                                    <div class="card-header">
                                                        <h4 class="card-title">Product Information</h4>
                                                        <div class="heading-elements">
                                                            <ul class="list-inline mb-0">

                                                            </ul>
                                                        </div>
                                                    </div>
                                                    <div class="card-content collapse show">
                                                        <div class="card-body">
                                                            <table id="productdetailtbl"
                                                                class="display table-bordered table-striped table-hover dt-responsive mb-0">
                                                                <thead>
                                                                    <tr>
                                                                        <th style="width: 0%;">#</th>
                                                                        <th nowrap>Expired Date</th>
                                                                        <th>Remaining Exp Days</th>
                                                                        <th nowrap>Batch No</th>
                                                                        <th nowrap>Product</th>
                                                                        <th nowrap>Category</th>
                                                                        <th nowrap>Unit</th>
                                                                        <th nowrap>Quantity</th>
                                                                        <th nowrap>Action</th>
                                                                    </tr>
                                                                </thead>
                                                            </table>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </section>
                            </div>
                            <div class="modal-footer">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_clinic')): ?>
                                    <p id="clickcode">Click to show the code</p>
                                    <div id ="viewcode" onclick="viewCode()"
                                        style="padding: 12px; border-radius: 5px; background: gray; color: gray;">There no
                                        authentication code yet
                                    </div>
                                <?php endif; ?>
                                <p class="btn btn-default" id="state" style="color: blue;"></p>
                                <button type="button" class="btn btn-warning" id="send_request"
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_clinic_leader')): ?> style="display: none"  <?php endif; ?>>Send Request</button>
                                <button type="button" class="btn btn-success" id="clinic_leader_approve"
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_clinic')): ?> style="display: none"  <?php endif; ?>>Approve
                                    Request</button>
                                <button id="closebuttonk" type="button"
                                    class="btn btn-danger waves-effect waves-float waves-light" data-dismiss="modal"
                                    onclick="closeModal()">Close</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>


            <!-- BEGIN: Info modal -->
            <div class="modal fade text-left" id="infoModal" data-keyboard="false" data-backdrop="static"
                tabindex="-1" role="dialog" aria-labelledby="myModalLabel133" aria-hidden="true"
                style="overflow-y: scroll;">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title">Product Information</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form id="regionform">
                            <input type="hidden" class="_token">
                            <div class="modal-body">
                                <table style="width: 100%;">
                                    <tbody>
                                        <tr>
                                            <td style="width: 40%">
                                                <label style="font-size: 14px;">Serial Number: </label>
                                            </td>
                                            <td style="width: 60%">
                                                <label id="seriel_info"
                                                    style="font-size: 14px; font-weight: bold;"></label>

                                            </td>
                                            &nbsp;
                                        </tr>
                                        <tr>
                                            <td style="width: 40%">
                                                <label style="font-size: 14px;">Expired Date: </label>
                                            </td>
                                            <td style="width: 60%">
                                                <label id="expired_info"
                                                    style="font-size: 14px; font-weight: bold;"></label>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="width: 40%">
                                                <label style="font-size: 14px;">Product Name: </label>
                                            </td>
                                            <td style="width: 60%">
                                                <label id="product_info"
                                                    style="font-size: 14px; font-weight: bold;"></label>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="width: 40%">
                                                <label style="font-size: 14px;">Category: </label>
                                            </td>
                                            <td style="width: 60%">
                                                <label id="category_info"
                                                    style="font-size: 14px; font-weight: bold;"></label>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="width: 40%">
                                                <label style="font-size: 14px;">UoM(Unit of measurement): </label>
                                            </td>
                                            <td style="width: 60%">
                                                <label id="unit_info" style="font-size: 14px; font-weight: bold;"></label>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="width: 40%">
                                                <label style="font-size: 14px;">Product Type: </label>
                                            </td>
                                            <td style="width: 60%">
                                                <label id="item_type_info"
                                                    style="font-size: 14px; font-weight: bold;"></label>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="width: 40%">
                                                <label style="font-size: 14px;">Remaining expire date: </label>
                                            </td>
                                            <td style="width: 60%">
                                                <label id="remaining_info"
                                                    style="font-size: 14px; font-weight: bold; background: orange; border-radius: 10px; color: white; padding: 5px 10px"></label>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="width: 40%">
                                                <label style="font-size: 14px;">Quality Checker: </label>
                                            </td>
                                            <td style="width: 60%">
                                                <label id="quality_info"
                                                    style="font-size: 14px; font-weight: bold;"></label>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="width: 40%">
                                                <label style="font-size: 14px;">Voucher No: </label>
                                            </td>
                                            <td style="width: 60%">
                                                <label id="voucher_info"
                                                    style="font-size: 14px; font-weight: bold;"></label>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="width: 40%">
                                                <label style="font-size: 14px;">Capacity: </label>
                                            </td>
                                            <td style="width: 60%">
                                                <label id="capacity_info"
                                                    style="font-size: 14px; font-weight: bold;"></label>

                                            </td>
                                        </tr>
                                        <td>
                                            <label style="font-size: 14px;">Quantity: </label>
                                        </td>
                                        <td>
                                            <label id="quantity_info" style="font-size: 14px; font-weight: bold;"></label>

                                        </td>
                                        </tr>
                                        <tr>
                                            <td style="width: 40%">
                                                <label style="font-size: 14px;">Unit Price: </label>
                                            </td>
                                            <td style="width: 60%">
                                                <label id="unitprice_info"
                                                    style="font-size: 14px; font-weight: bold;"></label>

                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="width: 40%">
                                                <label style="font-size: 14px;">Total Price: </label>
                                            </td>
                                            <td style="width: 60%">
                                                <label id="total_info"
                                                    style="font-size: 14px; font-weight: bold;"></label>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="modal-footer">
                                <button id="closebuttonk" type="button"
                                    class="btn btn-danger waves-effect waves-float waves-light"
                                    data-dismiss="modal">Close</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            
            <div class="modal fade" id="requestModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel"></h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                                onclick="closeModalWithClearValidation()">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <label strong>Do you really want to
                                send request for this product?</label>
                            <input type="hidden" id="request_id">
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-info send_request">Yes</button>
                            <button id="closebutton" type="button" class="btn btn-danger"
                                onclick="closeModalWithClearValidation()" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="modal fade" id="approveModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel"></h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                                onclick="closeModalWithClearValidation()">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form id="request_approval">
                            <?php echo e(csrf_field()); ?>

                            <div class="modal-body">
                                <div class="form-group">
                                    <label strong>Approve or Reject Request</label>
                                    <select class="custom-select browser-default select2" name="approve_id"
                                        id="approve_id">
                                        <option value="3">Approved</option>
                                        <option value="1">Rejected</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="remark">Remark</label>
                                    <textarea name="remark" id="remark" class="form-control"></textarea>
                                </div>
                                <input type="hidden" id="app_id" name="app_id">
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-info approve_request">Submit</button>
                                <button id="closebutton" type="button" class="btn btn-danger"
                                    onclick="closeModalWithClearValidation()" data-dismiss="modal">Close</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            
            <div class="modal fade" id="deliverModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel"></h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                                onclick="closeModalWithClearValidation()">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form id="request_deliver">
                            <?php echo e(csrf_field()); ?>

                            <div class="modal-body">
                                <div class="modal-header">Authenticate Receiver (Are you sure you have received the
                                    product?)</div>
                                <div class="form-group">
                                    <label for="">Enter authintication code</label>
                                    <input type="text" name="code" class="form-control" id="code"
                                        min="8" required>
                                </div>
                                <input type="hidden" id="deliver_id" name="deliver_id">
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-info deliver_request">Submit</button>
                                <button id="closebutton" type="button" class="btn btn-danger"
                                    onclick="closeModalWithClearValidation()" data-dismiss="modal">Close</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            
            <div class="modal fade" id="clinicApproveModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel"></h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                                onclick="closeModalWithClearValidation()">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <label strong>Do you really want to
                                send request for this product?</label>
                            <select id="select_id" class="form-control">
                                <option value="2">Approve</option>
                                <option value="1">Rejecte</option>
                            </select>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-info clinic_leader_approve">Submit</button>
                            <button id="closebutton" type="button" class="btn btn-danger"
                                onclick="closeModalWithClearValidation()" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>

            
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        var state = false;

        function viewCode() {
            state = !state;
            if (state === true) {
                $('#clickcode').html('click to hide code');
                $('#viewcode').css({
                    "background": "white",
                    "color": "black",
                })
            } else {
                $('#clickcode').html('click to show code');
                $('#viewcode').css({
                    "background": "gray",
                    "color": "gray",
                })
            }
        }
        var diff = 0;
        var errorcolor = "#ffcccc";
        $(function() {
            cardSection = $('#page-block');
        });
        /* BEGIN: Display zone table using yajra datatable */
        $(document).ready(function() {
            var ctable = $('#laravel-datatable-campus').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                searchHighlight: true,
                dom: 'lBfrtip', // Add l before B to include lengthMenu
                buttons: [{
                        extend: 'copy',
                        title: 'Received Detail', // Title for the 'copy' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'csv',
                        title: 'Received Detail', // Title for the 'csv' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'excel',
                        title: 'Received Detail', // Title for the 'excel' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'pdf',
                        title: 'Received Detail', // Title for the 'pdf' button
                        orientation: 'landscape', // Set orientation: 'landscape' or 'portrait'
                        pageSize: 'A4', // Set page size
                        customize: function(doc) {
                            // Customize header, footer, and body style
                            doc.styles.tableHeader = {
                                fillColor: '#4CAF50',
                                color: 'white',
                                alignment: 'center'
                            };
                            doc.styles.title = {
                                fontSize: 14,
                                alignment: 'center'
                            };
                            doc.defaultStyle.fontSize = 10; // Change default font size
                            doc.content[1].table.widths = '*'.repeat(doc.content[1].table.body[0]
                                .length).split(''); // Automatically adjust column widths
                            doc.pageMargins = [10, 10, 10, 10]; // Adjust page margins
                            doc.pageSize = 'A4'; // Ensure the page size is A4
                            doc.content[1].layout = {
                                hLineWidth: function(i, node) {
                                    return (i === 0 || i === node.table.body.length) ? 2 :
                                        1;
                                },
                                vLineWidth: function(i, node) {
                                    return (i === 0 || i === node.table.widths.length) ? 2 :
                                        1;
                                },
                                hLineColor: function(i, node) {
                                    return (i === 0 || i === node.table.body.length) ?
                                        'black' : 'gray';
                                },
                                vLineColor: function(i, node) {
                                    return (i === 0 || i === node.table.widths.length) ?
                                        'black' : 'gray';
                                },
                                paddingLeft: function(i, node) {
                                    return 4;
                                },
                                paddingRight: function(i, node) {
                                    return 4;
                                },
                                paddingTop: function(i, node) {
                                    return 2;
                                },
                                paddingBottom: function(i, node) {
                                    return 2;
                                },
                            };
                        },
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'print',
                        title: 'Received Detail',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5] // Indexes of the columns you want to include
                        }
                    }
                ],
                lengthMenu: [
                    [10, 25, 50, 500, -1],
                    [10, 25, 50, 500, "All"]
                ],
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: '/get-dyCampus',
                    type: 'DELETE',
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'date_created',
                        name: 'date_created'
                    },
                    {
                        data: 'sku',
                        name: 'sku'
                    },
                    {
                        data: 'supplier',
                        name: 'supplier'
                    },
                    {
                        data: 'receiption',
                        name: 'receiption'
                    },
                    {
                        data: 'item_no',
                        name: 'item_no'
                    },
                    {
                        data: 'status',
                        name: 'status'
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_campus')): ?>
                                return '<div class="btn-group dropleft"><button type="button" class="btn btn-sm dropdown-toffle hide-arrow" data-toggle="dropdown" arial-haspopup="true" arial-expanded="false"><i class="fa fa-ellipsis-v"></i></button><div class = "dropdown-menu" > <a class="dropdown-item campusInfo" onclick="campusInfoFn(' +
                                    data.id +
                                    ')" id="dtinfobtn" title="Open campus information page" data-id = "' +
                                    data.id +
                                    '"><i class="fa fa-info"></i><span> Info </span></a>' +
                                    '<a class = "dropdown-item campusEdit" onclick = "campusEditFn(' +
                                    data
                                    .id +
                                    ')" id = "dteditbtn" title = "Open campus update page" data - id = "' +
                                    data.id +
                                    '"><i class="fa fa-edit"></i><span> Edit </span></a>' +
                                    '<a class = "dropdown-item campusApprove" onclick = "requestFn(' +
                                    data
                                    .id +
                                    ')" id = "request" title = "request" data-id = "' +
                                    data.id +
                                    '"><i class="fa fa-check-circle" style="padding-top: 3px;"></i>&nbsp;<span> Request Approvale</span></a>' +
                                    '<a class = "dropdown-item campusDeliver" onclick = "deliverFn(' +
                                    data
                                    .id +
                                    ')" id = "deliver" title = "request" data-id = "' +
                                    data.id +
                                    '"><i class="fa fa-truck" style="padding-top: 3px;"></i>&nbsp;<span> Deliver Product </span></a></div></div> ';
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_clinic')): ?>
                                return ' <a class="btn btn-info campusInfo" style="padding: 5px 5px; width: 100%;" onclick="campusInfoFn(' +
                                    data.id +
                                    ')" id="dtinfobtn" title="Open campus information page" data-id = "' +
                                    data.id +
                                    '"><span> View Detail </span></a>';
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_clinic_leader')): ?>
                                return ' <a class="btn btn-info campusInfo" style="padding: 5px 5px; width: 100%;" onclick="campusInfoFn(' +
                                    data.id +
                                    ')" id="dtinfobtn" title="Open campus information page" data-id = "' +
                                    data.id +
                                    '"><span> View Detail </span></a>';
                            <?php endif; ?>
                        },
                        orderable: false,
                        searchable: false
                    }
                ],
                "fnRowCallback": function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_campus')): ?>
                        if (aData.status == "1" || aData.status == "5") {
                            $(nRow).find('td:eq(6)').html('Campus');
                            $(nRow).find('.campusEdit').css({
                                'display': 'flex'
                            });
                            $(nRow).find('.campusApprove').css({
                                'display': 'none'
                            });
                            $(nRow).find('.campusDeliver').css({
                                'display': 'none'
                            });
                            $(nRow).find('td:eq(6)').css({
                                "color": "orange",
                                "font-weight": "bold",
                                "text-shadow": "1px 1px 10px #4CAF50"
                            });
                        } else if (aData.status == "2") {
                            $(nRow).find('td:eq(6)').html('Pending');
                            $(nRow).find('.campusEdit').css({
                                'display': 'none'
                            });
                            $(nRow).find('.campusApprove').css({
                                'display': 'flex'
                            });
                            $(nRow).find('.campusDeliver').css({
                                'display': 'none'
                            });
                            $(nRow).find('td:eq(6)').css({
                                "color": "blue",
                                "font-weight": "bold",
                                "text-shadow": "1px 1px 10px #f44336"
                            });
                        } else if (aData.status == "3") {
                            $(nRow).find('td:eq(6)').html('Ready for Delivery');
                            $(nRow).find('.campusEdit').css({
                                "display": "none"
                            });
                            $(nRow).find('.campusApprove').css({
                                "display": "none",
                                "opacity": "0",
                            });
                            $(nRow).find('.campusDeliver').css({
                                'display': 'flex'
                            });
                            $(nRow).find('td:eq(6)').css({
                                "color": "green",
                                "font-weight": "bold",
                                "text-shadow": "1px 1px 10px #f44336"
                            });
                        } else if (aData.status == "4") {
                            $(nRow).find('td:eq(6)').html('Withdrawn');
                            $(nRow).find('.campusEdit').css({
                                "display": "none"
                            });
                            $(nRow).find('.campusApprove').css({
                                "display": "none",
                                "opacity": "0",
                            });
                            $(nRow).find('.campusDeliver').css({
                                'display': 'none'
                            });
                            $(nRow).find('td:eq(6)').css({
                                "color": "rgb(100,20,30)",
                                "font-weight": "bold",
                                "text-shadow": "1px 1px 10px #f44336"
                            });
                        }
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_clinic')): ?>
                        if (aData.status == "1") {
                            $(nRow).find('td:eq(6)').html('Campus');
                            $(nRow).find('td:eq(6)').css({
                                "color": "orange",
                                "font-weight": "bold",
                                "text-shadow": "1px 1px 10px #4CAF50"
                            });
                        } else if (aData.status == "2") {
                            $(nRow).find('td:eq(6)').html('Pending');
                            $(nRow).find('td:eq(6)').css({
                                "color": "blue",
                                "font-weight": "bold",
                                "text-shadow": "1px 1px 10px #f44336"
                            });
                        } else if (aData.status == "3") {
                            $(nRow).find('td:eq(6)').html('Ready for Delivery');
                            $(nRow).find('td:eq(6)').css({
                                "color": "green",
                                "font-weight": "bold",
                                "text-shadow": "1px 1px 10px #f44336"
                            });
                        } else if (aData.status == "4") {
                            $(nRow).find('td:eq(6)').html('Withdrawn');
                            $(nRow).find('td:eq(6)').css({
                                "color": "rgb(100,20,30)",
                                "font-weight": "bold",
                                "text-shadow": "1px 1px 10px #f44336"
                            });
                        } else if (aData.status == "5") {
                            $(nRow).find('td:eq(6)').html('Waiting Clinic Leader');
                            $(nRow).find('td:eq(6)').css({
                                "color": "blue",
                                "font-weight": "bold",
                                "text-shadow": "1px 1px 10px #4CAF50"
                            });
                        }
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_clinic_leader')): ?>
                        if (aData.status == "1") {
                            $(nRow).find('td:eq(6)').html('Campus');
                            $(nRow).find('td:eq(6)').css({
                                "color": "orange",
                                "font-weight": "bold",
                                "text-shadow": "1px 1px 10px #4CAF50"
                            });
                        } else if (aData.status == "2") {
                            $(nRow).find('td:eq(6)').html('Pending');
                            $(nRow).find('td:eq(6)').css({
                                "color": "blue",
                                "font-weight": "bold",
                                "text-shadow": "1px 1px 10px #f44336"
                            });
                        } else if (aData.status == "3") {
                            $(nRow).find('td:eq(6)').html('Ready for Delivery');
                            $(nRow).find('td:eq(6)').css({
                                "color": "green",
                                "font-weight": "bold",
                                "text-shadow": "1px 1px 10px #f44336"
                            });
                        } else if (aData.status == "4") {
                            $(nRow).find('td:eq(6)').html('Withdrawn');
                            $(nRow).find('td:eq(6)').css({
                                "color": "rgb(100,20,30)",
                                "font-weight": "bold",
                                "text-shadow": "1px 1px 10px #f44336"
                            });
                        } else if (aData.status == "5") {
                            $(nRow).find('td:eq(6)').html('Waiting Clinic Leader');
                            $(nRow).find('td:eq(6)').css({
                                "color": "blue",
                                "font-weight": "bold",
                                "text-shadow": "1px 1px 10px #4CAF50"
                            });
                        }
                    <?php endif; ?>
                }

            });
            ctable.on('draw', function() {
                var body = $(ctable.table().body());
                body.unhighlight();
                body.highlight(ctable.search());
            })
        });
    </script>
    <script>
        var i = 0,
            m = 0,
            j = 0,
            num = $('#item').val();

        $('#incoming_good').val(num);
        $(document).on('click', '#new_receiving', function() {
            j = 0;
            var current_date = moment();
            var current_date = current_date.format('MMMM D, YYYY');
            $('#date_created').val(current_date);
            $.get('/getskucampus', function(data) {
                $('#SKU').val(data.sku);
            });
            $('#stock').val('');
            $('#supplier').val('');
            $('#receiption').val('');
            $('#item').val('0');
            $('#card').empty();
            $('#item-error').html('');
            $('#receiption-error').html('');
            $("#operationtypes").val("1");
            $("#campusId").val('');
            $("#campustitlelbl").html("Receive products");
            $('#sku-error').html('');
            $('#shelf-error').html('');
            $('#incoming-error').html('');
            $('#voucher-error').html('');
            $('#stock-error').html('');
            $('#savebutton').text('Save');
            $('#savebutton').prop("disabled", false);
            $('#receivingForm').modal('show');
        });
        /* BEGIN: Add woreda button */
        $("#adds").click(function() {
            $('#table-error').html('');
            num = $('#item').val();
            var lastrowcount = $('#dynamicTable tr:last').find('td').eq(1).find('input').val();
            ++i;
            ++m;
            ++j;
            ++num;
            $('#item').val(num);
            $("#card").append(
                '<br><div class="card all" style="background-color: rgb(200,200,200);padding: 10px"><p style="color: black; background: green; text-align: center; width: 20px" class="rounded p' +
                j +
                '">' +
                j + ' item</p><div class="row">' +
                '<div style="display:none;"><input type="hidden" name="campus[' + m +
                '][vals]" id="vals' + m +
                '" class="vals form-control" readonly="true" style="font-weight:bold;" value="' + m +
                '"/></div>' +
                '<div style="display:none;"><input type="hidden" name="campus[' + m +
                '][id]" id="id' +
                m +
                '" class="vals form-control" readonly="true" style="font-weight:bold;" value=""/></div>' +
                '<div style="display:none;"><input type="hidden" name="campus[' + m +
                '][campus_id]" value="" class="vals form-control" readonly="true" style="font-weight:bold;" value=""/></div>' +
                '</div><div class="row"><div class="col-md-3"><div class="form-group"><label>Item | Category | Unit | Expired Date</label><select class="custom-select browser-default select2 item" name="campus[' +
                m +
                '][product_id]" id="product' +
                m +
                '" onclick="prfn(this)" onblur="checkPrFn(this)"><option value=""></option></select></div></div>' +
                '<div class="col-md-3"><div class="form-group"><label>Expire Date</label><input type="date" name="campus[' +
                m +
                '][expired_date]" id="expired_date' +
                m +
                '" class="expire_date form-control numeral-mask" onchange="edfn(this)" onblur="checkEdFn(this)"/></div></div>' +
                '<div class="col-md-3"><div calss="form-group"><label>Batch Number</label><input type="number" name="campus[' +
                m +
                '][seriel_number]" placeholder="Write Batch Number..." id="seriel_number' +
                m +
                '" class="serie form-control numeral-mask" onkeyup="srkp(this)" onclick="srfn(this)" onblur="checkSrFn(this)"/></div></div>' +
                '<div class="col-md-3"><div class="form-group"><label>Total Quantity</label><input type="text" name="campus[' +
                m +
                '][quantity]" placeholder="Write Quantity..." onkeypress="return Validatequantity(event);" id="quantity' +
                m +
                '" class="quantity form-control numeral-mask" onkeyup="qnkp(this)" onclick="qnfn(this)"/></div></div>' +
                '</div><div class="row">' +
                '<div class="col-md-3"><div class="form-group"><label>Unit Price</label><input type="text" name="campus[' +
                m +
                '][unit_price]" placeholder="Write Unit Price here..." id="unit_price' +
                m +
                '" class="unit_price form-control numeral-mask" onkeyup="upkp(this)" onclick="upfn(this)"/></div></div>' +
                '<div class="col-md-3"><div class="form-group"><label>Voucher No</label><input type="number" name="campus[' +
                m +
                '][voucher_no]" placeholder="..." id="voucher_no' +
                m +
                '" class="voucher_no form-control numeral-mask" onclick="voucherFn(this)"/></div></div>' +
                '<div class="col-md-3"><div class="form-group"><label>Item Quality Checker</label><select class="custom-select browser-default select2 quality_cheker" name="campus[' +
                m +
                '][quality_checker]" id="quality_checker' +
                m +
                '" onclick="chekerFn(this)" onblur="checkQualityFn(this)"></select></div></div><button type="button" id="removebtn' +
                m +
                '" class="btn btn-light btn-sm remove-tr float-end" style="color:#ea5455;background-color:#FFFFFF;border-color:#FFFFFF; margin-left: 30px;"><i class="fa fa-times fa-lg" aria-hidden="true"></i></button></div>' +
                '<div class="row"></div></div>'
            );

            $('#quality_checker' + m).select2({
                placeholder: "Select Quality Checker here",
            });
            $('#product' + m).select2({
                placeholder: "Select Product here",
            });
            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                $('#product' + m).append(
                    '<option value="<?php echo e($product->id); ?>"><?php echo e($product->item_name); ?> | <?php echo e($product->category->name); ?> | <?php echo e($product->unit->name); ?> (<?php echo e($product->unit->package); ?>) | expired(<?php echo e($product->item_expiration_status == '1' ? 'Yes' : 'No'); ?>)</option>'
                );
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            /*
                        $.get('/getprlist', function(data) {
                            $.each(data.product, function(key, value) {
                                package1 = value.unit.package;
                                if (package1 == "on") {
                                    package1 = "Yes";
                                } else {
                                    package1 = "No"
                                }
                                $('#product' + m).append('<option value="' + value.id + '">' + value.item_name +
                                    ' | ' + value.category.name + '| ' + value.unit
                                    .name + '(' + package1 + ')</option>');
                            });
                        });*/
            <?php $__currentLoopData = $quality; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quality): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                $('#quality_checker' + m).append(
                    '<option value="<?php echo e($quality->id); ?>"><?php echo e($quality->name); ?></option > '
                );
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            renumberRows();
        });
        //BEGIN: Click remove row
        $(document).on('click', '.remove-tr', function() {
            id = $(this).val();
            $(this).parents('.all').remove();
            renumberRows();
            --i;
            --j;
            --num;
            $('#item').val(num);
        });

        function renumberRows() {
            var ind = 1;
            $('.all').each(function(index, el) {
                $(this).children('p').html(ind);
                ind++;
            });
            if (ind == 0) {
                $('.totalrownumber').hide();
            } else {
                $('.totalrownumber').hide();
            }
        }
    </script>
    <script>
        $(document).on('click', '#savebutton', function() {

            var optype = $("#operationtypes").val();
            var campusData = $('#Register');
            var formData = campusData.serialize();
            $.ajax({
                url: '/campusstore',
                type: 'post',
                data: formData,
                beforeSend: function() {
                    cardSection.block({
                        message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                        css: {
                            backgroundColor: 'transparent',
                            color: '#fff',
                            border: '0'
                        },
                        overlayCSS: {
                            opacity: 0.5
                        }
                    });

                    if (parseFloat(optype) == "2") {
                        $('#savebutton').text('Updating...');
                        $('#savebutton').prop("disabled", true);
                    } else {
                        $('#savebutton').text('Saving...');
                        $('#savebutton').prop("disabled", true);
                    }

                },
                complete: function() {
                    cardSection.block({
                        message: '',
                        timeout: 1,
                        css: {
                            backgroundColor: '',
                            color: '',
                            border: ''
                        },
                    });
                },

                success: function(data) {

                    if (data.errors) {
                        if (data.errors.receiption) {
                            $('#receiption-error').html(data.errors.receiption[0]);
                        }
                        if (data.errors.supplier) {
                            $('#supplier-error').html(data.errors.supplier[0]);
                        }
                        if (data.errors.SKU) {
                            $('#sku-error').html(data.errors.SKU[0]);
                        }
                        if (data.errors.date_created) {
                            $('#date-error').html(data.errors.date_created[0]);
                        }
                        if (data.errors.voucher) {
                            $('#voucher-error').html(data.errors.voucher[0]);
                        }
                        alert_toast('An Error Occured~', 'error');

                        if (parseFloat(optype) == "2") {
                            $('#savebutton').text('Update');
                            $('#savebutton').prop("disabled", false);
                        } else {
                            $('#savebutton').text('Save');
                            $('#savebutton').prop("disabled", false);
                        }
                    } else if (data.new_error) {
                        alert_toast(data.new_error, 'error')

                        if (parseFloat(optype) == "2") {
                            $('#savebutton').text('Update');
                            $('#savebutton').prop("disabled", false);
                        } else {
                            $('#savebutton').text('Save');
                            $('#savebutton').prop("disabled", false);
                        }
                    } else if (data.expired_error) {
                        var exp = parseFloat(data.expired_error);
                        toastrMessage('error', 'error', data.message);
                        if (parseFloat(optype) == "2") {
                            $('#savebutton').text('Update');
                            $('#savebutton').prop("disabled", false);
                        } else {
                            $('#savebutton').text('Save');
                            $('#savebutton').prop("disabled", false);
                        }
                        $('#expired_date' + exp).css("background", errorcolor);
                    } else if (data.errors2) {
                        var expired_date = "";
                        var product = "";
                        var capacity = "";
                        var quantity = "";
                        var unit_price = "";
                        var seriel_number = "";
                        var quality_checker = "";
                        for (var k = 1; k <= m; k++) {
                            expired_date = ($('#expired_date' + k)).val();
                            product = ($('#product' + k)).val();
                            voucher_no = ($('#voucher_no' + k)).val();
                            quantity = ($('#quantity' + k)).val();
                            unit_price = ($('#unit_price' + k)).val();
                            quality_checker = ($('#quality_checker' + k)).val();
                            seriel_number = ($('#seriel_number' + k)).val();

                            if (($('#product' + k).val()) != undefined) {
                                if (product == "" || product == null) {
                                    $('#product' + k).css("background", errorcolor);
                                }
                            }
                            if (($('#quantity' + k).val()) != undefined) {
                                if (quantity == "" || quantity == null) {
                                    $('#quantity' + k).css("background", errorcolor);
                                }
                            }
                            if (($('#unit_price' + k).val()) != undefined) {
                                if (unit_price == "" || unit_price == null) {
                                    $('#unit_price' + k).css("background", errorcolor);
                                }
                            }
                            if (($('#voucher_no' + k).val()) != undefined) {
                                if (voucher_no == "" || voucher_no == null) {
                                    $('#voucher_no' + k).css("background", errorcolor);
                                }
                            }
                            if (($('#quality_checker' + k).val()) != undefined) {
                                if (quality_checker == "" || quality_checker == null) {
                                    $('#quality_checker' + k).css("background", errorcolor);
                                }
                            }
                            if (($('#seriel_number' + k).val()) != undefined) {
                                if (seriel_number == "" || seriel_number == null) {
                                    $('#seriel_number' + k).css("background", errorcolor);
                                }
                            }
                        }
                        if (parseFloat(optype) == "2") {
                            $('#savebutton').text('Update');
                            $('#savebutton').prop("disabled", false);
                        } else {
                            $('#savebutton').text('Save');
                            $('#savebutton').prop("disabled", false);
                        }
                        alert_toast("Please fill all highlighted required fields",
                            "error");
                    } else if (data.success) {
                        alert_toast('Product Recieved Successfully!', 'success');
                        $('#receivingForm').modal('hide');
                        var cTable = $('#laravel-datatable-campus').dataTable();
                        cTable.fnDraw(false);
                        $('#savebutton').html('Save');
                        $('#savebutton').prop("disabled", false);
                    } else {
                        alert('new error')
                        if (parseFloat(optype) == "2") {
                            $('#savebutton').text('Update');
                            $('#savebutton').prop("disabled", false);
                        } else {
                            $('#savebutton').text('Save');
                            $('#savebutton').prop("disabled", false);
                        }
                    }
                }
            });
        });
        /* BEGIN: Edit button */
        function campusEditFn(recordId) {
            $('#card').empty();
            $("#operationtypes").val("2");
            $("#campusId").val(recordId);
            $("#receivingForm").modal('show');
            $("#campustitlelbl").html("Edit products");
            j = 0;
            m = 0;
            i = 0;
            num = 0;
            $.get("/showsproducts" + '/' + recordId, function(data) {
                if (data.campus) {
                    $('#SKU').val(data.campus.sku);
                    $('#date_created').val(data.campus.date_created);
                    $('#supplier').val(data.campus.supplier);
                    $('#receiption').val(data.campus.receiption);
                    $('#voucher').val(data.campus.voucher);
                    $('#item').val(data.campus.item_no);
                }
                $.each(data.product, function(key, value) {
                    ++i;
                    ++m;
                    ++j;
                    ++num;
                    $("#card").append(
                        '<br><div class="card all" style="background: rgb(200,200,200); padding: 10px"><p class="p' +
                        j +
                        '">' + j + '</p><div class="row">' +
                        '<div style="display:none;"><input type="hidden" name="campus[' + m +
                        '][vals]" id="vals' + m +
                        '" class="vals form-control" readonly="true" style="font-weight:bold;" value="' +
                        m +
                        '"/></div>' +
                        '<div style="display:none;"><input type="hidden" name="campus[' + m +
                        '][id]" id="id' +
                        m +
                        '" class="vals form-control" readonly="true" style="font-weight:bold;" value="' +
                        value.id + '"/></div>' +
                        '<div style="display:none;"><input type="hidden" name="campus[' + m +
                        '][campus_id]" value="" class="vals form-control" readonly="true" style="font-weight:bold;" value=""/></div>' +
                        '</div><div class="row"><div class="col-md-3"><div class="form-group"><label>Item | Category | Unit(package)</label><select class="custom-select browser-default select2 item" name="campus[' +
                        m +
                        '][product_id]" id="product' +
                        m +
                        '" onclick="prfn(this)" onblur="checkPrFn(this)"><option value=""></option></select></div></div>' +
                        '<div class="col-md-3"><div class="form-group"><label>Expire Date</label><input type="date" name="campus[' +
                        m +
                        '][expired_date]" id="expired_date' +
                        m +
                        '" class="expire_date form-control numeral-mask" onclick="edfn(this)" onblur="checkEdFn(this)" value="' +
                        value.expired_date + '"/></div></div>' +
                        '<div class="col-md-3"><div calss="form-group"><label>Seriel Number</label><input type="number" name="campus[' +
                        m +
                        '][seriel_number]" placeholder="Write Seriel Number..." id="seriel_number' +
                        m +
                        '" class="serie form-control numeral-mask" onkeyup="srkp(this)" onclick="srfn(this)" onblur="checkSrFn(this)" value="' +
                        value.seriel_number + '"/></div></div>' +
                        '<div class="col-md-3"><div class="form-group"><label>Total Quantity</label><input type="text" name="campus[' +
                        m +
                        '][quantity]" placeholder="Write Quantity..." onkeypress="return Validatequantity(event);" id="quantity' +
                        m +
                        '" class="quantity form-control numeral-mask" onkeyup="qnkp(this)" onclick="qnfn(this)" value="' +
                        value.quantity + '"/></div>' +
                        '</div></div><div class="row"><div class="col-md-3"><div class="form-group"><label>Unit Price</label><input type="text" name="campus[' +
                        m +
                        '][unit_price]" placeholder="Write Unit Price here..." id="unit_price' +
                        m +
                        '" class="unit_price form-control numeral-mask" onkeyup="upkp(this)" onclick="upfn(this)" value="' +
                        value.unit_price + '"/></div></div>' +
                        '<div class="col-md-3"><div class="form-group"><label>Voucher No</label><input type="number" name="campus[' +
                        m +
                        '][voucher_no]" placeholder="..." id="voucher_no' +
                        m +
                        '" class="voucher_no form-control numeral-mask" onclick="voucher_noFn(this)" value="' +
                        value.voucher_no + '"/></div></div>' +
                        '<div class="col-md-3"><div class="form-group"><label>Item Quality Checker</label><select class="custom-select browser-default select2 quality_cheker" name="campus[' +
                        m +
                        '][quality_checker]" id="quality_checker' +
                        m +
                        '" onclick="chekerFn(this)" onblur="checkQualityFn(this)"></select></div></div><button type="button" id="removebtn' +
                        m +
                        '" class="btn btn-light btn-sm remove-tr" style="color:#ea5455;background-color:#FFFFFF;border-color:#FFFFFF; margin-left: 30px;"><i class="fa fa-times fa-lg" aria-hidden="true"></i></button></div>' +
                        '<div class="row"></div></div>'
                    );

                    $('#quality_checker' + m).select2({
                        placeholder: "Select Quality Checker here",
                    });
                    $('#product' + m).select2({
                        placeholder: "Select Product here",
                    });

                    var package2;
                    $.each(data.pr, function(key, value) {
                        package2 = value.unit.package;
                        if (package2 == "on") {
                            package2 = "Yes";
                        } else {
                            package2 = "No"
                        }
                        $('#product' + m).append(
                            '<option value="' + value.id +
                            '">' + value.item_name +
                            ' | ' + value.category.name + '| ' + value.unit.name + '(' +
                            value.unit.package + ')</option>');
                    });
                    $('#product' + m).val(value.product_id).trigger('change');
                    $.each(data.quality, function(key, value) {
                        $('#quality_checker' + m).append(
                            '<option value="' + value.id + '">' + value.name +
                            '</option > '
                        );
                    });
                    $('#quality_checker' + m).val(value.quality_checker).trigger('change');
                    /* $('#select2-Status' + m + '-container').parent().css({
                         "position": "relative",
                         "z-index": "2",
                         "display": "grid",
                         "table-layout": "fixed",
                         "width": "100%"
                     });*/
                });
                //end dynamic
            });
            $("#campustitlelb").html("Edit Campus & Products");
            $('#savebutton').text('Update');
            $('#savebutton').prop(
                "disabled", false);
            $("#inlineForm").modal('show');
        }

        function campusInfoFn(record_id) {
            $('#request_id').val(record_id);
            // $("#informationmodal").modal('show');
            $.get("/show_campusStore" + '/' + record_id, function(data) {
                $.each(data.campus, function(key, value) {
                    $("#incoming_info").html(data.campus.item_no);
                    $("#receiption_info").html(data.campus.receiption);
                    $("#sku_info").html(data.campus.sku);
                    $("#supplier_info").html(data.campus.supplier);
                    $("#date_created_info").html(data.campus.date_created);
                    $("#created_by").html(data.cr.username);
                    $("#updated_by").html(data.ur.username);
                    //var st = data.zone.status;
                    var ca = new Date(data.campus.created_at);

                    $("#created_at").html(data.crdate);

                    if (data.ur !== "") {
                        $("#updated_at").html(data.upgdate);
                    }
                });
                if (data.campus.status == '2') {
                    $('#send_request').css({
                        "display": "none"
                    });
                    $('#clinic_leader_approve').css({
                        "display": "none"
                    });
                    $('#state').html('Pending');
                }
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_campus')): ?>
                    $('#state').html('In Campus');
                    $('#clinic_leader_approve').css({
                        "display": "none"
                    });
                    $('#send_request').css({
                        "display": "none"
                    });
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_clinic')): ?>
                    $('#viewcode').html(data.campus.code);
                    if (data.campus.status == '5') {
                        $('#send_request').css({
                            "display": "none"
                        });
                        $('#clinic_leader_approve').css({
                            "display": "none"
                        });
                        $('#view_code').css({
                            "display": "flex"
                        });
                        $('#state').html('Request Is Waiting to be approved by Clinic Leader');
                    }
                    if (data.campus.status == '1') {
                        $('#clinic_leader_approve').css({
                            "display": "none"
                        });
                        $('#send_request').css({
                            "display": "flex"
                        });
                        $('#view_code').css({
                            "display": "flex"
                        });
                        $('#state').html('');
                    }
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_clinic_leader')): ?>
                    if (data.campus.status == '5') {
                        $('#send_request').css({
                            "display": "none"
                        });
                        $('#clinic_leader_approve').css({
                            "display": "flex"
                        });
                        $('#view_code').css({
                            "display": "flex"
                        });
                    }
                    if (data.campus.status == '1') {
                        $('#state').html('In Campus');
                        $('#clinic_leader_approve').css({
                            "display": "none"
                        });
                        $('#send_request').css({
                            "display": "none"
                        });
                    }
                <?php endif; ?>

                if (data.campus.status == '3') {
                    $('#clinic_leader_approve').css({
                        "display": "none"
                    });
                    $('#send_request').css({
                        "display": "none"
                    });
                    $('#state').html('Ready For Delivery');
                }
                if (data.campus.status == '4') {
                    $('#clinic_leader_approve').css({
                        "display": "none"
                    });
                    $('#send_request').css({
                        "display": "none"
                    });
                    $('#state').html('Delivered!');
                }
            });

            $('#productdetailtbl').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                searchHighlight: true,
                dom: 'lBfrtip', // Add l before B to include lengthMenu
                buttons: [{
                        extend: 'copy',
                        title: 'Your Title Here' // Title for the 'copy' button
                    },
                    {
                        extend: 'csv',
                        title: 'Your Title Here' // Title for the 'csv' button
                    },
                    {
                        extend: 'excel',
                        title: 'Your Title Here' // Title for the 'excel' button
                    },
                    {
                        extend: 'pdf',
                        title: 'Your Title Here' // Title for the 'pdf' button
                    },
                    {
                        extend: 'print',
                        title: 'Yout title here'
                    }
                ],
                lengthMenu: [
                    [10, 25, 50, 500, -1],
                    [10, 25, 50, 500, "All"]
                ],
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: '/campusInfo/' + record_id,
                    type: 'DELETE',
                    dataType: "json",
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },

                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'expired_date',
                        name: 'expired_date',
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return '<p class="rem"></p>';
                        },
                        orderable: true,
                        searchable: true
                    },
                    {
                        data: 'seriel_number',
                        name: 'seriel_number',
                    },
                    {
                        data: 'product.item_name',
                        name: 'product.item_name',
                    },
                    {
                        data: 'product.category.name',
                        name: 'product.category.name',
                    },
                    {
                        data: 'unit',
                        name: 'unit',
                    },
                    {
                        data: 'total_quantity',
                        name: 'total_quantity',
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return '<a class="btn btn-info productInfo" onclick="productInfoFn(' +
                                data.id +
                                ')" id="dtinfobtn" title="Open product information page" data-id = "' +
                                data.id +
                                '"><span> Detail </span></a> ';
                        },
                        orderable: false,
                        searchable: false
                    }
                ],
                "fnRowCallback": function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                    if (aData.product.item_expiration_status == '1') {
                        diff = calculateRemainingDays(aData.expired_date);
                        if (diff == "1") {
                            $(nRow).find('.rem').html('None');
                        } else if (diff > 0) {
                            $(nRow).find('.rem').html(diff);
                        } else if (diff === 0) {
                            $(nRow).find('.rem').html("Product expires today.");
                        } else {
                            $(nRow).find('.rem').html("Product has expired.");
                        }
                    } else {
                        $(nRow).find('.rem').html('Not expired')
                    }

                }
            });
            $(".collapse").collapse('show');
            $('#informationModal').modal('show');
        }

        function calculateRemainingDays(expireDate) {
            if (expireDate == "Has No Expired Date") {
                var exprt = "1";
                return exprt;
            }
            // Parse the expiration date string to Date object
            const expiryDate = new Date(expireDate);

            // Get current date
            const currentDate = new Date();

            // Calculate difference in milliseconds
            const differenceMs = expiryDate.getTime() - currentDate.getTime();
            // Convert milliseconds to days
            const remainingDays = Math.ceil(differenceMs / (1000 * 60 * 60 * 24));
            return remainingDays;


        }

        function productInfoFn(rec_id) {
            $.get("/productDetail" + '/' + rec_id, function(data) {
                if (data.store) {
                    var unit_price = parseFloat(data.store.unit_price).toLocaleString('en-US', {
                        style: 'decimal',
                        maximumFractionDigits: 2,
                        minimumFractionDigits: 2
                    });
                    var total_price = parseFloat(data.store.total_price).toLocaleString('en-US', {
                        style: 'decimal',
                        maximumFractionDigits: 2,
                        minimumFractionDigits: 2
                    });
                    $('#unitprice_info').html(unit_price + ' Birr');
                    $('#total_info').html(total_price + ' Birr');
                    $('#seriel_info').html(data.store.seriel_number);
                    $('#quantity_info').html(data.quantity);
                    if (data.product.item_expiration_status == '1') {
                        $('#expired_info').html(data.store.expired_date);
                    } else {
                        $('#expired_info').html('Item has no expired date')
                    }

                    $('#quality_info').html(data.store.quality.name);
                    $('#capacity_info').html(data.product.unit.capacity);
                    $('#voucher_info').html(data.store.voucher_no);
                }
                if (data.product) {
                    $('#product_info').html(data.product.item_name);
                    $('#category_info').html(data.product.category.name);
                    $('#unit_info').html(data.product.unit.name +
                        " (" + data.product.unit.package +
                        ")");
                    data.product.item_type == '1' ? $('#item_type_info').html("Fixed Item") : $(
                            '#item_type_info')
                        .html("None Fixed Item");
                }
                if (data.product.item_expiration_status == '1') {
                    diff = calculateRemainingDays(data.store.expired_date);
                    if (diff > 0) {
                        $('#remaining_info').html(diff);
                    } else if (diff === 0) {
                        $('#remaining_info').html("Product expires today.");
                    } else {
                        $('#remaining_info').html("Product has expired.");
                    }
                } else {
                    $('#remaining_info').html("Item Has No Expired date.");
                }


            });
            $('#infoModal').modal('show');
        }
    </script>
    <script>
        function calculateRemainingDays(expireDate) {
            // Parse the expiration date string to Date object
            const expiryDate = new Date(expireDate);

            // Get current date
            const currentDate = new Date();

            // Calculate difference in milliseconds
            const differenceMs = expiryDate.getTime() - currentDate.getTime();

            // Convert milliseconds to days
            const remainingDays = Math.ceil(differenceMs / (1000 * 60 * 60 * 24));

            return remainingDays;
        }

        function skuUp() {
            $('#sku-error').html('');
        }

        function voucherUp() {
            $('#voucher-error').html('');
        }

        function removeSupplierValidation() {
            $('#supplier-error').html('');
        }

        function removeReceiptionValidation() {
            $('#receiption-error').html('');
        }

        function receiptionUp() {
            $('#receiption-error').html('');
        }

        function edfn(ele) {
            var cid = $(ele).closest('tr').find('.vals').val();
            $('#expired_date' + cid).css("background", "white");
            $('#table-error').html('');
        }

        function prfn(ele) {
            var cid = $(ele).closest('tr').find('.vals').val();
            $('#product' + cid).css("background", "white");
            $('#table-error').html('');
        }

        function mdfn(ele) {
            var cid = $(ele).closest('tr').find('.vals').val();
            $('#model' + cid).css("background", "white");
            $('#table-error').html('');
        }


        function upkp(ele) {
            var cid = $(ele).closest('.all').find('.vals').val();
            $('#unit_price' + cid).css("background", "white");
            $('#table-error').html('');
        }

        function qnkp(ele) {
            var cid = $(ele).closest('.all').find('.vals').val();
            $('#quantity' + cid).css("background", "white");
            $('#table-error').html('');
        }

        function edfn(ele) {
            var cid = $(ele).closest('.all').find('.vals').val();
            $('#expired_date' + cid).css("background", "white");
            $('#table-error').html('');
        }

        function tpfn(ele) {
            var cid = $(ele).closest('tr').find('.vals').val();
            $('#total_price' + cid).css("background", "white");
            $('#table-error').html('');
        }

        function srkp(ele) {
            var cid = $(ele).closest('.all').find('.vals').val();
            $('#seriel_number' + cid).css("background", "white");
            $('#table-error').html('');
        }

        function closeRegisterModal() {
            $('#item_no').val('');
            $('#incoming_goods').val('');
            $('#stock').val('');
            $('#store_no').val('');
            $('#shelf_no').val('');
            $('#SKU').val('');
            $('#receiption_name').val('');
            $('#date').val('');
            $('#card').empty();
            $('#item-error').html('');
            $('#receiption-error').html('');
            $('#sku-error').html('');
            $('#shelf-error').html('');
            $('#incoming-error').html('');
            $('#store-error').html('');
            $('#stock-error').html('');
            var rTable = $('#laravel-datatable-campus').dataTable();
            rTable.fnDraw(false);
        }

        function checkProductFn(ele) {
            var cid = $(ele).closest('tr').find('.vals').val();
            var expire_date = $(ele).closest('tr').find('.expire_date').val();
            var product = $(ele).closest('tr').find('.product').val();
            var model = $(ele).closest('tr').find('.model').val();
            var quantity = $(ele).closest('tr').find('.quantity').val();
            var unit_price = $(ele).closest('tr').find('.unit_price').val();
            var total_price = $(ele).closest('tr').find('.total_price').val();
            var Depnum = "";
            var arr = [];
            var arr1 = [];
            var found = 0;
            var found1 = 0;
            $('.department_name').each(function() {
                var name = $(this).val();
                if (name == "") {} else {
                    if (arr.includes(name)) {
                        found++;
                    } else {
                        arr.push(name);
                    }
                }
            });
            $('.department_slug').each(function() {
                var name = $(this).val();
                if (name == "") {} else {
                    if (arr1.includes(name)) {
                        found1++;
                    } else {
                        arr1.push(name);
                    }
                }
            });
            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                url: '/Departmentval',
                type: 'post',
                data: {
                    streamidval: streamids,
                    Departmentnam: dep_name,
                    Departmentslug: dep_slug,
                    Did: did,
                },
                success: function(data) {
                    if (parseFloat(data.department_name) == 2) {
                        alert_toast('please highlight the input', 'error');
                        $('#department_name' + cid).val("");
                        $('#department_name' + cid).css("background", errorcolor);
                        alert_toast('Department Name has already been taken', 'error');
                        if (parseFloat(optype) == 1) {
                            $('#savebutton').text('Save');
                            $('#savebutton').prop("disabled", false);
                        } else if (parseFloat(optype) == 2) {
                            $('#savebutton').text('Update');
                            $('#savebutton').prop("disabled", false);
                        }
                    } else if (parseFloat(data.department_slug) == 2) {
                        alert_toast('please highlight the input', 'error');
                        $('#department_slug' + cid).val("");
                        $('#department_slug' + cid).css("background", errorcolor);
                        alert_toast('Department Slug has already been taken', 'error');
                        if (parseFloat(optype) == 1) {
                            $('#savebutton').text('Save');
                            $('#savebutton').prop("disabled", false);
                        } else if (parseFloat(optype) == 2) {
                            $('#savebutton').text('Update');
                            $('#savebutton').prop("disabled", false);
                        }
                    } else if (parseFloat(found) > 0) {
                        alert_toast('please highlight the input', 'error');
                        $('#department_name' + cid).val("");
                        $('#department_name' + cid).css("background", errorcolor);

                        if (parseFloat(optype) == 1) {
                            $('#savebutton').text('Save');
                            $('#savebutton').prop("disabled", false);
                        } else if (parseFloat(optype) == 2) {
                            $('#savebutton').text('Update');
                            $('#savebutton').prop("disabled", false);
                        }
                    } else if (parseFloat(found1) > 0) {
                        alert_toast('please highlight the input', 'error');
                        $('#department_slug' + cid).val("");
                        $('#department_slug' + cid).css("background", errorcolor);

                        if (parseFloat(optype) == 1) {
                            $('#savebutton').text('Save');
                            $('#savebutton').prop("disabled", false);
                        } else if (parseFloat(optype) == 2) {
                            $('#savebutton').text('Update');
                            $('#savebutton').prop("disabled", false);
                        }
                    }
                }
            });
        }

        function requestFn(record_id) {
            $.get("/checkApprove" + '/' + record_id, function(data) {
                if (data.success) {
                    $('#app_id').val(record_id);
                    $('#approveModal').modal('show');

                } else {
                    alert_toast('There is no request', 'error');
                }
            });

        }

        function deliverFn(record_id) {
            $.get("/deliverProduct" + '/' + record_id, function(data) {
                if (data.success) {
                    $('#deliver_id').val(record_id);
                    $('#code').val('');
                    $('#deliverModal').modal('show');

                } else {
                    alert_toast('There is no request', 'error');
                }
            });

        }
        $(document).on('click', '.approve_request', function() {
            var requestData = $('#request_approval');
            var formData = requestData.serialize();
            $.ajax({
                url: '/approveRequest',
                type: 'post',
                data: formData,
                beforeSend: function() {
                    $('.approve_request').text('Submitting...');
                },
                success: function(data) {
                    if (data.success) {
                        $('#approveModal').modal('hide');
                        $('.approve_request').html('Submit');
                        alert_toast('Successfully Decision is submitted!', 'success');
                        var cTable = $('#laravel-datatable-campus').dataTable();
                        cTable.fnDraw(false);
                    } else {
                        $('.approve_request').html('Submit');
                        alert_toast('Something wrong!', 'error');
                    }
                }
            });
        });
        $(document).on('click', '.deliver_request', function() {
            var deliverData = $('#request_deliver');
            var formData = deliverData.serialize();
            $.ajax({
                url: '/deliverRequest',
                type: 'post',
                data: formData,
                beforeSend: function() {
                    $('.deliver_request').text('Submitting...');
                },
                success: function(data) {
                    if (data.success) {
                        $('#code').val('');
                        $('#deliverModal').modal('hide');
                        $('.deliver_request').html('Submit');
                        alert_toast('Successfully product Delivered!', 'success');
                        var cTable = $('#laravel-datatable-campus').dataTable();
                        cTable.fnDraw(false);
                    } else {
                        $('.deliver_request').html('Submit');
                        alert_toast(data.error, 'error');
                    }
                }
            });
        });

        $('#send_request').click(function() {
            $('#requestModal').modal('show');
        });
        $('#clinic_leader_approve').click(function() {
            $('#clinicApproveModal').modal('show');
        });
        $(document).on('click', '.clinic_leader_approve', function() {
            var request_id = $('#request_id').val();
            var approve_id = $('#select_id').val();
            $('.clinic_leader_approve').html('Submitting...');
            $.get("/appRequest" + '/' + request_id + '/' + approve_id, function(data) {
                if (data.success) {
                    $('#clinicApproveModal').modal('hide');
                    $('#informationModal').modal('hide');
                    $('.clinic_leader_approve').html('Submit');
                    var cTable = $('#laravel-datatable-campus').dataTable();
                    cTable.fnDraw(false);
                    alert_toast('Successfully request is Approved!', 'success');
                } else {
                    $('.clinic_leader_approve').html('Submit');
                    alert_toast('Something wrong!', 'error');
                }
            });
        });
        $(document).on('click', '.send_request', function() {
            var request_id = $('#request_id').val();
            $('.send_request').html('Submitting...');
            $.get("/sendRequest" + '/' + request_id, function(data) {
                if (data.success) {
                    $('#requestModal').modal('hide');
                    $('#informationModal').modal('hide');
                    $('#request_id').val('');
                    $('.send_request').html('Yes');
                    var cTable = $('#laravel-datatable-campus').dataTable();
                    cTable.fnDraw(false);
                    alert_toast('Successfully request is submitted!', 'success');
                } else {
                    $('.send_request').html('Yes');
                    alert_toast('Something wrong!', 'error');
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Werabe University Project\Werabe University Project\resources\views\campus\index.blade.php ENDPATH**/ ?>