<?php $__env->startSection('title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="app-content content">
        <section id="responsive-datatable">
            <div class="row">
                <div class="col-12">
                    <!-- Your HTML content goes here -->
                    <div class="card">
                        <div class="card-header border-bottom">
                            <h3 class="card-title">Students</h3>

                            <form id="importForm" enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <input id="fileInput" type="file" name="file">
                                <button class="btn btn-warning" type="submit" id="import">Import</button>
                            </form>
                            <button type="button" class="btn btn-gradient-info btn-sm add">Add</button>

                        </div>
                        <div class="card-datatable">
                            <div id="message" class="w-100 mb-10" style="margin: 10px;"></div>
                            <div style="width:98%; margin-left:1%;">
                                <div class="table-responsive">

                                    <table id="laravel-datatable-student"
                                        class="display table-bordered table-striped table-hover dt-responsive mb-0 dataTable no-footer"
                                        style="width: 100%;" role="grid" aria-describedby="laravel-datatable-student">

                                        <thead>
                                            <tr role="row">
                                                <th scope="col" width="1%">#</th>
                                                <th nowrap="1">Full Name</th>
                                                <th nowrap="1">Student Id</th>
                                                <th nowrap="1">Sex</th>
                                                <th nowrap="1">Age</th>
                                                <th nowrap="1">Department</th>
                                                <th nowrap="1">Status</th>
                                                <th nowrap="1">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody></tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- BEGIN: Student Add modal  -->
        <div class="modal fade text-left" id="inlineForm" data-keyboard="false" data-backdrop="static" tabindex="-1"
            role="dialog" aria-labelledby="patientlbl" aria-hidden="true" style="overflow-y: scroll;">
            <div class="modal-dialog modal-xl" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="studentlbl">Add Student</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                            onclick="closeModal()">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form id="Register">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="edit_id" id="edit_id">
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-md-4">
                                    <label strong style="font-size: 16px;">Full Name</label><label
                                        style="color: red; font-size:16px;">*</label>
                                    <div class="form-group">
                                        <input type="text" placeholder="Write Patient Name here" class="form-control"
                                            name="full_name" id='full_name' autofocus onkeyup="removeNameValidation()" />
                                        <span class="text-danger">
                                            <strong id="full_name-error"></strong>
                                        </span>
                                    </div>

                                </div>
                                <div class="col-md-4">
                                    <label strong style="font-size: 16px;">Student ID</label><label
                                        style="color: red; font-size:16px;">*</label>
                                    <div class="form-group">
                                        <input type="text" placeholder="Write Student Id here" class="form-control"
                                            name="student_id" id='student_id' autofocus
                                            onkeyup="removeStudentIdValidation()" />
                                        <span class="text-danger">
                                            <strong id="student_id-error"></strong>
                                        </span>
                                    </div>

                                </div>
                                <div class="col-md-4">
                                    <label strong style="font-size: 16px;">Department</label><label
                                        style="color: red; font-size:16px;">*</label>
                                    <div class="form-group">
                                        <input type="text" placeholder="Write Department here" class="form-control"
                                            name="department" id='department' autofocus
                                            onkeyup="removeDepartmentValidation()" />
                                        <span class="text-danger">
                                            <strong id="department-error"></strong>
                                        </span>
                                    </div>

                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <label strong style="font-size: 16px;">Age</label><label
                                        style="color: red; font-size:16px;">*</label>
                                    <div class="form-group">
                                        <input type="number" placeholder="Write Age here" class="form-control"
                                            name="age" id='age' autofocus onkeyup="removeAgeValidation()" />
                                        <span class="text-danger">
                                            <strong id="age-error"></strong>
                                        </span>
                                    </div>

                                </div>
                                <div class="col-md-4">
                                    <label strong style="font-size: 16px;">Sex</label><label
                                        style="color: red; font-size:16px;">*</label>

                                    <div class="form-group">
                                        <div>
                                            <select class="custom-select browser-default select2" name="sex"
                                                id="sex" onchange="removeSexValidation()">
                                                <option value=""></option>
                                                <option value="Male">Male</option>
                                                <option value="Female">Female</option>
                                            </select>
                                            <span class="text-danger">
                                                <strong id="sex-error"></strong>
                                            </span>
                                        </div>
                                    </div>

                                </div>
                                <div class="col-md-4">
                                    <label strong style="font-size: 16px;">Entry Year</label><label
                                        style="color: red; font-size:16px;">*</label>
                                    <div class="form-group">
                                        <div>
                                            <select class="custom-select browser-default select2" name="entry_year"
                                                id="entry_year" onchange="removeYearValidation()">
                                                <option value=""></option>
                                                <option value="2013">2013</option>
                                                <option value="2014">2014</option>
                                                <option value="2015">2015</option>
                                                <option value="2016">2016</option>
                                                <option value="2017">2017</option>
                                                <option value="2018">2018</option>
                                                <option value="2019">2019</option>
                                                <option value="2020">2020</option>
                                            </select>
                                            <span class="text-danger">
                                                <strong id="entry_year-error"></strong>
                                            </span>
                                        </div>
                                    </div>

                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <label strong style="font-size: 16px;">Phone (optional)</label><label
                                        style=" font-size:16px;">
                                    </label>

                                    <div class="input-group mb-2">

                                        <div class="input-group-prepend">
                                            <button class="btn btn-outline-secondary dropdown-toggle" type="button"
                                                data-toggle="dropdown" aria-haspopup="true"
                                                aria-expanded="false">+251</button>
                                            <div class="dropdown-menu">
                                                <!-- Country code list options go here -->
                                                <!-- Add more country codes as needed -->
                                            </div>
                                        </div>
                                        <input type="tel" class="form-control" id="phone" name="phone"
                                            placeholder="Enter phone number" onkeyup="removePhoneValidation()">

                                        <span class="text-danger">
                                            <strong id="phone-error"></strong>
                                        </span>
                                    </div>

                                </div>
                                <div class="col-md-4">
                                    <label strong style="font-size: 16px;">Address (optional)</label><label
                                        style=" font-size:16px;">
                                    </label>
                                    <div class="form-group">
                                        <input type="text" placeholder="Write Category Name here" class="form-control"
                                            name="address" id='address' autofocus
                                            onkeyup="removeAddressValidation()" />
                                        <span class="text-danger">
                                            <strong id="address-error"></strong>
                                        </span>
                                    </div>

                                </div>
                                <div class="col-md-4">
                                    <label strong style="font-size: 16px;">Status</label><label
                                        style="color: red; font-size:16px;">*</label>
                                    <div class="form-group">
                                        <div>
                                            <select class="custom-select browser-default select2" name="status"
                                                id="status" onchange="removeStatusValidation()">
                                                <option value="Active">Active</option>
                                                <option value="Inactive">Inactive</option>
                                            </select>
                                            <span class="text-danger">
                                                <strong id="status-error"></strong>
                                            </span>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button id="savenewbutton" type="button" class="btn btn-info">Save &
                                New</button>
                            <button id="savebutton" type="button" class="btn btn-info">Save & Close</button>
                            <button id="closebutton" type="button" class="btn btn-danger" onclick="closeModal()"
                                data-dismiss="modal">Close</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- BEGIN: Info modal -->
        <div class="modal fade text-left" id="infoModal" data-keyboard="false" data-backdrop="static" tabindex="-1"
            role="dialog" aria-labelledby="myModalLabel133" aria-hidden="true" style="overflow-y: scroll;">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">Student Information</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form id="studentform">
                        <input type="hidden" class="_token">
                        <div class="modal-body">
                            <table style="width: 100%;">
                                <tbody>
                                    <tr>
                                        <td style="width: 40%">
                                            <label style="font-size: 14px;">Student ID: </label>
                                        </td>
                                        <td style="width: 60%">
                                            <label id="student_info" style="font-size: 14px; font-weight: bold;"></label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="width: 40%">
                                            <label style="font-size: 14px;">Full Name: </label>
                                        </td>
                                        <td style="width: 60%">
                                            <label id="name_info" style="font-size: 14px; font-weight: bold;"></label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="width: 40%">
                                            <label style="font-size: 14px;">Address: </label>
                                        </td>
                                        <td style="width: 60%">
                                            <label id="address_info" style="font-size: 14px; font-weight: bold;"></label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="width: 40%">
                                            <label style="font-size: 14px;">Age: </label>
                                        </td>
                                        <td style="width: 60%">
                                            <label id="age_info" style="font-size: 14px; font-weight: bold;"></label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="width: 40%">
                                            <label style="font-size: 14px;">Phone: </label>
                                        </td>
                                        <td style="width: 60%">
                                            <label id="phone_info" style="font-size: 14px; font-weight: bold;"></label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="width: 40%">
                                            <label style="font-size: 14px;">Department: </label>
                                        </td>
                                        <td style="width: 60%">
                                            <label id="department_info"
                                                style="font-size: 14px; font-weight: bold;"></label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="width: 40%">
                                            <label style="font-size: 14px;">Sex: </label>
                                        </td>
                                        <td style="width: 60%">
                                            <label id="sex_info" style="font-size: 14px; font-weight: bold;"></label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="width: 40%">
                                            <label style="font-size: 14px;">Entry Year: </label>
                                        </td>
                                        <td style="width: 60%">
                                            <label id="year_info" style="font-size: 14px; font-weight: bold;"></label>
                                        </td>
                                    </tr>
                                    <td>
                                        <label style="font-size: 14px;">Status: </label>
                                    </td>
                                    <td>
                                        <label id="status_info" style="font-size: 14px; font-weight: bold;"></label>
                                    </td>
                                    </tr>
                                    <tr>
                                        <td colspan="2">
                                            <div class="divider newext">
                                                <div class="divider-text">Action Information</div>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <label style="font-size: 14px;">Created By</label>
                                        </td>
                                        <td>
                                            <label id="createdby_info"
                                                style="font-size: 14px; font-weight: bold;"></label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <label style="font-size: 14px;">Created Date</label>
                                        </td>
                                        <td>
                                            <label id="createdat_info"
                                                style="font-size: 14px; font-weight: bold;"></label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <label style="font-size: 14px;">Last Edited By</label>
                                        </td>
                                        <td>
                                            <label id="updatedby_info"
                                                style="font-size: 14px; font-weight: bold;"></label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="width: 30%">
                                            <label style="font-size: 14px;">Last Edited Date</label>
                                        </td>
                                        <td style="width: 70%">
                                            <label id="updatedat_info"
                                                style="font-size: 14px; font-weight: bold;"></label>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="modal-footer">
                            <button id="closebuttonk" type="button"
                                class="btn btn-danger waves-effect waves-float waves-light"
                                data-dismiss="modal">Close</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        var errorcolor = "#ffcccc";
        $(function() {
            cardSection = $('#page-block');
        });
        /* BEGIN: Display zone table using yajra datatable */
        $(document).ready(function() {
            $('.dropdown-menu a').on('click', function() {
                var countryCode = $(this).data('country-code');
                var currentVal = $('#phone').val();
                if (currentVal.startsWith(countryCode)) {
                    return; // If the phone number already starts with the selected country code, do nothing
                }
                $('#phone').val(countryCode + ' ' +
                    currentVal); // Prepend the selected country code to the input value
            });
            var ctable = $('#laravel-datatable-student').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                searchHighlight: true,
                dom: 'lBfrtip', // Add l before B to include lengthMenu
                buttons: [{
                        extend: 'copy',
                        title: 'Student List', // Title for the 'copy' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'csv',
                        title: 'Student List', // Title for the 'csv' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'excel',
                        title: 'Student List', // Title for the 'excel' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'pdf',
                        title: 'Student List', // Title for the 'pdf' button
                        orientation: 'landscape', // Set orientation: 'landscape' or 'portrait'
                        pageSize: 'A4', // Set page size
                        customize: function(doc) {
                            // Customize header, footer, and body style
                            doc.styles.tableHeader = {
                                fillColor: '#4CAF50',
                                color: 'white',
                                alignment: 'center'
                            };
                            doc.styles.title = {
                                fontSize: 14,
                                alignment: 'center'
                            };
                            doc.defaultStyle.fontSize = 10; // Change default font size
                            doc.content[1].table.widths = '*'.repeat(doc.content[1].table.body[0]
                                .length).split(''); // Automatically adjust column widths
                            doc.pageMargins = [10, 10, 10, 10]; // Adjust page margins
                            doc.pageSize = 'A4'; // Ensure the page size is A4
                            doc.content[1].layout = {
                                hLineWidth: function(i, node) {
                                    return (i === 0 || i === node.table.body.length) ? 2 :
                                        1;
                                },
                                vLineWidth: function(i, node) {
                                    return (i === 0 || i === node.table.widths.length) ? 2 :
                                        1;
                                },
                                hLineColor: function(i, node) {
                                    return (i === 0 || i === node.table.body.length) ?
                                        'black' : 'gray';
                                },
                                vLineColor: function(i, node) {
                                    return (i === 0 || i === node.table.widths.length) ?
                                        'black' : 'gray';
                                },
                                paddingLeft: function(i, node) {
                                    return 4;
                                },
                                paddingRight: function(i, node) {
                                    return 4;
                                },
                                paddingTop: function(i, node) {
                                    return 2;
                                },
                                paddingBottom: function(i, node) {
                                    return 2;
                                },
                            };
                        },
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'print',
                        title: 'Student List',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6] // Indexes of the columns you want to include
                        }
                    }
                ],
                lengthMenu: [
                    [10, 25, 50, 500, -1],
                    [10, 25, 50, 500, "All"]
                ],
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: '/getstudents',
                    type: 'DELETE',
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'full_name',
                        name: 'full_name'
                    },
                    {
                        data: 'student_id',
                        name: 'student_id'
                    },
                    {
                        data: 'sex',
                        name: 'sex'
                    },
                    {
                        data: 'age',
                        name: 'age'
                    },
                    {
                        data: 'department',
                        name: 'department'
                    },
                    {
                        data: 'status',
                        name: 'status'
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return '<div class="btn-group dropleft"><button type="button" class="btn btn-sm dropdown-toffle hide-arrow" data-toggle="dropdown" arial-haspopup="true" arial-expanded="false"><i class="fa fa-ellipsis-v"></i></button><div class = "dropdown-menu" > ' +
                                '<a class = "dropdown-item patientView" onclick = "studentInfoFn(' +
                                data
                                .id +
                                ')" id = "dtViewbtn" title = "View student detail" data - id = "' +
                                data.id +
                                '"><i class="fa fa-info"></i><span> View Detail </span></a>' +
                                '<a class = "dropdown-item studentView" onclick = "studentEditFn(' +
                                data
                                .id +
                                ')" id = "dteditbtn" title = "Open Student update page" data - id = "' +
                                data.id +
                                '"><i class="fa fa-edit"></i><span> Edit </span></a>' +
                                '</div></div> ';
                        },
                        orderable: false,
                        searchable: false
                    }
                ],
                "fnRowCallback": function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                    if (aData.status == "Active") {
                        $(nRow).find('td:eq(7)').css({
                            "color": "#4CAF50",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #4CAF50"
                        });
                    } else if (aData.status == "Inactive") {

                        $(nRow).find('td:eq(7)').css({
                            "color": "#f44336",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #f44336"
                        });
                    }
                }
            });
            /* End: Yajra data table*/
            $('#laravel-datatable-student tbody').on('click', 'tr', function() {
                if ($(this).hasClass('selected')) {
                    $(this).removeClass('selected');
                } else {
                    $('tr.selected').removeClass('selected');
                    $(this).addClass('selected');
                }
            });

            $('#status').select2({
                minimumResultsForSearch: -1
            });
        });
        ctable.on('draw', function() {
            var body = $(ctable.table().body());
            body.unhighlight();
            body.highlight(ctable.search());
        })
    </script>
    <script>
        $('.add').click(function() {
            $('#studentlbl').html('Add Student');
            $('#full_name').val('');
            $('#student_id').val('');
            $('#address').val('');
            $('#age').val('');
            $('#sex').val('');
            $('#entry_year').val('');
            $('#department').val('');
            $('#phone').val('');
            $('#status').val('Active').trigger('change');
            $('#full_name-error').html('');
            $('#student_id-error').html('');
            $('#address-error').html('');
            $('#age-error').html('');
            $('#phone-error').html('');
            $('#sex-error').html('');
            $('#entry_year-error').html('');
            $('#status-error').html('');
            $('#sex-error').html('');
            $('#department-error').html('');
            $('#savenewbutton').css('display', 'flex');
            $('#savebutton').html('Save & Close');
            $('#savenewbutton').html('Save & New');
            $('#entry_year').select2({
                placeholder: "Select Entry Year here",
            });
            $('#doctor').select2({
                placeholder: "Select Doctor here",
            });
            $('#sex').select2({
                placeholder: "Select Sex here",
            });
            $('#inlineForm').modal('show');
        });
        $('#savebutton').click(function() {
            var categoryForm = $('#Register');
            var formData = categoryForm.serialize();
            var id = $('#edit_id').val();
            $.ajax({
                url: '/createupdatestudent/' + id,
                type: 'post',
                data: formData,
                beforeSend: function() {
                    cardSection.block({
                        message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                        css: {
                            backgroundColor: 'transparent',
                            color: '#fff',
                            border: '0'
                        },
                        overlayCSS: {
                            opacity: 0.5
                        }
                    });
                    if (id != "" && id != null) {
                        $('#savebutton').text('Updating...');
                        $('#savebutton').prop("disabled", true);
                    } else {
                        $('#savebutton').text('Saving...');
                        $('#savebutton').prop("disabled", true);
                    }

                },
                complete: function() {
                    cardSection.block({
                        message: '',
                        timeout: 1,
                        css: {
                            backgroundColor: '',
                            color: '',
                            border: ''
                        },
                    });
                },
                success: function(data) {
                    if (data.errors) {
                        if (data.errors.full_name) {
                            $('#full_name-error').html(data.errors.full_name[0]);
                        }
                        if (data.errors.student_id) {
                            $('#student_id-error').html(data.errors.student_id[0]);
                        }
                        if (data.errors.sex) {
                            $('#sex-error').html(data.errors.sex[0]);
                        }
                        if (data.errors.entry_year) {
                            $('#entry_year-error').html(data.errors.entry_year[0]);
                        }
                        if (data.errors.age) {
                            $('#age-error').html(data.errors.age[0]);
                        }
                        if (data.errors.department) {
                            $('#department-error').html(data.errors.department[0]);
                        }
                        if (data.errors.status) {
                            $('#status-error').html(data.errors.status[0]);
                        }
                        if (id != "" && id != null) {
                            $('#savebutton').text('Update');
                        } else {
                            $('#savebutton').text('Save & Close');
                        }
                        alert_toast('Check your input?', 'error');
                        $('#savebutton').prop("disabled", false);
                    } else if (data.success) {
                        alert_toast(data.success, 'success');
                        var cTable = $('#laravel-datatable-student').dataTable();
                        cTable.fnDraw(false);
                        $('#savebutton').html('Save & Close');
                        $('#savebutton').prop("disabled", false);
                        $('#inlineForm').modal('hide');
                    }
                }

            });
        });

        $('#savenewbutton').click(function() {
            var categoryForm = $('#Register');
            var formData = categoryForm.serialize();
            var id = $('#edit_id').val();
            $.ajax({
                url: '/createupdatestudent/' + id,
                type: 'post',
                data: formData,
                beforeSend: function() {
                    cardSection.block({
                        message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                        css: {
                            backgroundColor: 'transparent',
                            color: '#fff',
                            border: '0'
                        },
                        overlayCSS: {
                            opacity: 0.5
                        }
                    });
                    $('#savenewbutton').text('Saving...');
                    $('#savenewbutton').prop("disabled", true);
                },
                complete: function() {
                    cardSection.block({
                        message: '',
                        timeout: 1,
                        css: {
                            backgroundColor: '',
                            color: '',
                            border: ''
                        },
                    });
                },
                success: function(data) {
                    if (data.errors) {
                        if (data.errors.full_name) {
                            $('#full_name-error').html(data.errors.full_name[0]);
                        }
                        if (data.errors.student_id) {
                            $('#student_id-error').html(data.errors.student_id[0]);
                        }
                        if (data.errors.sex) {
                            $('#sex-error').html(data.errors.sex[0]);
                        }
                        if (data.errors.entry_year) {
                            $('#entry_year-error').html(data.errors.entry_year[0]);
                        }
                        if (data.errors.age) {
                            $('#age-error').html(data.errors.age[0]);
                        }
                        if (data.errors.department) {
                            $('#department-error').html(data.errors.department[0]);
                        }
                        if (data.errors.status) {
                            $('#status-error').html(data.errors.status[0]);
                        }
                        $('#savenewbutton').text('Save & New');
                        $('#savenewbutton').prop("disabled", false);
                    } else if (data.success) {
                        alert_toast(data.success, 'success');
                        var cTable = $('#laravel-datatable-student').dataTable();
                        cTable.fnDraw(false);
                        $('#savenewbutton').html('Save & New');
                        $('#savenewbutton').prop("disabled", false);
                        $('#full_name').val('');
                        $('#student_id').val('');
                        $('#sex').val('').trigger('change');
                        $('#entry_year').val('').trigger('change');
                        $('#age').val('');
                        $('#department').val('');
                        $('#status').val('Active').trigger('change');
                        $('#phone').val('');
                        $('#address').val('');
                        $('#inlineForm').modal('show');
                    }
                }

            });
        });
        $(document).ready(function() {
            $('#importForm').submit(function(event) {
                event.preventDefault();

                var studentForm = new FormData($(this)[0]);
                $.ajax({
                    url: '/importStudent',
                    type: 'post',
                    data: studentForm,
                    processData: false,
                    contentType: false,
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                        $('#import').text('Importing...');
                        $('#import').prop("disabled", true);
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                    success: function(data) {
                        if (data.errors) {
                            $('#import').html('Import');
                            $('#import').prop("disabled", false);
                            alert_toast("An error occurred while processing the request.",
                                'error');
                            $('#message').html(data.errors);
                            $('#message').addClass('btn btn-danger');
                            $('#fileInput').val('');
                        } else if (data.success) {
                            $('#fileInput').val('');
                            $('#message').html(data.success, 'success');
                            $('#message').addClass('btn btn-success');
                            $('#import').html('Import');
                            $('#import').prop("disabled", false);
                            alert_toast(data.success, 'success');
                            var cTable = $('#laravel-datatable-student').dataTable();
                            cTable.fnDraw(false);
                        }
                    },

                });
            });
        });

        function studentEditFn(record_id) {
            $('#edit_id').val(record_id);
            $('#studentlbl').html('Edit Student');
            $('#savenewbutton').css('display', 'none');
            $('#savebutton').html('Update');
            $.get('/editstudent/' + record_id, function(data) {
                $('#full_name').val(data.student.full_name);
                $('#student_id').val(data.student.student_id);
                $('#address').val(data.student.address);
                $('#age').val(data.student.age);
                $('#phone').val(data.student.phone);
                $('#department').val(data.student.department);
                $('#status').val(data.student.status).trigger('change');
                $('#entry_year').val(data.student.entry_year).trigger('change');
                $('#sex').val(data.student.sex).trigger('change');
            });
            $('#inlineForm').modal('show');
        }

        function studentInfoFn(record_id) {
            $.get('/show_student/' + record_id, function(data) {
                $('#name_info').html(data.student.full_name);
                $('#student_info').html(data.student.student_id);
                $('#address_info').html(data.student.address);
                $('#age_info').html(data.student.age);
                $('#phone_info').html(data.student.phone);
                $('#department_info').html(data.student.department);
                $('#year_info').html(data.student.entry_year);
                $('#sex_info').html(data.student.sex);
                $('#createdby_info').html(data.cr.username);
                $('#updatedby_info').html(data.ur.username);
                $('#createdat_info').html(data.crdate);

                if (data.ur !== "") {
                    $('#updatedat_info').html(data.upgdate);
                }
                var st = data.student.status;

                if (st == "Active") {
                    $("#status_info").html("<b style='color:#1cc88a'>" + data.student.status + "</b>");
                }
                if (st == "Inactive") {
                    $("#status_info").html("<b style='color:#e74a3b'>" + data.student.status + "</b>");
                }
            });
            $('#infoModal').modal('show');
        }
    </script>
    <script>
        function removeNameValidation() {
            $('#full_name-error').html('');
        }

        function removeStudentIdValidation() {
            $('#student_id-error').html('');
        }

        function removeDepartmentValidation() {
            $('#department-error').html('');
        }

        function removeAgeValidation() {
            $('#age-error').html('');
        }

        function removeSexValidation() {
            $('#sex-error').html('');
        }

        function removeYearValidation() {
            $('#entry_year-error').html('');
        }

        function removePhoneValidation() {
            $('#phone-error').html('');
        }

        function removeAddressValidation() {
            $('#address-error').html('');
        }

        function removeStatusValidation() {
            $('#status-error').html('');
        }

        function closeModal() {
            $('#full_name').val('');
            $('#student_id').val('');
            $('#address').val('');
            $('#age').val('');
            $('#sex').val('');
            $('#entry_year').val('');
            $('#department').val('');
            $('#phone').val('');
            $('#full_name-error').html('');
            $('#student_id-error').html('');
            $('#address-error').html('');
            $('#age-error').html('');
            $('#phone-error').html('');
            $('#sex-error').html('');
            $('#entry_year-error').html('');
            $('#status-error').html('');
            $('#sex-error').html('');
            $('#department-error').html('');
            $('#status').val('').trigger('change');
            $('#savenewbutton').css('display', 'flex');
            $('#savebutton').html('Save & Close');
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Werabe University Project\Werabe University Project\resources\views\registry\students.blade.php ENDPATH**/ ?>