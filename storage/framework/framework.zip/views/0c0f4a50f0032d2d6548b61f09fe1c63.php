<?php $__env->startSection('title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="app-content content">
        <section id="responsive-datatable">
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('proctor')): ?>
                            <select name="filter_block" id="filter_block" class="custom-select browser-default" readonly>
                                <?php $__currentLoopData = $block; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block_filter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(auth()->user()->block == $block_filter->block_name): ?>
                                        <option value="<?php echo e($block_filter->id); ?>"><?php echo e($block_filter->block_name); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        <?php else: ?>
                            <label for="">filter by block</label>
                            <select name="filter_block" id="filter_block" class="custom-select browser-default select2"
                                onchange="filterBlock()">
                                <option value=""></option>
                                <?php $__currentLoopData = $block; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block_filter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($block_filter->id); ?>"><?php echo e($block_filter->block_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        <?php endif; ?>
                    </div>
                </div>
                <input type="hidden" id="filter_id" value="0">
            </div>

            <div class="row">
                <div class="col-md-12" style="margin-top: 30px;">

                    <div class="row">

                        <!-- total dorm -->
                        <a href="" class="col-xl-3 col-md-4 mb-2">
                            <div class="card border-left-primary shadow h-60">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                <?php echo e(__('dorm.total_dorms')); ?></div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                &nbsp;<span id="total_dorm"><?php echo e($total_dorm); ?></span>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-building fa-2x text-gray-300 text-blue"
                                                style="color: blue;"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <a href="" class="col-xl-3 col-md-4 mb-2">
                            <div class="card border-left-primary shadow h-60">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                <?php echo e(__('dorm.available_dorms')); ?></div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">&nbsp;<span
                                                    id="available_dorm"><?php echo e($available_dorm); ?></span></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-building fa-2x text-gray-300 text-green"
                                                style="color: green;"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <a href="" class="col-xl-3 col-md-4 mb-2">
                            <div class="card border-left-primary shadow h-60">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1"
                                                style="font-size: 11px;">
                                                Fully Occupied Dorms</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">&nbsp;<span
                                                    id="full_occupied_dorm"><?php echo e($full_occupied_dorm); ?></span></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-building fa-2x text-red" style="color: red;"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <a href="" class="col-xl-3 col-md-4 mb-2">
                            <div class="card border-left-primary shadow h-60">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1"
                                                style="font-size: 10px;">
                                                Partial Occupied Dorms</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">&nbsp;<span
                                                    id="half_occupied_dorm"><?php echo e($partial_occupied_dorm); ?></span></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-building fa-2x text-gray-300" style="color: black;"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
            <!-- Your HTML content goes here -->
            <div class="card">
                <div class="card-header border-bottom">
                    <h3 class="card-title"><?php echo e(__('dorm.dorms')); ?></h3>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dorm.createupdate')): ?>
                        <button type="button" class="btn btn-gradient-info btn-sm add"
                            onclick="addDorm()"><?php echo e(__('dormitory.add')); ?></button>
                    <?php endif; ?>
                </div>
                <div class="card-datatable">
                    <div style="width:98%; margin-left:1%;">
                        <div class="table-responsive">

                            <table id="laravel-datatable-dorm"
                                class="display table-bordered table-striped table-hover dt-responsive mb-0 dataTable no-footer"
                                style="width: 100%; font-size: 12px;" role="grid"
                                aria-describedby="laravel-datatable-drom">

                                <thead>
                                    <tr role="row">
                                        <th scope="col" width="1%">#</th>
                                        <th nowrap><?php echo e(__('dorm.images')); ?></th>
                                        <th nowrap><?php echo e(__('dorm.block')); ?></th>
                                        <th nowrap><?php echo e(__('dorm.dorm_number')); ?></th>
                                        <th nowrap><?php echo e(__('dorm.no_of_beds')); ?></th>
                                        <th nowrap><?php echo e(__('dorm.no_of_keys')); ?></th>
                                        <th nowrap><?php echo e(__('dorm.students')); ?></th>
                                        <th nowrap><?php echo e(__('dorm.status')); ?></th>
                                        <th nowrap><?php echo e(__('dorm.action')); ?></th>
                                    </tr>
                                </thead>
                                <tbody></tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

        </section>
    </div>
    <!-- BEGIN: Add Dorm modal  -->
    <div class="modal fade" id="dormModal" data-keyboard="false" data-backdrop="static" tabindex="-1" role="dialog"
        aria-labelledby="categorylbl" aria-hidden="true" style="overflow-y: scroll;">
        <div class="modal-dialog modal-xl" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="dormlbl"><?php echo e(__('dorm.add_dorm')); ?></h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                        onclick="closeModal()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="Register" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="edit_id" id="edit_id">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-4">
                                <label strong style="font-size: 16px;"><?php echo e(__('dorm.block')); ?></label>
                                <div class="form-group">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('proctor')): ?>
                                        <select name="block_id" id="block_id" class="custom-select browser-default"
                                            readonly>
                                            <?php $__currentLoopData = $block; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(auth()->user()->block == $block->block_name): ?>
                                                    <option value="<?php echo e($block->id); ?>"><?php echo e($block->block_name); ?>

                                                    </option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    <?php else: ?>
                                        <select name="block_id" id="block_id" class="custom-select browser-default select2"
                                            onchange="removeBlockValidation()">
                                            <option value=""></option>
                                            <?php $__currentLoopData = $block; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($block->id); ?>"><?php echo e($block->block_name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    <?php endif; ?>
                                    <span class="text-danger">
                                        <strong id="block-error"></strong>
                                    </span>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label strong style="font-size: 16px;"><?php echo e(__('dorm.dorm_number')); ?></label><label
                                    style="color: red; font-size:16px;">*</label>
                                <div class="form-group">
                                    <input type="number" placeholder="<?php echo e(__('dorm.dorm_placeholder')); ?>"
                                        class="form-control" name="dorm_name" id='dorm_name' autofocus
                                        onkeyup="removeDormNumberValidation()" />
                                    <span class="text-danger">
                                        <strong id="dorm-error"></strong>
                                    </span>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label strong style="font-size: 16px;"><?php echo e(__('dorm.no_of_beds')); ?></label><label
                                    style="color: red; font-size:16px;">*</label>
                                <div class="form-group">
                                    <input type="number" placeholder="<?php echo e(__('dorm.bed_placeholder')); ?>"
                                        class="form-control" name="beds" id='beds' autofocus
                                        onkeyup="removeBedValidation()" />

                                    <span class="text-danger">
                                        <strong id="bed-error"></strong>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <label strong style="font-size: 16px;"><?php echo e(__('dorm.no_of_keys')); ?></label><label
                                    style="color: red; font-size:16px;">*</label>
                                <div class="form-group">
                                    <input type="number" placeholder="<?php echo e(__('dorm.key_placeholder')); ?>"
                                        class="form-control" name="keys" id='keys' autofocus
                                        onkeyup="removeKeyValidation()" />
                                    <span class="text-danger">
                                        <strong id="key-error"></strong>
                                    </span>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label strong style="font-size: 16px;"><?php echo e(__('dorm.remark')); ?></label><label
                                    style="color: red; font-size:16px;"></label>
                                <div class="form-group">
                                    <textarea name="remark" id="remark" placeholder="<?php echo e(__('dorm.remark_placeholder')); ?>" class="form-control"
                                        cols="30" rows="1" onkeyup="removeRemarkValidation()"></textarea>
                                    <span class="text-danger">
                                        <strong id="remark-error"></strong>
                                    </span>
                                </div>
                            </div>
                        </div><br>
                        <div class="divider">
                            <div class="divider-text"><?php echo e(__('dorm.add_new_service')); ?></div>
                        </div><br>
                        <div class="row">
                            <div class="col-xl-12 col-lg-12">
                                <div class="table-responsive">
                                    <table id="dynamicTable" class="mb-0 rtable  dt-responsive" style="width: 100%">
                                        <thead>
                                            <tr>
                                                <th style="width: 3%; text-align: center;">#</th>
                                                <th style="width: 15%; text-align: center;">
                                                    <?php echo e(__('dorm.photo')); ?><b style="color: red;"> *</b>
                                                </th>
                                                <th style="width: 15%; text-align: center;">
                                                    <?php echo e(__('dorm.service_name')); ?> <b style="color: red;"> *</b>
                                                </th>
                                                <th style="width: 15%; text-align: center;">
                                                    <?php echo e(__('dorm.quantity')); ?><b></b>
                                                </th>
                                                <th style="width: 15%; text-align: center;">
                                                    <?php echo e(__('dorm.unit_price')); ?><b></b>
                                                </th>
                                                <th style="width: 15%; text-align: center;">
                                                    <?php echo e(__('dorm.remark')); ?>

                                                    <b style="color: red;"> </b>
                                                </th>
                                                <th style="width: 15%; text-align: center;">
                                                    <?php echo e(__('dorm.status')); ?><b style="color: red;"> *</b>
                                                </th>
                                                <th style="width: 3%"></th>
                                            </tr>
                                        </thead>
                                        <tbody></tbody>
                                    </table>
                                    <span class="text-danger">
                                        <strong id="table-error"></strong>
                                    </span>
                                    <table style="width: 100%">
                                        <tbody>
                                            <tr>
                                                <td colspan="2">
                                                    <button type="button" name="adds" id="adds"
                                                        class="btn btn-success btn-sm waves-effect waves-float waves-light"><i
                                                            class="fa fa-plus" arial-hidden="true"></i>
                                                        <?php echo e(__('dorm.add_new')); ?> </button>
                                                </td>
                                                <td></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="modal-footer">
                        <button id="savedorm" type="button"
                            class="btn btn-info"><?php echo e(__('dormitory.saveblock')); ?></button>
                        <button id="closebutton" type="button" class="btn btn-danger" onclick="closeModal()"
                            data-dismiss="modal"><?php echo e(__('dormitory.close')); ?></button>
                    </div>
                </form>
            </div>

        </div>
    </div>

    <!-- BEGIN:  Dorm Information Modal -->
    <div class="modal fade" id="dormDetailModal" data-keyboard="false" data-backdrop="static" tabindex="-1"
        role="dialog" aria-labelledby="myModalLabel35" aria-hidden="true" style="overflow-y: scroll;">
        <div class="modal-dialog modal-xl" role="document" style="font-size: 11px;">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title"><?php echo e(__('dorm.dorm_information')); ?></h4>
                    <div class="row">
                        <div style="text-align: right" id="statusdisplay"></div>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                aria-hidden="true">×</span></button>
                    </div>
                </div>
                <form id="InformationForm">
                    <input type="hidden" name="_token" value="bEE2UUJ5zm8YDMuIHSOQT8ZRMeUGaxv9eDaOVNb1">
                    <input type="hidden" name="drm_id" id="drm_id">
                    <div class="modal-body">
                        <section id="input-mask-wrapper">
                            <div class="col-xl-12">
                                <div class="row">
                                    <div class="col-md-3 col-sm-12">
                                        <div class="card">
                                            <div class="card-header">
                                                <h4 class="card-title"><?php echo e(__('dorm.basic_information')); ?></h4>
                                                <div class="heading-elements">
                                                    <ul class="list-inline mb-0">

                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="card-content collapse show">
                                                <div class="card-body">
                                                    <div class="row">
                                                        <table style="width: 100%;">
                                                            <tbody>

                                                                <tr>
                                                                    <td><label strong=""
                                                                            style="font-size: 14px;"><?php echo e(__('dorm.block')); ?>

                                                                        </label>
                                                                    </td>
                                                                    <td><label id="block_info" strong=""
                                                                            style="font-size:14px;font-weight:bold;"></label>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td><label strong=""
                                                                            style="font-size: 14px;"><?php echo e(__('dorm.dorm')); ?>:
                                                                        </label>
                                                                    </td>
                                                                    <td><label id="dorm_info" strong=""
                                                                            style="font-size:14px;font-weight:bold;">
                                                                        </label>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td><label strong=""
                                                                            style="font-size: 14px;"><?php echo e(__('dorm.no_of_beds')); ?>:
                                                                        </label>
                                                                    </td>
                                                                    <td><label id="bed_info" strong=""
                                                                            style="font-size:14px;font-weight:bold;"></label>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td><label strong=""
                                                                            style="font-size: 14px;"><?php echo e(__('dorm.no_of_keys')); ?>:
                                                                        </label>
                                                                    </td>
                                                                    <td><label id="key_info" strong=""
                                                                            style="font-size:14px;font-weight:bold;"></label>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td style="width: 43%"><label strong=""
                                                                            style="font-size: 14px;"><?php echo e(__('dorm.remark')); ?></label>
                                                                    </td>
                                                                    <td style="width: 57%"><label id="remark_info"
                                                                            strong=""
                                                                            style="font-size:14px;font-weight:bold;"></label>
                                                                    </td>
                                                                </tr>

                                                                <tr>
                                                                    <td style="width: 43%"><label strong=""
                                                                            style="font-size: 14px;"><?php echo e(__('dorm.status')); ?></label>
                                                                    </td>
                                                                    <td style="width: 57%"><label id="status_info"
                                                                            strong=""
                                                                            style="font-size:14px;font-weight:bold;"><?php echo e(__('dorm.occupied')); ?></label>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                    <div class="divider newext">
                                                        <div class="divider-text"><?php echo e(__('dorm.action_information')); ?>

                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <table style="width: 100%;">
                                                            <tbody>
                                                                <tr>
                                                                    <td style="width: 35%"><label strong=""
                                                                            style="font-size: 14px;"><?php echo e(__('dorm.created_by')); ?></label>
                                                                    </td>
                                                                    <td style="width: 65%"><label id="createdby_info"
                                                                            strong=""
                                                                            style="font-size:14px;font-weight:bold;"></label>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td><label strong=""
                                                                            style="font-size: 14px;"><?php echo e(__('dorm.created_date')); ?></label>
                                                                    </td>
                                                                    <td><label id="createddate_info" strong=""
                                                                            style="font-size:14px;font-weight:bold;"></label>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td><label strong=""
                                                                            style="font-size: 14px;"><?php echo e(__('dorm.last_edited_by')); ?></label>
                                                                    </td>
                                                                    <td><label id="updatedby_info" strong=""
                                                                            style="font-size:14px;font-weight:bold;"></label>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td><label strong=""
                                                                            style="font-size: 14px;"><?php echo e(__('dorm.last_edited_date')); ?></label>
                                                                    </td>
                                                                    <td><label id="updateddate_info" strong=""
                                                                            style="font-size:14px;font-weight:bold;"></label>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-9 col-sm-12">
                                        <div class="card">
                                            <div class="card-header">
                                                <h4 class="card-title"><?php echo e(__('dorm.students')); ?></h4>
                                                <div class="heading-elements">
                                                    <ul class="list-inline mb-0">

                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="card-content collapse show">
                                                <div class="card-body">
                                                    <table id="dormstudenttbl"
                                                        class="display table-bordered table-striped table-hover dt-responsive mb-0">
                                                        <thead>
                                                            <tr role="row">
                                                                <th scope="col" width="1%">#</th>
                                                                <th nowrap><?php echo e(__('dorm.full_name')); ?></th>
                                                                <th nowrap><?php echo e(__('dorm.student_id')); ?></th>
                                                                <th nowrap><?php echo e(__('dorm.department')); ?></th>
                                                                <th nowrap>Entry Year</th>
                                                                <th nowrap><?php echo e(__('dorm.sex')); ?></th>
                                                                <th nowrap><?php echo e(__('dorm.status')); ?></th>

                                                            </tr>
                                                        </thead>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                        <br>

                                        <div class="card">
                                            <div class="card-header">
                                                <h4 class="card-title"><?php echo e(__('dorm.services')); ?></h4>
                                                <div class="heading-elements">
                                                    <ul class="list-inline mb-0">

                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="card-content collapse show">
                                                <div class="card-body">
                                                    <table id="dormservicetbl"
                                                        class="display table-bordered table-striped table-hover dt-responsive mb-0">
                                                        <thead>
                                                            <tr role="row">
                                                                <th scope="col" width="1%">#</th>
                                                                <th nowrap><?php echo e(__('dorm.images')); ?></th>
                                                                <th nowrap><?php echo e(__('dorm.service_name')); ?></th>
                                                                <th nowrap><?php echo e(__('dorm.quantity')); ?></th>
                                                                <th nowrap><?php echo e(__('dorm.unit_price')); ?></th>
                                                                <th nowrap><?php echo e(__('dorm.status')); ?></th>
                                                                <th nowrap><?php echo e(__('dorm.remark')); ?></th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                    <div class="modal-footer">
                        <button id="closebuttonk" type="button"
                            class="btn btn-danger waves-effect waves-float waves-light" data-dismiss="modal"
                            onclick="closeModal()"><?php echo e(__('dormitory.close')); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        var errorcolor = "#ffcccc";
        $(function() {
            cardSection = $('#page-block');
        });
        /* BEGIN: Display zone table using yajra datatable */
        $(document).ready(function() {
            var ctable = $('#laravel-datatable-dorm').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                searchHighlight: true,
                dom: 'lBfrtip', // Add l before B to include lengthMenu
                buttons: [{
                        extend: 'pdf',
                        title: 'Your Title Here' // Title for the 'pdf' button
                    },
                    {
                        extend: 'print',
                        title: 'Yout title here'
                    }
                ],
                lengthMenu: [
                    [10, 25, 50, 500, -1],
                    [10, 25, 50, 500, "All"]
                ],
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: '/getdorms',
                    data: function(data) {
                        data.block_id = $('#filter_block').val();
                    },
                    type: 'DELETE',
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'photo',
                        name: 'photo',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'block.block_name',
                        name: 'block.block_name'
                    },
                    {
                        data: 'dorm_name',
                        name: 'dorm_name'
                    },
                    {
                        data: 'beds',
                        name: 'beds'
                    },
                    {
                        data: 'keys',
                        name: 'keys'
                    },
                    {
                        data: 'student',
                        name: 'student'
                    },
                    {
                        data: 'status',
                        name: 'status'
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return '<div class="btn-group dropleft"><button type="button" class="btn btn-sm dropdown-toffle hide-arrow" data-toggle="dropdown" arial-haspopup="true" arial-expanded="false"><i class="fa fa-ellipsis-v"></i></button><div class = "dropdown-menu" > ' +
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dorm.edit')): ?>
                                    '<a class = "dropdown-item categoryEdit" onclick = "editDorm(' +
                                    data
                                        .id +
                                        ')" id = "dteditbtn" title = "Open dorm update page" data - id = "' +
                                        data.id +
                                        '"><i class="fa fa-edit"></i><span> Edit </span></a>' +
                                <?php endif; ?>
                            '<a class = "dropdown-item categoryEdit" onclick = "dormDetail(' +
                            data
                                .id +
                                ')" id = "dteditbtn" title = "Open View Detail update page" data - id = "' +
                                data.id +
                                '"><i class="fa fa-book"></i><span> View Detail </span></a>' +
                                '</div></div> ';
                        },
                        orderable: false,
                        searchable: false
                    }
                ],

                "fnRowCallback": function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                    if (aData.status == "Fully Occupied") {
                        $(nRow).find('td:eq(7)').css({
                            "color": "#f44336",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #f44336"
                        });
                    } else if (aData.status == "Available") {
                        $(nRow).find('td:eq(7)').css({
                            "color": "#4CAF50",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #4CAF50"
                        });
                    } else if (aData.status == "Partialy Occupied") {
                        $(nRow).find('td:eq(7)').css({
                            "color": "orange",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #4CAF50"
                        });
                    }

                }
            });
            /* End: Yajra data table*/
            $('#laravel-datatable-crud tbody').on('click', 'tr', function() {
                if ($(this).hasClass('selected')) {
                    $(this).removeClass('selected');
                } else {
                    $('tr.selected').removeClass('selected');
                    $(this).addClass('selected');
                }
            });

            $('#status').select2({
                minimumResultsForSearch: -1
            });
        });
        ctable.on('draw', function() {
            var body = $(ctable.table().body());
            body.unhighlight();
            body.highlight(ctable.search());
        })
    </script>
    <script>
        function addDorm(record_id) {
            $('#dormlbl').html('Add Dorm & Services');
            $('#edit_id').val('');
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('proctor')): ?>
            <?php else: ?>
                $('#block_id').val('');
                $('#block_id').select2({
                    placeholder: "Select a block",
                });
            <?php endif; ?>
            $('#dorm_name').val('');
            $('#beds').val('');
            $('#keys').val('');
            $('#remark').val('');
            $('#dorm-error').html('');
            $('#bed-error').html('');
            $('#key-error').html('');
            $('#remark-error').html('');
            $('#block-error').html('');
            $('#savedorm').html('<?php echo e(__('dormitory.saveblock')); ?>');
            $('#savedorm').prop("disabled", false);
            $('#dynamicTable tbody').empty();
            $('#dormModal').modal('show');
        }
        var i = 0,
            m = 0,
            j = 0;
        /* BEGIN: Add woreda button */
        $("#adds").click(function() {
            $('#table-error').html('');
            var lastrowcount = $('#dynamicTable tr:last').find('td').eq(1).find('input').val();
            ++i;
            ++m;
            ++j;
            $("#dynamicTable > tbody").append('<tr id="rowind' + m +
                '"><td style="font-weight:bold;width:3%;text-align:center;">' + j + '</td>' +
                '<td style="display:none;"><input type="hidden" name="service[' + m + '][vals]" id="vals' + m +
                '" class="vals form-control" readonly="true" style="font-weight:bold;" value="' + m +
                '"/></td>' +
                '<td style="display:none;"><input type="hidden" name="service[' + m +
                '][id]" id="id' +
                m +
                '" class="vals form-control" readonly="true" style="font-weight:bold;" value=""/></td>' +
                '<td style="display:none;"><input type="hidden" name="service[' + m +
                '][id]" value="" class="vals form-control" readonly="true" style="font-weight:bold;" value=""/></td>' +
                '<td style="width: 17%; padd"><input type="file" name="service[' + m +
                '][service_photo]"  id="Service_Name' +
                m +
                '" class="service_name form-control numeral-mask" onclick="wrfn(this)" onblur="checkWoredaNumFn(this)"/></td>' +
                '<td style="width:17%; padd"><input type="text" name="service[' + m +
                '][service_name]" placeholder="<?php echo e(__('dorm.service_name_placeholder')); ?>" id="service_name' +
                m +
                '" class="service_name form-control numeral-mask" onclick="servicenamefn(this)"/></td>' +
                '<td style="width:17%; padd"><input type="number" name="service[' + m +
                '][quantity]" placeholder="<?php echo e(__('dorm.quantity_placeholder')); ?>" id="quantity' +
                m +
                '" class="quantity form-control numeral-mask" onclick="quantityfn(this)"/></td>' +
                '<td style="width:17%; padd"><input type="number" name="service[' + m +
                '][unit_price]" placeholder="Write unit price here..." id="unit_price' +
                m +
                '" class="unit_price form-control numeral-mask" step="0.01" min="0" onclick="unitpricefn(this)"/></td>' +
                '<td style="width:17%; padd"><input type="text" name="service[' + m +
                '][remark]" placeholder="<?php echo e(__('dorm.remark_placeholder')); ?>" onkeypress="return ValidatePhone(event);" onkeyup="cusPhoneCV()" id="remark' +
                m +
                '" class="remark form-control numeral-mask" onclick="remarkfn(this)" onblur="checkRemarkFn(this)"/></td>' +
                '<td style="width:17%;"><select id="Status' + m +
                '" class="select2 form-control form-control Status" name="service[' + m +
                '][status]" onchange="statusvalfn(this)"><option value="Common">Common</option><option value="Individual">Individual</option></select></td>' +
                '<td style="width:3%;text-align:center;"><button type="button" id="removebtn' + m +
                '" class="btn btn-light btn-sm remove-tr" style="color:#ea5455;background-color:#FFFFFF;border-color:#FFFFFF"><i class="fa fa-times fa-lg" aria-hidden="true"></i></button></td></tr>'
            );

            renumberRows();
        });
        /* BEGIN: Click remove row */
        $(document).on('click', '.remove-tr', function() {
            id = $(this).val();
            $(this).parents('tr').remove();
            renumberRows();
            --i;
            --j;
        });

        /* BEGIN: Edit button */
        function editDorm(recordId) {
            $("#edit_id").val(recordId);
            $("#dormlbl").html("Edit Dorm & Service");
            $('#dynamicTable tbody').empty();
            j = 0;
            m = 0;
            i = 0;
            $.get("/showdorms" + '/' + recordId, function(data) {
                if (data.dorm) {
                    $('#dorm_name').val(data.dorm.dorm_name);
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('proctor')): ?>
                    <?php else: ?>
                        $('#block_id').val(data.dorm.block_id).trigger('change');
                    <?php endif; ?>
                    $('#beds').val(data.dorm.beds);
                    $('#keys').val(data.dorm.keys);
                    $('#remark').val(data.dorm.remark);
                }
                $.each(data.service, function(key, value) {
                    ++i;
                    ++m;
                    ++j;
                    $("#dynamicTable > tbody").append('<tr id="rowind' + m +
                        '"><td style="font-weight:bold;width:3%;text-align:center;">' + j + '</td>' +
                        '<td style="display:none;"><input type="hidden" name="service[' + m +
                        '][vals]" id="vals' + m +
                        '" class="vals form-control" readonly="true" style="font-weight:bold;" value="' +
                        m +
                        '"/></td>' +
                        '<td style="display:none;"><input type="hidden" name="service[' + m +
                        '][id]" id="id' +
                        m +
                        '" class="vals form-control" readonly="true" style="font-weight:bold;" value=""/></td>' +
                        '<td style="display:none;"><input type="hidden" name="service[' + m +
                        '][id]" value="' + value.id +
                        '" class="vals form-control" readonly="true" style="font-weight:bold;" value=""/></td>' +
                        '<td style="width: 17%; padd"><input type="file" name="service[' + m +
                        '][service_photo]"  id="Service_Name' +
                        m +
                        '" class="service_name form-control numeral-mask" onclick="wrfn(this)" onblur="checkWoredaNumFn(this)"/></td>' +
                        '<td style="width:17%; padd"><input type="text" name="service[' + m +
                        '][service_name]" placeholder="<?php echo e(__('dorm.service_name_placeholder')); ?>" id="service_name' +
                        m +
                        '" class="service_name form-control numeral-mask" value="' + value
                        .service_name +
                        '" onclick="servicenamefn(this)"/></td>' +
                        '<td style="width:17%; padd"><input type="number" name="service[' + m +
                        '][quantity]" placeholder="<?php echo e(__('dorm.quantity_placeholder')); ?>" id="quantity' +
                        m +
                        '" class="quantity form-control numeral-mask" value="' + value.quantity +
                        '" onclick="quantityfn(this)"/></td>' +
                        '<td style="width:17%; padd"><input type="number" name="service[' + m +
                        '][unit_price]" placeholder="Write unit price here..." id="unit_price' +
                        m +
                        '" class="unit_price form-control numeral-mask" value="' + value.unit_price +
                        '" step="0.01" min="0" onclick="unitpricefn(this)"/></td>' +
                        '<td style="width:17%; padd"><input type="text" name="service[' + m +
                        '][remark]" placeholder="<?php echo e(__('dorm.remark_placeholder')); ?>" onkeypress="return ValidatePhone(event);" onkeyup="cusPhoneCV()" id="remark' +
                        m +
                        '" class="remark form-control numeral-mask" value="' + value.remark +
                        '" onclick="remarkfn(this)" onblur="checkRemarkFn(this)"/></td>' +
                        '<td style="width:17%;"><select id="Status' + m +
                        '" class="select2 form-control form-control Status" name="service[' + m +
                        '][status]" onchange="statusvalfn(this)"><option value="Common">Common</option><option value="Individual">Individual</option></select></td>' +
                        '<td style="width:3%;text-align:center;"><button type="button" id="removebtn' +
                        m +
                        '" class="btn btn-light btn-sm remove-tr" style="color:#ea5455;background-color:#FFFFFF;border-color:#FFFFFF"><i class="fa fa-times fa-lg" aria-hidden="true"></i></button></td></tr>'
                    );
                    //alert(value.status)
                    var statusdefopt = '<option selected value="' + value.status + '">' + value.status +
                        '</option>';
                    if (parseFloat(value.TransactionFlag) >= 1) {
                        $('#removebtn' + m).hide();
                    } else if (parseFloat(value.TransactionFlag) == 0) {
                        $('#removebtn' + m).show();
                    }

                    var statusopt =
                        '<option value="Common">Common</option><option value="Individual">Individual</option>';
                    $('#Status' + m).append(statusopt);
                    $("#Status" + m + " option[value='" + value.status + "']").remove();
                    $('#Status' + m).append(statusdefopt);

                    $('#select2-Status' + m + '-container').parent().css({
                        "position": "relative",
                        "z-index": "2",
                        "display": "grid",
                        "table-layout": "fixed",
                        "width": "100%"
                    });
                });
                //end dynamic
            });
            $('#savedorm').text('Update');
            $('#savedorm').prop(
                "disabled", false);
            $("#dormModal").modal('show');
        }

        $('#savedorm').click(function() {
            var optype = $("#operationtypes").val();
            var categoryForm = $('#Register')[0];
            var formData = new FormData(categoryForm);
            var id = $('#edit_id').val();
            $.ajax({
                url: '/createupdatedorm/' + id,
                type: 'post',
                data: formData,
                contentType: false,
                processData: false,
                beforeSend: function() {
                    cardSection.block({
                        message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                        css: {
                            backgroundColor: 'transparent',
                            color: '#fff',
                            border: '0'
                        },
                        overlayCSS: {
                            opacity: 0.5
                        }
                    });


                    if (id != "" && id != null) {
                        $('#savedorm').html('Updating...');
                        $('#savedorm').prop("disabled", true);
                    } else {
                        $('#savedorm').html('Saving...');
                        $('#savedorm').prop("disabled", true);
                    }

                },
                complete: function() {
                    cardSection.block({
                        message: '',
                        timeout: 1,
                        css: {
                            backgroundColor: '',
                            color: '',
                            border: ''
                        },
                    });
                },

                success: function(data) {
                    if (data.errors) {
                        if (data.errors.dorm_name) {
                            $('#dorm-error').html(data.errors.dorm_name[0]);
                        }
                        if (data.errors.beds) {
                            $('#bed-error').html(data.errors.beds[0]);
                        }
                        if (data.errors.keys) {
                            $('#key-error').html(data.errors.keys[0]);
                        }
                        if (data.errors.remark) {
                            $('#remark-error').html(data.errors.remark[0]);
                        }
                        if (data.errors.block_id) {
                            $('#block-error').html(data.errors.block_id[0]);
                        }
                        if (id != "" && id != null) {
                            $('#savedorm').html('<?php echo e(__('dormitory.update')); ?>');
                        } else {
                            $('#savedorm').html('<?php echo e(__('dormitory.saveblock')); ?>');
                        }
                        $('#savedorm').prop("disabled", false);
                        alert_toast('Whoops!, An Error Occured~', 'error');
                    } else if (data.unique_error) {
                        $('#dorm-error').html(data.unique_error);
                        if (id != "" && id != null) {
                            $('#savedorm').html('<?php echo e(__('dormitory.update')); ?>');
                        } else {
                            $('#savedorm').html('<?php echo e(__('dormitory.saveblock')); ?>');
                        }
                        $('#savedorm').prop("disabled", false);
                    } else if (data.errors2) {
                        var service_name = "";
                        var quantity = "";
                        var unit_price = "";
                        var status = "";
                        for (var k = 1; k <= m; k++) {
                            service_name = ($('#service_name' + k)).val();
                            quantity = ($('#quantity' + k)).val();
                            remark = ($('#remark' + k)).val();
                            unit_price = ($('#unit_price' + k)).val();
                            status = ($('#Status' + k)).val();
                            if (($('#service_name' + k).val()) != undefined) {
                                if (service_name == "" || service_name == null) {
                                    $('#service_name' + k).css("background", errorcolor);
                                }
                            }
                            if (($('#quantity' + k).val()) != undefined) {
                                if (quantity == "" || quantity == null) {
                                    $('#quantity' + k).css("background", errorcolor);
                                }
                            }
                            if (($('#status' + k).val()) != undefined) {
                                if (status == "" || status == null) {
                                    $('#status' + k).css("background", errorcolor);
                                }
                            }
                            if (($('#unit_price' + k).val()) != undefined) {
                                if (unit_price == "" || unit_price == null) {
                                    $('#unit_price' + k).css("background", errorcolor);
                                }
                            }
                        }
                        if (id != "" && id != null) {
                            $('#savedorm').html('<?php echo e(__('dormitory.update')); ?>');
                        } else {
                            $('#savedorm').html('<?php echo e(__('dormitory.saveblock')); ?>');
                        }
                        $('#savedorm').prop("disabled", false);
                        alert_toast("Please fill all highlighted required fields",
                            "error");
                    } else if (data.success) {
                        alert_toast(data.success, 'success');
                        var cTable = $('#laravel-datatable-dorm').dataTable();
                        cTable.fnDraw(false);
                        $('#dormModal').modal('hide');
                        $('#savedorm').html('<?php echo e(__('dormitory.save_block')); ?>');
                        $('#savedorm').prop("disabled", false);
                    } else {
                        alert_toast(data.new_error, 'error')
                        if (id != "" && id != null) {
                            $('#savedorm').text('Update');
                        } else {
                            $('#savedorm').text('<?php echo e(__('dormitory.save_block')); ?> ');
                        }
                    }
                }
            });
        });

        function dormDetail(record_id) {
            $.get('/dorminfo/' + record_id, function(data) {
                if (data.dorm) {
                    $('#block_info').html(data.dorm.block.block_name);
                    $('#dorm_info').html(data.dorm.dorm_name);
                    $('#bed_info').html(data.dorm.beds);
                    $('#key_info').html(data.dorm.keys);
                    $('#remark_info').html(data.dorm.remark);
                    $('#createdby_info').html(data.cr.name);
                    $('#createddate_info').html(data.crdate);
                    $('#updatedby_info').html(data.ur.name);
                    if (data.ur !== "" || data.ur == null) {
                        $('#updateddate_info').html(data.upgdate);
                    }
                }
            });
            var studentdorm = $('#dormstudenttbl').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                searchHighlight: true,
                dom: 'Bfrtip', // Add l before B to include lengthMenu
                buttons: [],
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: '/dormstudent/' + record_id,
                    type: 'DELETE',
                    dataType: "json",
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },

                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'full_name',
                        name: 'full_name'
                    },
                    {
                        data: 'student_id',
                        name: 'student_id'
                    },
                    {
                        data: 'department',
                        name: 'department'
                    },
                    {
                        data: 'entry_year',
                        name: 'entry_year'
                    },
                    {
                        data: 'sex',
                        name: 'sex'
                    },
                    {
                        data: 'status',
                        name: 'status'
                    },
                ],
                "fnRowCallback": function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                    if (aData.status == "Active") {
                        $(nRow).find('td:eq(6)').css({
                            "color": "#4CAF50",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #4CAF50"
                        });
                    } else if (aData.status == "Inactive") {
                        $(nRow).find('td:eq(6)').css({
                            "color": "#f44336",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #f44336"
                        });
                    } else if (aData.status == "Transfer") {
                        $(nRow).find('td:eq(6)').css({
                            "color": "orange",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #4CAF50"
                        });
                    } else if (aData.status == "Cleared") {
                        $(nRow).find('td:eq(6)').css({
                            "color": "orange",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #4CAF50"
                        });
                    }

                }
            });
            var servicedorm = $('#dormservicetbl').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                searchHighlight: true,
                dom: 'Bfrtip', // Add l before B to include lengthMenu
                buttons: [],
                lengthMenu: [
                    [10, 25, 50, 500, -1],
                    [10, 25, 50, 500, "All"]
                ],
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: '/getdormservice/' + record_id,
                    type: 'DELETE',
                    dataType: "json",
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },

                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return '<img src="<?php echo url('uploads/block1.jpg'); ?>" width="40" height="35" onclick="viewServicePhoto()">';
                        },
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'service_name',
                        name: 'service_name'
                    },
                    {
                        data: 'quantity',
                        name: 'quantity'
                    },
                    {
                        data: 'unit_price',
                        name: 'unit_price'
                    },
                    {
                        data: 'status',
                        name: 'status'
                    },
                    {
                        data: 'remark',
                        name: 'remark'
                    },
                ],
                "fnRowCallback": function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                    if (aData.status == "Common") {
                        $(nRow).find('td:eq(5)').css({
                            "color": "#4CAF50",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #4CAF50"
                        });
                    } else if (aData.status == "Individual") {
                        $(nRow).find('td:eq(5)').css({
                            "color": "orange",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #f44336"
                        });
                    }

                }
            });
            $('#dormDetailModal').modal('show');
        }
        $('#filter_block').select2({
            placeholder: "Select a block",
        });
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('proctor')): ?>
            $.get('/getdormdata/' + $('#filter_block').val(), function(data) {
                if (data.success) {
                    $('#total_dorm').html(data.totaldorm);
                    $('#available_dorm').html(data.availabledorm);
                    $('#full_occupied_dorm').html(data.fulloccupieddorm);
                    $('#half_occupied_dorm').html(data.partialoccupieddorm);
                }
            });
        <?php endif; ?>
        function filterBlock() {
            $.get('/getdormdata/' + $('#filter_block').val(), function(data) {
                if (data.success) {
                    $('#total_dorm').html(data.totaldorm);
                    $('#available_dorm').html(data.availabledorm);
                    $('#full_occupied_dorm').html(data.fulloccupieddorm);
                    $('#half_occupied_dorm').html(data.partialoccupieddorm);
                }
            });
            var nTable = $('#laravel-datatable-dorm').dataTable();
            nTable.fnDraw(false);
        }

        function removeBlockValidation() {
            $('#block-error').html('');
        }

        function removeDormNumberValidation() {
            $('#dorm-error').html('');
        }

        function removeBedValidation() {
            $('#bed-error').html('');
        }

        function removeKeyValidation() {
            $('#key-error').html('');
        }

        function servicenamefn(ele) {
            var cid = $(ele).closest('tr').find('.vals').val();
            $('#service_name' + cid).css("background", "white");
        }

        function quantityfn(ele) {
            var cid = $(ele).closest('tr').find('.vals').val();
            $('#quantity' + cid).css("background", "white");
        }

        function unitpricefn(ele) {
            var cid = $(ele).closest('tr').find('.vals').val();
            $('#unit_price' + cid).css("background", "white");
        }

        function removeRemarkValidation() {
            $('#remark-error').html('');
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Werabe University Project\Werabe University Project\resources\views\dormitory\dorms1.blade.php ENDPATH**/ ?>