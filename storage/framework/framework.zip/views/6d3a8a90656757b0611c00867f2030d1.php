<?php $__env->startSection('content'); ?>
    <div class="app-content content">
        <section id="responsive-datatable">
            <div class="bg-light p-4 rounded">
                <h2>Permissions</h2>
                <div class="lead">
                    Manage your permissions here.
                    <a href="<?php echo e(route('permissions.create')); ?>" class="btn btn-primary btn-sm float-right">Add permissions</a>
                </div>

                <div class="mt-2">
                </div>

                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col" width="15%">Name</th>
                            <th scope="col" width="15%">Action Table</th>
                            <th scope="col" colspan="3" width="1%"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($permission->name); ?></td>
                                <td><?php echo e($permission->role_table); ?></td>
                                <td><a href="<?php echo e(route('permissions.edit', $permission->id)); ?>"
                                        class="btn btn-info btn-sm">Edit</a></td>


                                
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Werabe University Project\Werabe University Project\resources\views\permissions\index.blade.php ENDPATH**/ ?>