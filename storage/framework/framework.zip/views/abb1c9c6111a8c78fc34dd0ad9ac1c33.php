<?php $__env->startSection('title', 'Dashboard -/ profiles'); ?>
<?php $__env->startSection('content'); ?>
    <div class="app-content content">
        <div class="py-12">
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">
                <div class="p-4 sm:p-8 bg-white shadow sm:rounded-lg">
                    <div class="max-w-xl">
                        <?php echo $__env->make('profile.partials.update-profile-information-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $('#change_password').click(function() {
            var passwordForm = $('#passwordForm');
            var formData = passwordForm.serialize();
            $.ajax({
                url: '/changePassword',
                type: 'post',
                data: formData,
                beforeSend: function() {
                    $('#change_password').html('changing...');
                },
                success: function(data) {
                    if (data.errors) {
                        if (data.errors.current_password) {
                            $('#current-error').html(data.errors.current_password[0]);
                        }
                        if (data.errors.password) {
                            $('#new-error').html(data.errors.password[0]);
                        }
                        $('#change_password').text('Change & Save');
                        alert_toastr('An error occured!', 'error');
                    } else if (data.success) {
                        alert_toast(data.success, 'success');
                        var cTable = $('#laravel-datatable-category').dataTable();
                        cTable.fnDraw(false);
                        $('#change_password').html('Change & Save');
                    }
                }

            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Werabe University Project\Werabe University Project\resources\views\profile\edit.blade.php ENDPATH**/ ?>