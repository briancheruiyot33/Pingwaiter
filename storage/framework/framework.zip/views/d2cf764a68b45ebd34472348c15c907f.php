<?php $__env->startSection('title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="app-content content">
        <section id="responsive-datatable">
            <div class="row">
                <div class="col-12">
                    <div class="row">

                        <!-- Earnings (Monthly) Card Example -->
                        <a href="/blocks" class="col-xl-4 col-md-4 mb-1">
                            <div class="card border-left-primary shadow h-40 py-1">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total
                                                Blocks
                                            </div>
                                            <div class="row no-gutters align-items-center">
                                                <div class="col-auto">
                                                    <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800 counter"
                                                        data-target="<?php echo e($total_block); ?>">0</div>
                                                </div>
                                                <div class="col">
                                                    <div class="progress progress-sm mr-2">
                                                        <div class="progress-bar bg-primary" role="progressbar"
                                                            style="width: 100%" aria-valuenow="100" aria-valuemin="0"
                                                            aria-valuemax="100"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <a href="/blocks" class="col-xl-4 col-md-4 mb-1">
                            <div class="card border-left-success shadow h-40 py-1">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Total
                                                Male
                                                Blocks
                                            </div>
                                            <div class="row no-gutters align-items-center">
                                                <div class="col-auto">
                                                    <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800 counter"
                                                        data-target="<?php echo e($male_block); ?>">0</div>
                                                </div>
                                                <div class="col">
                                                    <div class="progress progress-sm mr-2">
                                                        <div class="progress-bar bg-success" role="progressbar"
                                                            style="width: <?php echo e($br1); ?>%" aria-valuenow="60"
                                                            aria-valuemin="0" aria-valuemax="100"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <a href="/blocks" class="col-xl-4 col-md-4 mb-1">
                            <div class="card border-left-info shadow h-40 py-1">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Total Female
                                                Blocks
                                            </div>
                                            <div class="row no-gutters align-items-center">
                                                <div class="col-auto">

                                                    <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800 counter"
                                                        data-target="<?php echo e($female_block); ?>">0</div>
                                                </div>
                                                <div class="col">
                                                    <div class="progress progress-sm mr-2">
                                                        <div class="progress-bar bg-info" role="progressbar"
                                                            style="width: <?php echo e($br2); ?>%" aria-valuenow="40"
                                                            aria-valuemin="0" aria-valuemax="100"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <!-- Your HTML content goes here -->
                    <div class="card">
                        <div class="card-header border-bottom">
                            <h3 class="card-title"><?php echo e(__('dormitory.title')); ?></h3>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('block.createupdate')): ?>
                                <button type="button" class="btn btn-gradient-info btn-sm add"
                                    onclick="addBlock()"><?php echo e(__('dormitory.add')); ?></button>
                            <?php endif; ?>
                        </div>
                        <div class="card-datatable">
                            <div style="width:98%; margin-left:1%;">
                                <div class="table-responsive">

                                    <table id="laravel-datatable-block"
                                        class="display table-bordered table-striped table-hover dt-responsive mb-0 dataTable no-footer"
                                        style="width: 100%; font-size: 11px;" role="grid"
                                        aria-describedby="laravel-datatable-block">

                                        <thead>
                                            <tr role="row">
                                                <th scope="col" width="1%" rowspan="2">#</th>
                                                <th nowrap rowspan="2"><?php echo e(__('dormitory.photo')); ?></th>
                                                <th nowrap rowspan="2"><?php echo e(__('dorm.block')); ?></th>
                                                <th nowrap rowspan="2"><?php echo e(__('dormitory.type')); ?></th>
                                                <th colspan="4" style="text-align: center"><?php echo e(__('dormitory.dorm')); ?>

                                                </th>
                                                <th nowrap rowspan="2"><?php echo e(__('dorm.students')); ?></th>
                                                <th nowrap rowspan="2"><?php echo e(__('dormitory.actions')); ?></th>
                                            </tr>
                                            <tr>
                                                <th nowrap><?php echo e(__('dormitory.total')); ?></th>
                                                <th nowrap><?php echo e(__('dormitory.available')); ?></th>
                                                <th>Full Occupied</th>
                                                <th>Partial Occupied</th>
                                            </tr>
                                        </thead>
                                        <tbody></tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

    </div>
    <!-- BEGIN: Block Add modal  -->
    <div class="modal fade text-left" id="inlineForm" data-keyboard="false" data-backdrop="static" tabindex="-1"
        role="dialog" aria-labelledby="blocklbl" aria-hidden="true" style="overflow-y: scroll;">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="blocklbl"><?php echo e(__('dormitory.blocklbl')); ?></h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                        onclick="closeModal()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="Register" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="edit_id" id="edit_id">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label strong style="font-size: 16px;"><?php echo e(__('dormitory.block_name')); ?></label><label
                                        style="color: red; font-size:16px;">*</label>
                                    <div class="form-group">
                                        <input type="text" placeholder="<?php echo e(__('dormitory.block_placeholder')); ?>"
                                            class="form-control" name="block_name" id='block_name' autofocus
                                            onkeyup="removeBlockValidation()" />
                                        <span class="text-danger">
                                            <strong id="block-error"></strong>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label strong style="font-size: 16px;"><?php echo e(__('dormitory.type')); ?></label><label
                                        style="color: red; font-size:16px;">*</label>
                                    <div class="form-group">
                                        <div>
                                            <select class="custom-select browser-default select2" name="block_type"
                                                id="block_type" onchange="removeBlockTypeValidation()">
                                                <option value=""></option>
                                                <option value="male">Male Block</option>
                                                <option value="female">Female Block</option>
                                            </select>
                                            <span class="text-danger">
                                                <strong id="block-type-error"></strong>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label strong style="font-size: 16px;"><?php echo e(__('dormitory.photo')); ?></label><label
                                        style="color: red; font-size:16px;">*</label>
                                    <div class="form-group">
                                        <input type="file" name="photo" id="photo" class="form-control">
                                        <span class="text-danger">
                                            <strong id="photo-error"></strong>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">

                            </div>
                            <div class="col-md-8">
                                <img id="photo-preview" src="#" alt="Image Preview"
                                    style="display: none; width: 100px; height: 100px; float: center;">
                            </div>
                        </div>

                    </div>

                    <div class="modal-footer">
                        <button id="savenewblock" type="button"
                            class="btn btn-info"><?php echo e(__('dormitory.savenewblock')); ?></button>
                        <button id="saveblock" type="button"
                            class="btn btn-info"><?php echo e(__('dormitory.saveblock')); ?></button>
                        <button id="closebutton" type="button" class="btn btn-danger" onclick="closeModal()"
                            data-dismiss="modal"><?php echo e(__('dormitory.close')); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- BEGIN: Block photo detail  -->
    <div class="modal fade text-left" id="blockPhotoModal" data-keyboard="false" data-backdrop="static" tabindex="-1"
        role="dialog" aria-labelledby="categorylbl" aria-hidden="true" style="overflow-y: scroll;">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content" style="background: rgb(247,247,247)">
                <div class="modal-header">
                    <h4 class="modal-title" id="categorylbl"></h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                        onclick="closeModal()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <img src="<?php echo url('uploads/block1.jpg'); ?>" width="100%" height="250px">
                </div>
                <div class="modal-footer">
                    <button id="closebutton" type="button" class="btn btn-danger" onclick="closeModal()"
                        data-dismiss="modal"><?php echo e(__('dormitory.close')); ?></button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            document.querySelectorAll('.counter').forEach(counter => {
                const target = parseInt(counter.getAttribute('data-target'));
                let count = 0;
                const duration = 2000; // Duration of the animation in milliseconds
                const interval = 20; // Interval in milliseconds
                const step = (target / (duration / interval));

                function updateCounter() {
                    count += step;
                    if (count < target + 1) {
                        counter.textContent = Math.floor(count);
                        setTimeout(updateCounter, interval);
                    } else {
                        counterElement.textContent = target;
                    }
                }

                updateCounter();
            });
        });
        document.getElementById('photo').addEventListener('change', function(event) {
            var reader = new FileReader();
            reader.onload = function() {
                var preview = document.getElementById('photo-preview');
                preview.src = reader.result;
                preview.style.display = 'block';
            }
            if (event.target.files[0]) {
                reader.readAsDataURL(event.target.files[0]);
            }
        });
        var errorcolor = "#ffcccc";
        $(function() {
            cardSection = $('#page-block');
        });
        /* BEGIN: Display zone table using yajra datatable */
        $(document).ready(function() {
            var ctable = $('#laravel-datatable-block').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                searchHighlight: true,
                dom: 'lBfrtip', // Add l before B to include lengthMenu
                buttons: [{
                        extend: 'pdf',
                        title: 'Your Title Here' // Title for the 'pdf' button
                    },
                    {
                        extend: 'print',
                        title: 'Yout title here'
                    }
                ],
                lengthMenu: [
                    [10, 25, 50, 500, -1],
                    [10, 25, 50, 500, "All"]
                ],
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: '/getblocks',
                    type: 'DELETE',
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'photo',
                        name: 'photo',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'block_name',
                        name: 'block_name'
                    },
                    {
                        data: 'block_type',
                        name: 'block_type'
                    },
                    {
                        data: 'total_dorm',
                        name: 'total_dorm'
                    },
                    {
                        data: 'available_dorm',
                        name: 'available_dorm'
                    },
                    {
                        data: 'full_occupied_dorm',
                        name: 'full_occupied_dorm'
                    },
                    {
                        data: 'partial_occupied_dorm',
                        name: 'partial_occupied_dorm'
                    },
                    {
                        data: 'student',
                        name: 'student'
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return '<div class="btn-group dropleft"><button type="button" class="btn btn-sm dropdown-toffle hide-arrow" data-toggle="dropdown" arial-haspopup="true" arial-expanded="false"><i class="fa fa-ellipsis-v"></i></button><div class = "dropdown-menu" > ' +
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('block.edit')): ?>
                                    '<a class = "dropdown-item categoryEdit" onclick = "blockEditFn(' +
                                    data
                                        .id +
                                        ')" id = "dteditbtn" title = "Open dorm update page" data - id = "' +
                                        data.id +
                                        '"><i class="fa fa-edit"></i><span> <?php echo e(__('dormitory.edit')); ?> </span></a>' +
                                <?php endif; ?>
                            '<a class = "dropdown-item blockEdit" onclick = "viewDorms(' +
                            data
                                .id +
                                ')" id = "dteditbtn" title = "Open View dorm page" data - id = "' +
                                data.id +
                                '"><i class="fa fa-eye"></i><span> View Dorms </span></a>' +
                                '</div></div> ';
                        },
                        orderable: false,
                        searchable: false
                    }
                ],
            });
            /* End: Yajra data table*/
            $('#laravel-datatable-crud tbody').on('click', 'tr', function() {
                if ($(this).hasClass('selected')) {
                    $(this).removeClass('selected');
                } else {
                    $('tr.selected').removeClass('selected');
                    $(this).addClass('selected');
                }
            });

            $('#status').select2({
                minimumResultsForSearch: -1
            });
        });
        ctable.on('draw', function() {
            var body = $(ctable.table().body());
            body.unhighlight();
            body.highlight(ctable.search());
        });
    </script>
    <script>
        $('#saveblock').click(function() {
            var categoryForm = $('#Register')[0];
            var formData = new FormData(categoryForm);
            var id = $('#edit_id').val();
            $.ajax({
                url: '/createupdateblock/' + id,
                type: 'post',
                data: formData,
                contentType: false,
                processData: false,
                beforeSend: function() {
                    cardSection.block({
                        message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                        css: {
                            backgroundColor: 'transparent',
                            color: '#fff',
                            border: '0'
                        },
                        overlayCSS: {
                            opacity: 0.5
                        }
                    });
                    if (id != "" && id != null) {
                        $('#saveblock').text('<?php echo e(__('dormitory.updating')); ?>');
                        $('#saveblock').prop("disabled", true);
                    } else {
                        $('#saveblock').text('<?php echo e(__('dormitory.saving')); ?>');
                        $('#saveblock').prop("disabled", true);
                    }

                },
                complete: function() {
                    cardSection.block({
                        message: '',
                        timeout: 1,
                        css: {
                            backgroundColor: '',
                            color: '',
                            border: ''
                        },
                    });
                },
                success: function(data) {
                    if (data.errors) {
                        if (data.errors.block_name) {
                            $('#block-error').html(data.errors.block_name[0]);
                        }
                        if (data.errors.block_type) {
                            $('#block-type-error').html(data.errors.block_type[0]);
                        }
                        if (data.errors.status) {
                            $('#status-error').html(data.errors.status[0]);
                        }
                        if (data.errors.photo) {
                            $('#photo-error').html(data.errors.photo[0]);
                        }
                        if (id != "" && id != null) {
                            $('#saveblock').html('<?php echo e(__('dormitory.update')); ?>');
                        } else {
                            $('#saveblock').html('<?php echo e(__('dormitory.saveblock')); ?>');
                        }
                        alert_toast('<?php echo e(__('dormitory.check_input')); ?>', 'error');
                        $('#saveblock').prop("disabled", false);
                    } else if (data.success) {
                        alert_toast(data.success, 'success');
                        var cTable = $('#laravel-datatable-block').dataTable();
                        cTable.fnDraw(false);
                        $('#saveblock').html('<?php echo e(__('dormitory.saveblock')); ?>');
                        $('#saveblock').prop("disabled", false);
                        $('#inlineForm').modal('hide');
                    }
                }

            });
        });

        $('#savenewblock').click(function() {
            var categoryForm = $('#Register')[0];
            var formData = new FormData(categoryForm);
            var id = $('#edit_id').val();
            $.ajax({
                url: '/createupdateblock/' + id,
                type: 'post',
                data: formData,
                contentType: false,
                processData: false,
                beforeSend: function() {
                    cardSection.block({
                        message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                        css: {
                            backgroundColor: 'transparent',
                            color: '#fff',
                            border: '0'
                        },
                        overlayCSS: {
                            opacity: 0.5
                        }
                    });
                    $('#savenewblock').html('<?php echo e(__('dormitory.saving')); ?>');
                    $('#savenewblock').prop("disabled", true);
                },
                complete: function() {
                    cardSection.block({
                        message: '',
                        timeout: 1,
                        css: {
                            backgroundColor: '',
                            color: '',
                            border: ''
                        },
                    });
                },
                success: function(data) {
                    if (data.errors) {
                        if (data.errors.block_name) {
                            $('#block-error').html(data.errors.block_name[0]);
                        }
                        if (data.errors.block_type) {
                            $('#block-type-error').html(data.errors.block_type[0]);
                        }
                        if (data.errors.status) {
                            $('#status-error').html(data.errors.status[0]);
                        }
                        if (data.errors.photo) {
                            $('#photo-error').html(data.errors.photo[0]);
                        }
                        $('#savenewblock').html('<?php echo e(__('dormitory.savenewblock')); ?>');
                        $('#savenewblock').prop("disabled", false);
                    } else if (data.success) {
                        alert_toast(data.success, 'success');
                        var cTable = $('#laravel-datatable-block').dataTable();
                        cTable.fnDraw(false);
                        $('#savenewblock').html('<?php echo e(__('dormitory.savenewblock')); ?>');
                        $('#block_name').val('');
                        $('#block_type').val('').trigger('change');
                        $('#savenewblock').prop("disabled", false);
                        $('#inlineForm').modal('show');
                    }
                }

            });
        });

        function viewBlockPhoto() {
            $('#blockPhotoModal').modal('show');
        }

        function blockEditFn(record_id) {
            $('#edit_id').val(record_id);
            $('#blocklbl').html('<?php echo e(__('dormitory.edit_block')); ?>');
            $('#savenewblock').css('display', 'none');
            $('#saveblock').html('<?php echo e(__('dormitory.update')); ?>');
            $.get('/editblock/' + record_id, function(data) {
                $('#block_name').val(data.block.block_name);
                $('#block_type').val(data.block.block_type).trigger('change');
                $('#status').val(data.block.status).trigger('change');
            });
            $('#inlineForm').modal('show');
        }

        function addBlock() {
            $('#floor').select2({
                placeholder: "<?php echo e(__('dormitory.floor_placeholder')); ?>"
            });
            $('#block_type').select2({
                placeholder: "<?php echo e(__('dormitory.block_type_placeholder')); ?>"
            });

            $('#edit_id').val('');
            $('#block-error').html('');
            $('#status-error').html('');
            $('#block-type-error').html('');
            $('#block_name').val('');
            $('#blocklbl').html('Add Block');
            $('#block_type').val('').trigger('change');
            $('#savenewblock').css({
                'display': 'flex'
            });
            $('#saveblock').html('Save & Close');
            $('#inlineForm').modal('show');
        }

        function viewDorms(record_id) {
            window.location = '/dorms';
        }

        function categoryDeleteFn(record_id) {
            $('#deleteing_id').val(record_id);
            $('#DeleteModal').modal('show');
        }
        $('.delete_category').click(function() {
            var delete_id = $('#deleteing_id').val();
            $.ajax({
                url: '/deletecategory/' + delete_id,
                type: 'get',
                beforeSend: function() {
                    $('.delete_category').text('Deleteing...');
                },
                success: function(data) {
                    if (data.errors) {
                        $('.delete_category').text('Delete');
                        alert_toast('an error occured', 'error');
                    } else if (data.success) {
                        $('.delete_category').text('Delete');
                        alert_toast(data.success, 'succes')
                        var cTable = $('#laravel-datatable-category').dataTable();
                        cTable.fnDraw(false);
                        $('#DeleteModal').modal('hide');
                    }
                }
            });
        });
    </script>
    <script>
        function removeBlockValidation() {
            $('#block-error').html('');
        }

        function removeStatusValidation() {
            $('#status-error').html('');
        }

        function removeFloorValidation() {
            $('#floor-error').html('');
        }

        function removeBlockTypeValidation() {
            $('#block-type-error').html('');
        }


        function closeModal() {
            $('#edit_id').val('');
            $('#name-error').html('');
            $('#status-error').html('');
            $('#name').val('');
            $('#status').val('').trigger('change');
            $('#savenewbutton').css('display', 'flex');
            $('#savebutton').html('Save & Close');
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Werabe University Project\Werabe University Project\resources\views\dormitory\blocks.blade.php ENDPATH**/ ?>