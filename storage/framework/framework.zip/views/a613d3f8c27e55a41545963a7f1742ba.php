<?php $__env->startSection('title', 'Dashboard -/ users'); ?>
<?php $__env->startSection('content'); ?>
    <hr>
    <style type="text/css">
        thead th {
            text-transform: uppercase;
        }

        #new_st {}
    </style>

    <div class="app-content content">
        <section id="responsive-datatable">
            
            <!-- BEGIN: instructor Add modal  -->
            <div class="modal fade text-left" id="userForm" data-keyboard="false" data-backdrop="static" tabindex="-1"
                role="dialog" aria-labelledby="usertitlelb" aria-hidden="true" style="overflow-y: scroll; display: none;"
                data-select2-id="inlineForm" arial-hidden="true">
                <div class="modal-dialog modal-xl" role="document" data-select2-id="15">
                    <div class="modal-content" data-select2-id="14">
                        <div class="modal-header">
                            <h4 class="modal-title" id="usertitlelbl"><?php echo e(__('users.add_user')); ?></h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                                onclick="closeRegisterModal()">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form id="Register" data-select2-id="Register">
                            <?php echo e(csrf_field()); ?>


                            <div class="modal-body" data-select2-id="13">
                                <div class="row">
                                    <div class="col-md-4">
                                        <input type="hidden" name="edit_id" id="edit_id">
                                        <div class="form-group">
                                            <label for=""><?php echo e(__('users.full_name')); ?>:</label><label
                                                style="color: red; font-size:16px;">*</label>
                                            <input type="text" name="name" id="name" class="form-control"
                                                onkeyup="removeNameError()"
                                                placeholder="<?php echo e(__('users.name_placeholder')); ?>">
                                            <span class="text-danger">
                                                <strong id="name-error"></strong>
                                            </span>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for=""><?php echo e(__('users.email')); ?>:</label><label
                                                style="color: red; font-size:16px;">*</label>
                                            <input type="email" name="email" id="email" class="form-control"
                                                onkeyup="removeEmailError()"
                                                placeholder="<?php echo e(__('users.email_placeholder')); ?>">
                                            <span class="text-danger">
                                                <strong id="email-error"></strong>
                                            </span>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for=""><?php echo e(__('users.username')); ?>: </label><label
                                                style="color: red; font-size:16px;">*</label>
                                            <input type="text" name="username" id="username" class="form-control"
                                                onkeyup="removeUsernameError()"
                                                placeholder="<?php echo e(__('users.username_placeholder')); ?>">
                                            <span class="text-danger">
                                                <strong id="username-error"></strong>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="row col-md-12">
                                        <div class="col-md-6" id="roleForm">
                                            <div class="form-group">
                                                <label for=""><?php echo e(__('users.role')); ?>:</label>
                                                <label style="color: red; font-size:16px;">*</label>
                                                <select class="form-control" name="role" id="role"
                                                    onclick="removeRoleError()">
                                                    <option value=""><?php echo e(__('users.role_placeholder')); ?></option>
                                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dorm_admin')): ?>
                                                            <?php if(
                                                                $role->name == 'dorm_admin' ||
                                                                    $role->name == 'dorm_management' ||
                                                                    $role->name == 'dorm_coordinator' ||
                                                                    $role->name == 'proctor' ||
                                                                    $role->name == 'finance'): ?>
                                                                <option value="<?php echo e($role->name); ?>">
                                                                    <?php echo e($role->name); ?>

                                                                </option>
                                                            <?php endif; ?>
                                                        <?php else: ?>
                                                            <option value="<?php echo e($role->name); ?>">
                                                                <?php echo e($role->name); ?></option>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <span class="text-danger">
                                                    <strong id="role-error"></strong>
                                                </span>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label strong
                                                    style="font-size: 16px;"><?php echo e(__('users.status')); ?></label><label
                                                    style="color: red; font-size:16px;">*</label>
                                                <div>
                                                    <select class="custom-select browser-default" name="status"
                                                        id="status" onclick="removeStatusValidation()">
                                                        <option value="Active">Active</option>
                                                        <option value="Inactive">Inactive</option>
                                                    </select>
                                                    <span class="text-danger">
                                                        <strong id="status-error"></strong>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button id="savebutton" type="button"
                                    class="btn btn-info waves-effect waves-float waves-light"><?php echo e(__('users.save')); ?></button>
                                <button id="closebutton" type="button" class="btn btn-danger"
                                    onclick="closeRegisterModal()" data-dismiss="modal"><?php echo e(__('users.close')); ?></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>


            
            <div class="modal fade text-left" id="deleteuserconfirmation" data-keyboard="false" data-backdrop="static"
                tabindex="-1" role="dialog" aria-labelledby="myModalLabel356" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="myModalLabel358">Confirmation</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">×</span>
                            </button>
                        </div>
                        <form id="deleteuserform">
                            <input type="hidden" name="_token" value="1GPNBVe9vuJC6vuzXAyRoVrFeGK6BQwCzQpy9egN">
                            <div class="modal-body" style="background-color:#eee8e8">
                                <label strong="" style="font-size: 16px;font-weight:bold;color:rgb(199, 21, 21);">Do
                                    you really
                                    want to delete this user?</label>
                                <div class="form-group">
                                    <input type="hidden" placeholder="" class="form-control" name="delete_id"
                                        id="delete_id" readonly="true">
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button id="deleteuserbtn" type="button"
                                    class="btn btn-info waves-effect waves-float waves-light delete_user">Delete</button>
                                <button id="closebuttonj" type="button"
                                    class="btn btn-danger waves-effect waves-float waves-light"
                                    data-dismiss="modal">Close</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>


            <!-- BEGIN: Info modal -->
            <div class="modal fade text-left" id="infoModal" data-keyboard="false" data-backdrop="static"
                tabindex="-1" role="dialog" aria-labelledby="myModalLabel1335" aria-hidden="true"
                style="overflow-y: scroll;">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title">User Information</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form id="userform">
                            <input type="hidden" class="_token">
                            <div class="modal-body">
                                <table style="width: 100%">
                                    <tbody>
                                        <tr>
                                            <td style="width: 30%">
                                                <label style="font-size: 14px;">Full Name</label>
                                            </td>
                                            <td style="width: 70%">
                                                <label id="nameinfo" style="font-size: 14px; font-weight: bold;"></label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label style="font-size: 14px;">Username</label>
                                            </td>
                                            <td>
                                                <label id="usernameinfo"
                                                    style="font-size: 14px; font-weight: bold;"></label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label style="font-size: 14px;">Email</label>
                                            </td>
                                            <td>
                                                <label id="emailinfo" style="font-size: 14px; font-weight: bold;"></label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label style="font-size: 14px;">Status</label>
                                            </td>
                                            <td>
                                                <label id="statusinfo"
                                                    style="font-size: 14px; font-weight: bold;"></label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label style="font-size: 14px;">Role</label>
                                            </td>
                                            <td>

                                                <label id="roleinfo" class="badge bg-primary"
                                                    style="color: white"></label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="2">
                                                <div class="divider newext">
                                                    <div class="divider-text">Action Information</div>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label style="font-size: 14px;">Created By</label>
                                            </td>
                                            <td>
                                                <label id="createdbyinfo"
                                                    style="font-size: 14px; font-weight: bold;"></label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label style="font-size: 14px;">Created Date</label>
                                            </td>
                                            <td>
                                                <label id="createddateinfo"
                                                    style="font-size: 14px; font-weight: bold;"></label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <label style="font-size: 14px;">Last Edited By</label>
                                            </td>
                                            <td>
                                                <label id="lasteditedbyinfo"
                                                    style="font-size: 14px; font-weight: bold;"></label>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="width: 30%">
                                                <label style="font-size: 14px;">Last Edited Date</label>
                                            </td>
                                            <td style="width: 70%">
                                                <label id="lastediteddateinfo"
                                                    style="font-size: 14px; font-weight: bold;"></label>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="modal-footer">
                                <button id="closebuttonk" type="button"
                                    class="btn btn-danger waves-effect waves-float waves-light"
                                    data-dismiss="modal">Close</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>


            <div class="row">
                <div class="col-12">
                    <!-- Your HTML content goes here -->
                    <div class="card">
                        <div class="card-header border-bottom">
                            <h3 class="card-title"><?php echo e(__('users.users')); ?></h3>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.add')): ?>
                                <button type="button" class="btn btn-gradient-info btn-sm userModal add" data-toggle="modal"
                                    data-target="#userForm"><?php echo e(__('users.add')); ?></button>
                            <?php endif; ?>
                        </div>
                        <div class="card-datatable">
                            <div style="width:98%; margin-left:1%;">
                                <div class="table-responsive">

                                    <table id="laravel-datatable-user"
                                        class="display table-bordered table-striped table-hover dt-responsive mb-0 dataTable no-footer"
                                        style="width: 100%;" role="grid" aria-describedby="laravel-datatable-user">

                                        <thead>
                                            <tr role="row">
                                                <th nowrap>#</th>
                                                <th nowrap><?php echo e(__('users.full_name')); ?></th>
                                                <th nowrap><?php echo e(__('users.email')); ?></th>
                                                <th nowrap><?php echo e(__('users.username')); ?></th>
                                                <th nowrap><?php echo e(__('users.role')); ?></th>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('assignblock')): ?>
                                                    <th nowrap>Block</th>
                                                <?php endif; ?>
                                                <th nowrap><?php echo e(__('users.status')); ?></th>
                                                <th nowrap><?php echo e(__('users.action')); ?></th>
                                            </tr>
                                        </thead>
                                        <tbody></tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <!-- BEGIN: assign service modal  -->
    <div class="modal fade" id="blockModal" data-keyboard="false" data-backdrop="static" tabindex="-1" role="dialog"
        aria-labelledby="blocklbl" aria-hidden="true" style="overflow-y: scroll;">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Assign Block </h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                        onclick="closeModal()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-body">
                    <form id="blockForm">
                        <?php echo e(csrf_field()); ?>


                        <div class="row">
                            <input type="hidden" name="usr_id" id="usr_id">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="">Block</label>
                                    <select name="block" id="block" class="custom-select browser-default select2"
                                        onchange="removeBlockValidation()">
                                        <option value=""></option>
                                        <?php $__currentLoopData = $blocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($block->block_name); ?>"><?php echo e($block->block_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select><span class="text-danger">
                                        <strong id="block-error"></strong>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>

                <div class="modal-footer">
                    
                    <button id="assignbutton" type="button" class="btn btn-info">Submit</button>
                    <button id="closebutton" type="button" class="btn btn-danger" onclick="closeModal()"
                        data-dismiss="modal"><?php echo e(__('dormitory.close')); ?></button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $(function() {
            cardSection = $('#page-block');
        });
        $('.add').click(function() {
            $('#usertitlelbl').html('<?php echo e(__('users.add_user')); ?>');
            $('#edit_id').val('');
            $('#role-error').html('');
            $('#role').val('');
        });

        $(document).ready(function() {
            /* BEGIN: yajra datatable*/
            var rtable = $('#laravel-datatable-user').DataTable({
                processing: true,
                serverSide: true,
                dom: 'lBfrtip', // Add l before B to include lengthMenu
                buttons: [{
                        extend: 'pdf',
                        title: 'User List', // Title for the 'pdf' button
                        orientation: 'landscape', // Set orientation: 'landscape' or 'portrait'
                        pageSize: 'A4', // Set page size
                        customize: function(doc) {
                            // Customize header, footer, and body style
                            doc.styles.tableHeader = {
                                fillColor: '#4CAF50',
                                color: 'white',
                                alignment: 'center'
                            };
                            doc.styles.title = {
                                fontSize: 14,
                                alignment: 'center'
                            };
                            doc.defaultStyle.fontSize = 10; // Change default font size
                            doc.content[1].table.widths = '*'.repeat(doc.content[1].table.body[0]
                                .length).split(''); // Automatically adjust column widths
                            doc.pageMargins = [10, 10, 10, 10]; // Adjust page margins
                            doc.pageSize = 'A4'; // Ensure the page size is A4
                            doc.content[1].layout = {
                                hLineWidth: function(i, node) {
                                    return (i === 0 || i === node.table.body.length) ? 2 :
                                        1;
                                },
                                vLineWidth: function(i, node) {
                                    return (i === 0 || i === node.table.widths.length) ? 2 :
                                        1;
                                },
                                hLineColor: function(i, node) {
                                    return (i === 0 || i === node.table.body.length) ?
                                        'black' : 'gray';
                                },
                                vLineColor: function(i, node) {
                                    return (i === 0 || i === node.table.widths.length) ?
                                        'black' : 'gray';
                                },
                                paddingLeft: function(i, node) {
                                    return 4;
                                },
                                paddingRight: function(i, node) {
                                    return 4;
                                },
                                paddingTop: function(i, node) {
                                    return 2;
                                },
                                paddingBottom: function(i, node) {
                                    return 2;
                                },
                            };
                        },
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'print',
                        title: 'User List',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6] // Indexes of the columns you want to include
                        }
                    }
                ],
                lengthMenu: [
                    [10, 25, 50, 500, -1],
                    [10, 25, 50, 500, "All"]
                ],
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: '/get-user',
                    type: 'DELETE',
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div></div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    }, {
                        data: 'name',
                        name: 'name'
                    },
                    {
                        data: 'email',
                        name: 'email'
                    },
                    {
                        data: 'username',
                        name: 'username'
                    }, {
                        data: 'role',
                        name: 'role'
                    },
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('assignblock')): ?>
                        {
                            data: 'block',
                            name: 'block'
                        },
                    <?php endif; ?> {
                        data: 'status',
                        name: 'status'
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return '<div class="btn-group dropleft"><button type="button" class="btn btn-sm dropdown-toffle hide-arrow" data-toggle="dropdown" arial-haspopup="true" arial-expanded="false"><i class="fa fa-ellipsis-v"></i></button><div class = "dropdown-menu"> <a class="dropdown-item userInfo" title="show" title = "Open user information page" data-id = "' +
                                data.id +
                                '"><i class="fa fa-info"></i><span> <?php echo e(__('users.info')); ?> </span></a>' +
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users.edit')): ?>
                                    '<a class ="dropdown-item editbtn" data-name="Lockset" data-status data-toggle="modal" id="smallButton" class="editbtn" title="Edit" data-id = "' +
                                    data.id +
                                        '"><i class="fa fa-edit"></i><span> <?php echo e(__('users.edit')); ?> </span></a>' +
                                <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('assignblock')): ?>
                                '<a class ="dropdown-item assignblock" data-status data-toggle="modal" id="assignblock" title="Assign Block" onclick = "assignBlock(' +
                                data.id +
                                    ')"><i class="fa fa-home"></i> <span> Assign Block </span></a>' +
                            <?php endif; ?>
                            '<a class ="dropdown-item reset" data-name="Lockset" data-status data-toggle="modal" id="smallButton" class="editbtn" title="Reset Password" onclick = "checkReset(' +
                            data.id +
                                ')"><i class="fa fa-key"></i><span> <?php echo e(__('users.reset_password')); ?> </span></a>' +
                                '</div></div> ';
                        },
                        orderable: false,
                        searchable: false
                    }
                ],

                "fnRowCallback": function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                    $(nRow).find('td:eq(4)').css({
                        "color": "orange",
                        "font-weight": "bold",
                        "text-shadow": "1px 1px 10px #4CAF50"
                    });
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('assignblock')): ?>
                        if (aData.role == 'proctor') {
                            $(nRow).find('.assignblock').css({
                                'display': 'flex'
                            });
                        } else {
                            $(nRow).find('.assignblock').css({
                                'display': 'none'
                            });
                        }
                        if (aData.status == "Active") {
                            $(nRow).find('td:eq(6)').css({
                                "color": "#4CAF50",
                                "font-weight": "bold",
                                "text-shadow": "1px 1px 10px #4CAF50"
                            });
                        } else if (aData.status == "Inactive") {

                            $(nRow).find('td:eq(6)').css({
                                "color": "#f44336",
                                "font-weight": "bold",
                                "text-shadow": "1px 1px 10px #f44336"
                            });
                        }
                    <?php else: ?>
                        if (aData.status == "Active") {
                            $(nRow).find('td:eq(5)').css({
                                "color": "#4CAF50",
                                "font-weight": "bold",
                                "text-shadow": "1px 1px 10px #4CAF50"
                            });
                        } else if (aData.status == "Inactive") {

                            $(nRow).find('td:eq(5)').css({
                                "color": "#f44336",
                                "font-weight": "bold",
                                "text-shadow": "1px 1px 10px #f44336"
                            });
                        }
                    <?php endif; ?>
                }
            });
            /* End: Yajra data table*/
            $('#laravel-datatable-crud tbody').on('click', 'tr', function() {
                if ($(this).hasClass('selected')) {
                    $(this).removeClass('selected');
                } else {
                    $('tr.selected').removeClass('selected');
                    $(this).addClass('selected');
                }
            });

            $('#status').select2({
                minimumResultsForSearch: -1
            });
        });

        /* BEGIN: Save button */
        $(document).on('click', '#savebutton', function() {
            var userData = $('#Register');
            var dataForm = userData.serialize();
            var edit = $('#edit_id').val();
            $.ajax({
                url: '/userStore',
                type: 'post',
                data: dataForm,
                beforeSend: function() {
                    if (edit != '') {
                        $('#savebutton').text('Updating...')
                    } else {
                        $('#savebutton').text('Saving...')
                    }

                },
                success: function(data) {
                    if (data.errors) {
                        if (data.errors.name) {
                            $('#name-error').html(data.errors.name[0]);
                        }
                        if (data.errors.email) {
                            $('#email-error').html(data.errors.email[0]);
                        }
                        if (data.errors.username) {
                            $('#username-error').html(data.errors.username[0]);
                        }
                        if (data.errors.status) {
                            $('#status-error').html(data.errors.status[0]);
                        }
                        if (data.errors.role) {
                            $('#role-error').html(data.errors.role[0]);
                        }
                        if (edit != '') {
                            $('#savebutton').text('Update')
                        } else {
                            $('#savebutton').text('Save')
                        }
                    }
                    if (data.success) {
                        alert_toast(data.success, 'success');
                        $('#savebutton').html('Save');
                        $('#userForm').modal('hide');
                        $('#name').val('');
                        $('#email').val('');
                        $('#username').val('');
                        $('#role').val('');
                        $('#edit_id').val('');
                        $('#status').trigger('').change();

                        var oTable = $('#laravel-datatable-user').dataTable();
                        oTable.fnDraw(false);
                    }
                }
            });
        });

        /* BEGIN: Edit Button */
        var check_role = 0;
        $(document).on('click', '.editbtn', function() {
            check_role++;
            $('#usertitlelbl').html('<?php echo e(__('edit_user')); ?>');
            var edit_id = $(this).attr('data-id');
            $('#edit_id').val(edit_id);
            $('#savebutton').html('<?php echo e(__('update')); ?>');
            $.ajax({
                url: '/editUser/' + edit_id,
                type: 'get',
                success: function(data) {
                    if (data.success) {
                        $('#name').val(data.success.name);
                        $('#email').val(data.success.email);
                        $('#username').val(data.success.username);
                        $('#status').val(data.success.status).trigger('change');
                        $('#role').val(data.userRole).trigger('change');
                        $('#userForm').modal('show');

                        var oTable = $('#laravel-datatable-user').dataTable();
                        oTable.fnDraw(false);
                    }
                }
            });
        });

        function checkReset(record_id) {
            var check = confirm('Are you sure to reset password?');
            if (check === true) {
                resetPassword(record_id);
            }
        }

        function resetPassword(record_id) {
            $.get('/resetpassword/' + record_id, function(data) {
                if (data.success) {
                    toastrMessage('success',
                        '<p style="color: white; font-size: 15px; background: blue; margin-top: 10px; padding: 10px;">' +
                        data.success + '</p>',
                        'success');
                } else {
                    toastrMessage('error', 'An Error Occured!', 'error');
                }
            });
        }
        /*BEGIN: Delete Button*/

        $(document).on('click', '.deletebtn', function() {
            var delete_id = $(this).attr('data-id');
            $('#deleteuserconfirmation').modal('show');
            $('#delete_id').val(delete_id);
        });
        $(document).on('click', '.delete_user', function(e) {
            e.preventDefault();

            $(this).text('Deleting..');
            var id = $('#delete_id').val();

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $.ajax({
                type: "DELETE",
                url: "/delete-user/" + id,
                dataType: "json",
                success: function(response) {
                    // console.log(response);
                    if (response.success) {
                        alert_toast('User Deleted Successfully.', 'success');
                        $('.delete_user').text('Delete');
                        $('#deleteuserconfirmation').modal('hide');
                        var oTable = $('#laravel-datatable-user').dataTable();
                        oTable.fnDraw(false);
                    }
                }
            });
        });

        /* BEGIN: Info BUtton */
        $(document).on('click', '.userInfo', function() {
            var info_id = $(this).attr('data-id');
            $.ajax({
                url: '/infoUser/' + info_id,
                type: 'get',
                success: function(data) {
                    if (data.users) {
                        $('#nameinfo').html(data.users.name);
                        $('#usernameinfo').html(data.users.username);
                        $('#emailinfo').html(data.users.email);
                        $('#createdbyinfo').html(data.cr.username);
                        if (data.users.status == "Active") {
                            $('#statusinfo').html(
                                "<sapn style='color: #1cc88a; font-weight: bold;font-size: 16px;'>" +
                                data.users.status + "</span>");
                        } else {
                            $('#statusinfo').html(
                                "<sapn style='color: #e74a3b; font-weight: bold; font-size: 16px;'>" +
                                data.users.status + "</span>");
                        }
                        $('#lasteditedbyinfo').html(data.ur.username);
                        $('#createddateinfo').html(data.crdate);

                        if (data.ur !== "") {
                            $('#lastediteddateinfo').html(data.upgdate);
                        }
                        if (data.userRole != "") {
                            $('#roleinfo').html(data.userRole);
                        } else {
                            $('#roleinfo').html('Not assigned Yet!')
                        }

                    }
                }
            });
            $('#infoModal').modal('show');
        });

        function assignBlock(record_id) {
            $('#block-error').html('');
            $('#usr_id').val(record_id);
            $('#block').val('');
            $('#block').select2({
                placeholder: "Select a block",
            });
            $('#blockModal').modal('show');
        }

        function removeBlockValidation() {
            $('#block-error').html('');
        }
        $('#assignbutton').click(function() {
            var assignForm = $('#blockForm');
            var formData2 = assignForm.serialize();
            $.ajax({
                url: '/assignblock',
                type: 'post',
                data: formData2,
                beforeSend: function() {
                    cardSection.block({
                        message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                        css: {
                            backgroundColor: 'transparent',
                            color: '#fff',
                            border: '0'
                        },
                        overlayCSS: {
                            opacity: 0.5
                        }
                    });
                    $('#assignbutton').text('Submiting...');
                    $('#assignbutton').prop("disabled", true);

                },
                complete: function() {
                    cardSection.block({
                        message: '',
                        timeout: 1,
                        css: {
                            backgroundColor: '',
                            color: '',
                            border: ''
                        },
                    });
                },
                success: function(data) {
                    if (data.errors) {
                        if (data.errors.block) {
                            $('#block-error').html(data.errors.block[0]);
                        }
                        $('#assignbutton').text('Submit');
                        alert_toast('Check your input?', 'error');
                        $('#assignbutton').prop("disabled", false);
                    } else if (data.success) {
                        var cTable = $('#laravel-datatable-user').dataTable();
                        cTable.fnDraw(false);
                        alert_toast(data.success, 'success');
                        $('#assignbutton').html('Submit');
                        $('#assignbutton').prop("disabled", false);
                        $('#blockModal').modal('hide');
                    }
                }

            });
        });
        /* BEGIN: functions */
        function removeNameError() {
            $('#name-error').html('');
        }

        function removeRoleError() {
            $('#role-error').html('');
        }

        function removeEmailError() {
            $('#email-error').html('');
        }

        function removeUsernameError() {
            $('#username-error').html('');
        }

        function closeRegisterModal() {
            $('#name-error').html('');
            $('#email-error').html('');
            $('#username-error').html('');
            $('#name').val('');
            $('#email').val('');
            $('#username').val('');
            $('#savebutton').html('Save');
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Werabe University Project\Werabe University Project\resources\views/users/index1.blade.php ENDPATH**/ ?>