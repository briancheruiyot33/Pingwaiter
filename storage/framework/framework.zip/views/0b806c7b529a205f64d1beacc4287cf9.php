<?php $__env->startSection('title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="app-content content">
        <section id="responsive-datatable">

            <div class="row">
                <div class="col-xl-4 col-md-6">
                    <div class="card bg-primary text-white mb-4">
                        <div class="card-body">All Common Request: <span id="total_block"><?php echo e($totalcommonservice); ?></span>
                        </div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="#">All Individual Request:
                                <span id="total_student"><?php echo e($totalindividualservice); ?></span></a>
                            <div class="small text-white"></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6">
                    <div class="card bg-warning text-white mb-4">
                        <div class="card-body">Pending Common Request: <span
                                id="total_male_block"><?php echo e($commonpending); ?></span></div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="#">Pending Individual Request:
                                <span id="total_male_student"><?php echo e($individualpending); ?></span></a>
                            <div class="small text-white"></div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6">
                    <div class="card bg-success text-white mb-4">
                        <div class="card-body">Paid Common Request: <span id="total_female_block"><?php echo e($commonpaid); ?></span>
                        </div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="#">Paid Individual Request:
                                <span id="total_female_student"><?php echo e($individualpaid); ?></span></a>
                            <div class="small text-white"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <!-- Your HTML content goes here -->
                    <div class="card">
                        <div class="card-header border-bottom">
                            <h3 class="card-title">Common Request</h3>

                        </div>
                        <div class="card-datatable">
                            <div id="message" class="w-100"></div>
                            <div style="width:98%; margin-left:1%;">
                                <div class="table-responsive">

                                    <table id="laravel-datatable-common"
                                        class="display table-bordered table-striped table-hover dt-responsive mb-0 dataTable no-footer"
                                        style="width: 100%;" role="grid" aria-describedby="laravel-datatable-common">

                                        <thead>

                                            <tr role="row">
                                                <th scope="col" width="1%">#</th>
                                                <th nowrap>Block</th>
                                                <th nowrap>Dorm</th>
                                                <th nowrap="1">Service Name</th>
                                                <th nowrap="1">Quantity</th>
                                                <th nowrap="1">Unit Price</th>
                                                <th nowrap="1">Status</th>
                                                <th nowrap="1">Reset No</th>
                                                <th nowrap="1">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody></tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Your HTML content goes here -->
                    <div class="card">
                        <div class="card-header border-bottom">
                            <h3 class="card-title">Individual Request</h3>

                        </div>
                        <div class="card-datatable">
                            <div id="message" class="w-100"></div>
                            <div style="width:98%; margin-left:1%;">
                                <div class="table-responsive">

                                    <table id="laravel-datatable-individual"
                                        class="display table-bordered table-striped table-hover dt-responsive mb-0 dataTable no-footer"
                                        style="width: 100%;" role="grid" aria-describedby="laravel-datatable-individual">

                                        <thead>

                                            <tr role="row">
                                                <th scope="col" width="1%">#</th>
                                                <th nowrap>Student Id</th>
                                                <th nowrap>Block</th>
                                                <th nowrap>Dorm</th>
                                                <th nowrap="1">Service Name</th>
                                                <th nowrap="1">Quantity</th>
                                                <th nowrap="1">Price</th>
                                                <th nowrap="1">Status</th>
                                                <th nowrap="1">Reset No</th>
                                                <th nowrap="1">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody></tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- BEGIN: Service Detail Info modal -->
        <div class="modal fade text-left" id="serviceDetailModal" data-keyboard="false" data-backdrop="static"
            tabindex="-1" role="dialog" aria-labelledby="myModalLabel133" aria-hidden="true" style="overflow-y: scroll;">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="myModalLabel133">Action Info</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form id="regionform">
                        <input type="hidden" class="_token">
                        <div class="modal-body">
                            <table style="width: 100%">
                                <tbody>
                                    <tr>
                                        <td>
                                            <label style="font-size: 14px;">Assigned By: </label>
                                        </td>
                                        <td>
                                            <label id="assignedby_info"
                                                style="font-size: 14px; font-weight: bold;"></label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <label style="font-size: 14px;">Assigned Date: </label>
                                        </td>
                                        <td>
                                            <label id="assigneddate_info"
                                                style="font-size: 14px; font-weight: bold;"></label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <label style="font-size: 14px;">Cleared By: </label>
                                        </td>
                                        <td>
                                            <label id="clearedby_info"
                                                style="font-size: 14px; font-weight: bold;"></label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="width: 30%">
                                            <label style="font-size: 14px;">Cleared Date: </label>
                                        </td>
                                        <td style="width: 70%">
                                            <label id="cleareddate_info"
                                                style="font-size: 14px; font-weight: bold;"></label>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>
                                            <label style="font-size: 14px;">Sent to Finance By: </label>
                                        </td>
                                        <td>
                                            <label id="sendby_info" style="font-size: 14px; font-weight: bold;"></label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="width: 30%">
                                            <label style="font-size: 14px;">Sent to finance Date: </label>
                                        </td>
                                        <td style="width: 70%">
                                            <label id="senddate_info" style="font-size: 14px; font-weight: bold;"></label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <label style="font-size: 14px;">Paid By: </label>
                                        </td>
                                        <td>
                                            <label id="paidby_info" style="font-size: 14px; font-weight: bold;"></label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="width: 30%">
                                            <label style="font-size: 14px;">Paid Date: </label>
                                        </td>
                                        <td style="width: 70%">
                                            <label id="paiddate_info" style="font-size: 14px; font-weight: bold;"></label>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="modal-footer">
                            <button id="closebuttonk" type="button"
                                class="btn btn-danger waves-effect waves-float waves-light"
                                data-dismiss="modal">Close</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- BEGIN: Service Detail Info modal -->
        <div class="modal fade text-left" id="commonServiceDetailModal" data-keyboard="false" data-backdrop="static"
            tabindex="-1" role="dialog" aria-labelledby="myModalLabel133" aria-hidden="true"
            style="overflow-y: scroll;">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="myModalLabel133">Action Info</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form id="regionform">
                        <input type="hidden" class="_token">
                        <div class="modal-body">
                            <table style="width: 100%">
                                <tbody>
                                    <tr>
                                        <td>
                                            <label style="font-size: 14px;">Sent to Finance By: </label>
                                        </td>
                                        <td>
                                            <label id="commonsentby_info"
                                                style="font-size: 14px; font-weight: bold;"></label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <label style="font-size: 14px;">Sent to Finance Date: </label>
                                        </td>
                                        <td>
                                            <label id="commonsentdate_info"
                                                style="font-size: 14px; font-weight: bold;"></label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <label style="font-size: 14px;">Paid By: </label>
                                        </td>
                                        <td>
                                            <label id="commonpaidby_info"
                                                style="font-size: 14px; font-weight: bold;"></label>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="width: 30%">
                                            <label style="font-size: 14px;">Paid Date: </label>
                                        </td>
                                        <td style="width: 70%">
                                            <label id="commonpaiddate_info"
                                                style="font-size: 14px; font-weight: bold;"></label>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="modal-footer">
                            <button id="closebuttonk" type="button"
                                class="btn btn-danger waves-effect waves-float waves-light"
                                data-dismiss="modal">Close</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        var errorcolor = "#ffcccc";
        $(function() {
            cardSection = $('#page-block');
        });

        $(document).ready(function() {
            var htable = $('#laravel-datatable-common').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                searchHighlight: true,
                dom: 'lBfrtip', // Add l before B to include lengthMenu
                buttons: [{
                    extend: 'pdf',
                    title: 'Common Services', // Title for the 'copy' button
                    exportOptions: {
                        columns: [0, 1, 2, 3, 4, 5, 6,
                            7
                        ] // Indexes of the columns you want to include
                    }
                }, {
                    extend: 'print',
                    title: 'Common Services', // Title for the 'copy' button
                    exportOptions: {
                        columns: [0, 1, 2, 3, 4, 5, 6,
                            7
                        ] // Indexes of the columns you want to include
                    }
                }, ],
                lengthMenu: [
                    [10, 25, 50, 500, -1],
                    [10, 25, 50, 500, "All"]
                ],
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: '/getcommonservicerequest',
                    type: 'DELETE',
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'dorm.block.block_name',
                        name: 'dorm.block.block_name',
                    },
                    {
                        data: 'dorm.dorm_name',
                        name: 'dorm.dorm_name',
                    },
                    {
                        data: 'service.service_name',
                        name: 'service.service_name',
                    },
                    {
                        data: 'quantity',
                        name: 'quantity',
                    },
                    {
                        data: 'service.unit_price',
                        name: 'service.unit_price',
                    },
                    {
                        data: 'state',
                        name: 'state',
                    },
                    {
                        data: 'reset_no',
                        name: 'reset_no',
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return '<div class="btn-group dropleft"><button type="button" class="btn btn-sm dropdown-toffle hide-arrow" data-toggle="dropdown" arial-haspopup="true" arial-expanded="false"><i class="fa fa-ellipsis-v"></i></button><div class = "dropdown-menu" > ' +
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('payment')): ?>
                                    '<a class = "dropdown-item payment" onclick = "commonPaid(' +
                                    data.id +
                                        ')" id = "dteditbtn" title = "payment page"><i class="fa fa-box"></i><span> Paid </span></a>' +
                                <?php endif; ?>
                            '<a class = "dropdown-item" onclick = "cmServiceDetail(' +
                            data.id +
                                ')" id = "dteditbtn" title = "Detail Page"><i class="fa fa-box"></i><span> Action Detail </span></a>' +
                                '</div></div> ';
                        },
                        orderable: false,
                        searchable: false
                    },
                ],
                "fnRowCallback": function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                    if (aData.state == "0") {
                        $(nRow).find('td:eq(6)').html('Pending');
                        $(nRow).find('td:eq(6)').css({
                            "color": "blue",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #f44336"
                        });
                    } else if (aData.state == "1") {
                        $(nRow).find('.payment').css({
                            'display': 'none'
                        });
                        $(nRow).find('td:eq(6)').html('Paid');
                        $(nRow).find('td:eq(6)').css({
                            "color": "green",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #f44336"
                        });
                    }
                }
            });
        });

        $(document).ready(function() {
            var ntable = $('#laravel-datatable-individual').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                searchHighlight: true,
                dom: 'lBfrtip', // Add l before B to include lengthMenu
                buttons: [{
                    extend: 'pdf',
                    title: 'Individual Services', // Title for the 'copy' button
                    exportOptions: {
                        columns: [0, 1, 2, 3, 4, 5, 6, 7,
                            8
                        ] // Indexes of the columns you want to include
                    }
                }, {
                    extend: 'print',
                    title: 'Individual Services', // Title for the 'copy' button
                    exportOptions: {
                        columns: [0, 1, 2, 3, 4, 5, 6,
                            7, 8
                        ] // Indexes of the columns you want to include
                    }
                }, ],
                lengthMenu: [
                    [10, 25, 50, 500, -1],
                    [10, 25, 50, 500, "All"]
                ],
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: '/getindividualservicerequest',
                    type: 'DELETE',
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'student.student_id',
                        name: 'student.student_id',
                    },
                    {
                        data: 'service.dorm.block.block_name',
                        name: 'service.dorm.block.block_name',
                    },
                    {
                        data: 'service.dorm.dorm_name',
                        name: 'service.dorm.dorm_name',
                    },
                    {
                        data: 'service.service_name',
                        name: 'service.service_name',
                    },
                    {
                        data: 'quantity',
                        name: 'quantity',
                    },
                    {
                        data: 'service.unit_price',
                        name: 'service.unit_price',
                    },
                    {
                        data: 'state',
                        name: 'state',
                    },
                    {
                        data: 'reset_no',
                        name: 'reset_no',
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return '<div class="btn-group dropleft"><button type="button" class="btn btn-sm dropdown-toffle hide-arrow" data-toggle="dropdown" arial-haspopup="true" arial-expanded="false"><i class="fa fa-ellipsis-v"></i></button><div class = "dropdown-menu" > ' +
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('payment')): ?>
                                    '<a class = "dropdown-item payment" onclick = "individualPaid(' +
                                    data
                                        .id +
                                        ')" id = "dteditbtn" title = "payment page" data - id = "' +
                                        data.id +
                                        '"><i class="fa fa-box"></i><span> Paid </span></a>' +
                                <?php endif; ?>
                            '<a class = "dropdown-item detail" onclick = "serviceDetail(' +
                            data
                                .id +
                                ')" id = "dteditbtn" title = "Detail Page" data - id = "' +
                                data.id +
                                '"><i class="fa fa-box"></i><span> Action Detail </span></a>' +
                                '</div></div> ';
                        },
                        orderable: false,
                        searchable: false
                    },
                ],
                "fnRowCallback": function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                    if (aData.state == "2") {
                        $(nRow).find('td:eq(7)').html('Pending');
                        $(nRow).find('td:eq(7)').css({
                            "color": "blue",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #f44336"
                        });
                    } else if (aData.state == "3") {
                        $(nRow).find('.payment').css({
                            'display': 'none'
                        });
                        $(nRow).find('td:eq(7)').html('Paid');
                        $(nRow).find('td:eq(7)').css({
                            "color": "green",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #f44336"
                        });
                    }
                }
            });
        });

        function individualPaid(record_id) {
            var check = prompt('Are you sure? Please enter Reset No here:');
            if (check == '') {} else {
                $.get('/individualpayment/' + record_id + '/' + check, function(data) {
                    if (data.success) {
                        alert_toast('Payment successfully completed!', 'success');
                        var inTable = $('#laravel-datatable-individual').dataTable();
                        inTable.fnDraw(false);
                    } else {
                        alert_toast('Whoops! An error occured please try again!', 'error');
                    }
                });
            }
        }

        function commonPaid(record_id) {
            var check = prompt('Are you sure? Please enter Reset No here:');
            if (check == '') {} else {
                $.get('/commonpayment/' + record_id + '/' + check, function(data) {
                    if (data.success) {
                        alert_toast('Payment successfully completed!', 'success');
                        var cnTable = $('#laravel-datatable-common').dataTable();
                        cnTable.fnDraw(false);
                    } else {
                        alert_toast('Whoops! An error occured please try again!', 'error');
                    }
                });
            }
        }

        function serviceDetail(record_id) {
            $.get('/studentservicedetail/' + record_id, function(data) {
                if (data.success) {
                    $('#assignedby_info').html(data.cr.name);
                    $('#assigneddate_info').html(data.crdate);
                    $('#cleareddate_info').html(data.cldate);
                    $('#senddate_info').html(data.sndate);
                    $('#paiddate_info').html(data.pddate);
                    if (data.cl !== "") {
                        $('#clearedby_info').html(data.cl.name);
                    } else {
                        $('#clearedby_info').html('');
                    }
                    if (data.sn !== "") {
                        $('#sendby_info').html(data.sn.name);
                    } else {
                        $('#sendby_info').html('');
                    }
                    if (data.pd !== "") {
                        $('#paidby_info').html(data.pd.name);
                    } else {
                        $('#paidby_info').html('');
                    }
                    $('#serviceDetailModal').modal('show');
                } else {
                    $('#serviceDetailModal').modal('show');
                }
            });
        }

        function cmServiceDetail(record_id) {
            $.get('/studentcommonservicedetail/' + record_id, function(data) {
                if (data.success) {
                    $('#commonsentby_info').html(data.sn.name);
                    $('#commonsentdate_info').html(data.sndate);
                    $('#commonpaiddate_info').html(data.pddate);
                    if (data.pd !== "") {
                        $('#commonpaidby_info').html(data.pd.name);
                    } else {
                        $('#commonpaidby_info').html('');
                    }
                    $('#commonServiceDetailModal').modal('show');
                } else {
                    alert_toast('hello')
                    $('#commonServiceDetailModal').modal('show');
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Werabe University Project\Werabe University Project\resources\views\dormitory\servicepayment1.blade.php ENDPATH**/ ?>