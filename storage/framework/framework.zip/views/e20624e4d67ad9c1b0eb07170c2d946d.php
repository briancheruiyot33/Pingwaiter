<link rel="preconnect" href="https://fonts.bunny.net">
<link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />
<link href="<?php echo url('assets/bootstrap/css/bootstrap.min.css'); ?>" rel="stylesheet">

<link href="<?php echo e(asset('admin_assets/vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">

<link href="<?php echo e(asset('dist/bootstrap.css')); ?>" rel="stylesheet">
<link href="<?php echo url('admin_assets/css/sb-admin-2.min.css'); ?>" rel="stylesheet">
<link rel="stylesheet" href="<?php echo url('assets/datatables-bs4/css/dataTables.bootstrap4.min.css'); ?>">
<link rel="stylesheet" href="<?php echo url('assets/datatables-responsive/css/responsive.bootstrap4.min.css'); ?>">
<link rel="stylesheet" href="<?php echo url('assets/datatables-buttons/css/buttons.bootstrap4.min.css'); ?>">
<link href="<?php echo url('assets/css/app.css'); ?>" rel="stylesheet">
<script src="<?php echo e(asset('dist/bootstrap.js')); ?>"></script>
<!-- Custom styles for this template -->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="<?php echo url('assets/bootstrap/js/bootstrap.bundle.min.js'); ?>"></script>

<!-- Custom styles for this template-->

<script src="<?php echo url('admin_assets/js/sb-admin-2.min.js'); ?>"></script>
<script src="<?php echo e(asset('assets/jquery.min.js')); ?>"></script>

<script src="<?php echo e(asset('admin_assets/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin_assets/vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin_assets/js/demo/datatables-demo.js')); ?>"></script>
<?php /**PATH C:\xampp\htdocs\Werabe University Project\Werabe University Project\resources\views\header.blade.php ENDPATH**/ ?>