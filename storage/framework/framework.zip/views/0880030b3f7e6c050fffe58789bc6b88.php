<?php $__env->startSection('title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="app-content content">
        <section id="responsive-datatable">
            <div class="row">
                <div class="col-12">
                    &nbsp;
                    <div class="row" style="justify-content: space-between; margin-bottom: 30px;">
                        <h1><span class="block_lable"><?php echo e($block->block_name); ?> (<?php echo e($block->floor); ?>)</span></h1>
                        <ul id="ul-block">
                            <li>
                                <a href="#">
                                    <i aria-hidden="true"></i>
                                    <span class="block_lable"><?php echo e($block->block_name); ?> (<?php echo e($block->floor); ?>)</span>
                                </a>
                            </li>
                        </ul>
                        
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dorm_admin')): ?>
                            <a href="/blocks" class="btn btn-danger"><?php echo e(__('dorm.back_to_blocks')); ?></a>
                        <?php else: ?>
                            <h1></h1>
                        <?php endif; ?>
                    </div>
                    <div class="row">
                        <div class="col-md-3">
                            <img src="<?php echo url('images/blocks/' . $block->photo); ?>" width="200" height="160">
                        </div>
                        <div class="col-md-9" style="margin-top: 30px;">

                            <div class="row">

                                <!-- Earnings (Monthly) Card Example -->
                                <a href="" class="col-xl-4 col-md-4 mb-2">
                                    <div class="card border-left-primary shadow h-60">
                                        <div class="card-body">
                                            <div class="row no-gutters align-items-center">
                                                <div class="col mr-2">
                                                    <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                        <?php echo e(__('dorm.total_dorms')); ?></div>
                                                    <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                        &nbsp;<span id="number_user"><?php echo e($total_dorm); ?></span>
                                                    </div>
                                                </div>
                                                <div class="col-auto">
                                                    <i class="fas fa-building fa-2x text-gray-300 text-blue"
                                                        style="color: blue;"></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                                <a href="" class="col-xl-4 col-md-4 mb-2">
                                    <div class="card border-left-primary shadow h-60">
                                        <div class="card-body">
                                            <div class="row no-gutters align-items-center">
                                                <div class="col mr-2">
                                                    <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                        <?php echo e(__('dorm.available_dorms')); ?></div>
                                                    <div class="h5 mb-0 font-weight-bold text-gray-800">&nbsp;<span
                                                            id="number_student"><?php echo e($available_dorm); ?></span></div>
                                                </div>
                                                <div class="col-auto">
                                                    <i class="fas fa-building fa-2x text-gray-300 text-red"
                                                        style="color: red;"></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                                <a href="" class="col-xl-4 col-md-4 mb-2">
                                    <div class="card border-left-primary shadow h-60">
                                        <div class="card-body">
                                            <div class="row no-gutters align-items-center">
                                                <div class="col mr-2">
                                                    <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                        Occupied Dorms</div>
                                                    <div class="h5 mb-0 font-weight-bold text-gray-800">&nbsp;<span
                                                            id="number_quality"><?php echo e($occupied_dorm); ?></span></div>
                                                </div>
                                                <div class="col-auto">
                                                    <i class="fas fa-building fa-2x text-gray-300"
                                                        style="color: black;"></i>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <!-- Your HTML content goes here -->
                    <div class="card">
                        <div class="card-header border-bottom">
                            <h3 class="card-title"><?php echo e(__('dorm.dorms')); ?></h3>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dorm_admin')): ?>
                                <button type="button" class="btn btn-gradient-info btn-sm add"
                                    onclick="addDorm()"><?php echo e(__('dormitory.add')); ?></button>
                            <?php endif; ?>

                        </div>
                        <div class="card-datatable">
                            <div style="width:98%; margin-left:1%;">
                                <div class="table-responsive">

                                    <table id="laravel-datatable-dorm"
                                        class="display table-bordered table-striped table-hover dt-responsive mb-0 dataTable no-footer"
                                        style="width: 100%; font-size: 12px;" role="grid"
                                        aria-describedby="laravel-datatable-drom">

                                        <thead>
                                            <tr role="row">
                                                <th scope="col" width="1%">#</th>
                                                <th nowrap><?php echo e(__('dorm.images')); ?></th>
                                                <th nowrap><?php echo e(__('dorm.dorm_number')); ?></th>
                                                <th nowrap><?php echo e(__('dorm.no_of_beds')); ?></th>
                                                <th nowrap><?php echo e(__('dorm.no_of_keys')); ?></th>
                                                <th nowrap><?php echo e(__('dorm.assign_students')); ?></th>
                                                <th nowrap><?php echo e(__('dorm.status')); ?></th>
                                                <th nowrap><?php echo e(__('dorm.action')); ?></th>
                                            </tr>
                                        </thead>
                                        <tbody></tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

    </div>

    <!-- BEGIN: Dorm Students modal  -->
    <div class="modal fade" id="studentsModal" data-keyboard="false" data-backdrop="static" tabindex="-1" role="dialog"
        aria-labelledby="categorylbl" aria-hidden="true" style="overflow-y: scroll;">
        <div class="modal-dialog modal-xl" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title"><?php echo e(__('dorm.dorm')); ?>1 <?php echo e(__('dorm.students')); ?></h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="closeModal()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-body">
                    <p style="color: red; text-align: center;"><?php echo e(__('dorm.dorm')); ?>1 <?php echo e(__('dorm.students')); ?></p>
                    <div class="card-header border-bottom row" style="justify-content: space-between">

                    </div>
                    <div class="card-datatable">

                        <div style="width:98%; margin-left:1%;">
                            <div class="table-responsive">

                                <table id="laravel-datatable-dorm"
                                    class="display table-bordered table-striped table-hover dt-responsive mb-0 dataTable no-footer"
                                    style="width: 100%;" role="grid" aria-describedby="laravel-datatable-user">

                                    <thead>
                                        <tr role="row">
                                            <th scope="col" width="1%">#</th>
                                            <th nowrap><?php echo e(__('dorm.full_name')); ?></th>
                                            <th nowrap><?php echo e(__('dorm.student_id')); ?></th>
                                            <th nowrap><?php echo e(__('dorm.department')); ?></th>
                                            <th nowrap><?php echo e(__('dorm.sex')); ?></th>
                                            <th nowrap><?php echo e(__('dorm.contact')); ?></th>
                                            <th nowrap><?php echo e(__('dorm.address')); ?></th>
                                            <th nowrap><?php echo e(__('dorm.status')); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody></tbody>
                                </table>
                            </div>
                        </div>
                    </div> --

                </div>
                <div class="modal-footer">
                    <button id="closebutton" type="button" class="btn btn-danger" onclick="closeModal()"
                        data-dismiss="modal"><?php echo e(__('dorm.close')); ?></button>
                </div>

            </div>
        </div>
    </div>

    <!-- BEGIN: Add Dorm modal  -->
    <div class="modal fade" id="dormModal" data-keyboard="false" data-backdrop="static" tabindex="-1" role="dialog"
        aria-labelledby="categorylbl" aria-hidden="true" style="overflow-y: scroll;">
        <div class="modal-dialog modal-xl" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="dormlbl"><?php echo e(__('dorm.add_dorm')); ?></h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                        onclick="closeModal()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="Register" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="edit_id" id="edit_id">
                    <input type="hidden" name="block_id" id="block_id" value="<?php echo e($block->id); ?>">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-4">
                                <label strong style="font-size: 16px;"><?php echo e(__('dorm.block')); ?></label>
                                <div class="form-group">
                                    <input type="text" class="form-control" value="<?php echo e($block->block_name); ?>"
                                        readonly />
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label strong style="font-size: 16px;"><?php echo e(__('dorm.dorm_number')); ?></label><label
                                    style="color: red; font-size:16px;">*</label>
                                <div class="form-group">
                                    <input type="text" placeholder="<?php echo e(__('dorm.dorm_placeholder')); ?>"
                                        class="form-control" name="dorm_name" id='dorm_name' autofocus
                                        onkeyup="removeDormNameValidation()" />
                                    <span class="text-danger">
                                        <strong id="dorm-error"></strong>
                                    </span>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label strong style="font-size: 16px;"><?php echo e(__('dorm.no_of_beds')); ?></label><label
                                    style="color: red; font-size:16px;">*</label>
                                <div class="form-group">
                                    <input type="text" placeholder="<?php echo e(__('dorm.bed_placeholder')); ?>"
                                        class="form-control" name="beds" id='beds' autofocus
                                        onkeyup="removeBedValidation()" />

                                    <span class="text-danger">
                                        <strong id="bed-error"></strong>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <label strong style="font-size: 16px;"><?php echo e(__('dorm.no_of_keys')); ?></label><label
                                    style="color: red; font-size:16px;">*</label>
                                <div class="form-group">
                                    <input type="text" placeholder="<?php echo e(__('dorm.key_placeholder')); ?>"
                                        class="form-control" name="keys" id='keys' autofocus
                                        onkeyup="removeKeyValidation()" />
                                    <span class="text-danger">
                                        <strong id="key-error"></strong>
                                    </span>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label strong style="font-size: 16px;"><?php echo e(__('dorm.remark')); ?></label><label
                                    style="color: red; font-size:16px;"></label>
                                <div class="form-group">
                                    <textarea name="remark" id="remark" placeholder="<?php echo e(__('dorm.remark_placeholder')); ?>" class="form-control"
                                        cols="30" rows="1" onkeyup="removeRemarkValidation()"></textarea>
                                    <span class="text-danger">
                                        <strong id="remark-error"></strong>
                                    </span>
                                </div>
                            </div>
                        </div><br>
                        <div class="divider">
                            <div class="divider-text"><?php echo e(__('dorm.add_new_service')); ?></div>
                        </div><br>
                        <div class="row">
                            <div class="col-xl-12 col-lg-12">
                                <div class="table-responsive">
                                    <table id="dynamicTable" class="mb-0 rtable  dt-responsive" style="width: 100%">
                                        <thead>
                                            <tr>
                                                <th style="width: 3%; text-align: center;">#</th>
                                                <th style="width: 15%; text-align: center;">
                                                    <?php echo e(__('dorm.photo')); ?><b style="color: red;"> *</b>
                                                </th>
                                                <th style="width: 15%; text-align: center;">
                                                    <?php echo e(__('dorm.service_name')); ?> <b style="color: red;"> *</b>
                                                </th>
                                                <th style="width: 15%; text-align: center;">
                                                    <?php echo e(__('dorm.quantity')); ?><b></b>
                                                </th>
                                                <th style="width: 15%; text-align: center;">
                                                    <?php echo e(__('dorm.unit_price')); ?><b></b>
                                                </th>
                                                <th style="width: 15%; text-align: center;">
                                                    <?php echo e(__('dorm.remark')); ?>

                                                    <b style="color: red;"></b>
                                                </th>
                                                <th style="width: 15%; text-align: center;">
                                                    <?php echo e(__('dorm.status')); ?><b style="color: red;"> *</b>
                                                </th>
                                                <th style="width: 3%"></th>
                                            </tr>
                                        </thead>
                                        <tbody></tbody>
                                    </table>
                                    <span class="text-danger">
                                        <strong id="table-error"></strong>
                                    </span>
                                    <table style="width: 100%">
                                        <tbody>
                                            <tr>
                                                <td colspan="2">
                                                    <button type="button" name="adds" id="adds"
                                                        class="btn btn-success btn-sm waves-effect waves-float waves-light"><i
                                                            class="fa fa-plus" arial-hidden="true"></i>
                                                        <?php echo e(__('dorm.add_new')); ?> </button>
                                                </td>
                                                <td></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="modal-footer">
                        <button id="savedorm" type="button"
                            class="btn btn-info"><?php echo e(__('dormitory.saveblock')); ?></button>
                        <button id="closebutton" type="button" class="btn btn-danger" onclick="closeModal()"
                            data-dismiss="modal"><?php echo e(__('dormitory.close')); ?></button>
                    </div>
                </form>
            </div>

        </div>
    </div>
    <!-- BEGIN:  Dorm Information Modal -->
    <div class="modal fade" id="dormDetailModal" data-keyboard="false" data-backdrop="static" tabindex="-1"
        role="dialog" aria-labelledby="myModalLabel35" aria-hidden="true" style="overflow-y: scroll;">
        <div class="modal-dialog modal-xl" role="document" style="font-size: 11px;">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title"><?php echo e(__('dorm.dorm_information')); ?></h4>
                    <div class="row">
                        <div style="text-align: right" id="statusdisplay"></div>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                aria-hidden="true">×</span></button>
                    </div>
                </div>
                <form id="InformationForm">
                    <input type="hidden" name="_token" value="bEE2UUJ5zm8YDMuIHSOQT8ZRMeUGaxv9eDaOVNb1">
                    <input type="hidden" name="drm_id" id="drm_id">
                    <div class="modal-body">
                        <section id="input-mask-wrapper">
                            <div class="col-xl-12">
                                <div class="row">
                                    <div class="col-md-3 col-sm-12">
                                        <div class="card">
                                            <div class="card-header">
                                                <h4 class="card-title"><?php echo e(__('dorm.basic_information')); ?></h4>
                                                <div class="heading-elements">
                                                    <ul class="list-inline mb-0">

                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="card-content collapse show">
                                                <div class="card-body">
                                                    <div class="row">
                                                        <table style="width: 100%;">
                                                            <tbody>

                                                                <tr>
                                                                    <td><label strong=""
                                                                            style="font-size: 14px;"><?php echo e(__('dorm.block')); ?>

                                                                        </label>
                                                                    </td>
                                                                    <td><label id="block_info" strong=""
                                                                            style="font-size:14px;font-weight:bold;">Block
                                                                            1</label>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td><label strong=""
                                                                            style="font-size: 14px;"><?php echo e(__('dorm.dorm')); ?>:
                                                                        </label>
                                                                    </td>
                                                                    <td><label id="dorm_info" strong=""
                                                                            style="font-size:14px;font-weight:bold;">
                                                                            8</label>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td><label strong=""
                                                                            style="font-size: 14px;"><?php echo e(__('dorm.no_of_beds')); ?>:
                                                                        </label>
                                                                    </td>
                                                                    <td><label id="bed_info" strong=""
                                                                            style="font-size:14px;font-weight:bold;">6</label>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td><label strong=""
                                                                            style="font-size: 14px;"><?php echo e(__('dorm.no_of_keys')); ?>:
                                                                        </label>
                                                                    </td>
                                                                    <td><label id="key_info" strong=""
                                                                            style="font-size:14px;font-weight:bold;">3</label>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td style="width: 43%"><label strong=""
                                                                            style="font-size: 14px;"><?php echo e(__('dorm.remark')); ?></label>
                                                                    </td>
                                                                    <td style="width: 57%"><label id="remark_info"
                                                                            strong=""
                                                                            style="font-size:14px;font-weight:bold;">Just
                                                                            for demo</label>
                                                                    </td>
                                                                </tr>

                                                                <tr>
                                                                    <td style="width: 43%"><label strong=""
                                                                            style="font-size: 14px;"><?php echo e(__('dorm.status')); ?></label>
                                                                    </td>
                                                                    <td style="width: 57%"><label id="status_info"
                                                                            strong=""
                                                                            style="font-size:14px;font-weight:bold;"><?php echo e(__('dorm.occupied')); ?></label>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                    <div class="divider newext">
                                                        <div class="divider-text"><?php echo e(__('dorm.action_information')); ?>

                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <table style="width: 100%;">
                                                            <tbody>
                                                                <tr>
                                                                    <td style="width: 35%"><label strong=""
                                                                            style="font-size: 14px;"><?php echo e(__('dorm.created_by')); ?></label>
                                                                    </td>
                                                                    <td style="width: 65%"><label id="created_by"
                                                                            strong=""
                                                                            style="font-size:14px;font-weight:bold;"></label>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td><label strong=""
                                                                            style="font-size: 14px;"><?php echo e(__('dorm.created_date')); ?></label>
                                                                    </td>
                                                                    <td><label id="created_at" strong=""
                                                                            style="font-size:14px;font-weight:bold;"></label>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td><label strong=""
                                                                            style="font-size: 14px;"><?php echo e(__('dorm.last_edited_by')); ?></label>
                                                                    </td>
                                                                    <td><label id="updated_by" strong=""
                                                                            style="font-size:14px;font-weight:bold;"></label>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td><label strong=""
                                                                            style="font-size: 14px;"><?php echo e(__('dorm.last_edited_date')); ?></label>
                                                                    </td>
                                                                    <td><label id="updated_at" strong=""
                                                                            style="font-size:14px;font-weight:bold;"></label>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-9 col-sm-12">
                                        <div class="card">
                                            <div class="card-header">
                                                <h4 class="card-title"><?php echo e(__('dorm.students')); ?></h4>
                                                <div class="heading-elements">
                                                    <ul class="list-inline mb-0">

                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="card-content collapse show">
                                                <div class="card-body">
                                                    <table id="dormstudenttbl"
                                                        class="display table-bordered table-striped table-hover dt-responsive mb-0">
                                                        <thead>
                                                            <tr role="row">
                                                                <th scope="col" width="1%">#</th>
                                                                <th nowrap><?php echo e(__('dorm.full_name')); ?></th>
                                                                <th nowrap><?php echo e(__('dorm.student_id')); ?></th>
                                                                <th nowrap><?php echo e(__('dorm.department')); ?></th>
                                                                <th nowrap>Entry Year</th>
                                                                <th nowrap><?php echo e(__('dorm.sex')); ?></th>
                                                                <th nowrap><?php echo e(__('dorm.status')); ?></th>

                                                            </tr>
                                                        </thead>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                        <br>

                                        <div class="card">
                                            <div class="card-header">
                                                <h4 class="card-title"><?php echo e(__('dorm.services')); ?></h4>
                                                <div class="heading-elements">
                                                    <ul class="list-inline mb-0">

                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="card-content collapse show">
                                                <div class="card-body">
                                                    <table id="dormservicetbl"
                                                        class="display table-bordered table-striped table-hover dt-responsive mb-0">
                                                        <thead>
                                                            <tr role="row">
                                                                <th scope="col" width="1%">#</th>
                                                                <th nowrap><?php echo e(__('dorm.images')); ?></th>
                                                                <th nowrap><?php echo e(__('dorm.service_name')); ?></th>
                                                                <th nowrap><?php echo e(__('dorm.quantity')); ?></th>
                                                                <th nowrap><?php echo e(__('dorm.unit_price')); ?></th>
                                                                <th nowrap><?php echo e(__('dorm.status')); ?></th>
                                                                <th nowrap><?php echo e(__('dorm.remark')); ?></th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                    <div class="modal-footer">
                        <button id="closebuttonk" type="button"
                            class="btn btn-danger waves-effect waves-float waves-light" data-dismiss="modal"
                            onclick="closeModal()"><?php echo e(__('dormitory.close')); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- BEGIN: Dorm Add modal  -->
    <div class="modal fade text-left" id="blockPhotoModal" data-keyboard="false" data-backdrop="static" tabindex="-1"
        role="dialog" aria-labelledby="categorylbl" aria-hidden="true" style="overflow-y: scroll;">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content" style="background: rgb(247,247,247)">
                <div class="modal-header">
                    <h4 class="modal-title" id="categorylbl"></h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                        onclick="closeModal()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <img src="<?php echo url('uploads/block1.jpg'); ?>" width="100%" height="250px">
                </div>
                <div class="modal-footer">
                    <button id="closebutton" type="button" class="btn btn-danger" onclick="closeModal()"
                        data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <!-- BEGIN: Dorm Add modal  -->
    <div class="modal fade text-left" id="dormPhotoModal" data-keyboard="false" data-backdrop="static" tabindex="-1"
        role="dialog" aria-labelledby="categorylbl" aria-hidden="true" style="overflow-y: scroll;">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content" style="background: rgb(247,247,247)">
                <div class="modal-header">
                    <h4 class="modal-title" id="categorylbl"></h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                        onclick="closeModal()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <img src="<?php echo url('uploads/dorm.jpg'); ?>" width="100%" height="250px">&nbsp;
                    <img src="<?php echo url('uploads/dorm1.jpg'); ?>" width="100%" height="250px">&nbsp;
                    <img src="<?php echo url('uploads/dorm2.jpg'); ?>" width="100%" height="250px">&nbsp;
                    <img src="<?php echo url('uploads/dorm3.jpg'); ?>" width="100%" height="250px">
                </div>
                <div class="modal-footer">
                    <button id="closebutton" type="button" class="btn btn-danger" onclick="closeModal()"
                        data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <!-- BEGIN: Dorm Add modal  -->
    <div class="modal fade text-left" id="servicePhotoModal" data-keyboard="false" data-backdrop="static"
        tabindex="-1" role="dialog" aria-labelledby="categorylbl" aria-hidden="true" style="overflow-y: scroll;">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content" style="background: rgb(247,247,247)">
                <div class="modal-header">
                    <h4 class="modal-title" id="categorylbl"></h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                        onclick="closeModal()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <img src="<?php echo url('uploads/block1.jpg'); ?>" width="100%" height="250px">
                </div>
                <div class="modal-footer">
                    <button id="closebutton" type="button" class="btn btn-danger" onclick="closeModal()"
                        data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    
    <div class="modal fade" id="DeleteModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Delete Category Data</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                        onclick="closeModalWithClearValidation()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" style="background-color:#e74a3b">
                    <label strong style="font-size: 16px;font-weight:bold;color:white;">Do you really want to
                        delete this category?</label>
                    <input type="hidden" id="deleteing_id">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-info delete_category">Delete</button>
                    <button id="closebutton" type="button" class="btn btn-danger"
                        onclick="closeModalWithClearValidation()" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        var errorcolor = "#ffcccc";
        $(function() {
            cardSection = $('#page-block');
        });
        /* BEGIN: Display zone table using yajra datatable */
        $(document).ready(function() {
            var ctable = $('#laravel-datatable-dorm').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                searchHighlight: true,
                dom: 'lBfrtip', // Add l before B to include lengthMenu
                buttons: [{
                        extend: 'copy',
                        title: 'Your Title Here' // Title for the 'copy' button
                    },
                    {
                        extend: 'csv',
                        title: 'Your Title Here' // Title for the 'csv' button
                    },
                    {
                        extend: 'excel',
                        title: 'Your Title Here' // Title for the 'excel' button
                    },
                    {
                        extend: 'pdf',
                        title: 'Your Title Here' // Title for the 'pdf' button
                    },
                    {
                        extend: 'print',
                        title: 'Yout title here'
                    }
                ],
                lengthMenu: [
                    [10, 25, 50, 500, -1],
                    [10, 25, 50, 500, "All"]
                ],
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: '/getdorms/' + $('#block_id').val(),
                    type: 'DELETE',
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return '<img src="<?php echo url('uploads/dorm.jpg'); ?>" width="40" height="35" onclick="viewDormPhoto()">';
                        },
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'dorm_name',
                        name: 'dorm_name'
                    },
                    {
                        data: 'beds',
                        name: 'beds'
                    },
                    {
                        data: 'keys',
                        name: 'keys'
                    },
                    {
                        data: 'student',
                        name: 'student'
                    },
                    {
                        data: 'status',
                        name: 'status'
                    },
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dorm_admin')): ?>
                        {
                            data: null,
                            render: function(data, type, full, meta) {
                                return '<div class="btn-group dropleft"><button type="button" class="btn btn-sm dropdown-toffle hide-arrow" data-toggle="dropdown" arial-haspopup="true" arial-expanded="false"><i class="fa fa-ellipsis-v"></i></button><div class = "dropdown-menu" > ' +
                                    '<a class = "dropdown-item categoryEdit" onclick = "editDorm(' +
                                    data
                                    .id +
                                    ')" id = "dteditbtn" title = "Open dorm update page" data - id = "' +
                                    data.id +
                                    '"><i class="fa fa-edit"></i><span> Edit </span></a>' +
                                    '<a class = "dropdown-item categoryEdit" onclick = "dormDetail(' +
                                    data
                                    .id +
                                    ')" id = "dteditbtn" title = "Open View Detail update page" data - id = "' +
                                    data.id +
                                    '"><i class="fa fa-info"></i><span> View Detail </span></a>' +
                                    '<a class = "dropdown-item categoryEdit" onclick = "dormStudent(' +
                                    data
                                    .id +
                                    ')" id = "dteditbtn" title = "Open View Detail update page" data - id = "' +
                                    data.id +
                                    '"><i class="fa fa-users"></i><span> Students </span></a>' +
                                    '</div></div> ';
                            },
                            orderable: false,
                            searchable: false
                        }
                    <?php endif; ?>
                ],

                "fnRowCallback": function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                    if (aData.status == "Fully Occupied") {
                        $(nRow).find('td:eq(6)').css({
                            "color": "#f44336",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #f44336"
                        });
                    } else if (aData.status == "Available") {
                        $(nRow).find('td:eq(6)').css({
                            "color": "#4CAF50",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #4CAF50"
                        });
                    } else if (aData.status == "Partialy Occupied") {
                        $(nRow).find('td:eq(6)').css({
                            "color": "orange",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #4CAF50"
                        });
                    }

                }
            });
            /* End: Yajra data table*/
            $('#laravel-datatable-crud tbody').on('click', 'tr', function() {
                if ($(this).hasClass('selected')) {
                    $(this).removeClass('selected');
                } else {
                    $('tr.selected').removeClass('selected');
                    $(this).addClass('selected');
                }
            });

            $('#status').select2({
                minimumResultsForSearch: -1
            });
        });
        ctable.on('draw', function() {
            var body = $(ctable.table().body());
            body.unhighlight();
            body.highlight(ctable.search());
        });

        $(".collapse").collapse('show');
    </script>
    <script>
        /* BEGIN: Add woreda button */
        var i = 0,
            m = 0,
            j = 0,
            num = 0;
        /* BEGIN: Add woreda button */
        $("#adds").click(function() {
            $('#table-error').html('');
            var lastrowcount = $('#dynamicTable tr:last').find('td').eq(1).find('input').val();
            ++i;
            ++m;
            ++j;
            $("#dynamicTable > tbody").append('<tr id="rowind' + m +
                '"><td style="font-weight:bold;width:3%;text-align:center;">' + j + '</td>' +
                '<td style="display:none;"><input type="hidden" name="service[' + m + '][vals]" id="vals' + m +
                '" class="vals form-control" readonly="true" style="font-weight:bold;" value="' + m +
                '"/></td>' +
                '<td style="display:none;"><input type="hidden" name="service[' + m +
                '][id]" id="id' +
                m +
                '" class="vals form-control" readonly="true" style="font-weight:bold;" value=""/></td>' +
                '<td style="display:none;"><input type="hidden" name="service[' + m +
                '][id]" value="" class="vals form-control" readonly="true" style="font-weight:bold;" value=""/></td>' +
                '<td style="width: 17%; padd"><input type="file" name="service[' + m +
                '][service_photo]"  id="service_photo' +
                m +
                '" class="service_name form-control numeral-mask" onclick="wrfn(this)" onblur="checkWoredaNumFn(this)"/></td>' +
                '<td style="width:17%; padd"><input type="text" name="service[' + m +
                '][service_name]" placeholder="<?php echo e(__('dorm.service_name_placeholder')); ?>" id="service_name' +
                m +
                '" class="service_name form-control numeral-mask" onclick="servicenamefn(this)"/></td>' +
                '<td style="width:17%; padd"><input type="number" name="service[' + m +
                '][quantity]" placeholder="<?php echo e(__('dorm.quantity_placeholder')); ?>" id="quantity' +
                m +
                '" class="quantity form-control numeral-mask" onclick="quantityfn(this)"/></td>' +
                '<td style="width:17%; padd"><input type="number" name="service[' + m +
                '][unit_price]" placeholder="Write unit price here..." id="unit_price' +
                m +
                '" class="unit_price form-control numeral-mask" step="0.01" min="0" onclick="unitpricefn(this)"/></td>' +
                '<td style="width:17%; padd"><input type="text" name="service[' + m +
                '][remark]" placeholder="<?php echo e(__('dorm.remark_placeholder')); ?>" onkeypress="return ValidatePhone(event);" onkeyup="cusPhoneCV()" id="remark' +
                m +
                '" class="remark form-control numeral-mask" onclick="remarkfn(this)" onblur="checkRemarkFn(this)"/></td>' +
                '<td style="width:17%;"><select id="Status' + m +
                '" class="select2 form-control form-control Status" name="service[' + m +
                '][status]" onchange="statusvalfn(this)"><option value="Common">Common</option><option value="Individual">Individual</option></select></td>' +
                '<td style="width:3%;text-align:center;"><button type="button" id="removebtn' + m +
                '" class="btn btn-light btn-sm remove-tr" style="color:#ea5455;background-color:#FFFFFF;border-color:#FFFFFF"><i class="fa fa-times fa-lg" aria-hidden="true"></i></button></td></tr>'
            );

            renumberRows();
        });
        /* BEGIN: Click remove row */
        $(document).on('click', '.remove-tr', function() {
            id = $(this).val();
            $(this).parents('tr').remove();
            renumberRows();
            --i;
            --j;
        });

        function renumberRows() {
            var ind;
            $('#dynamicTable > tbody tr').each(function(index, el) {
                $(this).children('td').first().text(index += 1);
                $('#numberofItemsLbl').html(index);
                ind = index;
            });
            if (ind == 0) {
                $('.totalrownumber').hide();
            } else {
                $('.totalrownumber').hide();
            }
        }
        $('#savedorm').click(function() {
            var optype = $("#operationtypes").val();
            var categoryForm = $('#Register')[0];
            var formData = new FormData(categoryForm);
            var id = $('#edit_id').val();
            $.ajax({
                url: '/createupdatedorm/' + id,
                type: 'post',
                data: formData,
                contentType: false,
                processData: false,
                beforeSend: function() {
                    cardSection.block({
                        message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                        css: {
                            backgroundColor: 'transparent',
                            color: '#fff',
                            border: '0'
                        },
                        overlayCSS: {
                            opacity: 0.5
                        }
                    });


                    if (id != "" && id != null) {
                        $('#savedorm').html('Updating...');
                        $('#savedorm').prop("disabled", true);
                    } else {
                        $('#savedorm').html('Saving...');
                        $('#savedorm').prop("disabled", true);
                    }

                },
                complete: function() {
                    cardSection.block({
                        message: '',
                        timeout: 1,
                        css: {
                            backgroundColor: '',
                            color: '',
                            border: ''
                        },
                    });
                },

                success: function(data) {
                    if (data.errors) {
                        if (data.errors.dorm_name) {
                            $('#dorm-error').html(data.errors.dorm_name[0]);
                        }
                        if (data.errors.beds) {
                            $('#bed-error').html(data.errors.beds[0]);
                        }
                        if (data.errors.keys) {
                            $('#key-error').html(data.errors.keys[0]);
                        }
                        if (data.errors.remark) {
                            $('#remark-error').html(data.errors.remark[0]);
                        }
                        if (data.errors.status) {
                            $('#status-error').html(data.errors.status[0]);
                        }
                        if (id != "" && id != null) {
                            $('#savedorm').html('<?php echo e(__('dormitory.update')); ?>');
                        } else {
                            $('#savedorm').html('<?php echo e(__('dormitory.saveblock')); ?>');
                        }
                        $('#savedorm').prop("disabled", false);
                        alert_toast('Whoops!, An Error Occured~', 'error');
                    } else if (data.unique_error) {
                        $('#dorm-error').html(data.unique_error);
                        if (id != "" && id != null) {
                            $('#savedorm').html('<?php echo e(__('dormitory.update')); ?>');
                        } else {
                            $('#savedorm').html('<?php echo e(__('dormitory.saveblock')); ?>');
                        }
                        $('#savedorm').prop("disabled", false);
                    } else if (data.new_error) {
                        alert_toast(data.new_error, 'error')
                        if (id != "" && id != null) {
                            $('#savedorm').html('<?php echo e(__('dormitory.update')); ?>');
                        } else {
                            $('#savedorm').html('<?php echo e(__('dormitory.saveblock')); ?>');
                        }
                    } else if (data.expired_error) {
                        var exp = parseFloat(data.expired_error);
                        alert_toast(data.message, 'error');
                        if (id != "" && id != null) {
                            $('#savedorm').html('<?php echo e(__('dormitory.update')); ?>');
                        } else {
                            $('#savedorm').html('<?php echo e(__('dormitory.saveblock')); ?>');
                        }
                        $('#expired_date' + exp).css("background", errorcolor);
                    } else if (data.errors2) {
                        var service_name = "";
                        var quantity = "";
                        var remark = "";
                        var status = "";
                        for (var k = 1; k <= m; k++) {
                            service_name = ($('#service_name' + k)).val();
                            quantity = ($('#quantity' + k)).val();
                            remark = ($('#remark' + k)).val();
                            status = ($('#Status' + k)).val();
                            if (($('#service_name' + k).val()) != undefined) {
                                if (service_name == "" || service_name == null) {
                                    $('#service_name' + k).css("background", errorcolor);
                                }
                            }
                            if (($('#quantity' + k).val()) != undefined) {
                                if (quantity == "" || quantity == null) {
                                    $('#quantity' + k).css("background", errorcolor);
                                }
                            }
                            if (($('#status' + k).val()) != undefined) {
                                if (status == "" || status == null) {
                                    $('#status' + k).css("background", errorcolor);
                                }
                            }
                        }
                        if (id != "" && id != null) {
                            $('#savedorm').html('<?php echo e(__('dormitory.update')); ?>');
                        } else {
                            $('#savedorm').html('<?php echo e(__('dormitory.saveblock')); ?>');
                        }
                        alert_toast("Please fill all highlighted required fields",
                            "error");
                    } else if (data.success) {
                        alert_toast(data.success, 'success');
                        var cTable = $('#laravel-datatable-dorm').dataTable();
                        cTable.fnDraw(false);
                        $('#dormModal').modal('hide');
                        $('#savedorm').html('<?php echo e(__('dormitory.save_block')); ?>');
                        $('#savedorm').prop("disabled", false);
                    } else {
                        alert_toast(data.new_error, 'error')
                        if (id != "" && id != null) {
                            $('#savedorm').text('Update');
                        } else {
                            $('#savedorm').text('<?php echo e(__('dormitory.save_block')); ?> ');
                        }
                    }
                }
            });
        });

        function viewBlockPhoto() {
            $('#blockPhotoModal').modal('show');
        }

        function viewDormPhoto() {
            $('#dormPhotoModal').modal('show');
        }

        function viewServicePhoto() {
            $('#servicePhotoModal').modal('show');
        }

        function addDorm(record_id) {
            $('#dormlbl').html('Add Dorm');
            $('#dorm_name').val('');
            $('#beds').val('');
            $('#keys').val('');
            $('#remark').val('');
            $('#status').val('Active').trigger('change');
            $('#dorm-error').html('');
            $('#bed-error').html('');
            $('#key-error').html('');
            $('#remark-error').html('');
            $('#status-error').html('');
            $('#savedorm').html('<?php echo e(__('dormitory.saveblock')); ?>');
            $('#savedorm').prop("disabled", false);
            $('#dynamicTable tbody').empty();
            $('#dormModal').modal('show');
        }



        function dormDetail(record_id) {
            var studentdorm = $('#dormstudenttbl').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                searchHighlight: true,
                dom: 'lBfrtip', // Add l before B to include lengthMenu
                buttons: [{
                        extend: 'copy',
                        title: 'Your Title Here' // Title for the 'copy' button
                    },
                    {
                        extend: 'csv',
                        title: 'Your Title Here' // Title for the 'csv' button
                    },
                    {
                        extend: 'excel',
                        title: 'Your Title Here' // Title for the 'excel' button
                    },
                    {
                        extend: 'pdf',
                        title: 'Your Title Here' // Title for the 'pdf' button
                    },
                    {
                        extend: 'print',
                        title: 'Yout title here'
                    }
                ],
                lengthMenu: [
                    [10, 25, 50, 500, -1],
                    [10, 25, 50, 500, "All"]
                ],
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: '/dormstudent/' + record_id,
                    type: 'DELETE',
                    dataType: "json",
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },

                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'full_name',
                        name: 'full_name'
                    },
                    {
                        data: 'student_id',
                        name: 'student_id'
                    },
                    {
                        data: 'department',
                        name: 'department'
                    },
                    {
                        data: 'entry_year',
                        name: 'entry_year'
                    },
                    {
                        data: 'sex',
                        name: 'sex'
                    },
                    {
                        data: 'status',
                        name: 'status'
                    },
                ],
            });
            var servicedorm = $('#dormservicetbl').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                searchHighlight: true,
                dom: 'lBfrtip', // Add l before B to include lengthMenu
                buttons: [{
                        extend: 'copy',
                        title: 'Your Title Here' // Title for the 'copy' button
                    },
                    {
                        extend: 'csv',
                        title: 'Your Title Here' // Title for the 'csv' button
                    },
                    {
                        extend: 'excel',
                        title: 'Your Title Here' // Title for the 'excel' button
                    },
                    {
                        extend: 'pdf',
                        title: 'Your Title Here' // Title for the 'pdf' button
                    },
                    {
                        extend: 'print',
                        title: 'Yout title here'
                    }
                ],
                lengthMenu: [
                    [10, 25, 50, 500, -1],
                    [10, 25, 50, 500, "All"]
                ],
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: '/getcategories',
                    type: 'DELETE',
                    dataType: "json",
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },

                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return '<img src="<?php echo url('uploads/block1.jpg'); ?>" width="40" height="35" onclick="viewServicePhoto()">';
                        },
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return 'Service 1';
                        },
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return '3';
                        },
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return '3';
                        },
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return 'Active';
                        },
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return 'Just for demo';
                        },
                        orderable: false,
                        searchable: false
                    },
                ],
            });
            $('#dormDetailModal').modal('show');
        }

        function dormStudent(record_id) {
            $('#studentsModal').modal('show');
        }

        function viewDetail(record_id) {
            $('#edit_id').val(record_id);
            $('#categorylbl').html('Detail');
            $('#savenewbutton').css('display', 'none');
            $('#savebutton').html('Update');
            $('#infoModal').modal('show');
        }

        function categoryDeleteFn(record_id) {
            $('#deleteing_id').val(record_id);
            $('#DeleteModal').modal('show');
        }
        $('.delete_category').click(function() {
            var delete_id = $('#deleteing_id').val();
            $.ajax({
                url: '/deletecategory/' + delete_id,
                type: 'get',
                beforeSend: function() {
                    $('.delete_category').text('Deleteing...');
                },
                success: function(data) {
                    if (data.errors) {
                        $('.delete_category').text('Delete');
                        alert_toast('an error occured', 'error');
                    } else if (data.success) {
                        $('.delete_category').text('Delete');
                        alert_toast(data.success, 'succes')
                        var cTable = $('#laravel-datatable-category').dataTable();
                        cTable.fnDraw(false);
                        $('#DeleteModal').modal('hide');
                    }
                }
            });
        });
    </script>
    <script>
        function removeNameValidation() {
            $('#name-error').html('');
        }

        function removeDormNameValidation() {
            $('#dorm-error').html('');
        }

        function removeStatusValidation() {
            $('#status-error').html('');
        }

        function servicenamefn(ele) {
            var cid = $(ele).closest('tr').find('.vals').val();
            $('#service_name' + cid).css("background", "white");
        }

        function quantityfn(ele) {
            var cid = $(ele).closest('tr').find('.vals').val();
            $('#quantity' + cid).css("background", "white");
        }

        function unitpricefn(ele) {
            var cid = $(ele).closest('tr').find('.vals').val();
            $('#unit_price' + cid).css("background", "white");
        }

        function closeModal() {
            $('#edit_id').val('');
            $('#name-error').html('');
            $('#status-error').html('');
            $('#name').val('');
            $('#status').val('').trigger('change');
            $('#savenewbutton').css('display', 'flex');
            $('#savebutton').html('Save & Close');
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Werabe University Project\Werabe University Project\resources\views\dormitory\changeddorms.blade.php ENDPATH**/ ?>