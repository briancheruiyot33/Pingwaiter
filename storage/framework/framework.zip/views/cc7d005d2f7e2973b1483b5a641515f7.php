<?php $__env->startSection('content'); ?>
    <div class="app-content content">
        <section id="responsive-datatable" style="font-size: 13px;">
            <div class="content py-2 px-2 w-100 bg-gradient-primary col-md-12 ml-0 " style="border-radius: 10px;">
                <h2 style="color: white; text-align: center;">Withdraw Report</h2>
            </div>
            <div id="success_message" style="padding: 13px 20px;"></div>
            <div class="row">
                <div class="col-12">
                    <!-- Your HTML content goes here -->
                    <div class="card">
                        <div class="card-header border-bottom">
                            <p>Withdraw List</p>
                            <div class="col-md-4 float-end" id="daterangein">
                                <div class="float-end"
                                    style="padding: 5px 10px; text-align: center; background: #fff; width: 100%; curson: pointer; border: 1px solid #ccc; margin: 10px -20px;">
                                    <i class="fa fa-calendar"></i>&nbsp;
                                    <span></span><i class="fa fa-caret-down"></i>
                                </div>
                            </div>
                        </div>
                        <div class="card-datatable">
                            <div class="tab-content">
                                <div class="tab-pane" id="in" aria-labelledby="in-tab" role="tabpanel">
                                    <div style="width:98%; margin-left:1%;">
                                        <div class="table-responsive">

                                            <table id="laravel-datatable-in"
                                                class="display table-bordered table-striped table-hover dt-responsive mb-0 dataTable"
                                                style="overflow-x: scroll;" role="grid"
                                                aria-describedby="laravel-datatable-in">
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th nowrap>Withdraw Date</th>
                                                        <th nowrap>Withdraw By</th>
                                                        <th nowrap>Receiver Name</th>
                                                        <th nowrap>Receiver Id</th>
                                                        <th nowrap>Receiver Sex</th>
                                                        <th nowrap>Item Name</th>
                                                        <th nowrap>Quantity</th>
                                                    </tr>
                                                </thead>
                                                <tbody></tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        var start_date = moment().subtract(1, 'M');
        var end_date = moment();
        var start = start_date.format('MMMM D, YYYY');
        var end = end_date.format('MMMM D, YYYY');
        $('#daterangein span').html(start_date.format('MMMM D, YYYY') + '-' + end_date.format('MMMM D, YYYY'));
        $('#daterangein').daterangepicker({
            startDate: start_date,
            endDate: end_date
        }, function(start_date, end_date) {
            $('#daterangein span').html(start_date.format('MMMM D, YYYY') + '-' + end_date.format('MMMM D, YYYY'));
            var cTable = $('#laravel-datatable-in').dataTable();
            cTable.fnDraw(false);
            start = start_date.format('MMMM D, YYYY');
            end = end_date.format('MMMM D, YYYY');
        });
        var errorcolor = "#ffcccc";
        $(function() {
            cardSection = $('#page-block');
        });

        /* BEGIN: Display In Report table using yajra datatable */
        $(document).ready(function() {
            var ctable = $('#laravel-datatable-in').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                searchHighlight: true,
                dom: 'lBfrtip', // Add l before B to include lengthMenu
                buttons: [{
                        extend: 'copy',
                        title: 'Your Title Here' // Title for the 'copy' button
                    },
                    {
                        extend: 'csv',
                        title: 'Your Title Here' // Title for the 'csv' button
                    },
                    {
                        extend: 'excel',
                        title: 'Your Title Here' // Title for the 'excel' button
                    },
                    {
                        extend: 'pdf',
                        title: 'Your Title Here' // Title for the 'pdf' button
                    },
                    {
                        extend: 'print',
                        title: '<p style="text-align: center; padding-bottom: 20px;">Campus Store Report From: ' +
                            start + ' To: ' + end + '</p>'
                    }
                ],
                lengthMenu: [
                    [10, 25, 50, 500, -1],
                    [10, 25, 50, 500, "All"]
                ],
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: "/supportinreport",
                    data: function(data) {
                        data.from_date = $('#daterangein').data('daterangepicker').startDate.format(
                            'YYYY-MM-DD');
                        data.to_date = $('#daterangein').data('daterangepicker').endDate.format(
                            'YYYY-MM-DD');
                    },
                    type: 'delete',
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'created_at',
                        name: 'created_at'
                    },
                    {
                        data: 'user.name',
                        name: 'user.name'
                    },
                    {
                        data: 'student.full_name',
                        name: 'student.full_name'
                    },
                    {
                        data: 'student.student_id',
                        name: 'student.student_id'
                    },
                    {
                        data: 'student.sex',
                        name: 'student.sex'
                    },
                    {
                        data: 'item.item_name',
                        name: 'item.item_name'
                    },
                    {
                        data: 'quantity',
                        name: 'quantity'
                    },
                ],
            });
            ctable.on('draw', function() {
                var body = $(ctable.table().body());
                body.unhighlight();
                body.highlight(ctable.search());
            })
        });
    </script>
    <script>
        $('#in').show();
        $('#daterangein').show();
        $('#report-title').html('Received Report');
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Werabe University Project\Werabe University Project\resources\views\support\report.blade.php ENDPATH**/ ?>