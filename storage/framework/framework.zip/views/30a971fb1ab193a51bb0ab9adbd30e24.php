<?php $__env->startSection('title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="app-content content">
        <section id="responsive-datatable">
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="">filter by block</label>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('proctor')): ?>
                            <select name="filter_block" id="filter_block" class="custom-select browser-default" readonly>
                                <?php $__currentLoopData = $block; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block_filter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(auth()->user()->block == $block_filter->block_name): ?>
                                        <option value="<?php echo e($block_filter->block_name); ?>"><?php echo e($block_filter->block_name); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        <?php else: ?>
                            <label for="">filter by block</label>
                            <select name="filter_block" id="filter_block" class="custom-select browser-default select2"
                                onchange="filterBlock()">
                                <option value=""></option>
                                <?php $__currentLoopData = $block; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block_filter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($block_filter->block_name); ?>"><?php echo e($block_filter->block_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="">filter by dorm</label>
                        <select name="filter_dorm" id="filter_dorm" class="custom-select browser-default select2"
                            onchange="filterDorm()">

                        </select>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group" style="display: grid;">
                        <label for="" style="opacity: 0;">print</label>
                        <button class="btn btn-success" onclick="print()">Print Service Agreement Paper</button>
                    </div>
                </div>
            </div>
            <div id="div_print" style="display: none;">

                <div class="card">
                    <div class="card-header">

                        <h3 class="col-md-12" style="text-align: center; text-decoration: underline;">Student Service
                            Agreement Paper
                        </h3>
                    </div>
                    <div class="">
                        <div class="col-md-12" style="display: flex; justify-content: space-between; padding: 5px 20px;">
                            <div class="row" style="display: flex; font-size: 12px;">
                                <p style="font-weight: 700;">Block: <span style="color: red;" id="block_no"></span>,
                                </p>&nbsp;
                                <p style="font-weight: 700;">Dorm No: <span style="color: red;" id="dorm_no"></span></p>
                            </div>
                            <div class="row" style="display: flex; font-size: 12px;">
                                <p>key: <span style="color: red;" id="key"></span>,</p>
                                &nbsp;&nbsp;
                                <div class="form-group" style="display: flex;">
                                    <p>Key Taker Name: </p>
                                    <p style="border-bottom: 1px solid black; width: 150px; margin-top: -50px;"></p>
                                </div>
                                <div class="form-group"style="display: flex;">
                                    <p>Phone: </p>
                                    <p style="border-bottom: 1px solid black; width: 130px"></p>
                                </div>
                                <div class="form-group"style="display: flex;">
                                    <p>Sign: </p>
                                    <p style="border-bottom: 1px solid black; width: 60px"></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12 100%">
                            <table border="1px" style="width: 100%;" id="serviceTable">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>FUll Name</th>
                                        <th>Student Id</th>
                                        <th>Department</th>
                                        <th>Batch</th>
                                        <th>Service</th>
                                        <th>Quantity</th>
                                        <th>Price</th>
                                        <th>Remark</th>
                                        <th>Sign</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td colspan="10" style="text-align: center;">No data available in table</td>
                                    </tr>
                                </tbody>
                            </table>
                            <hr>
                            <p class="text-center" style="text-align: center;">Dorm services</p>

                            <table border="1px" style="width: 100%;" id="commonServiceTable">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Service</th>
                                        <th>Quantity</th>
                                        <th>Unit Price</th>
                                        <th>Service Type</th>
                                        <th>Remark</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td colspan="5" style="text-align: center;">No data available in table</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>

                </div>

            </div>

            <div style="justify-content: space-between; display: flex; margin-bottom: 10px;" class="w-100">
                <h1 style="color: white;">Services</h1>
            </div>
            <div style="width:98%; margin-left:1%;">
                <div class="table-responsive">

                    <table id="laravel-datatable-service"
                        class="display table-bordered table-striped table-hover dt-responsive mb-0 dataTable no-footer"
                        style="width: 100%;" role="grid" aria-describedby="laravel-datatable-service">

                        <thead>
                            <tr role="row">
                                <th scope="col" width="1%">#</th>
                                <th nowrap="1">Photo</th>
                                <th nowrap="1">Service Name</th>
                                <th nowrap="1">Quantity</th>
                                <th nowrap="1">Unit Price</th>
                                <th nowrap="1">Remark</th>
                                <th nowrap="1">Status</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        var errorcolor = "#ffcccc";
        $(function() {
            cardSection = $('#page-block');
        });
        $(document).ready(function() {
            var ctable = $('#laravel-datatable-service').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                searchHighlight: true,
                dom: 'lBfrtip', // Add l before B to include lengthMenu
                buttons: [{
                    extend: 'print',
                    title: 'Student list detail',
                    exportOptions: {
                        columns: [0, 1, 2, 3, 4, 5, 6,
                            7, 8
                        ] // Indexes of the columns you want to include
                    }
                }],
                lengthMenu: [
                    [10, 25, 50, 500, -1],
                    [10, 25, 50, 500, "All"]
                ],
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: '/getservices',
                    data: function(data) {
                        data.dorm = $('#filter_dorm').val();
                    },
                    type: 'DELETE',
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return '<img src="<?php echo url('uploads/dorm.jpg'); ?>" width="40" height="35" onclick="viewDormPhoto()">';
                        },
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'service_name',
                        name: 'service_name',
                    },
                    {
                        data: 'quantity',
                        name: 'quantity',
                    },
                    {
                        data: 'unit_price',
                        name: 'unit_price',
                    },
                    {
                        data: 'remark',
                        name: 'remark',
                    },
                    {
                        data: 'status',
                        name: 'status',
                    },
                ],
                "fnRowCallback": function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                    if (aData.status == "Common") {
                        $(nRow).find('td:eq(6)').css({
                            "color": "#4CAF50",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #4CAF50"
                        });
                    } else if (aData.status == "Individual") {
                        $(nRow).find('.clear').css({
                            'display': 'none',
                        });
                        $(nRow).find('.finance').css({
                            'display': 'none',
                        });
                        $(nRow).find('.detail').css({
                            'display': 'none',
                        });
                        $(nRow).find('td:eq(6)').css({
                            "color": "orange",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #f44336"
                        });
                    }
                }
            });
            /* End: Yajra data table*/
            $('#laravel-datatable-service tbody').on('click', 'tr', function() {
                if ($(this).hasClass('selected')) {
                    $(this).removeClass('selected');
                } else {
                    $('tr.selected').removeClass('selected');
                    $(this).addClass('selected');
                }
            });
        });

        $('#filter_block').select2({
            placeholder: "Select a block",
        });

        $('#filter_dorm').select2({
            placeholder: "Select a dorm",
        });
        var sl = 0;

        function filterDorm() {

            var ctable = $('#laravel-datatable-service').dataTable();
            ctable.fnDraw(false);
            $("#serviceTable > tbody").empty();
            $("#commonServiceTable > tbody").empty();
            $.get('/getagreement/' + $('#filter_dorm').val(), function(data) {
                let i = 0;
                let j = 0;
                if (data.dorm) {
                    $('#dorm_no').html(data.dorm.dorm_name);
                    $('#key').html(data.dorm.keys);
                }
                if (data.block) {
                    $('#block_no').html(data.block);
                }
                $.each(data.student, function(key, value) {
                    i++;
                    $("#serviceTable > tbody").append('<tr><td rowspan="4">' + i + '</td>' +
                        '<td rowspan="4">' + value.full_name + '</td>' +
                        '<td rowspan="4">' + value.student_id + '</td>' +
                        '<td rowspan="4">' + value.department + '</td>' +
                        '<td rowspan="4">' + value.entry_year + '</td></tr>'
                    );
                    for (let i = 0; i < 3; i++) {
                        $("#serviceTable > tbody").append('<tr>' +
                            '<td><span style="opacity: 0">service 1</span></td>' +
                            '<td><span style="opacity: 0">service 1</span></td>' +
                            '<td><span style="opacity: 0">service 1</span></td>' +
                            '<td><span style="opacity: 0">service 1</span></td>' +
                            '<td><span style="opacity: 0">service 1</span></td></tr>'
                        );
                    }
                    /*$.get('/studentserviceagreement/' + value.id, function(response) {
                                            $("#serviceTable > tbody").append('<tr>' +
                                                '<td><span style="opacity: 0">service 1</span></td>' +
                                                '<td><span style="opacity: 0">service 1</span></td>' +
                                                '<td><span style="opacity: 0">service 1</span></td>' +
                                                '<td><span style="opacity: 0">service 1</span></td>' +
                                                '<td><span style="opacity: 0">service 1</span></td></tr>'
                                            );
                                             sl = 1;
                                             $.each(data.studentservice, function(key, value) {
                                                 sl++;
                                                 if (sl < 5) {
                                                     $("#serviceTable > tbody").append('<tr>' +
                                                         '<td>' + value.service_name + '</td>' +
                                                         '<td>' + value.quantity + '</td>' +
                                                         '<td>' + value.unit_price + '</td>' +
                                                         '<td>' + value.remark + '</td>' +
                                                         '<td><span style="opacity: 0">service 1</span></td></tr>'
                                                     );
                                                 }
                                             });

                                            //alert_toast(sl)

                                        });*/

                });

                $.each(data.service, function(key, value) {
                    j++;
                    $("#commonServiceTable > tbody").append('<tr><td>' + j + '</td>' +
                        '<td>' + value.service_name + '</td>' +
                        '<td>' + value.quantity + '</td>' +
                        '<td>' + value.unit_price + '</td>' +
                        '<td>' + value.status + '</td>' +
                        '<td>' + value.remark + '</td></tr>'
                    );
                });
                if (i === 0) {
                    $("#serviceTable > tbody").append('<tr>' +
                        '<td colspan="10" align="center">No student available in dorm</td>'
                    );
                }
                if (j === 0) {
                    $("#commonServiceTable > tbody").append('<tr>' +
                        '<td colspan="5" align="center">No service available in dorm</td>'
                    );
                }
            });
        }
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('proctor')): ?>
            $.get('/getdormlist/' + $('#filter_block').val(), function(data) {
                // Clear existing options
                var selectElement1 = $('#filter_dorm');
                selectElement1.empty();
                selectElement1.append($('<option>', {
                    value: '',
                    text: 'Select a dorm',
                    disabled: true,
                    selected: true
                }));
                // Append new options
                $.each(data.dorm, function(key, value) {
                    selectElement1.append($('<option>', {
                        value: value.id, // Assuming dirn_id is the unique identifier
                        text: value.dorm_name
                    }));
                });
                // Initialize Select2 with placeholder
                selectElement1.select2({
                    placeholder: 'Select a dorm',
                    allowClear: true // Optional: allows clearing the selection
                });
            });
        <?php endif; ?>
        function filterBlock() {
            $.get('/getdormlist/' + $('#filter_block').val(), function(data) {
                // Clear existing options
                var selectElement1 = $('#filter_dorm');
                selectElement1.empty();
                selectElement1.append($('<option>', {
                    value: '',
                    text: 'Select a dorm',
                    disabled: true,
                    selected: true
                }));
                // Append new options
                $.each(data.dorm, function(key, value) {
                    selectElement1.append($('<option>', {
                        value: value.id, // Assuming dirn_id is the unique identifier
                        text: value.dorm_name
                    }));
                });
                // Initialize Select2 with placeholder
                selectElement1.select2({
                    placeholder: 'Select a dorm',
                    allowClear: true // Optional: allows clearing the selection
                });
            });


        }




        function print() {

            var div_content = document.getElementById("div_print").innerHTML;
            var a = window.open('', '', 'height=1000, width=1000');
            a.document.write('<html>');
            a.document.write('<body>');
            a.document.write(div_content);
            a.document.write('</body></html>');
            a.document.close();
            a.print();
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Werabe University Project\Werabe University Project\resources\views\dormitory\services.blade.php ENDPATH**/ ?>