<?php $__env->startSection('title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="app-content content">
        <section id="responsive-datatable">
            <div class="row">
                <div class="col-12">
                    <!-- Your HTML content goes here -->
                    <div class="card">
                        <div class="card-header border-bottom">
                            <h3 class="card-title">Patients</h3>


                        </div>
                        <div class="card-datatable">
                            <div style="width:98%; margin-left:1%;">
                                <div class="table-responsive">

                                    <table id="laravel-datatable-patient"
                                        class="display table-bordered table-striped table-hover dt-responsive mb-0 dataTable no-footer"
                                        style="width: 100%;" role="grid" aria-describedby="laravel-datatable-user">

                                        <thead>
                                            <tr role="row">
                                                <th scope="col" width="1%">#</th>
                                                <th nowrap="1">Full Name</th>
                                                <th nowrap="1">Student Id</th>
                                                <th nowrap="1">Sex</th>
                                                <th nowrap="1">Phone</th>
                                                <th nowrap="1">Age</th>
                                                <th nowrap="1">State</th>
                                                <th nowrap="1">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody></tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
    
    <div class="modal fade text-left" id="pharmacyModal" data-keyboard="false" data-backdrop="static" tabindex="-1"
        role="dialog" aria-labelledby="lbl" aria-hidden="true" style="overflow-y: scroll;">
        <div class="modal-dialog modal-xl" role="document" style="font-size: 11px;">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="pharmacylbl">Werabe University Student Clinic PRESCRIPTION PAPER</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="closeModal()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="form-pharmacy">
                        <?php echo e(csrf_field()); ?>

                        <div class="row">
                            <input type="hidden" name="patient_id" id="patient_id">
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>Patient's Full Name:</label>
                                    <input type="text" id="fname" value="" class="form-control" readonly>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>USER ID:</label>
                                    <input type="text" id="user_id" value="" readonly class="form-control">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>Gender:</label>
                                    <input type="text" id="gender" readonly class="form-control">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>AGE:</label>
                                    <input type="text" id="age_number" class="form-control" readonly>
                                </div>
                            </div>

                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>Name of Prescriber's:</label>
                                    <input type="text" id="pname" class="form-control" readonly>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xl-12 col-lg-12 col-md-12">
                                <div class="table-responsive">
                                    <table id="pharmacyTable">
                                        <thead>
                                            <tr>
                                                <th style="width: 3%; text-align: center;">#</th>

                                                <th nowrap>
                                                    Drug|Category|Type|Unit<b style="color: red;"> *</b>
                                                </th>
                                                <th nowrap>Description
                                                    <b style="color: red;"> *</b>
                                                </th>
                                                <th>Quantity</th>
                                                <th nowrap>Withdraw</th>
                                                <th nowrap>Cancel</th>
                                            </tr>
                                        </thead>
                                        <tbody></tbody>
                                    </table>
                                    <span class="text-danger">
                                        <strong id="table-error"></strong>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <p style="color: green;" id="withp">Withdraw Completed</p>
                    <button id="checkwithdraw" type="button"
                        class="btn btn-info waves-effect waves-float waves-light">Finish</button>
                    <button id="closebutton" type="button" class="btn btn-danger" onclick="closeModal()"
                        data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    
    <div class="modal fade" id="checkModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="checklbl">Are you sure to complete withdraw?</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                        onclick="closeModalWithClearValidation()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                </div>
                <div class="modal-footer">
                    <button type="button" id="savewithdraw" class="btn btn-info">Yes</button>
                    <button id="closebutton" type="button" class="btn btn-danger"
                        onclick="closeModalWithClearValidation()" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        var current_date = moment();
        var current_date = current_date.format('MMMM D, YYYY');
        $('#date').val(current_date);
        var errorcolor = "#ffcccc";
        $(function() {
            cardSection = $('#page-block');
        });
        /* BEGIN: Display zone table using yajra datatable */
        $(document).ready(function() {
            var ctable = $('#laravel-datatable-patient').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                searchHighlight: true,
                dom: 'lBfrtip', // Add l before B to include lengthMenu
                buttons: [{
                        extend: 'copy',
                        title: 'Patient under pharmacy', // Title for the 'copy' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'csv',
                        title: 'Patient under pharmacy', // Title for the 'csv' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'excel',
                        title: 'Patient under pharmacy', // Title for the 'excel' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'pdf',
                        title: 'Patient under pharmacy',
                        orientation: 'landscape', // Set orientation: 'landscape' or 'portrait'
                        pageSize: 'A4', // Set page size
                        customize: function(doc) {
                            // Customize header, footer, and body style
                            doc.styles.tableHeader = {
                                fillColor: '#4CAF50',
                                color: 'white',
                                alignment: 'center'
                            };
                            doc.styles.title = {
                                fontSize: 14,
                                alignment: 'center'
                            };
                            doc.defaultStyle.fontSize = 10; // Change default font size
                            doc.content[1].table.widths = '*'.repeat(doc.content[1].table.body[0]
                                .length).split(''); // Automatically adjust column widths
                            doc.pageMargins = [10, 10, 10, 10]; // Adjust page margins
                            doc.pageSize = 'A4'; // Ensure the page size is A4
                            doc.content[1].layout = {
                                hLineWidth: function(i, node) {
                                    return (i === 0 || i === node.table.body.length) ? 2 :
                                        1;
                                },
                                vLineWidth: function(i, node) {
                                    return (i === 0 || i === node.table.widths.length) ? 2 :
                                        1;
                                },
                                hLineColor: function(i, node) {
                                    return (i === 0 || i === node.table.body.length) ?
                                        'black' : 'gray';
                                },
                                vLineColor: function(i, node) {
                                    return (i === 0 || i === node.table.widths.length) ?
                                        'black' : 'gray';
                                },
                                paddingLeft: function(i, node) {
                                    return 4;
                                },
                                paddingRight: function(i, node) {
                                    return 4;
                                },
                                paddingTop: function(i, node) {
                                    return 2;
                                },
                                paddingBottom: function(i, node) {
                                    return 2;
                                },
                            };
                        },
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'print',
                        title: 'Patient under pharmacy',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6] // Indexes of the columns you want to include
                        }
                    }
                ],
                lengthMenu: [
                    [10, 25, 50, 500, -1],
                    [10, 25, 50, 500, "All"]
                ],
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: '/getpatientspharmacy',
                    type: 'DELETE',
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'student.full_name',
                        name: 'student.full_name'
                    },
                    {
                        data: 'student.student_id',
                        name: 'student.student_id'
                    },
                    {
                        data: 'student.sex',
                        name: 'student.sex'
                    },
                    {
                        data: 'student.phone',
                        name: 'student.phone'
                    },
                    {
                        data: 'student.age',
                        name: 'student.age'
                    },
                    {
                        data: 'state',
                        name: 'state'
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return '<div class="btn-group dropleft"><button type="button" class="btn btn-sm dropdown-toffle hide-arrow" data-toggle="dropdown" arial-haspopup="true" arial-expanded="false"><i class="fa fa-ellipsis-v"></i></button><div class = "dropdown-menu" > ' +
                                '<a class = "dropdown-item patientView" ' +
                                'onclick = "viewDetailFn(' +
                                data.id +
                                ')" id = "dtViewbtn" title = "Open patient update page"><i class="fa fa-info"></i>&nbsp;<span>Detail</span></a>' +
                                '<a class = "dropdown-item text-danger check" onclick = "checkSend(' +
                                data
                                .id +
                                ')" id = "dteditbtn" title = "Send Back"><i class="fa fa-plane"></i><span> Sent Back </span></a>' +
                                '</div></div> ';
                        },
                        orderable: false,
                        searchable: false
                    }
                ],
                "fnRowCallback": function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                    if (aData.state == "4") {
                        $(nRow).find('td:eq(6)').html('Pending');
                        $(nRow).find('td:eq(6)').css({
                            "color": "blue",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #4CAF50"
                        });
                        $(nRow).find('.check').css({
                            "display": "flex",
                        });
                    } else if (aData.state == "1") {
                        $(nRow).find('td:eq(6)').html('Completed');
                        $(nRow).find('td:eq(6)').css({
                            "color": "green",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #4CAF50"
                        });
                        $(nRow).find('.check').css({
                            "display": "none",
                        });
                    }
                }
            });

            /* End: Yajra data table*/
            $('#laravel-datatable-patient tbody').on('click', 'tr', function() {
                if ($(this).hasClass('selected')) {
                    $(this).removeClass('selected');
                } else {
                    $('tr.selected').removeClass('selected');
                    $(this).addClass('selected');
                }
            });

            $('#status').select2({
                minimumResultsForSearch: -1
            });
        });
        ctable.on('draw', function() {
            var body = $(ctable.table().body());
            body.unhighlight();
            body.highlight(ctable.search());
        })

        function viewHistoryFn(record_id) {
            $('#historyModal').modal('show');
        }
    </script>
    <script>
        function checkSend(record_id) {
            var check = prompt('Are you sure? write yes in the space provided');
            if (check == "yes") {
                sentBack(record_id);
            }
        }

        function sentBack(record_id) {
            $.get('/sendback/' + record_id, function(data) {
                if (data.success) {
                    alert_toast('Patient sent back to opd successfully', 'success');
                    var pTable = $('#laravel-datatable-patient').dataTable();
                    pTable.fnDraw(false);
                } else {
                    alert_toast('An error occured', 'error');
                }
            });
        }

        function viewDetailFn(record_id) {
            $.get('/sendPharmacy/' + record_id, function(data) {
                if (data.student) {
                    $('#fname').val(data.student.full_name);
                    $('#user_id').val(data.student.student_id);
                    $('#gender').val(data.student.sex);
                    $('#age_number').val(data.student.age);
                    $('#patient_id').val(record_id);
                    $('#pname').val(data.patient.user.name);
                    if (data.patient.state == '1') {
                        $('#checkwithdraw').css({
                            "display": "none"
                        });
                        $('#withp').css({
                            "display": "flex"
                        });
                    } else {
                        $('#checkwithdraw').css({
                            "display": "flex"
                        });
                        $('#withp').css({
                            "display": "none"
                        });
                    }
                    $('#sendModal').modal('hide');
                    $('#pharmacyModal').modal('show');
                }
            });
            var nTable = $('#pharmacyTable').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                searchHighlight: true,
                dom: 'lBfrtip', // Add l before B to include lengthMenu
                buttons: [{
                        extend: 'copy',
                        title: 'Patient under pharmacy', // Title for the 'copy' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'csv',
                        title: 'Patient under pharmacy', // Title for the 'csv' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'excel',
                        title: 'Patient under pharmacy', // Title for the 'excel' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'pdf',
                        title: 'Patient under pharmacy',
                        orientation: 'landscape', // Set orientation: 'landscape' or 'portrait'
                        pageSize: 'A4', // Set page size
                        customize: function(doc) {
                            // Customize header, footer, and body style
                            doc.styles.tableHeader = {
                                fillColor: '#4CAF50',
                                color: 'white',
                                alignment: 'center'
                            };
                            doc.styles.title = {
                                fontSize: 14,
                                alignment: 'center'
                            };
                            doc.defaultStyle.fontSize = 10; // Change default font size
                            doc.content[1].table.widths = '*'.repeat(doc.content[1].table.body[0]
                                .length).split(''); // Automatically adjust column widths
                            doc.pageMargins = [10, 10, 10, 10]; // Adjust page margins
                            doc.pageSize = 'A4'; // Ensure the page size is A4
                            doc.content[1].layout = {
                                hLineWidth: function(i, node) {
                                    return (i === 0 || i === node.table.body.length) ? 2 :
                                        1;
                                },
                                vLineWidth: function(i, node) {
                                    return (i === 0 || i === node.table.widths.length) ? 2 :
                                        1;
                                },
                                hLineColor: function(i, node) {
                                    return (i === 0 || i === node.table.body.length) ?
                                        'black' : 'gray';
                                },
                                vLineColor: function(i, node) {
                                    return (i === 0 || i === node.table.widths.length) ?
                                        'black' : 'gray';
                                },
                                paddingLeft: function(i, node) {
                                    return 4;
                                },
                                paddingRight: function(i, node) {
                                    return 4;
                                },
                                paddingTop: function(i, node) {
                                    return 2;
                                },
                                paddingBottom: function(i, node) {
                                    return 2;
                                },
                            };
                        },
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'print',
                        title: 'Patient under pharmacy',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6] // Indexes of the columns you want to include
                        }
                    }
                ],
                lengthMenu: [
                    [10, 25, 50, 500, -1],
                    [10, 25, 50, 500, "All"]
                ],
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: '/pharmacyInfo/' + record_id,
                    type: 'DELETE',
                    dataType: "json",
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },

                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'select_column',
                        name: 'select_column',
                    },
                    {
                        data: 'description',
                        name: 'description',
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return '<input type="text" class="quan' + data.id + ' form-control">';
                        },
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return ' <p class="done">Completed</p><a class="btn btn-info withdraw" onclick="withdrawFn(' +
                                data.id +
                                ')" id="dtinfobtn" title="Withdraw Product" data-id = "' +
                                data.id +
                                '"><span> Withdraw </span></a> ';
                        },
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return ' <p class="cancled">Cancled</p><a class="btn btn-danger cancel" onclick="checkCancel(' +
                                data.id +
                                ')" id="dtinfobtn" title="Cancel Withdraw" data-id = "' +
                                data.id +
                                '"><span> Cancel </span></a> ';
                        },
                        orderable: false,
                        searchable: false
                    }
                ],
                "fnRowCallback": function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {

                    if (aData.status == "1") {
                        $(nRow).find('.quan').prop('readonly',
                            false);
                        $(nRow).find('.done').css({
                            "display": "none"
                        });
                        $(nRow).find('.cancled').css({
                            "display": "none"
                        });
                        $(nRow).find('.withdraw').css({
                            "display": "flex"
                        });
                        $(nRow).find('.cancel').css({
                            "display": "flex"
                        });
                        $(nRow).find('.quan' + aData.id + '').val(aData.quantity * aData.product.unit.capacity);
                    } else if (aData.status == "3") {
                        $(nRow).find('.quan' + aData.id + '').prop('readonly',
                            true);
                        $(nRow).find('.quan' + aData.id + '').val(aData.quantity * aData.product.unit.capacity);
                        $(nRow).find('.cancled').css({
                            "display": "flex",
                            "color": "red",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #4CAF50"
                        });
                        $(nRow).find('.withdraw').css({
                            "display": "none"
                        });
                        $(nRow).find('.cancel').css({
                            "display": "none"
                        });
                        $(nRow).find('.done').html('No');
                    } else {
                        $(nRow).find('.quan' + aData.id + '').prop('readonly',
                            true);
                        $(nRow).find('.quan' + aData.id + '').val(aData.quantity * aData.product.unit.capacity);
                        $(nRow).find('.done').css({
                            "display": "flex",
                            "color": "green",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #4CAF50"
                        });
                        $(nRow).find('.withdraw').css({
                            "display": "none"
                        });
                        $(nRow).find('.cancel').css({
                            "display": "none"
                        });
                        $(nRow).find('.cancled').html('No')
                    }

                }
            });
        }

        $('#checkwithdraw').click(function() {
            $('#checkModal').modal('show');
        });
        $('#savewithdraw').click(function() {
            $('#savewithdraw').html('completing...');
            $.get('/withdraw/' + $('#patient_id').val(), function(data) {
                if (data.errors) {
                    $('#savewithdraw').html('Yes');
                    $('#savewithdraw').prop("disabled", false);
                    alert_toast("Something wrong",
                        "error");
                } else if (data.success) {
                    alert_toast('Withdraw completed successfully!', 'success');
                    $('#pharmacyModal').modal('hide');
                    $('#checkModal').modal('hide');
                    var pTable = $('#laravel-datatable-patient').dataTable();
                    pTable.fnDraw(false);
                    $('#savewithdraw').html('Yes');
                    $('#savewithdraw').prop("disabled", false);
                } else {
                    alert('new error')
                    $('#savewithdraw').html('Yes');
                    $('#savewithdraw').prop("disabled", false);
                }
            });
        });

        function withdrawFn(record_id) {
            var quantity = $('.quan' + record_id + '').val();

            var store_id = $('#product' + record_id + '').val();
            $.get("/withdrawPharmacy/" + record_id + '/' + quantity + '/' + store_id, function(data) {
                if (data.success) {
                    alert_toast('Successfully withdrawn', 'success');
                    var wTable = $('#pharmacyTable').dataTable();
                    wTable.fnDraw(false);
                } else if (data.errors) {
                    alert_toast(data.errors, 'error');
                } else {
                    alert_toast('something wrong');
                }
            });
        }

        function checkCancel(record_id) {
            var check = confirm("Are you sure to cancel withdraw?");
            if (check === true) {
                cancelFn(record_id)
            }
        }

        function cancelFn(record_id) {
            var quantity = 'cancel';

            var store_id = $('#product' + record_id + '').val();
            $.get("/withdrawPharmacy/" + record_id + '/' + quantity + '/' + store_id, function(data) {
                if (data.success) {
                    alert_toast(data.success, 'success');
                    var wTable = $('#pharmacyTable').dataTable();
                    wTable.fnDraw(false);
                } else if (data.errors) {
                    alert_toast(data.errors, 'error');
                } else {
                    alert_toast('something wrong');
                }
            });
        }
    </script>
    <script>
        function removeNameValidation() {
            $('#name-error').html('');
        }

        function removeStatusValidation() {
            $('#status-error').html('');
        }

        function closeModal() {
            $('#name-error').html('');
            $('#status-error').html('');
            $('#name').val('');
            $('#status').val('').trigger('change');
            $('#savenewbutton').css('display', 'flex');
            $('#savebutton').html('Save & Close');
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Werabe University Project\Werabe University Project\resources\views\patients\pharmacy.blade.php ENDPATH**/ ?>