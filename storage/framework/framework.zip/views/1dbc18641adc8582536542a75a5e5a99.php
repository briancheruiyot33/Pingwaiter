<?php $__env->startSection('title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="app-content content">
        <section id="responsive-datatable">
            <div class="row">
                <div class="col-12">
                    <!-- Your HTML content goes here -->
                    <div class="card">
                        <div class="card-header border-bottom">
                            <h3 class="card-title">Patients</h3>


                        </div>
                        <div class="card-datatable">
                            <div style="width:98%; margin-left:1%;">
                                <div class="table-responsive">

                                    <table id="laravel-datatable-patient"
                                        class="display table-bordered table-striped table-hover dt-responsive mb-0 dataTable no-footer"
                                        style="width: 100%;" role="grid" aria-describedby="laravel-datatable-user">

                                        <thead>
                                            <tr role="row">
                                                <th scope="col" width="1%">#</th>
                                                <th nowrap="1">Full Name</th>
                                                <th nowrap="1">Student Id</th>
                                                <th nowrap="1">Sex</th>
                                                <th nowrap="1">Phone</th>
                                                <th nowrap="1">Age</th>
                                                <th nowrap="1">State</th>
                                                <th nowrap="1">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody></tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- BEGIN: Category Add modal  -->
        <div class="modal fade text-left" id="inlineForm" data-keyboard="false" data-backdrop="static" tabindex="-1"
            role="dialog" aria-labelledby="patientlbl" aria-hidden="true" style="overflow-y: scroll;">
            <div class="modal-dialog modal-xl" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="patientlbl">Add patient</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                            onclick="closeModal()">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form id="Register">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="edit_id" id="edit_id">
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-md-4">
                                    <label strong style="font-size: 16px;">Full Name</label><label
                                        style="color: red; font-size:16px;">*</label>
                                    <div class="form-group">
                                        <input type="text" placeholder="Write Patient Name here" class="form-control"
                                            name="full_name" id='full_name' autofocus onkeyup="removeNameValidation()" />
                                        <span class="text-danger">
                                            <strong id="full_name-error"></strong>
                                        </span>
                                    </div>

                                </div>
                                <div class="col-md-4">
                                    <label strong style="font-size: 16px;">Student ID</label><label
                                        style="color: red; font-size:16px;">*</label>
                                    <div class="form-group">
                                        <input type="text" placeholder="Write Student Id here" class="form-control"
                                            name="student_id" id='student_id' autofocus onkeyup="removeNameValidation()" />
                                        <span class="text-danger">
                                            <strong id="student_id-error"></strong>
                                        </span>
                                    </div>

                                </div>
                                <div class="col-md-4">
                                    <label strong style="font-size: 16px;">Address</label><label
                                        style="color: red; font-size:16px;"></label>
                                    <div class="form-group">
                                        <input type="text" placeholder="Write Category Name here" class="form-control"
                                            name="address" id='address' autofocus onkeyup="removeaddressValidation()" />
                                        <span class="text-danger">
                                            <strong id="address-error"></strong>
                                        </span>
                                    </div>

                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <label strong style="font-size: 16px;">Age</label><label
                                        style="color: red; font-size:16px;"></label>
                                    <div class="form-group">
                                        <input type="number" placeholder="Write Age here" class="form-control"
                                            name="age" id='age' autofocus onkeyup="removeageValidation()" />
                                        <span class="text-danger">
                                            <strong id="age-error"></strong>
                                        </span>
                                    </div>

                                </div>
                                <div class="col-md-4">
                                    <label strong style="font-size: 16px;">Phone</label><label
                                        style="color: red; font-size:16px;"></label>
                                    <div class="form-group">
                                        <input type="text" placeholder="Write Phone here" class="form-control"
                                            name="phone" id='phone' autofocus onkeyup="removeNameValidation()" />
                                        <span class="text-danger">
                                            <strong id="phone-error"></strong>
                                        </span>
                                    </div>

                                </div>
                                <div class="col-md-4">
                                    <label strong style="font-size: 16px;">Department</label><label
                                        style="color: red; font-size:16px;"></label>
                                    <div class="form-group">
                                        <input type="text" placeholder="Write Department here" class="form-control"
                                            name="department" id='department' autofocus
                                            onkeyup="removedepartmentValidation()" />
                                        <span class="text-danger">
                                            <strong id="department-error"></strong>
                                        </span>
                                    </div>

                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <label strong style="font-size: 16px;">Sex</label><label
                                        style="color: red; font-size:16px;"></label>

                                    <div class="form-group">
                                        <div>
                                            <select class="custom-select browser-default select2" name="sex"
                                                id="sex" onchange="removeSexValidation()">
                                                <option value=""></option>
                                                <option value="Male">Male</option>
                                                <option value="Female">Female</option>
                                            </select>
                                            <span class="text-danger">
                                                <strong id="sex-error"></strong>
                                            </span>
                                        </div>
                                    </div>

                                </div>
                                <div class="col-md-4">
                                    <label strong style="font-size: 16px;">Entry Year</label><label
                                        style="color: red; font-size:16px;">*</label>
                                    <div class="form-group">
                                        <div>
                                            <select class="custom-select browser-default select2" name="entry_year"
                                                id="entry_year" onchange="removeStatusValidation()">
                                                <option value=""></option>
                                                <option value="2013">2013</option>
                                                <option value="2014">2014</option>
                                                <option value="2015">2015</option>
                                                <option value="2016">2016</option>
                                                <option value="2017">2017</option>
                                                <option value="2018">2018</option>
                                                <option value="2019">2019</option>
                                                <option value="2020">2020</option>
                                            </select>
                                            <span class="text-danger">
                                                <strong id="entry_year-error"></strong>
                                            </span>
                                        </div>
                                    </div>

                                </div>
                                <div class="col-md-4">
                                    <label strong style="font-size: 16px;">Status</label><label
                                        style="color: red; font-size:16px;">*</label>
                                    <div class="form-group">
                                        <div>
                                            <select class="custom-select browser-default select2" name="status"
                                                id="status" onchange="removeStatusValidation()">
                                                <option value="Active">Active</option>
                                                <option value="Inactive">Inactive</option>
                                            </select>
                                            <span class="text-danger">
                                                <strong id="status-error"></strong>
                                            </span>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button id="savenewbutton" type="button" class="btn btn-info">Save &
                                New</button>
                            <button id="savebutton" type="button" class="btn btn-info">Save & Close</button>
                            <button id="closebutton" type="button" class="btn btn-danger" onclick="closeModal()"
                                data-dismiss="modal">Close</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    
    <div class="modal fade" id="sendModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Send Patient To:</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                        onclick="closeModalWithClearValidation()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <div>
                            <div class="row">
                                &nbsp;&nbsp;<button class="btn btn-primary">Pharmacy</button>&nbsp;
                                <button class="btn btn-warning">Labratory</button>&nbsp;
                                <button class="btn btn-success">Reference</button>&nbsp;
                                <button class="btn btn-danger">No Where</button>
                            </div>
                        </div>
                    </div>
                    <input type="hidden" id="send_id">
                </div>
                <div class="modal-footer">
                    <button id="closebutton" type="button" class="btn btn-default"
                        onclick="closeModalWithClearValidation()" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        var errorcolor = "#ffcccc";
        $(function() {
            cardSection = $('#page-block');
        });
        /* BEGIN: Display zone table using yajra datatable */
        $(document).ready(function() {
            var ctable = $('#laravel-datatable-patient').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                searchHighlight: true,
                "pagingType": "simple",
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                "dom": "<'row'<'col-lg-10 col-md-10 col-xs-8'f><'col-lg-2 col-md-2 col-xs-8'>>" +
                    "<'row'<'col-sm-12'tr>>" +
                    "<'row'<'col-sm-12 col-md-3'l><'col-sm-12 col-md-5'i><'col-sm-12 col-md-3'p>>",
                dom: 'Bfrtip', // Add export buttons
                buttons: [
                    'copy', 'csv', 'excel', 'pdf', 'print'
                ],
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: '/getpatientsopd',
                    type: 'DELETE',
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'student.full_name',
                        name: 'student.full_name'
                    },
                    {
                        data: 'student.student_id',
                        name: 'student.student_id'
                    },
                    {
                        data: 'student.sex',
                        name: 'student.sex'
                    },
                    {
                        data: 'student.phone',
                        name: 'student.phone'
                    },
                    {
                        data: 'student.age',
                        name: 'student.age'
                    },
                    {
                        data: 'state',
                        name: 'state'
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return '<div class="btn-group dropleft"><button type="button" class="btn btn-sm dropdown-toffle hide-arrow" data-toggle="dropdown" arial-haspopup="true" arial-expanded="false"><i class="fa fa-ellipsis-v"></i></button><div class = "dropdown-menu" > ' +
                                '<a class = "dropdown-item patientView" onclick = "patientViewFn(' +
                                data
                                .id +
                                ')" id = "dtViewbtn" title = "Open patient update page" data - id = "' +
                                data.id +
                                '"><i class="fa fa-info"></i><span> View History</span></a>' +
                                '<a class = "dropdown-item" onclick = "sendFn(' +
                                data
                                .id +
                                ')" id = "sendBtn" title = "Send" data-id = "' +
                                data.id +
                                '"><i class="fa fa-key"></i><span> Decision </span></a></div></div> ';
                        },
                        orderable: false,
                        searchable: false
                    }
                ],
                "fnRowCallback": function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                    if (aData.state == "2") {
                        $(nRow).find('td:eq(6)').html('Pending');
                        $(nRow).find('td:eq(6)').css({
                            "color": "blue",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #4CAF50"
                        });
                    } else if (aData.state == "3") {
                        $(nRow).find('td:eq(6)').html('Under Doctor')
                        $(nRow).find('td:eq(6)').css({
                            "color": "orange",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #f44336"
                        });
                    }
                }
            });
            /* End: Yajra data table*/
            $('#laravel-datatable-patient tbody').on('click', 'tr', function() {
                if ($(this).hasClass('selected')) {
                    $(this).removeClass('selected');
                } else {
                    $('tr.selected').removeClass('selected');
                    $(this).addClass('selected');
                }
            });

            $('#status').select2({
                minimumResultsForSearch: -1
            });
        });
        ctable.on('draw', function() {
            var body = $(ctable.table().body());
            body.unhighlight();
            body.highlight(ctable.search());
        })
    </script>
    <script>
        function sendFn(record_id) {
            $('#send_id').val(record_id);
            $('#sendModal').modal('show');
        }
        $('.send').click(function() {
            var send_id = $('#send_id').val();
            $.ajax({
                url: '/sendpatient/' + send_id,
                type: 'get',
                beforeSend: function() {
                    $('.send').text('Sending...');
                },
                success: function(data) {
                    if (data.errors) {
                        $('.send').text('Send');
                        alert_toast('an error occured', 'error');
                    } else if (data.success) {
                        $('.send').text('Send');
                        alert_toast(data.success, 'success')
                        var cTable = $('#laravel-datatable-patient').dataTable();
                        cTable.fnDraw(false);
                        $('#sendModal').modal('hide');
                    }
                }
            });
        });
    </script>
    <script>
        function removeNameValidation() {
            $('#name-error').html('');
        }

        function removeStatusValidation() {
            $('#status-error').html('');
        }

        function closeModal() {
            $('#name-error').html('');
            $('#status-error').html('');
            $('#name').val('');
            $('#status').val('').trigger('change');
            $('#savenewbutton').css('display', 'flex');
            $('#savebutton').html('Save & Close');
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Werabe University Project\Werabe University Project\resources\views\clinics\doctor.blade.php ENDPATH**/ ?>