<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>

    <div id="main-content" data-select2-id="main-content">
        <div class="app-content content ">

            <div class="col-md-12">
                <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg"
                        style="padding: 10px 30px; align-items: center; border-radius: 10px; margin-bottom: 20px;">
                        <div class="p-6 text-gray-900" style="text-align: center">
                            <h3>Welcome to <?php echo e(__('dashboard.dashboard')); ?></h3>
                            <p><?php echo e(__('dashboard.logged')); ?></p>
                        </div>
                    </div>
                </div>
            </div>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('proctor')): ?>
                <h1>Your are assigned to: <span style="color: red;">
                        <?php echo e(auth()->user()->block); ?>

                    </span></h1>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dorm_admin')): ?>
                <div class="container-fluid">
                    <!-- Begin Page Content -->
                    <h3>Block Data Information</h3>
                    <div class="row">
                        <div class="col-xl-4 col-md-6">
                            <div class="card bg-primary text-white mb-4">
                                <div class="card-body">Total Block: <span id="total_block">0</span></div>
                                <div class="card-footer d-flex align-items-center justify-content-between">
                                    <a class="small text-white stretched-link" href="#">Total Student:
                                        <span id="total_student">0</span></a>
                                    <div class="small text-white"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-md-6">
                            <div class="card bg-warning text-white mb-4">
                                <div class="card-body">Total Male Block: <span id="total_male_block">0</span></div>
                                <div class="card-footer d-flex align-items-center justify-content-between">
                                    <a class="small text-white stretched-link" href="#">Total Male Student:
                                        <span id="total_male_student">0</span></a>
                                    <div class="small text-white"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-md-6">
                            <div class="card bg-success text-white mb-4">
                                <div class="card-body">Total Female Block: <span id="total_female_block">0</span></div>
                                <div class="card-footer d-flex align-items-center justify-content-between">
                                    <a class="small text-white stretched-link" href="#">Total Female Student:
                                        <span id="total_female_student">0</span></a>
                                    <div class="small text-white"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <h3>Male Dorm Data Information</h3>

                    <div class="row">
                        <a href="/blocks" class="col-xl-3 col-md-3 mb-1">
                            <div class="card border-left-success shadow h-40 py-1">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total
                                                Dorms
                                            </div>
                                            <div class="row no-gutters align-items-center">
                                                <div class="col-auto">
                                                    <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800" data-target="0">
                                                        <span id="total_male_dorm">0</span>
                                                    </div>
                                                </div>
                                                <div class="col">
                                                    <div class="progress progress-sm mr-2">
                                                        <div class="progress-bar bg-primary" id="br" role="progressbar"
                                                            style="width: 100%" aria-valuenow="0" aria-valuemin="0"
                                                            aria-valuemax="0"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <a href="/blocks" class="col-xl-3 col-md-3 mb-1">
                            <div class="card border-left-warning shadow h-40 py-1">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Available
                                                Dorms
                                            </div>
                                            <div class="row no-gutters align-items-center">
                                                <div class="col-auto">
                                                    <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800" data-target="0">
                                                        <span id="available_male_dorm">0</span>
                                                    </div>
                                                </div>
                                                <div class="col">
                                                    <div class="progress progress-sm mr-2">
                                                        <div class="progress-bar bg-warning" id="br1" role="progressbar"
                                                            style="width: 0%" aria-valuenow="60" aria-valuemin="0"
                                                            aria-valuemax="0"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <a href="/blocks" class="col-xl-3 col-md-3 mb-1">
                            <div class="card border-left-secondary shadow h-40 py-1">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-secondary text-uppercase mb-1"
                                                style="font-size: 11px;">Fully
                                                Occupied
                                                Dorms
                                            </div>
                                            <div class="row no-gutters align-items-center">
                                                <div class="col-auto">
                                                    <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800" data-target="0">
                                                        <span id="full_occupied_male_dorm">0</span>
                                                    </div>
                                                </div>
                                                <div class="col">
                                                    <div class="progress progress-sm mr-2">
                                                        <div class="progress-bar bg-secondary" id="br2"
                                                            role="progressbar" style="width: 0%" aria-valuenow="40"
                                                            aria-valuemin="0" aria-valuemax="0"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <a href="/blocks" class="col-xl-3 col-md-3 mb-1">
                            <div class="card border-left-secondary shadow h-40 py-1">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-secondary text-uppercase mb-1"
                                                style="font-size: 9px;">Partialy
                                                Occupied
                                                Dorms
                                            </div>
                                            <div class="row no-gutters align-items-center">
                                                <div class="col-auto">
                                                    <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800" data-target="0">
                                                        <span id="partial_occupied_male_dorm">0</span>
                                                    </div>
                                                </div>
                                                <div class="col">
                                                    <div class="progress progress-sm mr-2">
                                                        <div class="progress-bar bg-secondary" id="br5"
                                                            role="progressbar" style="width: 0%" aria-valuenow="40"
                                                            aria-valuemin="0" aria-valuemax="0"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <h3>Female Dorm Data Information</h3>
                    <div class="row">
                        <a href="/dorms" class="col-xl-3 col-md-3 mb-1">
                            <div class="card border-left-primary shadow h-40 py-1">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total
                                                Dorms
                                            </div>
                                            <div class="row no-gutters align-items-center">
                                                <div class="col-auto">
                                                    <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800" data-target="0">
                                                        <span id="total_female_dorm">0</span>
                                                    </div>
                                                </div>
                                                <div class="col">
                                                    <div class="progress progress-sm mr-2">
                                                        <div class="progress-bar bg-primary" role="progressbar"
                                                            style="width: 100%" aria-valuenow="100" aria-valuemin="0"
                                                            aria-valuemax="100"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <a href="/dorms" class="col-xl-3 col-md-3 mb-1">
                            <div class="card border-left-warning shadow h-40 py-1">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Available
                                                Dorms
                                            </div>
                                            <div class="row no-gutters align-items-center">
                                                <div class="col-auto">
                                                    <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800" data-target="0">
                                                        <span id="available_female_dorm">0</span>
                                                    </div>
                                                </div>
                                                <div class="col">
                                                    <div class="progress progress-sm mr-2">
                                                        <div class="progress-bar bg-warning" id="br3"
                                                            role="progressbar" style="width: 0%" aria-valuenow="60"
                                                            aria-valuemin="0" aria-valuemax="100"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <a href="/dorms" class="col-xl-3 col-md-3 mb-1">
                            <div class="card border-left-secondary shadow h-40 py-1">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-secondary text-uppercase mb-1"
                                                style="font-size: 11px;">Fully Occupied
                                                Dorms
                                            </div>
                                            <div class="row no-gutters align-items-center">
                                                <div class="col-auto">
                                                    <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800" data-target="0">
                                                        <span id="full_occupied_female_dorm">0</span>
                                                    </div>
                                                </div>
                                                <div class="col">
                                                    <div class="progress progress-sm mr-2">
                                                        <div class="progress-bar bg-secondary" id="br4"
                                                            role="progressbar" style="width: 0%" aria-valuenow="40"
                                                            aria-valuemin="0" aria-valuemax="100"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <a href="/dorms" class="col-xl-3 col-md-3 mb-1">
                            <div class="card border-left-secondary shadow h-40 py-1">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-secondary text-uppercase mb-1"
                                                style="font-size: 9px;">Partialy Occupied
                                                Dorms
                                            </div>
                                            <div class="row no-gutters align-items-center">
                                                <div class="col-auto">
                                                    <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800" data-target="0">
                                                        <span id="partial_occupied_female_dorm">0</span>
                                                    </div>
                                                </div>
                                                <div class="col">
                                                    <div class="progress progress-sm mr-2">
                                                        <div class="progress-bar bg-secondary" id="br6"
                                                            role="progressbar" style="width: 0%" aria-valuenow="40"
                                                            aria-valuemin="0" aria-valuemax="100"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('coordinator')): ?>
                <div class="container-fluid">
                    <!-- Begin Page Content -->
                    <h3>Block Data Information</h3>
                    <div class="row">
                        <div class="col-xl-4 col-md-6">
                            <div class="card bg-primary text-white mb-4">
                                <div class="card-body">Total Block: <span id="total_block">0</span></div>
                                <div class="card-footer d-flex align-items-center justify-content-between">
                                    <a class="small text-white stretched-link" href="#">Total Student:
                                        <span id="total_student">0</span></a>
                                    <div class="small text-white"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-md-6">
                            <div class="card bg-warning text-white mb-4">
                                <div class="card-body">Total Male Block: <span id="total_male_block">0</span></div>
                                <div class="card-footer d-flex align-items-center justify-content-between">
                                    <a class="small text-white stretched-link" href="#">Total Male Student:
                                        <span id="total_male_student">0</span></a>
                                    <div class="small text-white"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-md-6">
                            <div class="card bg-success text-white mb-4">
                                <div class="card-body">Total Female Block: <span id="total_female_block">0</span></div>
                                <div class="card-footer d-flex align-items-center justify-content-between">
                                    <a class="small text-white stretched-link" href="#">Total Female Student:
                                        <span id="total_female_student">0</span></a>
                                    <div class="small text-white"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <h3>Male Dorm Data Information</h3>

                    <div class="row">
                        <a href="/blocks" class="col-xl-3 col-md-3 mb-1">
                            <div class="card border-left-success shadow h-40 py-1">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total
                                                Dorms
                                            </div>
                                            <div class="row no-gutters align-items-center">
                                                <div class="col-auto">
                                                    <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800" data-target="0">
                                                        <span id="total_male_dorm">0</span>
                                                    </div>
                                                </div>
                                                <div class="col">
                                                    <div class="progress progress-sm mr-2">
                                                        <div class="progress-bar bg-primary" id="br"
                                                            role="progressbar" style="width: 100%" aria-valuenow="0"
                                                            aria-valuemin="0" aria-valuemax="0"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <a href="/blocks" class="col-xl-3 col-md-3 mb-1">
                            <div class="card border-left-warning shadow h-40 py-1">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Available
                                                Dorms
                                            </div>
                                            <div class="row no-gutters align-items-center">
                                                <div class="col-auto">
                                                    <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800" data-target="0">
                                                        <span id="available_male_dorm">0</span>
                                                    </div>
                                                </div>
                                                <div class="col">
                                                    <div class="progress progress-sm mr-2">
                                                        <div class="progress-bar bg-warning" id="br1"
                                                            role="progressbar" style="width: 0%" aria-valuenow="60"
                                                            aria-valuemin="0" aria-valuemax="0"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <a href="/blocks" class="col-xl-3 col-md-3 mb-1">
                            <div class="card border-left-secondary shadow h-40 py-1">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-secondary text-uppercase mb-1"
                                                style="font-size: 11px;">Fully
                                                Occupied
                                                Dorms
                                            </div>
                                            <div class="row no-gutters align-items-center">
                                                <div class="col-auto">
                                                    <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800" data-target="0">
                                                        <span id="full_occupied_male_dorm">0</span>
                                                    </div>
                                                </div>
                                                <div class="col">
                                                    <div class="progress progress-sm mr-2">
                                                        <div class="progress-bar bg-secondary" id="br2"
                                                            role="progressbar" style="width: 0%" aria-valuenow="40"
                                                            aria-valuemin="0" aria-valuemax="0"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <a href="/blocks" class="col-xl-3 col-md-3 mb-1">
                            <div class="card border-left-secondary shadow h-40 py-1">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-secondary text-uppercase mb-1"
                                                style="font-size: 9px;">Partialy
                                                Occupied
                                                Dorms
                                            </div>
                                            <div class="row no-gutters align-items-center">
                                                <div class="col-auto">
                                                    <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800" data-target="0">
                                                        <span id="partial_occupied_male_dorm">0</span>
                                                    </div>
                                                </div>
                                                <div class="col">
                                                    <div class="progress progress-sm mr-2">
                                                        <div class="progress-bar bg-secondary" id="br5"
                                                            role="progressbar" style="width: 0%" aria-valuenow="40"
                                                            aria-valuemin="0" aria-valuemax="0"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <h3>Female Dorm Data Information</h3>
                    <div class="row">
                        <a href="/dorms" class="col-xl-3 col-md-3 mb-1">
                            <div class="card border-left-primary shadow h-40 py-1">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total
                                                Dorms
                                            </div>
                                            <div class="row no-gutters align-items-center">
                                                <div class="col-auto">
                                                    <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800" data-target="0">
                                                        <span id="total_female_dorm">0</span>
                                                    </div>
                                                </div>
                                                <div class="col">
                                                    <div class="progress progress-sm mr-2">
                                                        <div class="progress-bar bg-primary" role="progressbar"
                                                            style="width: 100%" aria-valuenow="100" aria-valuemin="0"
                                                            aria-valuemax="100"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <a href="/dorms" class="col-xl-3 col-md-3 mb-1">
                            <div class="card border-left-warning shadow h-40 py-1">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Available
                                                Dorms
                                            </div>
                                            <div class="row no-gutters align-items-center">
                                                <div class="col-auto">
                                                    <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800" data-target="0">
                                                        <span id="available_female_dorm">0</span>
                                                    </div>
                                                </div>
                                                <div class="col">
                                                    <div class="progress progress-sm mr-2">
                                                        <div class="progress-bar bg-warning" id="br3"
                                                            role="progressbar" style="width: 0%" aria-valuenow="60"
                                                            aria-valuemin="0" aria-valuemax="100"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <a href="/dorms" class="col-xl-3 col-md-3 mb-1">
                            <div class="card border-left-secondary shadow h-40 py-1">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-secondary text-uppercase mb-1"
                                                style="font-size: 11px;">Fully Occupied
                                                Dorms
                                            </div>
                                            <div class="row no-gutters align-items-center">
                                                <div class="col-auto">
                                                    <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800" data-target="0">
                                                        <span id="full_occupied_female_dorm">0</span>
                                                    </div>
                                                </div>
                                                <div class="col">
                                                    <div class="progress progress-sm mr-2">
                                                        <div class="progress-bar bg-secondary" id="br4"
                                                            role="progressbar" style="width: 0%" aria-valuenow="40"
                                                            aria-valuemin="0" aria-valuemax="100"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <a href="/dorms" class="col-xl-3 col-md-3 mb-1">
                            <div class="card border-left-secondary shadow h-40 py-1">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-secondary text-uppercase mb-1"
                                                style="font-size: 9px;">Partialy Occupied
                                                Dorms
                                            </div>
                                            <div class="row no-gutters align-items-center">
                                                <div class="col-auto">
                                                    <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800" data-target="0">
                                                        <span id="partial_occupied_female_dorm">0</span>
                                                    </div>
                                                </div>
                                                <div class="col">
                                                    <div class="progress progress-sm mr-2">
                                                        <div class="progress-bar bg-secondary" id="br6"
                                                            role="progressbar" style="width: 0%" aria-valuenow="40"
                                                            aria-valuemin="0" aria-valuemax="100"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('management')): ?>
                <div class="container-fluid">
                    <!-- Begin Page Content -->
                    <h3>Block Data Information</h3>
                    <div class="row">
                        <div class="col-xl-4 col-md-6">
                            <div class="card bg-primary text-white mb-4">
                                <div class="card-body">Total Block: <span id="total_block">0</span></div>
                                <div class="card-footer d-flex align-items-center justify-content-between">
                                    <a class="small text-white stretched-link" href="#">Total Student:
                                        <span id="total_student">0</span></a>
                                    <div class="small text-white"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-md-6">
                            <div class="card bg-warning text-white mb-4">
                                <div class="card-body">Total Male Block: <span id="total_male_block">0</span></div>
                                <div class="card-footer d-flex align-items-center justify-content-between">
                                    <a class="small text-white stretched-link" href="#">Total Male Student:
                                        <span id="total_male_student">0</span></a>
                                    <div class="small text-white"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-md-6">
                            <div class="card bg-success text-white mb-4">
                                <div class="card-body">Total Female Block: <span id="total_female_block">0</span></div>
                                <div class="card-footer d-flex align-items-center justify-content-between">
                                    <a class="small text-white stretched-link" href="#">Total Female Student:
                                        <span id="total_female_student">0</span></a>
                                    <div class="small text-white"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <h3>Male Dorm Data Information</h3>

                    <div class="row">
                        <a href="/blocks" class="col-xl-3 col-md-3 mb-1">
                            <div class="card border-left-success shadow h-40 py-1">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total
                                                Dorms
                                            </div>
                                            <div class="row no-gutters align-items-center">
                                                <div class="col-auto">
                                                    <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800" data-target="0">
                                                        <span id="total_male_dorm">0</span>
                                                    </div>
                                                </div>
                                                <div class="col">
                                                    <div class="progress progress-sm mr-2">
                                                        <div class="progress-bar bg-primary" id="br"
                                                            role="progressbar" style="width: 100%" aria-valuenow="0"
                                                            aria-valuemin="0" aria-valuemax="0"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <a href="/blocks" class="col-xl-3 col-md-3 mb-1">
                            <div class="card border-left-warning shadow h-40 py-1">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Available
                                                Dorms
                                            </div>
                                            <div class="row no-gutters align-items-center">
                                                <div class="col-auto">
                                                    <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800" data-target="0">
                                                        <span id="available_male_dorm">0</span>
                                                    </div>
                                                </div>
                                                <div class="col">
                                                    <div class="progress progress-sm mr-2">
                                                        <div class="progress-bar bg-warning" id="br1"
                                                            role="progressbar" style="width: 0%" aria-valuenow="60"
                                                            aria-valuemin="0" aria-valuemax="0"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <a href="/blocks" class="col-xl-3 col-md-3 mb-1">
                            <div class="card border-left-secondary shadow h-40 py-1">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-secondary text-uppercase mb-1"
                                                style="font-size: 11px;">Fully
                                                Occupied
                                                Dorms
                                            </div>
                                            <div class="row no-gutters align-items-center">
                                                <div class="col-auto">
                                                    <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800" data-target="0">
                                                        <span id="full_occupied_male_dorm">0</span>
                                                    </div>
                                                </div>
                                                <div class="col">
                                                    <div class="progress progress-sm mr-2">
                                                        <div class="progress-bar bg-secondary" id="br2"
                                                            role="progressbar" style="width: 0%" aria-valuenow="40"
                                                            aria-valuemin="0" aria-valuemax="0"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <a href="/blocks" class="col-xl-3 col-md-3 mb-1">
                            <div class="card border-left-secondary shadow h-40 py-1">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-secondary text-uppercase mb-1"
                                                style="font-size: 9px;">Partialy
                                                Occupied
                                                Dorms
                                            </div>
                                            <div class="row no-gutters align-items-center">
                                                <div class="col-auto">
                                                    <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800" data-target="0">
                                                        <span id="partial_occupied_male_dorm">0</span>
                                                    </div>
                                                </div>
                                                <div class="col">
                                                    <div class="progress progress-sm mr-2">
                                                        <div class="progress-bar bg-secondary" id="br5"
                                                            role="progressbar" style="width: 0%" aria-valuenow="40"
                                                            aria-valuemin="0" aria-valuemax="0"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <h3>Female Dorm Data Information</h3>
                    <div class="row">
                        <a href="/dorms" class="col-xl-3 col-md-3 mb-1">
                            <div class="card border-left-primary shadow h-40 py-1">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total
                                                Dorms
                                            </div>
                                            <div class="row no-gutters align-items-center">
                                                <div class="col-auto">
                                                    <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800" data-target="0">
                                                        <span id="total_female_dorm">0</span>
                                                    </div>
                                                </div>
                                                <div class="col">
                                                    <div class="progress progress-sm mr-2">
                                                        <div class="progress-bar bg-primary" role="progressbar"
                                                            style="width: 100%" aria-valuenow="100" aria-valuemin="0"
                                                            aria-valuemax="100"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <a href="/dorms" class="col-xl-3 col-md-3 mb-1">
                            <div class="card border-left-warning shadow h-40 py-1">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Available
                                                Dorms
                                            </div>
                                            <div class="row no-gutters align-items-center">
                                                <div class="col-auto">
                                                    <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800" data-target="0">
                                                        <span id="available_female_dorm">0</span>
                                                    </div>
                                                </div>
                                                <div class="col">
                                                    <div class="progress progress-sm mr-2">
                                                        <div class="progress-bar bg-warning" id="br3"
                                                            role="progressbar" style="width: 0%" aria-valuenow="60"
                                                            aria-valuemin="0" aria-valuemax="100"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <a href="/dorms" class="col-xl-3 col-md-3 mb-1">
                            <div class="card border-left-secondary shadow h-40 py-1">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-secondary text-uppercase mb-1"
                                                style="font-size: 11px;">Fully Occupied
                                                Dorms
                                            </div>
                                            <div class="row no-gutters align-items-center">
                                                <div class="col-auto">
                                                    <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800" data-target="0">
                                                        <span id="full_occupied_female_dorm">0</span>
                                                    </div>
                                                </div>
                                                <div class="col">
                                                    <div class="progress progress-sm mr-2">
                                                        <div class="progress-bar bg-secondary" id="br4"
                                                            role="progressbar" style="width: 0%" aria-valuenow="40"
                                                            aria-valuemin="0" aria-valuemax="100"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <a href="/dorms" class="col-xl-3 col-md-3 mb-1">
                            <div class="card border-left-secondary shadow h-40 py-1">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-secondary text-uppercase mb-1"
                                                style="font-size: 9px;">Partialy Occupied
                                                Dorms
                                            </div>
                                            <div class="row no-gutters align-items-center">
                                                <div class="col-auto">
                                                    <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800" data-target="0">
                                                        <span id="partial_occupied_female_dorm">0</span>
                                                    </div>
                                                </div>
                                                <div class="col">
                                                    <div class="progress progress-sm mr-2">
                                                        <div class="progress-bar bg-secondary" id="br6"
                                                            role="progressbar" style="width: 0%" aria-valuenow="40"
                                                            aria-valuemin="0" aria-valuemax="100"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>

                </div>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_admin')): ?>
                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-2">
                        <h1 class="h3 mb-0 text-gray-800">Data Information</h1>
                    </div>

                    <div class="row">

                        <!-- Earnings (Monthly) Card Example -->
                        <a href="/users" class="col-xl-4 col-md-4 mb-2">
                            <div class="card border-left-primary shadow h-60">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                Users</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                &nbsp;<span id="number_user"></span>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-users fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <a href="/students" class="col-xl-4 col-md-4 mb-2">
                            <div class="card border-left-primary shadow h-60">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                Students</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">&nbsp;<span
                                                    id="number_student"></span></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-users fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <a href="/quality_checker" class="col-xl-4 col-md-4 mb-2">
                            <div class="card border-left-primary shadow h-60">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                Quality Checker</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">&nbsp;<span
                                                    id="number_quality"></span></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-users fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="row">

                        <!-- Earnings (Monthly) Card Example -->
                        <a href="/product" class="col-xl-4 col-md-4 mb-2">
                            <div class="card border-left-primary shadow h-60">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                Items</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                &nbsp;<span id="number_item"></span>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-stream fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <a href="/category" class="col-xl-4 col-md-4 mb-2">
                            <div class="card border-left-primary shadow h-60">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                Category</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">&nbsp;<span
                                                    id="number_category"></span></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-stream fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <a href="/unit" class="col-xl-4 col-md-4 mb-2">
                            <div class="card border-left-primary shadow h-60">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                Unit</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">&nbsp;<span
                                                    id="number_unit"></span>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-stream fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_campus')): ?>
                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-2">
                        <h1 class="h3 mb-0 text-gray-800">Requests</h1>
                    </div>

                    <div class="row">
                        <a href="<?php echo e(url('list-all')); ?>" class="col-xl-3 col-md-3 mb-2">
                            <div class="card border-left-primary shadow h-60">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                All Requests</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                &nbsp; <span id="all-request"></span>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-bell fa-2x text-gray-300" style="color: rgb(14, 2, 58);"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <!-- Earnings (Monthly) Card Example -->
                        <a href="<?php echo e(url('request/2')); ?>" class="col-xl-3 col-md-3 mb-2">
                            <div class="card border-left-primary shadow h-60">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                Pending</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                &nbsp; <span id="pending-request"></span>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-bell fa-2x text-gray-300" style="color: blue;"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <a href="<?php echo e(url('request/3')); ?>" class="col-xl-3 col-md-3 mb-2">
                            <div class="card border-left-warning shadow h-60">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                Delivery waiting</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">&nbsp;
                                                &nbsp; <span id="delivery-request"></span></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-bell fa-2x text-gray-300" style="color: orange;"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <a href="<?php echo e(url('request/4')); ?>" class="col-xl-3 col-md-3 mb-2">
                            <div class="card border-left-success shadow h-60">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1"
                                                style="font-size: 12px;">
                                                Completed</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">&nbsp;<span
                                                    id="complete"></span>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-bell fa-2x text-gray-300" style="color: green;"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_clinic_leader')): ?>
                <input type="hidden" id="jun" value="<?php echo e($jun); ?>">
                <input type="hidden" id="feb" value="<?php echo e($feb); ?>">
                <input type="hidden" id="mar" value="<?php echo e($mar); ?>">
                <input type="hidden" id="app" value="<?php echo e($app); ?>">
                <input type="hidden" id="may" value="<?php echo e($may); ?>">
                <input type="hidden" id="june" value="<?php echo e($june); ?>">
                <input type="hidden" id="july" value="<?php echo e($july); ?>">
                <input type="hidden" id="aug" value="<?php echo e($aug); ?>">
                <input type="hidden" id="sep" value="<?php echo e($sep); ?>">
                <input type="hidden" id="oct" value="<?php echo e($oct); ?>">
                <input type="hidden" id="nev" value="<?php echo e($nev); ?>">
                <input type="hidden" id="dec" value="<?php echo e($dec); ?>">
                <!-- Begin Page Content -->
                <div class="container-fluid">
                    

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-2">
                        <h1 class="h3 mb-0 text-gray-800">Requests</h1>
                    </div>

                    <div class="row">
                        <a href="<?php echo e(url('campusStore')); ?>" class="col-xl-4 col-md-4 mb-2">
                            <div class="card border-left-primary shadow h-60">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                All requests</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                &nbsp; <span><?php echo e($all_count); ?></span>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-bell fa-2x text-gray-300" style="color: rgb(14, 2, 58);"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <!-- Staff pending count -->
                        <a href="<?php echo e(url('campusStore')); ?>" class="col-xl-4 col-md-4 mb-2">
                            <div class="card border-left-primary shadow h-60">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                Clinic Pending</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                &nbsp; <span id=""><?php echo e($campus_count); ?></span>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-bell fa-2x text-gray-300" style="color: blue;"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <a href="<?php echo e(url('list-all-request')); ?>" class="col-xl-4 col-md-4 mb-2">
                            <div class="card border-left-success shadow h-60">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1"
                                                style="font-size: 12px;">
                                                Staff Pending</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">&nbsp;<span
                                                    id="leader-pending"></span><?php echo e($store_count); ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-bell fa-2x text-gray-300" style="color: green;"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <!-- Content Row -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-2">
                        <h1 class="h3 mb-0 text-gray-800">Patient Statistics</h1>
                    </div>
                    <div class="row">

                        <!-- Area Chart -->
                        <div class="col-xl-12 col-lg-12">
                            <div class="card shadow mb-2">
                                <!-- Card Header - Dropdown -->
                                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">Patients Overview</h6>
                                    <h6 class="m-0 font-weight-bold text-primary">Total Patients:
                                        <span><?php echo e($count); ?></span>
                                    </h6>
                                    <select name="selYear" id="selYear" class="form-control col-md-3"
                                        onchange="getYear()">
                                        <option value="<?php echo e($currentYear); ?>"><?php echo e($currentYear); ?></option>
                                        <option value="2024">2024</option>
                                        <option value="2025">2025</option>
                                        <option value="2026">2026</option>
                                        <option value="2027">2027</option>
                                        <option value="2028">2028</option>
                                    </select>
                                </div>
                                <!-- Card Body -->
                                <div class="card-body" style="height: 300px;">
                                    <div class="chart-area h-100">
                                        <canvas id="myAreaChart"></canvas>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_clinic')): ?>
                <!-- Begin Page Content -->
                <div class="container-fluid">
                    

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-2">
                        <h1 class="h3 mb-0 text-gray-800">Received Requests</h1>
                    </div>

                    <div class="row">
                        <a href="<?php echo e(url('list-all-request')); ?>" class="col-xl-3 col-md-3 mb-2">
                            <div class="card border-left-primary shadow h-60">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                All Requests</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                &nbsp; <span id="clinic-all-request"></span>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-bell fa-2x text-gray-300" style="color: rgb(14, 2, 58);"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <!-- Earnings (Monthly) Card Example -->
                        <a href="<?php echo e(url('pharmacy-request/1')); ?>" class="col-xl-3 col-md-3 mb-2">
                            <div class="card border-left-primary shadow h-60">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                Pending</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                &nbsp; <span id="clinic-pending-request"></span>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-bell fa-2x text-gray-300" style="color: blue;"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <a href="<?php echo e(url('pharmacy-request/2')); ?>" class="col-xl-3 col-md-3 mb-2">
                            <div class="card border-left-warning shadow h-60">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                Delivery waiting</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">&nbsp;
                                                &nbsp; <span id="clinic-delivery-request"></span></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-bell fa-2x text-gray-300" style="color: orange;"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <a href="<?php echo e(url('pharmacy-request/3')); ?>" class="col-xl-3 col-md-3 mb-2">
                            <div class="card border-left-success shadow h-60">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1"
                                                style="font-size: 12px;">
                                                Completed</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">&nbsp;<span
                                                    id="clinic-complete"></span></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-bell fa-2x text-gray-300" style="color: green;"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_pharmacy')): ?>
                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-2">
                        <h1 class="h3 mb-0 text-gray-800">Patient Requests</h1>
                    </div>

                    <div class="row">
                        <a href="<?php echo e(url('patient_pharmacy')); ?>" class="col-xl-4 col-md-4 mb-2">
                            <div class="card border-left-primary shadow h-60">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1"
                                                style="font-size: 11px;">
                                                All Patients</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                &nbsp; <span id="all_pharmacy_patient"></span>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-users fa-2x text-gray-300" style="color: rgb(14, 2, 58);"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <!-- Earnings (Monthly) Card Example -->
                        <a href="<?php echo e(url('patient_pharmacy')); ?>" class="col-xl-4 col-md-4 mb-2">
                            <div class="card border-left-primary shadow h-60">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1"
                                                style="font-size: 11px;">
                                                Pending Patients</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                &nbsp; <span id="pending_pharmacy_patient"></span>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-users fa-2x text-gray-300" style="color: blue;"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <a href="<?php echo e(url('patient_pharmacy')); ?>" class="col-xl-4 col-md-4 mb-2">
                            <div class="card border-left-success shadow h-60">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1"
                                                style="font-size: 11px;">
                                                Completed Patients</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">&nbsp;<span
                                                    id="complete_pharmacy_patient"></span></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-users fa-2x text-gray-300" style="color: green;"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header border-bottom">
                        <h3 class="card-title">Employee Schedules</h3>

                    </div>
                    <div class="card-datatable">
                        <div style="width:98%; margin-left:1%;">
                            <div class="table-responsive">

                                <table id="laravel-datatable-category"
                                    class="display table-bordered table-striped table-hover dt-responsive mb-0 dataTable no-footer"
                                    style="width: 100%;" role="grid" aria-describedby="laravel-datatable-user">

                                    <thead>
                                        <tr role="row">
                                            <th nowrap>#</th>
                                            <th nowrap>Employee Name</th>
                                            <th nowrap>Type</th>
                                            <th nowrap>In Time</th>
                                            <th nowrap>Out Time</th>
                                            <th nowrap>Working Days</th>
                                            <th nowrap>Current Status</th>
                                        </tr>
                                    </thead>
                                    <tbody></tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_doctor')): ?>
                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-2">
                        <h1 class="h3 mb-0 text-gray-800">Patient Information</h1>
                    </div>

                    <div class="row">
                        <a href="<?php echo e(url('patient_doctor')); ?>" class="col-xl-3 col-md-3 mb-2">
                            <div class="card border-left-primary shadow h-60">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1"
                                                style="font-size: 11px;">
                                                All patient</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                &nbsp; <span id="doctor-all"></span>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-users fa-2x text-gray-300" style="color: rgb(14, 2, 58);"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <a href="<?php echo e(url('patient_doctor')); ?>" class="col-xl-3 col-md-3 mb-2">
                            <div class="card border-left-primary shadow h-60">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1"
                                                style="font-size: 11px;">
                                                Pending</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                &nbsp; <span id="doctor-pending"></span>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-users fa-2x text-gray-300" style="color: rgb(14, 2, 58);"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <!-- Earnings (Monthly) Card Example -->
                        <a href="<?php echo e(url('patient_doctor')); ?>" class="col-xl-3 col-md-3 mb-2">
                            <div class="card border-left-primary shadow h-60">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1"
                                                style="font-size: 11px;">
                                                Lab checking</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                &nbsp; <span id="doctor-lab-check"></span>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-users fa-2x text-gray-300" style="color: blue;"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <a href="<?php echo e(url('patient_doctor')); ?>" class="col-xl-3 col-md-3 mb-2">
                            <div class="card border-left-warning shadow h-60">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1"
                                                style="font-size: 11px;">
                                                Lab result</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">&nbsp;
                                                &nbsp; <span id="doctor-lab-result"></span></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-users fa-2x text-gray-300" style="color: orange;"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header border-bottom">
                        <h3 class="card-title">Employee Schedules</h3>

                    </div>
                    <div class="card-datatable">
                        <div style="width:98%; margin-left:1%;">
                            <div class="table-responsive">

                                <table id="laravel-datatable-category"
                                    class="display table-bordered table-striped table-hover dt-responsive mb-0 dataTable no-footer"
                                    style="width: 100%;" role="grid" aria-describedby="laravel-datatable-user">

                                    <thead>
                                        <tr role="row">
                                            <th nowrap>#</th>
                                            <th nowrap>Employee Name</th>
                                            <th nowrap>Type</th>
                                            <th nowrap>In Time</th>
                                            <th nowrap>Out Time</th>
                                            <th nowrap>Working Days</th>
                                            <th nowrap>Current Status</th>
                                        </tr>
                                    </thead>
                                    <tbody></tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_labratory')): ?>
                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-2">
                        <h1 class="h3 mb-0 text-gray-800">Patient Requests</h1>
                    </div>

                    <div class="row">
                        <a href="<?php echo e(url('patient_labratory')); ?>" class="col-xl-4 col-md-4 mb-2">
                            <div class="card border-left-primary shadow h-60">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1"
                                                style="font-size: 11px;">
                                                All Patients</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                &nbsp; <span id="all_labratory_patient"></span>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-users fa-2x text-gray-300" style="color: rgb(14, 2, 58);"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <!-- Earnings (Monthly) Card Example -->
                        <a href="<?php echo e(url('patient_labratory')); ?>" class="col-xl-4 col-md-4 mb-2">
                            <div class="card border-left-primary shadow h-60">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1"
                                                style="font-size: 11px;">
                                                Pending Patients</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">
                                                &nbsp; <span id="pending_labratory_patient"></span>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-users fa-2x text-gray-300" style="color: blue;"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <a href="<?php echo e(url('patient_labratory')); ?>" class="col-xl-4 col-md-4 mb-2">
                            <div class="card border-left-success shadow h-60">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1"
                                                style="font-size: 11px;">
                                                Completed Patients</div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800">&nbsp;<span
                                                    id="complete_labratory_patient"></span></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-users fa-2x text-gray-300" style="color: green;"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header border-bottom">
                        <h3 class="card-title">Employee Schedules</h3>

                    </div>
                    <div class="card-datatable">
                        <div style="width:98%; margin-left:1%;">
                            <div class="table-responsive">

                                <table id="laravel-datatable-category"
                                    class="display table-bordered table-striped table-hover dt-responsive mb-0 dataTable no-footer"
                                    style="width: 100%;" role="grid" aria-describedby="laravel-datatable-user">

                                    <thead>
                                        <tr role="row">
                                            <th nowrap>#</th>
                                            <th nowrap>Employee Name</th>
                                            <th nowrap>Type</th>
                                            <th nowrap>In Time</th>
                                            <th nowrap>Out Time</th>
                                            <th nowrap>Working Days</th>
                                            <th nowrap>Current Status</th>
                                        </tr>
                                    </thead>
                                    <tbody></tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_register')): ?>
                <div class="card">
                    <div class="card-header border-bottom">
                        <h3 class="card-title">Employee Schedules</h3>

                    </div>
                    <div class="card-datatable">
                        <div style="width:98%; margin-left:1%;">
                            <div class="table-responsive">

                                <table id="laravel-datatable-category"
                                    class="display table-bordered table-striped table-hover dt-responsive mb-0 dataTable no-footer"
                                    style="width: 100%;" role="grid" aria-describedby="laravel-datatable-user">

                                    <thead>
                                        <tr role="row">
                                            <th nowrap>#</th>
                                            <th nowrap>Employee Name</th>
                                            <th nowrap>Type</th>
                                            <th nowrap>In Time</th>
                                            <th nowrap>Out Time</th>
                                            <th nowrap>Working Days</th>
                                            <th nowrap>Current Status</th>
                                        </tr>
                                    </thead>
                                    <tbody></tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            document.querySelectorAll('.counter').forEach(counter => {
                const target = parseInt(counter.getAttribute('data-target'));
                let count = 0;
                const duration = 2000; // Duration of the animation in milliseconds
                const interval = 20; // Interval in milliseconds
                const step = (target / (duration / interval));

                function updateCounter() {
                    count += step;
                    if (count < target + 1) {
                        counter.textContent = Math.floor(count);
                        setTimeout(updateCounter, interval);
                    } else {
                        counterElement.textContent = target;
                    }
                }

                updateCounter();
            });
        });

        function getYear() {
            window.location = '/dashboard/' + $('#selYear').val();
        }

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_admin')): ?>
            $.get('/adminstatistics', function(data) {
                if (data.success) {
                    $('#number_user').html(data.user);
                    $('#number_student').html(data.student);
                    $('#number_quality').html(data.quality);
                    $('#number_category').html(data.category);
                    $('#number_unit').html(data.unit);
                    $('#number_item').html(data.item);
                }
            });
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_campus')): ?>
            $.get('/stat-campus', function(data) {
                if (data.success) {
                    $('#campus_num').html(data.available);
                    $('#clinic_num').html(data.withdraw);
                    $('#all_num').html(data.received);
                }
            });
            $.get('/campus-notification', function(data) {
                if (data.success) {
                    $('#all-request').html(data.all_request);
                    $('#pending-request').html(data.pending);
                    $('#delivery-request').html(data.delivery);
                    $('#complete').html(data.complete);
                }
            });
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_clinic')): ?>
            $.get('/stat-withdraw', function(data) {
                if (data.success) {
                    $('#withdraw').html(data.success);
                    $('#clinic_all').html(data.success);
                    $('#pharmacy_all').html(data.success);
                }
            });
            $.get('/clinic-notification', function(data) {
                if (data.success) {
                    $('#clinic-all-request').html(data.all_request);
                    $('#clinic-pending-request').html(data.pending);
                    $('#clinic-delivery-request').html(data.delivery);
                    $('#clinic-complete').html(data.complete);
                }
            });
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_pharmacy')): ?>
            $.get('/pharmacy-notification', function(data) {
                if (data.success) {
                    $('#all_pharmacy_patient').html(data.all_request);
                    $('#pending_pharmacy_patient').html(data.pending);
                    $('#complete_pharmacy_patient').html(data.complete);
                }
            });
            $(document).ready(function() {
                var ctable = $('#laravel-datatable-category').DataTable({
                    destroy: true,
                    processing: true,
                    serverSide: true,
                    searchHighlight: true,
                    dom: 'lBfrtip', // Add l before B to include lengthMenu
                    buttons: [{
                        extend: 'copy',
                        title: 'Your Title Here' // Title for the 'copy' button
                    }],
                    lengthMenu: [
                        [10, 25, 50, 500, -1],
                        [10, 25, 50, 500, "All"]
                    ],
                    language: {
                        search: '',
                        searchPlaceholder: "Search here"
                    },
                    ajax: {
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        url: '/getschedules',
                        type: 'DELETE',
                        beforeSend: function() {
                            cardSection.block({
                                message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                                css: {
                                    backgroundColor: 'transparent',
                                    color: '#fff',
                                    border: '0'
                                },
                                overlayCSS: {
                                    opacity: 0.5
                                }
                            });
                        },
                        complete: function() {
                            cardSection.block({
                                message: '',
                                timeout: 1,
                                css: {
                                    backgroundColor: '',
                                    color: '',
                                    border: ''
                                },
                            });
                        },
                    },
                    columns: [{
                            data: 'DT_RowIndex',
                            name: 'DT_RowIndex',
                            orderable: false,
                            searchable: false
                        },
                        {
                            data: 'user',
                            name: 'user'
                        },
                        {
                            data: 'role',
                            name: 'role'
                        },
                        {
                            data: 'in_time',
                            name: 'in_time'
                        },
                        {
                            data: 'out_time',
                            name: 'out_time'
                        },
                        {
                            data: 'working_day',
                            name: 'working_day'
                        },
                        {
                            data: null,
                            render: function(data, type, full, meta) {
                                return data.status == '0' ?
                                    '<i class="fa fa-circle text-danger"> Out of Duty</i>' :
                                    ' <i class="fa fa-check-circle text-success"> On Duty</i>';
                            },
                            orderable: false,
                            searchable: false
                        },
                    ],
                    "fnRowCallback": function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                        $(nRow).find('td:eq(2)').css({
                            "color": "orange",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #4CAF50"
                        });
                    }
                });
            });
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_labratory')): ?>
            $.get('/labratory-notification', function(data) {
                if (data.success) {
                    $('#all_labratory_patient').html(data.all_request);
                    $('#pending_labratory_patient').html(data.pending);
                    $('#complete_labratory_patient').html(data.complete);
                }
            });

            $(document).ready(function() {
                var ctable = $('#laravel-datatable-category').DataTable({
                    destroy: true,
                    processing: true,
                    serverSide: true,
                    searchHighlight: true,
                    dom: 'lBfrtip', // Add l before B to include lengthMenu
                    buttons: [{
                        extend: 'copy',
                        title: 'Your Title Here' // Title for the 'copy' button
                    }],
                    lengthMenu: [
                        [10, 25, 50, 500, -1],
                        [10, 25, 50, 500, "All"]
                    ],
                    language: {
                        search: '',
                        searchPlaceholder: "Search here"
                    },
                    ajax: {
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        url: '/getschedules',
                        type: 'DELETE',
                        beforeSend: function() {
                            cardSection.block({
                                message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                                css: {
                                    backgroundColor: 'transparent',
                                    color: '#fff',
                                    border: '0'
                                },
                                overlayCSS: {
                                    opacity: 0.5
                                }
                            });
                        },
                        complete: function() {
                            cardSection.block({
                                message: '',
                                timeout: 1,
                                css: {
                                    backgroundColor: '',
                                    color: '',
                                    border: ''
                                },
                            });
                        },
                    },
                    columns: [{
                            data: 'DT_RowIndex',
                            name: 'DT_RowIndex',
                            orderable: false,
                            searchable: false
                        },
                        {
                            data: 'user',
                            name: 'user'
                        },
                        {
                            data: 'role',
                            name: 'role'
                        },
                        {
                            data: 'in_time',
                            name: 'in_time'
                        },
                        {
                            data: 'out_time',
                            name: 'out_time'
                        },
                        {
                            data: 'working_day',
                            name: 'working_day'
                        },
                        {
                            data: null,
                            render: function(data, type, full, meta) {
                                return data.status == '0' ?
                                    '<i class="fa fa-circle text-danger"> Out of Duty</i>' :
                                    ' <i class="fa fa-check-circle text-success"> On Duty</i>';
                            },
                            orderable: false,
                            searchable: false
                        },
                    ],
                    "fnRowCallback": function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                        $(nRow).find('td:eq(2)').css({
                            "color": "orange",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #4CAF50"
                        });
                    }
                });
            });
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_doctor')): ?>
            $.get('/doctor-notification', function(data) {
                if (data.success) {
                    $('#doctor-all').html(data.count);
                    $('#doctor-pending').html(data.pending);
                    $('#doctor-lab-check').html(data.check);
                    $('#doctor-lab-result').html(data.lab_result);
                }
            });

            $(document).ready(function() {
                var ctable = $('#laravel-datatable-category').DataTable({
                    destroy: true,
                    processing: true,
                    serverSide: true,
                    searchHighlight: true,
                    dom: 'lBfrtip', // Add l before B to include lengthMenu
                    buttons: [{
                        extend: 'copy',
                        title: 'Your Title Here' // Title for the 'copy' button
                    }],
                    lengthMenu: [
                        [10, 25, 50, 500, -1],
                        [10, 25, 50, 500, "All"]
                    ],
                    language: {
                        search: '',
                        searchPlaceholder: "Search here"
                    },
                    ajax: {
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        url: '/getschedules',
                        type: 'DELETE',
                        beforeSend: function() {
                            cardSection.block({
                                message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                                css: {
                                    backgroundColor: 'transparent',
                                    color: '#fff',
                                    border: '0'
                                },
                                overlayCSS: {
                                    opacity: 0.5
                                }
                            });
                        },
                        complete: function() {
                            cardSection.block({
                                message: '',
                                timeout: 1,
                                css: {
                                    backgroundColor: '',
                                    color: '',
                                    border: ''
                                },
                            });
                        },
                    },
                    columns: [{
                            data: 'DT_RowIndex',
                            name: 'DT_RowIndex',
                            orderable: false,
                            searchable: false
                        },
                        {
                            data: 'user',
                            name: 'user'
                        },
                        {
                            data: 'role',
                            name: 'role'
                        },
                        {
                            data: 'in_time',
                            name: 'in_time'
                        },
                        {
                            data: 'out_time',
                            name: 'out_time'
                        },
                        {
                            data: 'working_day',
                            name: 'working_day'
                        },
                        {
                            data: null,
                            render: function(data, type, full, meta) {
                                return data.status == '0' ?
                                    '<i class="fa fa-circle text-danger"> Out of Duty</i>' :
                                    ' <i class="fa fa-check-circle text-success"> On Duty</i>';
                            },
                            orderable: false,
                            searchable: false
                        },
                    ],
                    "fnRowCallback": function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                        $(nRow).find('td:eq(2)').css({
                            "color": "orange",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #4CAF50"
                        });
                    }
                });
            });
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_register')): ?>

            $(document).ready(function() {
                var ctable = $('#laravel-datatable-category').DataTable({
                    destroy: true,
                    processing: true,
                    serverSide: true,
                    searchHighlight: true,
                    dom: 'lBfrtip', // Add l before B to include lengthMenu
                    buttons: [{
                        extend: 'copy',
                        title: 'Your Title Here' // Title for the 'copy' button
                    }],
                    lengthMenu: [
                        [10, 25, 50, 500, -1],
                        [10, 25, 50, 500, "All"]
                    ],
                    language: {
                        search: '',
                        searchPlaceholder: "Search here"
                    },
                    ajax: {
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        url: '/getschedules',
                        type: 'DELETE',
                        beforeSend: function() {
                            cardSection.block({
                                message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                                css: {
                                    backgroundColor: 'transparent',
                                    color: '#fff',
                                    border: '0'
                                },
                                overlayCSS: {
                                    opacity: 0.5
                                }
                            });
                        },
                        complete: function() {
                            cardSection.block({
                                message: '',
                                timeout: 1,
                                css: {
                                    backgroundColor: '',
                                    color: '',
                                    border: ''
                                },
                            });
                        },
                    },
                    columns: [{
                            data: 'DT_RowIndex',
                            name: 'DT_RowIndex',
                            orderable: false,
                            searchable: false
                        },
                        {
                            data: 'user',
                            name: 'user'
                        },
                        {
                            data: 'role',
                            name: 'role'
                        },
                        {
                            data: 'in_time',
                            name: 'in_time'
                        },
                        {
                            data: 'out_time',
                            name: 'out_time'
                        },
                        {
                            data: 'working_day',
                            name: 'working_day'
                        },
                        {
                            data: null,
                            render: function(data, type, full, meta) {
                                return data.status == '0' ?
                                    '<i class="fa fa-circle text-danger"> Out of Duty</i>' :
                                    ' <i class="fa fa-check-circle text-success"> On Duty</i>';
                            },
                            orderable: false,
                            searchable: false
                        },
                    ],
                    "fnRowCallback": function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                        $(nRow).find('td:eq(2)').css({
                            "color": "orange",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #4CAF50"
                        });
                    }
                });
            });
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dorm_admin')): ?>
            $.get('/dormstatistics', function(data) {
                if (data.success) {
                    $('#total_block').html(data.totalblock);
                    $('#total_student').html(data.totalstudent);
                    $('#total_male_block').html(data.totalmaleblock);
                    $('#total_female_block').html(data.totalfemaleblock);
                    $('#total_male_student').html(data.totalmalestudent);
                    $('#total_female_student').html(data.totalfemalestudent);

                    $('#total_male_dorm').html(data.totalmaledorm);
                    let br1 = (data.availablemaledorm / data.totalmaledorm) * 100;
                    let br2 = (data.fulloccupiedmaledorm / data.totalmaledorm) * 100;
                    let br5 = (data.partialoccupiedmaledorm / data.totalmaledorm) * 100;
                    let br3 = (data.availablefemaledorm / data.totalfemaledorm) * 100;
                    let br4 = (data.fulloccupiedfemaledorm / data.totalfemaledorm) * 100;
                    let br6 = (data.partialoccupiedfemaledorm / data.totalfemaledorm) * 100;
                    $('#br1').css({
                        'width': br1 + '%'
                    });
                    $('#br2').css({
                        'width': br2 + '%'
                    });
                    $('#br5').css({
                        'width': br5 + '%'
                    });
                    $('#available_male_dorm').html(data.availablemaledorm);
                    $('#full_occupied_male_dorm').html(data.fulloccupiedmaledorm);
                    $('#partial_occupied_male_dorm').html(data.partialoccupiedmaledorm);
                    $('#br3').css({
                        'width': br3 + '%'
                    });
                    $('#br4').css({
                        'width': br4 + '%'
                    });
                    $('#br6').css({
                        'width': br6 + '%'
                    });
                    $('#total_female_dorm').html(data.totalfemaledorm);
                    $('#available_female_dorm').html(data.availablefemaledorm);
                    $('#full_occupied_female_dorm').html(data.fulloccupiedfemaledorm);
                    $('#partial_occupied_female_dorm').html(data.partialoccupiedfemaledorm);
                }
            });
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('management')): ?>
            $.get('/dormstatistics', function(data) {
                if (data.success) {
                    $('#total_block').html(data.totalblock);
                    $('#total_student').html(data.totalstudent);
                    $('#total_male_block').html(data.totalmaleblock);
                    $('#total_female_block').html(data.totalfemaleblock);
                    $('#total_male_student').html(data.totalmalestudent);
                    $('#total_female_student').html(data.totalfemalestudent);

                    $('#total_male_dorm').html(data.totalmaledorm);
                    let br1 = (data.availablemaledorm / data.totalmaledorm) * 100;
                    let br2 = (data.fulloccupiedmaledorm / data.totalmaledorm) * 100;
                    let br5 = (data.partialoccupiedmaledorm / data.totalmaledorm) * 100;
                    let br3 = (data.availablefemaledorm / data.totalfemaledorm) * 100;
                    let br4 = (data.fulloccupiedfemaledorm / data.totalfemaledorm) * 100;
                    let br6 = (data.partialoccupiedfemaledorm / data.totalfemaledorm) * 100;
                    $('#br1').css({
                        'width': br1 + '%'
                    });
                    $('#br2').css({
                        'width': br2 + '%'
                    });
                    $('#br5').css({
                        'width': br5 + '%'
                    });
                    $('#available_male_dorm').html(data.availablemaledorm);
                    $('#full_occupied_male_dorm').html(data.fulloccupiedmaledorm);
                    $('#partial_occupied_male_dorm').html(data.partialoccupiedmaledorm);
                    $('#br3').css({
                        'width': br3 + '%'
                    });
                    $('#br4').css({
                        'width': br4 + '%'
                    });
                    $('#br6').css({
                        'width': br6 + '%'
                    });
                    $('#total_female_dorm').html(data.totalfemaledorm);
                    $('#available_female_dorm').html(data.availablefemaledorm);
                    $('#full_occupied_female_dorm').html(data.fulloccupiedfemaledorm);
                    $('#partial_occupied_female_dorm').html(data.partialoccupiedfemaledorm);
                }
            });
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('coordinator')): ?>
            $.get('/dormstatistics', function(data) {
                if (data.success) {
                    $('#total_block').html(data.totalblock);
                    $('#total_student').html(data.totalstudent);
                    $('#total_male_block').html(data.totalmaleblock);
                    $('#total_female_block').html(data.totalfemaleblock);
                    $('#total_male_student').html(data.totalmalestudent);
                    $('#total_female_student').html(data.totalfemalestudent);

                    $('#total_male_dorm').html(data.totalmaledorm);
                    let br1 = (data.availablemaledorm / data.totalmaledorm) * 100;
                    let br2 = (data.fulloccupiedmaledorm / data.totalmaledorm) * 100;
                    let br5 = (data.partialoccupiedmaledorm / data.totalmaledorm) * 100;
                    let br3 = (data.availablefemaledorm / data.totalfemaledorm) * 100;
                    let br4 = (data.fulloccupiedfemaledorm / data.totalfemaledorm) * 100;
                    let br6 = (data.partialoccupiedfemaledorm / data.totalfemaledorm) * 100;
                    $('#br1').css({
                        'width': br1 + '%'
                    });
                    $('#br2').css({
                        'width': br2 + '%'
                    });
                    $('#br5').css({
                        'width': br5 + '%'
                    });
                    $('#available_male_dorm').html(data.availablemaledorm);
                    $('#full_occupied_male_dorm').html(data.fulloccupiedmaledorm);
                    $('#partial_occupied_male_dorm').html(data.partialoccupiedmaledorm);
                    $('#br3').css({
                        'width': br3 + '%'
                    });
                    $('#br4').css({
                        'width': br4 + '%'
                    });
                    $('#br6').css({
                        'width': br6 + '%'
                    });
                    $('#total_female_dorm').html(data.totalfemaledorm);
                    $('#available_female_dorm').html(data.availablefemaledorm);
                    $('#full_occupied_female_dorm').html(data.fulloccupiedfemaledorm);
                    $('#partial_occupied_female_dorm').html(data.partialoccupiedfemaledorm);
                }
            });
        <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Werabe University Project\Werabe University Project\resources\views\dashboard1.blade.php ENDPATH**/ ?>