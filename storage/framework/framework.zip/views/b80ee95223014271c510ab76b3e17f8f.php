
<?php $__env->startSection('content'); ?>
    <div class="app-content content">
        <section id="responsive-datatable">
            <div class="content py-5 px-3 w-100 bg-gradient-primary col-md-12 ml-0 ">
                <h2 style="color: white;">Campus Store Report</h2>
            </div>
            <div id="success_message" style="padding: 13px 20px;"></div>
            <div class="row">
                <div class="col-12">
                    <!-- Your HTML content goes here -->
                    <div class="card">
                        <div class="card-header border-bottom">
                            <h3 class="card-title" id="report-title">Campus Store Report</h3>
                            <div class="col-md-4" id="daterangein">
                                <div class="float-end"
                                    style="padding: 5px 10px; text-align: center; background: #fff; width: 100%; curson: pointer; border: 1px solid #ccc; margin: 10px -20px;">
                                    <i class="fa fa-calendar"></i>&nbsp;
                                    <span></span><i class="fa fa-caret-down"></i>
                                </div>
                            </div>
                        </div>
                        <div class="card-datatable">
                            <div class="tab-content">
                                <div class="tab-pane" id="in" aria-labelledby="in-tab" role="tabpanel">
                                    <div style="width:98%; margin-left:1%;">
                                        <div class="table-responsive">

                                            <table id="laravel-datatable-in"
                                                class="display table-bordered table-striped table-hover dt-responsive mb-0 dataTable"
                                                style="overflow-x: scroll;" role="grid"
                                                aria-describedby="laravel-datatable-in">
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Product Name</th>
                                                        <th>Category</th>
                                                        <th>Type</th>
                                                        <th>Unit</th>
                                                        <th>Quantity</th>
                                                        <th>Total Price</th>
                                                        <th>Active</th>
                                                    </tr>
                                                </thead>
                                                <tbody></tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        var start_date = moment().subtract(1, 'M');
        var end_date = moment();
        var start = start_date.format('MMMM D, YYYY');
        var end = end_date.format('MMMM D, YYYY');
        $('#daterangein span').html(start_date.format('MMMM D, YYYY') + '-' + end_date.format('MMMM D, YYYY'));
        $('#daterangein').daterangepicker({
            startDate: start_date,
            endDate: end_date
        }, function(start_date, end_date) {
            $('#daterangein span').html(start_date.format('MMMM D, YYYY') + '-' + end_date.format('MMMM D, YYYY'));
            var cTable = $('#laravel-datatable-in').dataTable();
            cTable.fnDraw(false);
            start = start_date.format('MMMM D, YYYY');
            end = end_date.format('MMMM D, YYYY');
        });
        var errorcolor = "#ffcccc";
        $(function() {
            cardSection = $('#page-block');
        });

        /* BEGIN: Display In Report table using yajra datatable */
        $(document).ready(function() {
            var t = 0;
            var ctable = $('#laravel-datatable-in').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                searchHighlight: true,
                dom: 'lBfrtip', // Add l before B to include lengthMenu
                buttons: [{
                        extend: 'copy',
                        title: 'Your Title Here' // Title for the 'copy' button
                    },
                    {
                        extend: 'csv',
                        title: 'Your Title Here' // Title for the 'csv' button
                    },
                    {
                        extend: 'excel',
                        title: 'Your Title Here' // Title for the 'excel' button
                    },
                    {
                        extend: 'pdf',
                        title: 'Patient report' // Title for the 'pdf' button
                    },
                    {
                        extend: 'print',
                        title: '<p style="text-align: center; padding-bottom: 20px;">Campus Store Report From: ' +
                            start + ' To: ' + end + '</p>'
                    }
                ],
                lengthMenu: [
                    [10, 25, 50, 500, -1],
                    [10, 25, 50, 500, "All"]
                ],
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: "/getcampusproductreport",
                    type: 'delete',
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'product.product',
                        name: 'product.product',
                    },
                    {
                        data: 'product.category.name',
                        name: 'product.category.name',
                    },
                    {
                        data: 'product.type.name',
                        name: 'product.type.name',
                    },
                    {
                        data: 'product.unit.name',
                        name: 'product.unit.name'
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return '<p class="qu"></p>';
                        },
                        orderable: true,
                        searchable: true
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return '<p class="pr"></p>';
                        },
                        orderable: true,
                        searchable: true
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return ' <a class="btn btn-success" style="padding: 5px 5px; width: 100%;" onclick="productFn(' +
                                data.product.id +
                                ')" id="dtinfobtn" title="Open clinic information page" data-id = "' +
                                data.id +
                                '"><span> Detail </span></a>';
                        },
                        orderable: false,
                        searchable: false
                    }
                ],
                "fnRowCallback": function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
$.get('/qreport/'+aData.product.id, function(data){
    if(data.success)
    { $(nRow).find('.qu').html(data.quantity);
    $(nRow).find('.pr').html(data.total_price + '.00 Birr'); }
});
                }
            });
            ctable.on('draw', function() {
                var body = $(ctable.table().body());
                body.unhighlight();
                body.highlight(ctable.search());
            })
        });
    </script>
    <script>
        $('#in').show();
        $('#daterangein').show();
        $('#report-title').html('Patient Report');
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Werabe University Project\Werabe University Project\resources\views\report\reportCampus.blade.php ENDPATH**/ ?>