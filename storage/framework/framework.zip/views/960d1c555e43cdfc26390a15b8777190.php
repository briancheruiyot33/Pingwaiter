<?php $__env->startSection('content'); ?>
    <div class="app-content content" style="font-size: 10px;">
        <section id="responsive-datatable" style="font-size: 10px;">
            <div class="content py-2 px-2 w-100 bg-gradient-primary col-md-12 ml-0 " style="font-size: 10px;">
                <h2 style="color: white; text-align: center;">Campus Specific Report</h2>
            </div>
            <div id="success_message" style="padding: 13px 20px;"></div>
            <div class="row">
                <div class="col-12">
                    <!-- Your HTML content goes here -->
                    <div class="card" style="font-size: 11px;">
                        <div class="card-header border-bottom">
                            <h3 class="card-title" id="report-title">Specific Report</h3>
                            <div class="col-md-4" id="daterangein" style="display: none;">
                                <div class="float-end"
                                    style="padding: 5px 10px; text-align: center; background: #fff; width: 100%; curson: pointer; border: 1px solid #ccc; margin: 10px -20px;">
                                    <i class="fa fa-calendar"></i>&nbsp;
                                    <span></span><i class="fa fa-caret-down"></i>
                                </div>
                            </div>

                        </div>
                        <div class="card-datatable">
                            <div class="tab-content">
                                <div class="tab-pane" id="in" aria-labelledby="in-tab" role="tabpanel">
                                    <div style="width:98%; margin-left:1%;">
                                        <div class="table-responsive">

                                            <table id="laravel-datatable-in"
                                                class="display table-bordered table-striped table-hover dt-responsive mb-0 dataTable"
                                                style="overflow-x: scroll;" role="grid"
                                                aria-describedby="laravel-datatable-in">
                                                <thead>
                                                    <tr>
                                                        <th rowspan="2">#</th>
                                                        <th nowrap rowspan="2">Date Received</th>
                                                        <th nowrap rowspan="2">Received By</th>
                                                        <th nowrap rowspan="2">Received From</th>
                                                        <th nowrap rowspan="2">Item Name</th>
                                                        <th nowrap rowspan="2">Category</th>
                                                        <th nowrap rowspan="2">Unit</th>
                                                        <th nowrap colspan="3" style="text-align: center;">Quantity</th>
                                                        <th nowrap rowspan="2">Batch No</th>
                                                        <th nowrap rowspan="2">Expired Date</th>
                                                    </tr>
                                                    <tr>
                                                        <th nowrap>Received</th>
                                                        <th nowrap>Issued</th>
                                                        <th nowrap>Balance</th>
                                                    </tr>
                                                </thead>
                                                <tbody></tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        var start_date = moment().subtract(1, 'M');
        var end_date = moment();
        var start = start_date.format('MMMM D, YYYY');
        var end = end_date.format('MMMM D, YYYY');
        $('#daterangein span').html(start_date.format('MMMM D, YYYY') + '-' + end_date.format('MMMM D, YYYY'));
        $('#daterangein').daterangepicker({
            startDate: start_date,
            endDate: end_date
        }, function(start_date, end_date) {
            $('#daterangein span').html(start_date.format('MMMM D, YYYY') + '-' + end_date.format('MMMM D, YYYY'));
            var cTable = $('#laravel-datatable-in').dataTable();
            cTable.fnDraw(false);
            start = start_date.format('MMMM D, YYYY');
            end = end_date.format('MMMM D, YYYY');
        });
        var errorcolor = "#ffcccc";
        $(function() {
            cardSection = $('#page-block');
        });

        /* BEGIN: Display In Report table using yajra datatable */
        $(document).ready(function() {
            var t = 0;
            var ctable = $('#laravel-datatable-in').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                searchHighlight: true,
                dom: 'lBfrtip', // Add l before B to include lengthMenu
                buttons: [{
                        extend: 'copy',
                        title: 'Campus Specific Report', // Title for the 'copy' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6,
                                7, 8, 9, 10, 11
                            ] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'csv',
                        title: 'Campus Specific Report', // Title for the 'csv' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6,
                                7, 8, 9, 10, 11
                            ] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'excel',
                        title: 'Campus Specific Report', // Title for the 'excel' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6,
                                7, 8, 9, 10, 11
                            ] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'pdf',
                        title: 'Campus Specific Report',
                        orientation: 'landscape', // Set orientation: 'landscape' or 'portrait'
                        pageSize: 'A4', // Set page size
                        customize: function(doc) {
                            // Customize header, footer, and body style
                            doc.styles.tableHeader = {
                                fillColor: '#4CAF50',
                                color: 'white',
                                alignment: 'center'
                            };
                            doc.styles.title = {
                                fontSize: 14,
                                alignment: 'center'
                            };
                            doc.defaultStyle.fontSize = 10; // Change default font size
                            doc.content[1].table.widths = '*'.repeat(doc.content[1].table.body[0]
                                .length).split(''); // Automatically adjust column widths
                            doc.pageMargins = [10, 10, 10, 10]; // Adjust page margins
                            doc.pageSize = 'A4'; // Ensure the page size is A4
                            doc.content[1].layout = {
                                hLineWidth: function(i, node) {
                                    return (i === 0 || i === node.table.body.length) ? 2 :
                                        1;
                                },
                                vLineWidth: function(i, node) {
                                    return (i === 0 || i === node.table.widths.length) ? 2 :
                                        1;
                                },
                                hLineColor: function(i, node) {
                                    return (i === 0 || i === node.table.body.length) ?
                                        'black' : 'gray';
                                },
                                vLineColor: function(i, node) {
                                    return (i === 0 || i === node.table.widths.length) ?
                                        'black' : 'gray';
                                },
                                paddingLeft: function(i, node) {
                                    return 4;
                                },
                                paddingRight: function(i, node) {
                                    return 4;
                                },
                                paddingTop: function(i, node) {
                                    return 2;
                                },
                                paddingBottom: function(i, node) {
                                    return 2;
                                },
                            };
                        },
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6,
                                7, 8, 9, 10, 11
                            ] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'print',
                        title: 'Campus Specific Report',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6,
                                7, 8, 9, 10, 11
                            ] // Indexes of the columns you want to include
                        }
                    }
                ],
                lengthMenu: [
                    [10, 25, 50, 500, -1],
                    [10, 25, 50, 500, "All"]
                ],
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: "/campusinreport",
                    data: function(data) {
                        data.from_date = $('#daterangein').data('daterangepicker').startDate.format(
                            'YYYY-MM-DD');
                        data.to_date = $('#daterangein').data('daterangepicker').endDate.format(
                            'YYYY-MM-DD');
                    },
                    type: 'delete',
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'campusstore.date_created',
                        name: 'campusstore.date_created'
                    },
                    {
                        data: 'campusstore.user.name',
                        name: 'campusstore.user.name'
                    },
                    {
                        data: 'campusstore.supplier',
                        name: 'campusstore.supplier'
                    },
                    {
                        data: 'product.item_name',
                        name: 'product.item_name'
                    },
                    {
                        data: 'product.category.name',
                        name: 'product.category.name'
                    },
                    {
                        data: 'unit',
                        name: 'unit'
                    },
                    {
                        data: 'total_quantity',
                        name: 'total_quantity'
                    },
                    {
                        data: 'withdraw_quantity',
                        name: 'withdraw_quantity'
                    },
                    {
                        data: 'balance_quantity',
                        name: 'balance_quantity'
                    },
                    {
                        data: 'seriel_number',
                        name: 'seriel_number'
                    },
                    {
                        data: 'expired_date',
                        name: 'expired_date'
                    },
                ],
            });
            ctable.on('draw', function() {
                var body = $(ctable.table().body());
                body.unhighlight();
                body.highlight(ctable.search());
            })
        });
    </script>
    <script>
        $('#in').show();
        $('#daterangein').show();
        $('#report-title').html('Specific Report');
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Werabe University Project\Werabe University Project\resources\views\report\campus-report.blade.php ENDPATH**/ ?>