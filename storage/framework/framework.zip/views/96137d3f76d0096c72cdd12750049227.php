<?php $__env->startSection('title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="app-content content">
        <section id="responsive-datatable">
            <div class="row">
                <div class="col-12">
                    <!-- Your HTML content goes here -->
                    <div class="card">
                        <div class="card-header border-bottom">
                            <h3 class="card-title">Patients</h3>


                        </div>
                        <div class="card-datatable">
                            <div style="width:98%; margin-left:1%;">
                                <div class="table-responsive">

                                    <table id="laravel-datatable-patient"
                                        class="display table-bordered table-striped table-hover dt-responsive mb-0 dataTable no-footer"
                                        style="width: 100%;" role="grid" aria-describedby="laravel-datatable-user">

                                        <thead>
                                            <tr role="row">
                                                <th scope="col" width="1%">#</th>
                                                <th nowrap="1">Full Name</th>
                                                <th nowrap="1">Student Id</th>
                                                <th nowrap="1">Sex</th>
                                                <th nowrap="1">Age</th>
                                                <th nowrap="1">Doctor</th>
                                                <th nowrap="1">State</th>
                                                <th nowrap="1">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody></tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- BEGIN: Category Add modal  -->
        <div class="modal fade text-left" id="inlineForm" data-keyboard="false" data-backdrop="static" tabindex="-1"
            role="dialog" aria-labelledby="patientlbl" aria-hidden="true" style="overflow-y: scroll;">
            <div class="modal-dialog modal-xl" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="patientlbl">Add patient</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                            onclick="closeModal()">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form id="Register">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="edit_id" id="edit_id">
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-md-4">
                                    <label strong style="font-size: 16px;">Full Name</label><label
                                        style="color: red; font-size:16px;">*</label>
                                    <div class="form-group">
                                        <input type="text" placeholder="Write Patient Name here" class="form-control"
                                            name="full_name" id='full_name' autofocus onkeyup="removeNameValidation()" />
                                        <span class="text-danger">
                                            <strong id="full_name-error"></strong>
                                        </span>
                                    </div>

                                </div>
                                <div class="col-md-4">
                                    <label strong style="font-size: 16px;">Student ID</label><label
                                        style="color: red; font-size:16px;">*</label>
                                    <div class="form-group">
                                        <input type="text" placeholder="Write Student Id here" class="form-control"
                                            name="student_id" id='student_id' autofocus onkeyup="removeNameValidation()" />
                                        <span class="text-danger">
                                            <strong id="student_id-error"></strong>
                                        </span>
                                    </div>

                                </div>
                                <div class="col-md-4">
                                    <label strong style="font-size: 16px;">Address</label><label
                                        style="color: red; font-size:16px;"></label>
                                    <div class="form-group">
                                        <input type="text" placeholder="Write Category Name here" class="form-control"
                                            name="address" id='address' autofocus onkeyup="removeaddressValidation()" />
                                        <span class="text-danger">
                                            <strong id="address-error"></strong>
                                        </span>
                                    </div>

                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <label strong style="font-size: 16px;">Age</label><label
                                        style="color: red; font-size:16px;"></label>
                                    <div class="form-group">
                                        <input type="number" placeholder="Write Age here" class="form-control"
                                            name="age" id='age' autofocus onkeyup="removeageValidation()" />
                                        <span class="text-danger">
                                            <strong id="age-error"></strong>
                                        </span>
                                    </div>

                                </div>
                                <div class="col-md-4">
                                    <label strong style="font-size: 16px;">Phone</label><label
                                        style="color: red; font-size:16px;"></label>
                                    <div class="form-group">
                                        <input type="text" placeholder="Write Phone here" class="form-control"
                                            name="phone" id='phone' autofocus onkeyup="removeNameValidation()" />
                                        <span class="text-danger">
                                            <strong id="phone-error"></strong>
                                        </span>
                                    </div>

                                </div>
                                <div class="col-md-4">
                                    <label strong style="font-size: 16px;">Department</label><label
                                        style="color: red; font-size:16px;"></label>
                                    <div class="form-group">
                                        <input type="text" placeholder="Write Department here" class="form-control"
                                            name="department" id='department' autofocus
                                            onkeyup="removedepartmentValidation()" />
                                        <span class="text-danger">
                                            <strong id="department-error"></strong>
                                        </span>
                                    </div>

                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <label strong style="font-size: 16px;">Sex</label><label
                                        style="color: red; font-size:16px;"></label>

                                    <div class="form-group">
                                        <div>
                                            <select class="custom-select browser-default select2" name="sex"
                                                id="sex" onchange="removeSexValidation()">
                                                <option value=""></option>
                                                <option value="Male">Male</option>
                                                <option value="Female">Female</option>
                                            </select>
                                            <span class="text-danger">
                                                <strong id="sex-error"></strong>
                                            </span>
                                        </div>
                                    </div>

                                </div>
                                <div class="col-md-4">
                                    <label strong style="font-size: 16px;">Entry Year</label><label
                                        style="color: red; font-size:16px;">*</label>
                                    <div class="form-group">
                                        <div>
                                            <select class="custom-select browser-default select2" name="entry_year"
                                                id="entry_year" onchange="removeStatusValidation()">
                                                <option value=""></option>
                                                <option value="2013">2013</option>
                                                <option value="2014">2014</option>
                                                <option value="2015">2015</option>
                                                <option value="2016">2016</option>
                                                <option value="2017">2017</option>
                                                <option value="2018">2018</option>
                                                <option value="2019">2019</option>
                                                <option value="2020">2020</option>
                                            </select>
                                            <span class="text-danger">
                                                <strong id="entry_year-error"></strong>
                                            </span>
                                        </div>
                                    </div>

                                </div>
                                <div class="col-md-4">
                                    <label strong style="font-size: 16px;">Status</label><label
                                        style="color: red; font-size:16px;">*</label>
                                    <div class="form-group">
                                        <div>
                                            <select class="custom-select browser-default select2" name="status"
                                                id="status" onchange="removeStatusValidation()">
                                                <option value="Active">Active</option>
                                                <option value="Inactive">Inactive</option>
                                            </select>
                                            <span class="text-danger">
                                                <strong id="status-error"></strong>
                                            </span>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button id="savenewbutton" type="button" class="btn btn-info">Save &
                                New</button>
                            <button id="savebutton" type="button" class="btn btn-info">Save & Close</button>
                            <button id="closebutton" type="button" class="btn btn-danger" onclick="closeModal()"
                                data-dismiss="modal">Close</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <div class="modal fade" id="adviceModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="example">Operation done:</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                        onclick="closeModalWithClearValidation()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <div>
                            <div class="row">
                                <label for="">Remark</label>
                                <textarea placeholder="Write Remark here..." id="rm" class="form-control" required></textarea>
                            </div>
                        </div>
                    </div>
                    <input type="hidden" id="remark_id">
                </div>
                <div class="modal-footer">
                    <button class="btn btn-primary" id="remark-button">Done</button>
                    <button id="closebutton" type="button" class="btn btn-default"
                        onclick="closeModalWithClearValidation()" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    
    <div class="modal fade" id="sendModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Send Patient To:</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                        onclick="closeModalWithClearValidation()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <div>
                            <div class="row">
                                &nbsp;&nbsp;<a class="btn btn-primary" id="pharmacy">Pharmacy</a>&nbsp;
                                <a class="btn btn-warning" id="labratory">Labratory</a>&nbsp;
                                <a class="btn btn-success" id="reference">Reference</a>&nbsp;
                                <a class="btn btn-danger" id="close">No Where</a>
                            </div>
                        </div>
                    </div>
                    <input type="hidden" id="send_id">
                </div>
                <div class="modal-footer">
                    <button id="closebutton" type="button" class="btn btn-default"
                        onclick="closeModalWithClearValidation()" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    
    <div class="modal fade text-left" id="historyModal" data-keyboard="false" data-backdrop="static" tabindex="-1"
        role="dialog" aria-labelledby="lbl" aria-hidden="true" style="overflow-y: scroll;">
        <div class="modal-dialog modal-xl" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="categorylbl">History Detail</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                        onclick="closeModal()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div style="justify-content: space-between; display: flex; margin-bottom: 10px;" class="w-100">
                        <h1 style="color: white;">History</h1>
                        <button type="button" class="btn btn-info btn-sm history">Add History</button>
                    </div>
                    <div style="width:98%; margin-left:1%;">
                        <div class="table-responsive">

                            <table id="laravel-datatable-history"
                                class="display table-bordered table-striped table-hover dt-responsive mb-0 dataTable no-footer"
                                style="width: 100%;" role="grid" aria-describedby="laravel-datatable-history">

                                <thead>
                                    <tr role="row">
                                        <th scope="col" width="1%">#</th>
                                        <th nowrap="1">Student Id</th>
                                        <th nowrap="1">Description</th>
                                    </tr>
                                </thead>
                                <tbody></tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button id="closebutton" type="button" class="btn btn-danger" onclick="closeModal()"
                        data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="addHistory" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addhistory">add history:</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                        onclick="closeHistorys()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-body">
                    <form id="form-history">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <div>
                                <div class="row">
                                    <textarea name="description" id="description" class="form-control" placeholder="write description here..."
                                        onkeyup="valdiateHistory()"></textarea>
                                    <span style="color: red" id="description-error"></span>
                                </div>
                            </div>
                        </div>
                        <input type="hidden" id="history_id" name="history_id">
                </div>
                </form>
                <div class="modal-footer">
                    <button id="savehistory" type="button"
                        class="btn btn-info waves-effect waves-float waves-light">Save</button>
                    <button id="closebutton" type="button" class="btn btn-default" onclick="closeHistory()"
                        data-dismiss="modal">Close</button>
                </div>

            </div>
        </div>
    </div>

    
    <div class="modal fade text-left" id="pharmacyModal" data-keyboard="false" data-backdrop="static" tabindex="-1"
        role="dialog" aria-labelledby="lbl" aria-hidden="true" style="overflow-y: scroll;">
        <div class="modal-dialog modal-xl" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="pharmacylbl">Werabe University Student Clinic PRESCRIPTION PAPER</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                        onclick="closeModal()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="form-pharmacy">
                        <?php echo e(csrf_field()); ?>

                        <div class="row">
                            <input type="hidden" name="patient_id" id="patient_id">
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>Patient's Full Name:</label>
                                    <input type="text" id="fname" value="" class="form-control" readonly>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>USER ID:</label>
                                    <input type="text" id="user_id" value="" readonly class="form-control">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>Gender:</label>
                                    <input type="text" id="gender" readonly class="form-control">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>Age:</label>
                                    <input type="text" id="age_number" class="form-control" readonly>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-xl-12 col-lg-12">
                                <div class="table-responsive">
                                    <table id="dynamicTable" class="mb-0 rtable  dt-responsive" style="width: 100%">
                                        <thead>
                                            <tr>
                                                <th style="width: 3%; text-align: center;">#</th>

                                                <th style="width: 20%; text-align: center;">
                                                    Drug Name<b style="color: red;"> *</b>
                                                </th>
                                                <th style="width: 80%; text-align: center;">
                                                    Strength, Dosage Form, Dose, Frequency, Duration, Quantity, How to use &
                                                    other information
                                                    <b style="color: red;"> *</b>
                                                </th>
                                                <th style="width: 3%"></th>
                                            </tr>
                                        </thead>
                                        <tbody></tbody>
                                    </table>
                                    <span class="text-danger">
                                        <strong id="table-error"></strong>
                                    </span>
                                    <table style="width: 100%">
                                        <tbody>
                                            <tr>
                                                <td colspan="2">
                                                    <button type="button" name="adds" id="adds"
                                                        class="btn btn-success btn-sm waves-effect waves-float waves-light"><i
                                                            class="fa fa-plus" arial-hidden="true"></i> Add
                                                        New </button>
                                                </td>
                                                <td></td>
                                            <tr class="totalrownumber">
                                                <td style="text-align: right;">
                                                    <label strong style="font-size: 16px;">No. of Items: </label>
                                                </td>
                                                <td style="text-align: right; width: 2%;">
                                                    <label id="numberofItemsLbl" strong
                                                        style="font-size: 16px; font-weight: bold;">0</label>
                                                </td>
                                            </tr>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button id="savepharmacy" type="button"
                        class="btn btn-info waves-effect waves-float waves-light">Save</button>
                    <button id="closebutton" type="button" class="btn btn-danger" onclick="closeModal()"
                        data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    
    <div class="modal fade text-left" id="labratoryModal" data-keyboard="false" data-backdrop="static" tabindex="-1"
        role="dialog" aria-labelledby="lbl" aria-hidden="true" style="overflow-y: scroll;">
        <div class="modal-dialog modal-xl" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="pharmacylbl">Werabe University Student Clinic
                        LABORATORY REQUEST</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                        onclick="closeModal()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>FULL NAME:</label>
                                <input type="text" name="fname" id="fullname" class="form-control" readonly>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>AGE:</label>
                                <input type="number" name="age" id="new_age" readonly class="form-control">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Gender:</label>
                                <input type="text" name="gender" id="new_sex" readonly class="form-control">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>USER ID:</label>
                                <input type="text" name="student_id" id="stud_id" class="form-control" readonly>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Name of Prescriber's </label>
                                <input type="text" name="pname" value="<?php echo e(auth()->user()->name); ?>" readonly
                                    class="form-control">
                            </div>
                        </div>
                    </div>
                    <form id="labratory-form">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="id">
                        <input type="hidden" name="lab_id" id="lab_id">
                        <div class="t1">
                            <table border="1px" class="ttt w-100">
                                <tr>
                                    <th>STOOL</th>
                                    <th>UNINALYSIS</th>
                                    <th colspan="2">HEAMATOLOGY</th>
                                    <th colspan="2">SEROLOGY</th>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="c1">APP <input type="checkbox" name="app" id="app"
                                                class="c2">
                                        </div>
                                    </td>
                                    <td>
                                        <div class="c1">color<input type="checkbox" id="color" name="color"
                                                class="c2">
                                        </div>
                                    </td>
                                    <td colspan="2">
                                        <div class="c1">Hg <p><input type="text" name="mg" id="hg"
                                                    class="form-control" readonly>Mg/di</p>
                                        </div>
                                    </td>
                                    <td rowspan="3" align="center">Widal <br>& <br>Weil Flex</td>
                                    <td>
                                        <div class="c1">'O'<input type="checkbox" name="o" id="o"
                                                class="c2">
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="c1">Cons<input type="checkbox" name="cons" id="cons"
                                                class="c2">
                                        </div>
                                    </td>
                                    <td>
                                        <div class="c1">Leucocyte<input type="checkbox" name="leurcocyte"
                                                id="leurcocyte" class="c2"></div>
                                    </td>
                                    <td colspan="2">
                                        <div class="c1">Hct<p><input type="number" name="hct" id="hct"
                                                    class="form-control" readonly>%</p>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="c1">'H'<input type="checkbox" name="h" id="h"
                                                class="c2">
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="c1">OIP<input type="checkbox" name="oip" id="oip"
                                                class="c2">
                                        </div>
                                    </td>
                                    <td>
                                        <div class="c1">nitrite<input type="checkbox" name="nitrate" id="nitrate"
                                                class="c2">
                                        </div>
                                    </td>
                                    <td colspan="2">
                                        <div class="c1">WBC<p><input type="text" name="wbc1" id="wbc1"
                                                    class="form-control" readonly>Mm3</p>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="c1">'Ox'<input type="checkbox" name="ox" id="ox"
                                                class="c2">
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td rowspan="10"></td>
                                    <td>
                                        <div class="c1">Urobilinogen<input type="checkbox" name="urobilinogen"
                                                id="urobilinogen" class="c2"></div>
                                    </td>
                                    <td rowspan="5" class="bottom" align="center">Diff Count</td>
                                    <td>
                                        <div class="c1">Netrophils<p><input type="number" name="netrophils"
                                                    id="netrophils" class="form-control" readonly>%
                                            </p>
                                        </div>
                                    </td>
                                    <td colspan="2">
                                        <div class="c1">RPR<input type="checkbox" name="rbr" id="rbr"
                                                class="c2">
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="c1">Protein<input type="checkbox" name="protein" id="protein"
                                                class="c2">
                                        </div>
                                    </td>
                                    <td>
                                        <div class="c1">Basophils<p><input type="number" name="basophils"
                                                    id="basophils" class="form-control" readonly>%
                                            </p>
                                        </div>
                                    </td>
                                    <td colspan="2">
                                        <div class="c1">Rheumatoid factor<input type="checkbox" name="theumatoid"
                                                id="theumatoid" class="c2"></div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="c1">PH<input type="checkbox" name="ph" id="ph"
                                                class="c2">
                                        </div>
                                    </td>
                                    <td>
                                        <div class="c1">Eosinophils<p><input type="number" name="eosinophils"
                                                    id="eosinophils" class="form-control" readonly>%</p>
                                        </div>
                                    </td>
                                    <td colspan="2">
                                        <div class="c1">HCG<input type="checkbox" name="hcg" id="hcg"
                                                class="c2">
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="c1">Blood<input type="checkbox" name="blood" id="blood"
                                                class="c2">
                                        </div>
                                    </td>
                                    <td>
                                        <div class="c1">Monocytes<p><input type="number" name="monocytes"
                                                    id="monocytes" class="form-control" readonly>%</p>
                                        </div>
                                    </td>
                                    <td colspan="2">
                                        <div class="c1">FBC/RBS<input type="checkbox" name="fbc" id="fbc"
                                                class="c2">
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="c1">Spec. gravity<input type="checkbox" name="spec"
                                                id="spec" class="c2"></div>
                                    </td>
                                    <td>
                                        <div class="c1">Lymphocyted<p><input type="number" name="lymphocyted"
                                                    id="lymphocyted" class="form-control" readonly>%</p>
                                        </div>
                                    </td>
                                    <td colspan="2">
                                        <div class="c1">Bactreglology<input type="checkbox" name="bactreglology"
                                                id="bactreglology" class="c2"></div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="c1">Ketones<input type="checkbox" name="ketones" id="ketones"
                                                class="c2">
                                        </div>
                                    </td>
                                    <td colspan="2">
                                        <div class="c1">ESR<p><input type="text" name="esr"
                                                    class="form-control" id="esr" readonly>mm/hr</p>
                                        </div>
                                    </td>
                                    <td colspan="2">
                                        <div class="c1">Gram stan<input type="checkbox" name="gram_stan"
                                                id="gram_stan" class="c2"></div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="c1">Bilirubin<input type="checkbox" name="bilirubin"
                                                id="bilirubin" class="c2"></div>
                                    </td>
                                    <td colspan="2">
                                        <div class="c1">Blood Film<input type="checkbox" name="blood_film"
                                                id="blood_film" class="c2"></div>
                                    </td>
                                    <td colspan="2">
                                        <div class="c1">A+B<input type="checkbox" name="ab" id="ab"
                                                class="c2">
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="c1">Glucose<input type="checkbox" name="glucose" id="glucose"
                                                class="c2">
                                        </div>
                                    </td>
                                    <td colspan="2">
                                        <div class="c1">IMUNOHEAMATOLOGY<input type="checkbox" name="imunohematology"
                                                id="imunohematology" class="c2"></div>
                                    </td>
                                    <td colspan="2">
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="c1">RBC/HPF<input type="checkbox" name="rbc" id="rbc"
                                                class="c2">
                                        </div>
                                    </td>
                                    <td colspan="2">
                                        <div class="c1">BLOOD group & RH<input type="checkbox" name="blood_group"
                                                id="blood_group" class="c2"></div>
                                    </td>
                                    <td colspan="2"></td>
                                </tr>
                                <tr>
                                    <td>
                                        <div class="c1">WBC/HPF<input type="checkbox" name="wbc" id="wbc"
                                                class="c2"></div>
                                    </td>
                                    <td colspan="2"></td>
                                    <td colspan="2"></td>
                                </tr>
                                <tr>
                                    <td colspan="6">
                                        <div class="c1">
                                            <textarea class="form-control" name="other" id="other" placeholder="Write Other description here..."></textarea>
                                            <textarea class="form-control" name="other_lab" id="other_lab" placeholder="Lab result" readonly></textarea>
                                        </div>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button id="savelabratory" type="button"
                        class="btn btn-info waves-effect waves-float waves-light">Save</button>
                    <button id="closebutton" type="button" class="btn btn-danger" onclick="closeModal()"
                        data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    
    <div class="modal fade text-left" id="referenceModal" data-keyboard="false" data-backdrop="static" tabindex="-1"
        role="dialog" aria-labelledby="lbl" aria-hidden="true" style="overflow-y: scroll;">
        <div class="modal-dialog modal-xl" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="referencelbl">Reference</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                        onclick="closeModal()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="print_id">
                    <div class="ref_container" id="div_print">
                        <div class="top">
                            <div class="date" style="display: flex;margin-left: 75%;">
                                <p>ቀን </p>
                                <p style=" margin-left: 10px;"> <span
                                        style="border-bottom: 1px dashed black;"><?php echo date('d-m-y'); ?>GC</span></p>
                            </div>
                            <h2><span class="title">ለወራቤ ኮምፕሬንሄስቭ ስፔስሻላዝድ ሆስፒታል</span></h2>
                            <h2><span style="border-bottom:  1px solid black;">ወራቤ</span></h2>
                            <h3 style="margin-left: 20%;">ጉዳይ:- <span style="border-bottom: 1px solid black;">የዱቤ ህክምና
                                    ይመለከታል</span></h3>
                            <p>በወራቤ ዩንቨርሲቲ በ <span style="border-bottom: 1px dashed black;">ወራቤ</span> ኮሌጅ <span
                                    style="border-bottom: 1px dashed black;" class="dep"></span>
                                ዲፓርትመንት
                                በአይድ
                                ቁጥር <span style="border-bottom: 1px dashed black;" class="stud_id"></span> የሚማር /የምትማር
                                ተማሪ <span style="border-bottom: 1px dashed black;" class="stud_name"></span> ከሆስፒታላችሁ ጋር በ
                                <?php echo date('d-m-y'); ?>GC
                                በገባነው ውል መሰረት የህክምና አገልግሎት እንዲያገኝ /እንድታገኝ መላካችን እየገልፅን ለተለመደው ትብብራቹሁ ምስጋናችን በመስቀደም ነው።</p>
                            <p style="margin-top: 70px; margin-bottom: 70px;">የላከው በላሙያ
                                ስም..........................................ፍርማ.........................</p>
                        </div>
                        <div class="bottom">
                            <div class="date" style="display: flex;margin-left: 75%;">
                                <p>ቀን </p>
                                <p style=" margin-left: 10px;"><span
                                        style="border-bottom: 1px dashed black;"><?php echo date('d-m-y'); ?>GC</span>
                                </p>
                            </div>
                            <h2><span class="title">ለወራቤ ኮምፕሬንሄቭ ስፔስሻላዝድ ሆስፒታል</span></h2>
                            <h2><span style="border-bottom:  1px solid black;">ወራቤ</span></h2>
                            <h3 style="margin-left: 20%;">ጉዳይ:- <span style="border-bottom: 1px solid black;">የዱቤ ህክምና
                                    ይመለከታል</span></h3>
                            <p>በወራቤ ዩንቨርሲቲ በ <span style="border-bottom: 1px dashed black;">ወራቤ</span> ኮሌጅ <span
                                    style="border-bottom: 1px dashed black;" class="dep"></span> ዲፓርትመንት በአይድ ቁጥር <span
                                    style="border-bottom: 1px dashed black;" class="stud_id"></span> የሚማር /የምትማር ተማሪ
                                <span style="border-bottom: 1px dashed black;" class="stud_name"></span> ከሆስፒታላችሁ ጋር በ
                                <?php echo date('d-m-y'); ?>GC በገባነው ውል መሰረት የህክምና አገልግሎት እንዲያገኝ /እንድታገኝ መላካችን እየገልፅን ለተለመደው ትብብራቹሁ
                                ምስጋናችን በመስቀደም
                                ነው።
                            </p>
                            <p style="margin-top: 70px; margin-bottom: 70px;">የላከው በላሙያ
                                ስም..........................................ፍርማ.........................</p>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-info waves-effect waves-float waves-light"
                        onclick="print()">Print</button>
                    <button type="button" class="btn btn-info waves-effect waves-float waves-light"
                        id="finish">Finshed</button>
                    <button id="closebutton" type="button" class="btn btn-danger" onclick="closeModal()"
                        data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <!-- BEGIN: Category Add modal  -->
    <div class="modal fade text-left" id="appointmentModal" data-keyboard="false" data-backdrop="static" tabindex="-1"
        role="dialog" aria-labelledby="patientlbl" aria-hidden="true" style="overflow-y: scroll;">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="appointbl">Add Appointment</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                        onclick="closeAppointmentModal()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="appointment-form">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="st_id" id="st_id">
                    <div class="modal-body">
                        <label strong style="font-size: 16px;">Start Date</label><label
                            style="color: red; font-size:16px;">*</label>
                        <div class="form-group">
                            <input type="date" class="form-control" name="start_date" id='start_date' autofocus
                                onchange="removeStartDate()" />
                            <span class="text-danger">
                                <strong id="start-error"></strong>
                            </span>
                        </div>
                        <label strong style="font-size: 16px;">End Date</label><label
                            style="color: red; font-size:16px;">*</label>
                        <div class="form-group">
                            <input type="date" class="form-control" name="end_date" id='end_date' autofocus
                                onchange="removeEndDate()" />
                            <span class="text-danger">
                                <strong id="end-error"></strong>
                            </span>
                        </div>
                        <label strong style="font-size: 16px;">Description</label><label
                            style="color: red; font-size:16px;">*</label>
                        <div class="form-group">
                            <textarea name="description" id="desc" placeholder="write description here..." class="form-control"
                                onkeyup="removeDesc()"></textarea>
                            <span class="text-danger">
                                <strong id="desc-error"></strong>
                            </span>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button id="appointmentbutton" type="button" class="btn btn-info">Set</button>
                        <button id="closebutton" type="button" class="btn btn-danger" onclick="closeModal()"
                            data-dismiss="modal">Close</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        var current_date = moment();
        var current_date = current_date.format('MMMM D, YYYY');
        $('#date').val(current_date);
        var errorcolor = "#ffcccc";
        $(function() {
            cardSection = $('#page-block');
        });
        $('.history').click(function() {
            $('#addHistory').modal('show');
        });
        /* BEGIN: Display zone table using yajra datatable */
        $(document).ready(function() {
            var ctable = $('#laravel-datatable-patient').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                searchHighlight: true,
                dom: 'lBfrtip', // Add l before B to include lengthMenu
                buttons: [{
                        extend: 'copy',
                        title: 'Patient under doctor', // Title for the 'copy' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'csv',
                        title: 'Patient under doctor', // Title for the 'csv' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'excel',
                        title: 'Patient under doctor', // Title for the 'excel' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'pdf',
                        title: 'Patient under doctor',
                        orientation: 'landscape', // Set orientation: 'landscape' or 'portrait'
                        pageSize: 'A4', // Set page size
                        customize: function(doc) {
                            // Customize header, footer, and body style
                            doc.styles.tableHeader = {
                                fillColor: '#4CAF50',
                                color: 'white',
                                alignment: 'center'
                            };
                            doc.styles.title = {
                                fontSize: 14,
                                alignment: 'center'
                            };
                            doc.defaultStyle.fontSize = 10; // Change default font size
                            doc.content[1].table.widths = '*'.repeat(doc.content[1].table.body[0]
                                .length).split(''); // Automatically adjust column widths
                            doc.pageMargins = [10, 10, 10, 10]; // Adjust page margins
                            doc.pageSize = 'A4'; // Ensure the page size is A4
                            doc.content[1].layout = {
                                hLineWidth: function(i, node) {
                                    return (i === 0 || i === node.table.body.length) ? 2 :
                                        1;
                                },
                                vLineWidth: function(i, node) {
                                    return (i === 0 || i === node.table.widths.length) ? 2 :
                                        1;
                                },
                                hLineColor: function(i, node) {
                                    return (i === 0 || i === node.table.body.length) ?
                                        'black' : 'gray';
                                },
                                vLineColor: function(i, node) {
                                    return (i === 0 || i === node.table.widths.length) ?
                                        'black' : 'gray';
                                },
                                paddingLeft: function(i, node) {
                                    return 4;
                                },
                                paddingRight: function(i, node) {
                                    return 4;
                                },
                                paddingTop: function(i, node) {
                                    return 2;
                                },
                                paddingBottom: function(i, node) {
                                    return 2;
                                },
                            };
                        },
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'print',
                        title: 'Patient under doctor',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6] // Indexes of the columns you want to include
                        }
                    }
                ],
                lengthMenu: [
                    [10, 25, 50, 500, -1],
                    [10, 25, 50, 500, "All"]
                ],
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: '/getpatientsopd',
                    type: 'DELETE',
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'student.full_name',
                        name: 'student.full_name'
                    },
                    {
                        data: 'student.student_id',
                        name: 'student.student_id'
                    },
                    {
                        data: 'student.sex',
                        name: 'student.sex'
                    },
                    {
                        data: 'student.age',
                        name: 'student.age'
                    },
                    {
                        data: 'user.name',
                        name: 'user.name'
                    },
                    {
                        data: 'state',
                        name: 'state'
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return '<div class="btn-group dropleft"><button type="button" class="btn btn-sm dropdown-toffle hide-arrow" data-toggle="dropdown" arial-haspopup="true" arial-expanded="false"><i class="fa fa-ellipsis-v"></i></button><div class = "dropdown-menu" > ' +
                                '<a class = "dropdown-item patientView" onclick = "viewHistoryFn(' +
                                data.student_id +
                                ')" id = "dtViewbtn" title = "View History" data - id = "' +
                                data.id +
                                '"><i class="fa fa-eye"></i>&nbsp;<span> View History</span></a>' +
                                '<a class = "dropdown-item pharmacy" onclick = "sendPharmacy(' +
                                data
                                .id +
                                ')" title = "Send To Pharmacy" data-id = "' +
                                data.id +
                                '"><i class="fa fa-paper-plane"></i>&nbsp;<span>Send To Pharmacy </span></a>' +
                                '<a class = "dropdown-item lab" onclick = "sendLabratory(' +
                                data
                                .id +
                                ')" title = "Send To Labratory" data-id = "' +
                                data.id +
                                '"><i class="fa fa-paper-plane"></i>&nbsp;<span>Send To Labratory </span></a>' +
                                '<a class = "dropdown-item labresult" style="display: none;" onclick = "labResult(' +
                                data
                                .id +
                                ')" title = "view detail" data-id = "' +
                                data.id +
                                '"><i class="fa fa-paper-plane"></i>&nbsp;<span>Lab Result</span></a>' +
                                '<a class = "dropdown-item reference" onclick = "reference(' +
                                data
                                .id +
                                ')" title = "Reference" data-id = "' +
                                data.id +
                                '"><i class="fa fa-paper-plane"></i>&nbsp;<span>Reference </span></a>' +
                                '<a class = "dropdown-item reference" onclick = "appointment(' +
                                data.student_id +
                                ')" title = "Appointment" data-id = "' +
                                data.id +
                                '"><i class="fa fa-clock"></i>&nbsp;<span class="text-success">Appointment</span></a>' +
                                '<a class = "dropdown-item no" onclick = "giveAdvice(' +
                                data
                                .id +
                                ')" title = "Clear" data-id = "' +
                                data.id +
                                '"><i class="fa fa-plane"></i>&nbsp;<span class="text-danger">Clear</span></a></div></div> ';
                        },
                        orderable: false,
                        searchable: false
                    }
                ],
                "fnRowCallback": function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                    if (aData.state == "2") {
                        $(nRow).find('td:eq(6)').html('Pending');
                        $(nRow).find('td:eq(6)').css({
                            "color": "blue",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #4CAF50"
                        });
                    } else if (aData.state == "5") {
                        $(nRow).find('.reference').css({
                            "display": "none"
                        })
                        $(nRow).find('.pharmacy').css({
                            "display": "none"
                        })
                        $(nRow).find('.no').css({
                            "display": "none"
                        })
                        $(nRow).find('td:eq(6)').html('Lab cheking')
                        $(nRow).find('.lab').css({
                            "display": "none"
                        })
                        $(nRow).find('td:eq(6)').css({
                            "color": "orange",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #f44336"
                        });
                    } else if (aData.state == "6") {
                        $(nRow).find('.labresult').css({
                            "display": "flex"
                        })
                        $(nRow).find('td:eq(6)').html('Lab Result')
                        $(nRow).find('.lab').css({
                            "display": "none"
                        })
                        $(nRow).find('td:eq(6)').css({
                            "color": "green",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #f44336"
                        });
                    }
                }
            });
            /* End: Yajra data table*/
            $('#laravel-datatable-patient tbody').on('click', 'tr', function() {
                if ($(this).hasClass('selected')) {
                    $(this).removeClass('selected');
                } else {
                    $('tr.selected').removeClass('selected');
                    $(this).addClass('selected');
                }
            });

            $('#status').select2({
                minimumResultsForSearch: -1
            });
        });
        ctable.on('draw', function() {
            var body = $(ctable.table().body());
            body.unhighlight();
            body.highlight(ctable.search());
        })

        function viewHistoryFn(record_id) {
            $('#history_id').val(record_id);
            var htable = $('#laravel-datatable-history').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                searchHighlight: true,
                dom: 'lBfrtip', // Add l before B to include lengthMenu
                buttons: [{
                        extend: 'copy',
                        title: 'Patient under doctor', // Title for the 'copy' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'csv',
                        title: 'Patient under doctor', // Title for the 'csv' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'excel',
                        title: 'Patient under doctor', // Title for the 'excel' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'pdf',
                        title: 'Patient under doctor',
                        orientation: 'landscape', // Set orientation: 'landscape' or 'portrait'
                        pageSize: 'A4', // Set page size
                        customize: function(doc) {
                            // Customize header, footer, and body style
                            doc.styles.tableHeader = {
                                fillColor: '#4CAF50',
                                color: 'white',
                                alignment: 'center'
                            };
                            doc.styles.title = {
                                fontSize: 14,
                                alignment: 'center'
                            };
                            doc.defaultStyle.fontSize = 10; // Change default font size
                            doc.content[1].table.widths = '*'.repeat(doc.content[1].table.body[0]
                                .length).split(''); // Automatically adjust column widths
                            doc.pageMargins = [10, 10, 10, 10]; // Adjust page margins
                            doc.pageSize = 'A4'; // Ensure the page size is A4
                            doc.content[1].layout = {
                                hLineWidth: function(i, node) {
                                    return (i === 0 || i === node.table.body.length) ? 2 :
                                        1;
                                },
                                vLineWidth: function(i, node) {
                                    return (i === 0 || i === node.table.widths.length) ? 2 :
                                        1;
                                },
                                hLineColor: function(i, node) {
                                    return (i === 0 || i === node.table.body.length) ?
                                        'black' : 'gray';
                                },
                                vLineColor: function(i, node) {
                                    return (i === 0 || i === node.table.widths.length) ?
                                        'black' : 'gray';
                                },
                                paddingLeft: function(i, node) {
                                    return 4;
                                },
                                paddingRight: function(i, node) {
                                    return 4;
                                },
                                paddingTop: function(i, node) {
                                    return 2;
                                },
                                paddingBottom: function(i, node) {
                                    return 2;
                                },
                            };
                        },
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'print',
                        title: 'Patient under doctor',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6] // Indexes of the columns you want to include
                        }
                    }
                ],
                lengthMenu: [
                    [10, 25, 50, 500, -1],
                    [10, 25, 50, 500, "All"]
                ],
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: '/gethistory/' + record_id,
                    type: 'DELETE',
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'student.student_id',
                        name: 'student.student_id',
                    },
                    {
                        data: 'description',
                        name: 'description',
                    },
                ],
            });
            $('#historyModal').modal('show');
        }


        function closeHistory() {
            $('#description-error').html('');
            $('#description').val('');
        }

        function valdiateHistory() {
            $('#description-error').html('');
        }
    </script>
    <script>
        $('#finish').click(function() {
            var check = prompt('Are you sure?');
            if (check == 'yes') {
                finished();
            }
        });

        function finished() {
            $.get('/finishPrint/' + $('#print_id').val(), function(data) {
                if (data.success) {
                    alert_toast(data.success, 'success');
                    $('#referenceModal').modal('hide');
                    var pTable = $('#laravel-datatable-patient').dataTable();
                    pTable.fnDraw(false);
                } else {
                    alert_toast('An error occured', 'error');
                }
            });
        }
        $('#savehistory').click(function() {
            var historyData = $('#form-history');
            var formData = historyData.serialize();
            $.ajax({
                url: '/historystore',
                type: 'post',
                data: formData,
                beforeSend: function() {
                    cardSection.block({
                        message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                        css: {
                            backgroundColor: 'transparent',
                            color: '#fff',
                            border: '0'
                        },
                        overlayCSS: {
                            opacity: 0.5
                        }
                    });
                    $('#savehistory').text('Saving...');
                    $('#savehistory').prop("disabled", true);
                },
                complete: function() {
                    cardSection.block({
                        message: '',
                        timeout: 1,
                        css: {
                            backgroundColor: '',
                            color: '',
                            border: ''
                        },
                    });
                },

                success: function(data) {
                    if (data.errors) {
                        $('#savehistory').html('Save');
                        $('#savehistory').prop("disabled", false);
                        alert_toast("An error occured!",
                            "error");
                        if (data.errors.description) {
                            $('#description-error').html(data.errors.description[0]);
                        }
                    } else if (data.success) {
                        alert_toast('History added Sucessfully!', 'success');
                        $('#addHistory').modal('hide');
                        $('#description').val('');
                        var hTable = $('#laravel-datatable-history').dataTable();
                        hTable.fnDraw(false);
                        $('#savehistory').html('Save');
                        $('#savehistory').prop("disabled", false);
                    } else {
                        alert('new error')
                        $('#savehistory').html('Save');
                        $('#savehistory').prop("disabled", false);
                    }
                }
            });
        });

        function removeDesc() {
            $('#desc-error').html('');
        }

        function removeStartDate() {
            $('#start-error').html('');
        }

        function removeEndDate() {
            $('#end-error').html('');
        }
        $('#appointmentbutton').click(function() {
            var appointmentData = $('#appointment-form');
            var formData = appointmentData.serialize();
            $.ajax({
                url: '/appointmentstore',
                type: 'post',
                data: formData,
                beforeSend: function() {
                    cardSection.block({
                        message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                        css: {
                            backgroundColor: 'transparent',
                            color: '#fff',
                            border: '0'
                        },
                        overlayCSS: {
                            opacity: 0.5
                        }
                    });
                    $('#appointmentbutton').text('Seting...');
                    $('#appointmentbutton').prop("disabled", true);
                },
                complete: function() {
                    cardSection.block({
                        message: '',
                        timeout: 1,
                        css: {
                            backgroundColor: '',
                            color: '',
                            border: ''
                        },
                    });
                },

                success: function(data) {
                    if (data.time_error) {
                        $('#appointmentbutton').html('Set');
                        $('#appointmentbutton').prop("disabled", false);
                        alert_toast(data.time_error,
                            "error");
                    } else if (data.errors) {
                        if (data.errors.start_date) {
                            $('#start-error').html(data.errors.start_date[0])
                        }
                        if (data.errors.end_date) {
                            $('#end-error').html(data.errors.end_date[0])
                        }
                        if (data.errors.description) {
                            $('#desc-error').html(data.errors.description[0])
                        }
                        $('#appointmentbutton').html('Set');
                        $('#appointmentbutton').prop("disabled", false);
                        alert_toast("An error occured!",
                            "error");
                    } else if (data.success) {
                        alert_toast('Appointment set sucessfully!', 'success');
                        $('#addHistory').modal('hide');
                        $('#desc').val('');
                        $('#start_date').val('');
                        $('#end_date').val('');
                        $('#stud_id').val('');
                        $('#appointmentbutton').html('Set');
                        $('#appointmentbutton').prop("disabled", false);
                        window.location = "/appointments";
                        var aTable = $('#laravel-datatable-appointment').dataTable();
                        aTable.fnDraw(false);
                    } else {
                        alert('new error')
                        $('#appointmentbutton').html('Set');
                        $('#appointmentbutton').prop("disabled", false);
                    }
                }
            });
        });
        $('#remark-button').click(function() {
            if ($('#rm').val() == null || $('#rm').val() == "") {
                alert_toast('Remark field is required', 'error');
            } else {
                $('#remark-button').html('Clearining...');
                $.get('/remark/' + $('#remark_id').val() + '/' + $('#rm').val(), function(data) {
                    if (data.errors) {
                        alert_toast(data.errors, 'error');
                        $('#remark-button').html('Clear');
                    } else if (data.success) {
                        alert_toast('Successfully cleared!', 'success');
                        var ptTable = $('#laravel-datatable-patient').dataTable();
                        ptTable.fnDraw(false);
                        $('#adviceModal').modal('hide');
                        $('#remark-button').html('Clear');
                    } else {
                        alert_toast('An error occured', 'error');
                        $('#remark-button').html('Clear');
                    }
                });
            }

        });

        function giveAdvice(record_id) {
            $('#remark_id').val(record_id);
            $('#adviceModal').modal('show');
        }

        function sendPharmacy(record_id) {
            $.get('/sendPharmacy/' + record_id, function(data) {
                if (data.student) {
                    $('#fname').val(data.student.full_name);
                    $('#user_id').val(data.student.student_id);
                    $('#gender').val(data.student.sex);
                    $('#age_number').val(data.student.age);
                    $('#patient_id').val(record_id);
                    $('#sendModal').modal('hide');
                    $('#pharmacyModal').modal('show');
                }
            });
        }

        function appointment(record_id) {
            $('#st_id').val(record_id);
            $('#appointmentModal').modal('show');
        }

        function reference(record_id) {
            $('#print_id').val(record_id);
            $.get('/getReference/' + record_id, function(data) {
                if (data.student) {
                    $('.dep').html(data.student.department);
                    $('.stud_id').html(data.student.student_id);
                    $('.stud_name').html(data.student.full_name);
                    $('#referenceModal').modal('show');
                }
            });

        }

        function print() {
            var div_content = document.getElementById("div_print").innerHTML;
            var a = window.open('', '', 'height=1000, width=1000');
            a.document.write('<html>');
            a.document.write('<body>');
            a.document.write(div_content);
            a.document.write('</body></html>');
            a.document.close();
            a.print();
        }

        function sendLabratory(record_id) {
            $('#savelabratory').css({
                "display": "flex"
            });
            $.get('/sendPharmacy/' + record_id, function(data) {
                if (data.student) {
                    $('#fullname').val(data.student.full_name);
                    $('#stud_id').val(data.student.student_id);
                    $('#new_sex').val(data.student.sex);
                    $('#new_age').val(data.student.age);
                    $('#lab_id').val(record_id);
                    $('#sendModal').modal('hide');
                    $('#labratoryModal').modal('show');
                }
            });
        }
        $('#savelabratory').css({
            "display": "flex"
        });

        function labResult(record_id) {
            $('#savelabratory').css({
                "display": "none"
            });
            $.get('/getLabratory/' + record_id, function(data) {
                if (data.student) {
                    $('#fullname').val(data.student.full_name);
                    $('#stud_id').val(data.student.student_id);
                    $('#new_sex').val(data.student.sex);
                    $('#new_age').val(data.student.age);
                    $('#lab_id').val(record_id);
                    $('#sendModal').modal('hide');
                    $('#labratoryModal').modal('show');
                }
                if (data.labratory) {
                    $('#other').val(data.labratory.other);
                    $('#other_lab').val(data.labratory.other_lab);
                    $('#labratory_id').val(data.labratory.id);
                    $('#hg').val(data.labratory.hg);
                    $('#hct').val(data.labratory.hct);
                    $('#wbc1').val(data.labratory.wbc1);
                    $('#netrophils').val(data.labratory.netrophils);
                    $('#basophils').val(data.labratory.basophils);
                    $('#eosinophils').val(data.labratory.eosinophils);
                    $('#monocytes').val(data.labratory.monocytes);
                    $('#lymphocyted').val(data.labratory.lymphocyted);
                    $('#esr').val(data.labratory.esr);
                    data.labratory.app == 'on' ? $('#app').prop('checked', true) : $('#app').prop('checked', false);
                    data.labratory.cons == 'on' ? $('#cons').prop('checked', true) : $('#cons').prop('checked',
                        false);
                    data.labratory.oip == 'on' ? $('#oip').prop('checked', true) : $('#oip').prop('checked', false);
                    data.labratory.color == 'on' ? $('#color').prop('checked', true) : $('#color').prop('checked',
                        false);
                    data.labratory.leurcocyte == 'on' ? $('#leurcocyte').prop('checked', true) : $('#leurcocyte')
                        .prop('checked', false);
                    data.labratory.blood == 'on' ? $('#blood').prop('checked', true) : $('#blood')
                        .prop('checked', false);
                    data.labratory.nitrate == 'on' ? $('#nitrate').prop('checked', true) : $('#nitrate')
                        .prop('checked', false);
                    data.labratory.urobilinogen == 'on' ? $('#urobilinogen').prop('checked', true) : $(
                            '#urobilinogen')
                        .prop('checked', false);
                    data.labratory.protein == 'on' ? $('#protein').prop('checked', true) : $('#protein')
                        .prop('checked', false);
                    data.labratory.ph == 'on' ? $('#ph').prop('checked', true) : $('#ph')
                        .prop('checked', false);
                    data.labratory.spec == 'on' ? $('#spec').prop('checked', true) : $('#spec')
                        .prop('checked', false);
                    data.labratory.ketones == 'on' ? $('#ketones').prop('checked', true) : $('#ketones')
                        .prop('checked', false);
                    data.labratory.bilirubin == 'on' ? $('#bilirubin').prop('checked', true) : $('#bilirubin')
                        .prop('checked', false);
                    data.labratory.glucose == 'on' ? $('#glucose').prop('checked', true) : $('#glucose')
                        .prop('checked', false);
                    data.labratory.rbc == 'on' ? $('#rbc').prop('checked', true) : $('#rbc')
                        .prop('checked', false);
                    data.labratory.wbc == 'on' ? $('#wbc').prop('checked', true) : $('#wbc')
                        .prop('checked', false);
                    data.labratory.blood_film == 'on' ? $('#blood_film').prop('checked', true) : $('#blood_film')
                        .prop('checked', false);
                    data.labratory.imunohematology == 'on' ? $('#imunohematology').prop('checked', true) : $(
                            '#imunohematology')
                        .prop('checked', false);
                    data.labratory.blood_group == 'on' ? $('#blood_group').prop('checked', true) : $('#blood_group')
                        .prop('checked', false);
                    data.labratory.o == 'on' ? $('#o').prop('checked', true) : $('#o')
                        .prop('checked', false);
                    data.labratory.h == 'on' ? $('#h').prop('checked', true) : $('#h')
                        .prop('checked', false);
                    data.labratory.ox == 'on' ? $('#ox').prop('checked', true) : $('#ox')
                        .prop('checked', false);
                    data.labratory.rbr == 'on' ? $('#rbr').prop('checked', true) : $('#rbr')
                        .prop('checked', false);
                    data.labratory.theumatoid == 'on' ? $('#theumatoid').prop('checked', true) : $('#theumatoid')
                        .prop('checked', false);
                    data.labratory.hcg == 'on' ? $('#hcg').prop('checked', true) : $('#hcg')
                        .prop('checked', false);
                    data.labratory.fbc == 'on' ? $('#fbc').prop('checked', true) : $('#fbc')
                        .prop('checked', false);
                    data.labratory.bactreglology == 'on' ? $('#bactreglology').prop('checked', true) : $(
                            '#bactreglology')
                        .prop('checked', false);
                    data.labratory.gram_stan == 'on' ? $('#gram_stan').prop('checked', true) : $(
                            '#gram_stan')
                        .prop('checked', false);
                    data.labratory.ab == 'on' ? $('#ab').prop('checked', true) : $(
                            '#ab')
                        .prop('checked', false);
                }
            });
        }
        var i = 0,
            m = 0,
            j = 0;
        /* BEGIN: Add woreda button */
        $("#adds").click(function() {
            $('#table-error').html('');
            var lastrowcount = $('#dynamicTable tr:last').find('td').eq(1).find('input').val();
            ++i;
            ++m;
            ++j;
            $("#dynamicTable > tbody").append('<tr id="rowind' + m +
                '"><td style="font-weight:bold;width:3%;text-align:center;">' + j + '</td>' +
                '<td style="display:none;"><input type="hidden" name="product[' + m + '][vals]" id="vals' + m +
                '" class="vals form-control" readonly="true" style="font-weight:bold;" value="' + m +
                '"/></td>' +
                '<td style="display:none;"><input type="hidden" name="product[' + m +
                '][id]" id="id' +
                m +
                '" class="vals form-control" readonly="true" style="font-weight:bold;" value=""/></td>' +
                '<td style="width: 13%; padd"><select class="custom-select browser-default select2 product" name="product[' +
                m +
                '][product_id]" id="product_id' +
                m +
                '" onclick="prfn(this)" onblur="checkPrFn(this)"><option value=""></option></select></td>' +
                '<td style="width:13%; padd"><input type="text" name="product[' + m +
                '][description]" placeholder="Write here..." onkeypress="return Validatedescription(event);" onkeyup="checkDscFn()" id="description' +
                m +
                '" class="description form-control numeral-mask" onclick="dscfn(this)" onblur="checkDscFn(this)"/></td>' +
                '<td style="width:3%;text-align:center;"><button type="button" id="removebtn' + m +
                '" class="btn btn-light btn-sm remove-tr" style="color:#ea5455;background-color:#FFFFFF;border-color:#FFFFFF"><i class="fa fa-times fa-lg" aria-hidden="true"></i></button></td></tr>'
            );

            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                $('#product_id' + m).append(
                    '<option value="<?php echo e($product->product->id); ?>"><?php echo e($product->product->item_name); ?> | <?php echo e($product->product->unit->name); ?></option>'
                );
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            $('#product_id' + m).select2({
                placeholder: "Select Product here",
            });
            /*
            $.get('/getplist', function(data) {
                $.each(data.product, function(key, value) {
                    $('#product_id' + m).append('<option value="' + value.id + '">' + value
                        .item_name +
                        '  </option>');
                });
            });*/
            renumberRows();
        });
        $(document).on('click', '.remove-tr', function() {
            id = $(this).val();
            $(this).parents('tr').remove();
            --i;
            --j;
            --m;
        });


        function sendFn(record_id) {
            $('#send_id').val(record_id);
            $('#sendModal').modal('show');
        }
        $('.send').click(function() {
            var send_id = $('#send_id').val();
            $.ajax({
                url: '/sendpatient/' + send_id,
                type: 'get',
                beforeSend: function() {
                    $('.send').text('Sending...');
                },
                success: function(data) {
                    if (data.errors) {
                        $('.send').text('Send');
                        alert_toast('an error occured', 'error');
                    } else if (data.success) {
                        $('.send').text('Send');
                        alert_toast(data.success, 'success')
                        var cTable = $('#laravel-datatable-patient').dataTable();
                        cTable.fnDraw(false);
                        $('#sendModal').modal('hide');
                    }
                }
            });
        });
        $('#savepharmacy').click(function() {
            var pharmacyData = $('#form-pharmacy');
            var formData = pharmacyData.serialize();
            $.ajax({
                url: '/pharmacystore',
                type: 'post',
                data: formData,
                beforeSend: function() {
                    cardSection.block({
                        message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                        css: {
                            backgroundColor: 'transparent',
                            color: '#fff',
                            border: '0'
                        },
                        overlayCSS: {
                            opacity: 0.5
                        }
                    });
                    $('#savepharmacy').text('Saving...');
                    $('#savepharmacy').prop("disabled", true);
                },
                complete: function() {
                    cardSection.block({
                        message: '',
                        timeout: 1,
                        css: {
                            backgroundColor: '',
                            color: '',
                            border: ''
                        },
                    });
                },

                success: function(data) {
                    if (data.errors) {
                        var product = "";
                        var description = "";
                        for (var k = 1; k <= m; k++) {
                            product = ($('#product_id' + k)).val();
                            description = ($('#description' + k)).val();

                            if (($('#product_id' + k).val()) != undefined) {
                                if (product == "" || product == null) {
                                    $('#product_id' + k).css("background", errorcolor);
                                }
                            }
                            if (($('#description' + k).val()) != undefined) {
                                if (description == "" || description == null) {
                                    $('#description' + k).css("background", errorcolor);
                                }
                            }
                        }
                        $('#savepharmacy').html('Save');
                        $('#savepharmacy').prop("disabled", false);
                        alert_toast(data.errors,
                            "error");
                    } else if (data.success) {
                        alert_toast('Patient send to pharmacy successfully!', 'success');
                        $('#pharmacyModal').modal('hide');
                        var pTable = $('#laravel-datatable-patient').dataTable();
                        pTable.fnDraw(false);
                        $('#savepharmacy').html('Save');
                        $('#savepharmacy').prop("disabled", false);
                    } else {
                        alert('new error')
                        $('#savepharmacy').html('Save');
                        $('#savepharmacy').prop("disabled", false);
                    }
                }
            });
        });
        $('#savelabratory').click(function() {
            $('#app').is(':checked') ? $('#app').val('on') : $('#app').val('');
            $('#cons').is(':checked') ? $('#cons').val('on') : $('#cons').val('');
            $('#oip').is(':checked') ? $('#oip').val('on') : $('#oip').val('');
            $('#color').is(':checked') ? $('#color').val('on') : $('#color').val('');
            $('#leurcocyte').is(':checked') ? $('#leurcocyte').val('on') : $('#leurcocyte').val('');
            $('#blood').is(':checked') ? $('#blood').val('on') : $('#blood').val('');
            $('#nitrate').is(':checked') ? $('#nitrate').val('on') : $('#nitrate').val('');
            $('#urobilinogen').is(':checked') ? $('#urobilinogen').val('on') : $('#urobilinogen').val('');
            $('#protein').is(':checked') ? $('#protein').val('on') : $('#protein').val('');
            $('#ph').is(':checked') ? $('#ph').val('on') : $('#ph').val('');
            $('#spec').is(':checked') ? $('#spec').val('on') : $('#spec').val('');
            $('#ketones').is(':checked') ? $('#ketones').val('on') : $('#ketones').val('');
            $('#bilirubin').is(':checked') ? $('#bilirubin').val('on') : $('#bilirubin').val('');
            $('#glucose').is(':checked') ? $('#glucose').val('on') : $('#glucose').val('');
            $('#rbc').is(':checked') ? $('#rbc').val('on') : $('#rbc').val('');
            $('#wbc').is(':checked') ? $('#wbc').val('on') : $('#wbc').val('');
            $('#blood_film').is(':checked') ? $('#blood_film').val('on') : $('#blood_film').val('');
            $('#imunohematology').is(':checked') ? $('#imunohematology').val('on') : $('#imunohematology').val('');
            $('#blood_group').is(':checked') ? $('#blood_group').val('on') : $('#blood_group').val('');
            $('#o').is(':checked') ? $('#o').val('on') : $('#o').val('');
            $('#h').is(':checked') ? $('#h').val('on') : $('#h').val('');
            $('#ox').is(':checked') ? $('#ox').val('on') : $('#ox').val('');
            $('#rbr').is(':checked') ? $('#rbr').val('on') : $('#rbr').val('');
            $('#theumatoid').is(':checked') ? $('#theumatoid').val('on') : $('#theumatoid').val('');
            $('#hcg').is(':checked') ? $('#hcg').val('on') : $('#hcg').val('');
            $('#fbc').is(':checked') ? $('#fbc').val('on') : $('#fbc').val('');
            $('#bactreglology').is(':checked') ? $('#bactreglology').val('on') : $('#bactreglology').val('');
            $('#gram_stan').is(':checked') ? $('#gram_stan').val('on') : $('#gram_stan').val('');
            $('#ab').is(':checked') ? $('#ab').val('on') : $('#ab').val('');
            var labratoryData = $('#labratory-form');
            var formData = labratoryData.serialize();
            $.ajax({
                url: '/labratorystore',
                type: 'post',
                data: formData,
                beforeSend: function() {
                    cardSection.block({
                        message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                        css: {
                            backgroundColor: 'transparent',
                            color: '#fff',
                            border: '0'
                        },
                        overlayCSS: {
                            opacity: 0.5
                        }
                    });
                    $('#savelabratory').text('Saving...');
                    $('#savelabratory').prop("disabled", true);
                },
                complete: function() {
                    cardSection.block({
                        message: '',
                        timeout: 1,
                        css: {
                            backgroundColor: '',
                            color: '',
                            border: ''
                        },
                    });
                },

                success: function(data) {
                    if (data.errors) {
                        $('#savelabratory').html('Save');
                        $('#savelabratory').prop("disabled", false);
                        alert_toast("Please fill all highlighted required fields pitch",
                            "error");
                    } else if (data.success) {
                        alert_toast('Patient send to labratory successfully!', 'success');
                        $('#labratoryModal').modal('hide');
                        var nTable = $('#laravel-datatable-patient').dataTable();
                        nTable.fnDraw(false);
                        $('#savelabratory').html('Save');
                        $('#savelabratory').prop("disabled", false);
                    } else {
                        alert('new error')
                        $('#savelabratory').html('Save');
                        $('#savelabratory').prop("disabled", false);
                    }
                }
            });
        });
    </script>
    <script>
        function removeNameValidation() {
            $('#name-error').html('');
        }

        function removeStatusValidation() {
            $('#status-error').html('');
        }

        function closeModal() {
            $('#name-error').html('');
            $('#status-error').html('');
            $('#name').val('');

            $('#dynamicTable tbody').empty();
            $('#status').val('').trigger('change');
            $('#savenewbutton').css('display', 'flex');
            $('#savebutton').html('Save & Close');
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Werabe University Project\Werabe University Project\resources\views\patients\doctor1.blade.php ENDPATH**/ ?>