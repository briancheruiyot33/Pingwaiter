<?php $__env->startSection('title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="app-content content">
        <section id="responsive-datatable">
            <div class="row">
                <div class="col-12">
                    <!-- Your HTML content goes here -->
                    <div class="card">
                        <div class="card-header border-bottom">
                            <h3 class="card-title">Items</h3>

                            <button type="button" class="btn btn-gradient-info btn-sm add">Add</button>

                        </div>
                        <div class="card-datatable">
                            <div style="width:98%; margin-left:1%;">
                                <div class="table-responsive">

                                    <table id="laravel-datatable-product"
                                        class="display table-bordered table-striped table-hover dt-responsive mb-0 dataTable no-footer"
                                        style="width: 100%;" role="grid" aria-describedby="laravel-datatable-user">

                                        <thead>
                                            <tr role="row">
                                                <th nowrap width="1%">#</th>
                                                <th nowrap>SKU</th>
                                                <th nowrap width="20%">Item Name</th>
                                                <th nowrap width="20%">Category</th>
                                                <th nowrap width="20%">Item Type</th>
                                                <th nowrap width="20%">Unit of measurment</th>
                                                <th nowrap width="20%">Status</th>
                                                <th nowrap width="5%">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody></tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- BEGIN: Category Add modal  -->
        <div class="modal fade text-left" id="inlineForm" data-keyboard="false" data-backdrop="static" tabindex="-1"
            role="dialog" aria-labelledby="lbl" aria-hidden="true" style="overflow-y: scroll;">
            <div class="modal-dialog modal-xl" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="categorylbl">Add Item</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                            onclick="closeModal()">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form id="Register">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="edit_id" id="edit_id">
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-md-3">
                                    <label strong style="font-size: 16px;">SKU</label><label
                                        style="color: red; font-size:16px;">*</label>
                                    <div class="form-group">
                                        <input type="text" class="form-control" name="SKU" id='SKU' readonly />
                                        <span class="text-danger">
                                            <strong id="sku-error"></strong>
                                        </span>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <label strong style="font-size: 16px;">Item Name</label><label
                                        style="color: red; font-size:16px;">*</label>
                                    <div class="form-group">
                                        <input type="text" placeholder="Write Item Name here" class="form-control"
                                            name="item_name" id='item_name' autofocus onkeyup="removeNameValidation()" />
                                        <span class="text-danger">
                                            <strong id="item-error"></strong>
                                        </span>
                                    </div>

                                </div>
                                <div class="col-md-3">
                                    <label strong style="font-size: 16px;">Category</label><label
                                        style="color: red; font-size:16px;">*</label>
                                    <div class="form-group">
                                        <select class="custom-select browser-default select2" name="category_id"
                                            id="category_id" onchange="removeCategoryValidation()">
                                            <option value=""></option>
                                            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <span class="text-danger">
                                            <strong id="category-error"></strong>
                                        </span>
                                    </div>
                                </div>
                                

                                <div class="col-md-3">
                                    <label strong style="font-size: 16px;">Unit of measurement</label><label
                                        style="color: red; font-size:16px;">*</label>
                                    <div class="form-group">
                                        <select class="custom-select browser-default select2" name="unit_id" id="unit_id"
                                            onchange="removeUnitValidation()">
                                            <option value=""></option>
                                            <?php $__currentLoopData = $unit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($unit->id); ?>"><?php echo e($unit->name); ?>

                                                    (<?php echo e($unit->package); ?>)
                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <span class="text-danger">
                                            <strong id="unit-error"></strong>
                                        </span>
                                    </div>

                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3">
                                    <label strong style="font-size: 16px;">Item Type</label><label
                                        style="color: red; font-size:16px;">*</label>
                                    <div class="form-group">
                                        <select class="custom-select browser-default select2" name="item_type"
                                            id="item_type" onchange="removeTypeValidation()">
                                            <option value=""></option>
                                            <option value="1">Fixed Item</option>
                                            <option value="2">None Fixed Item</option>
                                        </select>
                                        <span class="text-danger">
                                            <strong id="fixed-error"></strong>
                                        </span>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <label strong style="font-size: 16px;">Item Expiration Status</label><label
                                        style="color: red; font-size:16px;">*</label>
                                    <div class="form-group">
                                        <select class="custom-select browser-default" name="item_expiration_status"
                                            id="item_expiration_status" onchange="removeExpirationValidation()">
                                            <option value=""></option>
                                            <option value="2">Has No Expiration Date</option>
                                            <option value="1">Has Expiration Date</option>
                                        </select>
                                        <span class="text-danger">
                                            <strong id="expiration-error"></strong>
                                        </span>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <label strong style="font-size: 16px;">Identifyed By</label><label
                                        style="color: red; font-size:16px;">*</label>
                                    <div class="form-group">
                                        <select id="mySelect" name="identifyed_by[]"
                                            onchange="removeIdentifyiedValidation()" multiple>
                                            <option value="Batch No">Batch No</option>
                                            <option value="Seriel Number">Seriel Number</option>
                                            <option value="Model">Model</option>
                                            <option value="Brand">Brand</option>
                                            <!-- Add more options as needed -->
                                        </select>
                                        <span class="text-danger">
                                            <strong id="identifyed-error"></strong>
                                        </span>
                                    </div>

                                </div>
                                <div class="col-md-3">
                                    <label strong style="font-size: 16px;">Status</label><label
                                        style="color: red; font-size:16px;">*</label>
                                    <div class="form-group">
                                        <div>
                                            <select class="custom-select browser-default select2" name="status"
                                                id="status" onchange="removeStatusValidation()">
                                                <option value="Active">Active</option>
                                                <option value="Inactive">Inactive</option>
                                            </select>
                                            <span class="text-danger">
                                                <strong id="status-error"></strong>
                                            </span>
                                        </div>
                                    </div>
                                </div>

                            </div>

                        </div>
                        <div class="modal-footer">
                            <button id="savenewbutton" type="button" class="btn btn-info">Save &
                                New</button>
                            <button id="savebutton" type="button" class="btn btn-info">Save & Close</button>
                            <button id="closebutton" type="button" class="btn btn-danger" onclick="closeModal()"
                                data-dismiss="modal">Close</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    
    <div class="modal fade" id="DeleteModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Delete product Data</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                        onclick="closeModalWithClearValidation()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" style="background-color:#e74a3b">
                    <label strong style="font-size: 16px;font-weight:bold;color:white;">Do you really want to
                        delete this product?</label>
                    <input type="hidden" id="deleteing_id">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-info delete_product">Delete</button>
                    <button id="closebutton" type="button" class="btn btn-danger"
                        onclick="closeModalWithClearValidation()" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>


    <!-- BEGIN: Info modal -->
    <div class="modal fade text-left" id="infoModal" data-keyboard="false" data-backdrop="static" tabindex="-1"
        role="dialog" aria-labelledby="myModalLabel133" aria-hidden="true" style="overflow-y: scroll;">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Item Information</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="regionform">
                    <input type="hidden" class="_token">
                    <div class="modal-body">
                        <table style="width: 100%;">
                            <tbody>
                                <tr>
                                    <td style="width: 40%">
                                        <label style="font-size: 14px;">SKU: </label>
                                    </td>
                                    <td style="width: 60%">
                                        <label id="sku_info" style="font-size: 14px; font-weight: bold;"></label>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 40%">
                                        <label style="font-size: 14px;">Item Name: </label>
                                    </td>
                                    <td style="width: 60%">
                                        <label id="item_info" style="font-size: 14px; font-weight: bold;"></label>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 40%">
                                        <label style="font-size: 14px;">Category: </label>
                                    </td>
                                    <td style="width: 60%">
                                        <label id="category_info" style="font-size: 14px; font-weight: bold;"></label>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 40%">
                                        <label style="font-size: 14px;">Item Type: </label>
                                    </td>
                                    <td style="width: 60%">
                                        <label id="type_info" style="font-size: 14px; font-weight: bold;"></label>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 40%">
                                        <label style="font-size: 14px;">Item Expiration Status: </label>
                                    </td>
                                    <td style="width: 60%">
                                        <label id="expiration_info" style="font-size: 14px; font-weight: bold;"></label>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 40%">
                                        <label style="font-size: 14px;">Unit of measurement: </label>
                                    </td>
                                    <td style="width: 60%">
                                        <label id="unit_info" style="font-size: 14px; font-weight: bold;"></label>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 40%">
                                        <label style="font-size: 14px;">Identifyed By: </label>
                                    </td>
                                    <td style="width: 60%">
                                        <label id="identifyed_info" style="font-size: 14px; font-weight: bold;"></label>
                                    </td>
                                </tr>
                                <td>
                                    <label style="font-size: 14px;">Status: </label>
                                </td>
                                <td>
                                    <label id="status_info" style="font-size: 14px; font-weight: bold;"></label>
                                </td>
                                </tr>
                                <tr>
                                    <td colspan="2">
                                        <div class="divider newext">
                                            <div class="divider-text">Action Information</div>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label style="font-size: 14px;">Created By</label>
                                    </td>
                                    <td>
                                        <label id="createdby_info" style="font-size: 14px; font-weight: bold;"></label>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label style="font-size: 14px;">Created Date</label>
                                    </td>
                                    <td>
                                        <label id="createdat_info" style="font-size: 14px; font-weight: bold;"></label>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label style="font-size: 14px;">Last Edited By</label>
                                    </td>
                                    <td>
                                        <label id="updatedby_info" style="font-size: 14px; font-weight: bold;"></label>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 30%">
                                        <label style="font-size: 14px;">Last Edited Date</label>
                                    </td>
                                    <td style="width: 70%">
                                        <label id="updatedat_info" style="font-size: 14px; font-weight: bold;"></label>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="modal-footer">
                        <button id="closebuttonk" type="button"
                            class="btn btn-danger waves-effect waves-float waves-light"
                            data-dismiss="modal">Close</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <div class="modal fade" id="DeleteModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Delete Region Data</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                        onclick="closeModalWithClearValidation()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" style="background-color:#e74a3b">
                    <label strong style="font-size: 16px;font-weight:bold;color:white;">Do you really want to
                        delete this region?</label>
                    <input type="hidden" id="deleteing_id">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-info delete_region">Delete</button>
                    <button id="closebutton" type="button" class="btn btn-danger"
                        onclick="closeModalWithClearValidation()" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        var errorcolor = "#ffcccc";
        $(function() {
            cardSection = $('#page-block');
        });
        /* BEGIN: Display zone table using yajra datatable */
        $(document).ready(function() {

            $('#mySelect').val(null).trigger('change');
            $('#mySelect').select2({
                placeholder: 'Select Identifier',
            });
            var ctable = $('#laravel-datatable-product').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                searchHighlight: true,
                dom: 'lBfrtip', // Add l before B to include lengthMenu
                buttons: [{
                        extend: 'copy',
                        title: 'Item list', // Title for the 'copy' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'csv',
                        title: 'Item list', // Title for the 'csv' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'excel',
                        title: 'Item list', // Title for the 'excel' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'pdf',
                        title: 'Item list', // Title for the 'pdf' button
                        orientation: 'landscape', // Set orientation: 'landscape' or 'portrait'
                        pageSize: 'A4', // Set page size
                        customize: function(doc) {
                            // Customize header, footer, and body style
                            doc.styles.tableHeader = {
                                fillColor: '#4CAF50',
                                color: 'white',
                                alignment: 'center'
                            };
                            doc.styles.title = {
                                fontSize: 14,
                                alignment: 'center'
                            };
                            doc.defaultStyle.fontSize = 10; // Change default font size
                            doc.content[1].table.widths = '*'.repeat(doc.content[1].table.body[0]
                                .length).split(''); // Automatically adjust column widths
                            doc.pageMargins = [10, 10, 10, 10]; // Adjust page margins
                            doc.pageSize = 'A4'; // Ensure the page size is A4
                            doc.content[1].layout = {
                                hLineWidth: function(i, node) {
                                    return (i === 0 || i === node.table.body.length) ? 2 :
                                        1;
                                },
                                vLineWidth: function(i, node) {
                                    return (i === 0 || i === node.table.widths.length) ? 2 :
                                        1;
                                },
                                hLineColor: function(i, node) {
                                    return (i === 0 || i === node.table.body.length) ?
                                        'black' : 'gray';
                                },
                                vLineColor: function(i, node) {
                                    return (i === 0 || i === node.table.widths.length) ?
                                        'black' : 'gray';
                                },
                                paddingLeft: function(i, node) {
                                    return 4;
                                },
                                paddingRight: function(i, node) {
                                    return 4;
                                },
                                paddingTop: function(i, node) {
                                    return 2;
                                },
                                paddingBottom: function(i, node) {
                                    return 2;
                                },
                            };
                        },
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'print',
                        title: 'Item list',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6] // Indexes of the columns you want to include
                        }
                    }
                ],
                lengthMenu: [
                    [10, 25, 50, 500, -1],
                    [10, 25, 50, 500, "All"]
                ],
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: '/getproducts',
                    type: 'DELETE',
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 0.5,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'sku',
                        name: 'sku'
                    },
                    {
                        data: 'item_name',
                        name: 'item_name'
                    },
                    {
                        data: 'category',
                        name: 'category',
                    },
                    {
                        data: 'item_type',
                        name: 'item_type'
                    },
                    {
                        data: 'unit',
                        name: 'unit'
                    },
                    {
                        data: 'status',
                        name: 'status'
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return '<div class="btn-group dropleft"><button type="button" class="btn btn-sm dropdown-toffle hide-arrow" data-toggle="dropdown" arial-haspopup="true" arial-expanded="false"><i class="fa fa-ellipsis-v"></i></button><div class = "dropdown-menu" >' +
                                ' <a  class ="dropdown-item productInfo" title="show" onclick = "productInfoFn(' +
                                data
                                .id +
                                ')"><i class="fa fa-info"></i><span> Info </span></a>' +
                                '<a class = "dropdown-item productEdit" onclick = "productEditFn(' +
                                data
                                .id +
                                ')" id = "dteditbtn" title = "Open item update page" data - id = "' +
                                data.id +
                                '"><i class="fa fa-edit"></i><span> Edit </span></a>' +
                                '</div></div> ';
                        },
                        orderable: false,
                        searchable: false
                    }
                ],
                "fnRowCallback": function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                    if (aData.status == "Active") {
                        $(nRow).find('td:eq(6)').css({
                            "color": "#4CAF50",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #4CAF50"
                        });
                    } else if (aData.status == "Inactive") {

                        $(nRow).find('td:eq(6)').css({
                            "color": "#f44336",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #f44336"
                        });
                    }
                }
            });
            /* End: Yajra data table*/
            $('#laravel-datatable-product tbody').on('click', 'tr', function() {
                if ($(this).hasClass('selected')) {
                    $(this).removeClass('selected');
                } else {
                    $('tr.selected').removeClass('selected');
                    $(this).addClass('selected');
                }
            });

            $('#status').select2({
                minimumResultsForSearch: -1
            });
        });
        ctable.on('draw', function() {
            var body = $(ctable.table().body());
            body.unhighlight();
            body.highlight(ctable.search());
        })
    </script>
    <script>
        $('.add').click(function() {
            $('#edit_id').val('');
            $('#categorylbl').html('Add Item');
            $('#item_name').val('');
            $('#category_id').val('').trigger('change');
            $('#unit_id').val('').trigger('change');
            $('#status').val('Active').trigger('change');
            $('#mySelect').val(null).trigger('change');
            $('#item_type').val('');
            $('#item_expiration_status').val('');
            $('#item-error').html('');
            $('#category-error').html('');
            $('#fixed-error').html('');
            $('#unit-error').html('');
            $('#status-error').html('');
            $('#category_id').select2({
                placeholder: "Select Category here",
            });
            $('#unit_id').select2({
                placeholder: "Select Unit here",
            });
            $('#item_type').select2({
                placeholder: "Select item type here",
            });
            $('#item_expiration_status').select2({
                placeholder: "Select expiration status here",
            });

            $.get('/getsku', function(data) {
                $('#SKU').val(data.sku);
            });
            $('#savenewbutton').css('display', 'flex');
            $('#savebutton').html('Save & Close');
            $('#savenewbutton').html('Save & New');
            $('#savenewbutton').prop("disabled", false);
            $('#savebutton').prop("disabled", false);
            $('#inlineForm').modal('show');
        });
        $('#savebutton').click(function() {
            var productForm = $('#Register');
            var formData = productForm.serialize();
            var id = $('#edit_id').val();
            $.ajax({
                url: '/createupdateproduct/' + id,
                type: 'post',
                data: formData,
                beforeSend: function() {
                    cardSection.block({
                        message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                        css: {
                            backgroundColor: 'transparent',
                            color: '#fff',
                            border: '0'
                        },
                        overlayCSS: {
                            opacity: 0.5
                        }
                    });
                    if (id != "" && id != null) {
                        $('#savebutton').text('Updating...');
                        $('#savebutton').prop("disabled", true);
                    } else {
                        $('#savebutton').text('Saving...');
                        $('#savebutton').prop("disabled", true);
                    }

                },
                complete: function() {
                    cardSection.block({
                        message: '',
                        timeout: 1,
                        css: {
                            backgroundColor: '',
                            color: '',
                            border: ''
                        },
                    });
                },
                success: function(data) {
                    if (data.errors) {
                        if (data.errors.item_name) {
                            $('#item-error').html(data.errors.item_name[0]);
                        }
                        if (data.errors.category_id) {
                            $('#category-error').html(data.errors.category_id[0]);
                        }
                        if (data.errors.item_type) {
                            $('#fixed-error').html(data.errors.item_type[0]);
                        }
                        if (data.errors.item_expiration_status) {
                            $('#expiration-error').html(data.errors.item_expiration_status[0]);
                        }
                        if (data.errors.identifyed_by) {
                            $('#identifyed-error').html(data.errors.identifyed_by[0]);
                        }
                        if (data.errors.unit_id) {
                            $('#unit-error').html(data.errors.unit_id[0]);
                        }
                        if (data.errors.status) {
                            $('#status-error').html(data.errors.status[0]);
                        }
                        if (id != "" && id != null) {
                            $('#savebutton').text('Update');
                        } else {
                            $('#savebutton').text('Save & Close');
                        }
                        alert_toast('An Error occured', 'error');
                        $('#savebutton').prop("disabled", false);
                    } else if (data.success) {
                        alert_toast(data.success, 'success');
                        var cTable = $('#laravel-datatable-product').dataTable();
                        cTable.fnDraw(false);
                        $('#savebutton').html('Save & Close');
                        $('#savebutton').prop("disabled", false);
                        $('#inlineForm').modal('hide');
                    }
                }

            });
        });

        $('#savenewbutton').click(function() {
            var productForm = $('#Register');
            var formData = productForm.serialize();
            var id = $('#edit_id').val();
            $.ajax({
                url: '/createupdateproduct/' + id,
                type: 'post',
                data: formData,
                beforeSend: function() {
                    cardSection.block({
                        message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                        css: {
                            backgroundColor: 'transparent',
                            color: '#fff',
                            border: '0'
                        },
                        overlayCSS: {
                            opacity: 0.5
                        }
                    });
                    $('#savenewbutton').text('Saving...');
                    $('#savenewbutton').prop("disabled", true);
                },
                complete: function() {
                    cardSection.block({
                        message: '',
                        timeout: 1,
                        css: {
                            backgroundColor: '',
                            color: '',
                            border: ''
                        },
                    });
                },
                success: function(data) {
                    if (data.errors) {
                        if (data.errors.item_name) {
                            $('#item-error').html(data.errors.item_name[0]);
                        }
                        if (data.errors.category_id) {
                            $('#category-error').html(data.errors.category_id[0]);
                        }
                        if (data.errors.item_type) {
                            $('#fixed-error').html(data.errors.item_type[0]);
                        }
                        if (data.errors.item_expiration_status) {
                            $('#expiration-error').html(data.errors.item_expiration_status[0]);
                        }
                        if (data.errors.identifyed_by) {
                            $('#identifyed-error').html(data.errors.identifyed_by[0]);
                        }
                        if (data.errors.unit_id) {
                            $('#unit-error').html(data.errors.unit_id[0]);
                        }
                        if (data.errors.status) {
                            $('#status-error').html(data.errors.status[0]);
                        }
                        if (id != "" && id != null) {
                            $('#savebutton').text('Update');
                        } else {
                            $('#savebutton').text('Save & Close');
                        }
                        $('#savenewbutton').text('Save & New');
                        alert_toast('Check your input?', 'error');
                        $('#savenewbutton').prop("disabled", false);
                    } else if (data.success) {
                        alert_toast(data.success, 'success');
                        var cTable = $('#laravel-datatable-product').dataTable();
                        cTable.fnDraw(false);
                        closeModal();
                        $('#inlineForm').modal('show');
                    }
                }

            });
        });

        function productEditFn(record_id) {
            $('#categorylbl').html('Edit Item');
            $('#edit_id').val(record_id);
            $('#savenewbutton').css('display', 'none');
            $('#savebutton').html('Update');
            $.get('/editproduct/' + record_id, function(data) {
                $('#item_name').val(data.product.item_name);
                $('#category_id').val(data.product.category_id).trigger('change');
                $('#unit_id').val(data.product.unit_id).trigger('change');
                $('#status').val(data.product.status).trigger('change');
                $('#SKU').val(data.product.sku);
                $('#item_type').val(data.product.item_type).trigger('change');
                $('#item_expiration_status').val(data.product.item_expiration_status).trigger('change');
                $('#mySelect').val(data.product.identifyed_by).trigger('change');
            });
            $('#inlineForm').modal('show');
        }

        function productDeleteFn(record_id) {
            $('#deleteing_id').val(record_id);
            $('#DeleteModal').modal('show');
        }
        $('.delete_product').click(function() {
            var delete_id = $('#deleteing_id').val();
            $.ajax({
                url: '/deleteproduct/' + delete_id,
                type: 'get',
                beforeSend: function() {
                    $('.delete_product').text('Deleteing...');
                },
                success: function(data) {
                    if (data.errors) {
                        $('.delete_product').text('Delete');
                        alert_toast('an error occured', 'error');
                    } else if (data.success) {
                        $('.delete_product').text('Delete');
                        alert_toast(data.success, 'success')
                        var cTable = $('#laravel-datatable-product').dataTable();
                        cTable.fnDraw(false);
                        $('#DeleteModal').modal('hide');
                    }
                }
            });
        });

        function productInfoFn(record_id) {
            $('#sku_info').html('');
            $('#product_info').html('');
            $('#category_info').html('');
            $('#type_info').html('');
            $('#unit_info').html('');
            $('#createdat_info').html('');
            $('#createdby_info').html('');
            $('#updatedat_info').html('');
            $('#updatedby_info').html('');
            $.get("/showproduct" + '/' + record_id, function(data) {
                $.each(data.product, function(key, value) {
                    $("#sku_info").html(data.product.sku);
                    $("#item_info").html(data.product.item_name);
                    $("#category_info").html(data.category_id.name);
                    var item_type = data.product.item_type;
                    if (item_type == "2") {
                        $("#type_info").html("None Fixed Item");
                    } else if (item_type == "1") {
                        $("#type_info").html("Fixed Item");
                    }
                    var item_expiration_status = data.product.item_expiration_status;
                    if (item_expiration_status == "2") {
                        $("#expiration_info").html("Has No Expiration Date");
                    } else if (item_expiration_status == "1") {
                        $("#expiration_info").html("Has Expiration Date");
                    }
                    $('#identifyed_info').html(data.product.identifyed_by);
                    $("#unit_info").html(data.unit_id.name);
                    $('#createdby_info').html(data.cr.username);
                    $('#updatedby_info').html(data.ur.username);
                    $('#createdat_info').html(data.crdate);

                    if (data.ur !== "") {
                        $('#updatedat_info').html(data.upgdate);
                    }
                    var st = data.product.status;

                    if (st == "Active") {
                        $("#status_info").html("<b style='color:#1cc88a'>" + data.product.status + "</b>");
                    }
                    if (st == "Inactive") {
                        $("#status_info").html("<b style='color:#e74a3b'>" + data.product.status + "</b>");
                    }

                });
            });
            $('#infoModal').modal('show');
        }
        // $("#informationmodal").modal('show');
    </script>
    <script>
        function removeNameValidation() {
            $('#item-error').html('');
        }

        function removeStatusValidation() {
            $('#status-error').html('');
        }

        function removeCategoryValidation() {
            $('#category-error').html('');
        }

        function removeUnitValidation() {
            $('#unit-error').html('');
        }

        function removeExpirationValidation() {
            $('#expiration-error').html('');
        }

        function removeTypeValidation() {
            $('#fixed-error').html('');
        }

        function removeIdentifyiedValidation() {
            $('#identifyed-error').html('');
        }

        function closeModal() {

            $('#edit_id').val('');
            $('#item_name').val('');
            $('#fixed-error').html('');
            $('#category_id').val('').trigger('change');
            $('#type_id').val('').trigger('change');
            $('#unit_id').val('').trigger('change');
            $('#mySelect').val(null).trigger('change');
            $('#status').val('Active').trigger('change');
            $('#item_expiration_status').val('');
            $('#item_type').val('');
            $('#item-error').html('');
            $('#category-error').html('');
            $('#type-error').html('');
            $('#unit-error').html('');
            $('#status-error').html('');
            $('#identifyed-error').html('');
            $('#expiration-error').html('');
            $('#category_id').select2({
                placeholder: "Select Category here",
            });
            $('#item_type').select2({
                placeholder: "Select item type here",
            });
            $('#item_expiration_status').select2({
                placeholder: "Select item expiration status here",
            });
            $('#type_id').select2({
                placeholder: "Select Type here",
            });
            $('#unit_id').select2({
                placeholder: "Select Unit here",
            });
            $.get('/getsku', function(data) {
                $('#SKU').val(data.sku);
            });
            $('#savenewbutton').css('display', 'flex');
            $('#savebutton').html('Save & Close');
            $('#savenewbutton').html('Save & New');
            $('#savenewbutton').prop("disabled", false);
            $('#savebutton').prop("disabled", false);
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Werabe University Project\Werabe University Project\resources\views\registry\products.blade.php ENDPATH**/ ?>