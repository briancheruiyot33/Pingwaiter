<?php $__env->startSection('content'); ?>
    <div class="app-content content">
        <section id="responsive-datatable">
            <div id="success_message" style="padding: 13px 20px;"></div>
            <div class="row">
                <div class="col-12">
                    <!-- Your HTML content goes here -->
                    <div class="card">
                        <div class="card-header border-bottom">
                            <h3 class="card-title">Penging Requests</h3>


                        </div>
                        <div class="card-datatable">
                            <div style="width:98%; margin-left:1%;">
                                <div class="table-responsive">

                                    <table id="laravel-datatable-campus"
                                        class="display table-bordered table-striped table-hover dt-responsive mb-0 dataTable no-footer"
                                        style="width: 100%;" role="grid" aria-describedby="laravel-datatable-crud_info">
                                        <thead>
                                            <tr role="row">
                                                <th style="width:7%;">#</th>
                                                <th>Date Received</th>
                                                <th>SKU</th>
                                                <th>Supplier Name</th>
                                                <th>Receiption Name</th>
                                                <th>Item No</th>
                                                <th>Status</th>
                                                <th style="width:5%;">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody></tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php echo $__env->make('campus-request.comman', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
            <div class="modal fade" id="requestModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel"></h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                                onclick="closeModalWithClearValidation()">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form id="request_approval">
                            <?php echo e(csrf_field()); ?>

                            <div class="modal-body">
                                <div class="form-group">
                                    <label strong>Approve or Reject Request</label>
                                    <select class="custom-select browser-default select2" name="approve_id" id="approve_id">
                                        <option value="3">Approved</option>
                                        <option value="1">Rejected</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="remark">Remark</label>
                                    <textarea name="remark" id="remark" class="form-control"></textarea>
                                </div>
                                <input type="hidden" id="request_id" name="app_id">
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-info send_request">Submit</button>
                                <button id="closebutton" type="button" class="btn btn-danger"
                                    onclick="closeModalWithClearValidation()" data-dismiss="modal">Close</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        var diff = 0;
        var errorcolor = "#ffcccc";
        $(function() {
            cardSection = $('#page-block');
        });
        /* BEGIN: Display zone table using yajra datatable */
        $(document).ready(function() {
            var ctable = $('#laravel-datatable-campus').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                searchHighlight: true,
                dom: 'lBfrtip', // Add l before B to include lengthMenu
                buttons: [{
                        extend: 'copy',
                        title: 'Received Detail', // Title for the 'copy' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'csv',
                        title: 'Received Detail', // Title for the 'csv' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'excel',
                        title: 'Received Detail', // Title for the 'excel' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'pdf',
                        title: 'Received Detail', // Title for the 'pdf' button
                        orientation: 'landscape', // Set orientation: 'landscape' or 'portrait'
                        pageSize: 'A4', // Set page size
                        customize: function(doc) {
                            // Customize header, footer, and body style
                            doc.styles.tableHeader = {
                                fillColor: '#4CAF50',
                                color: 'white',
                                alignment: 'center'
                            };
                            doc.styles.title = {
                                fontSize: 14,
                                alignment: 'center'
                            };
                            doc.defaultStyle.fontSize = 10; // Change default font size
                            doc.content[1].table.widths = '*'.repeat(doc.content[1].table.body[0]
                                .length).split(''); // Automatically adjust column widths
                            doc.pageMargins = [10, 10, 10, 10]; // Adjust page margins
                            doc.pageSize = 'A4'; // Ensure the page size is A4
                            doc.content[1].layout = {
                                hLineWidth: function(i, node) {
                                    return (i === 0 || i === node.table.body.length) ? 2 :
                                        1;
                                },
                                vLineWidth: function(i, node) {
                                    return (i === 0 || i === node.table.widths.length) ? 2 :
                                        1;
                                },
                                hLineColor: function(i, node) {
                                    return (i === 0 || i === node.table.body.length) ?
                                        'black' : 'gray';
                                },
                                vLineColor: function(i, node) {
                                    return (i === 0 || i === node.table.widths.length) ?
                                        'black' : 'gray';
                                },
                                paddingLeft: function(i, node) {
                                    return 4;
                                },
                                paddingRight: function(i, node) {
                                    return 4;
                                },
                                paddingTop: function(i, node) {
                                    return 2;
                                },
                                paddingBottom: function(i, node) {
                                    return 2;
                                },
                            };
                        },
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'print',
                        title: 'Received Detail',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5] // Indexes of the columns you want to include
                        }
                    }
                ],
                lengthMenu: [
                    [10, 25, 50, 500, -1],
                    [10, 25, 50, 500, "All"]
                ],
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: '/getcampusrequest/' + 2,
                    type: 'DELETE',
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'date_created',
                        name: 'date_created'
                    },
                    {
                        data: 'sku',
                        name: 'sku'
                    },
                    {
                        data: 'supplier',
                        name: 'supplier'
                    },
                    {
                        data: 'receiption',
                        name: 'receiption'
                    },
                    {
                        data: 'item_no',
                        name: 'item_no'
                    },
                    {
                        data: 'status',
                        name: 'status'
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return '<div class="btn-group dropleft"><button type="button" class="btn btn-sm dropdown-toffle hide-arrow" data-toggle="dropdown" arial-haspopup="true" arial-expanded="false"><i class="fa fa-ellipsis-v"></i></button><div class = "dropdown-menu" > <a class="dropdown-item campusInfo" onclick="campusInfoFn(' +
                                data.id +
                                ')" id="dtinfobtn" title="Open campus information page" data-id = "' +
                                data.id +
                                '"><i class="fa fa-info"></i><span> Info </span></a>' +
                                '<a class = "dropdown-item campusApprove" onclick = "requestFn(' +
                                data
                                .id +
                                ')" id = "request" title = "request" data-id = "' +
                                data.id +
                                '"><i class="fa fa-check-circle" style="padding-top: 3px;"></i>&nbsp;<span> Request Approvale</span></a></div></div> ';
                        },
                        orderable: false,
                        searchable: false
                    }
                ],
                "fnRowCallback": function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                    if (aData.status == "2") {
                        $(nRow).find('td:eq(6)').html('Pending');
                        $(nRow).find('td:eq(6)').css({
                            "color": "blue",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #f44336"
                        });
                    }
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_clinic')): ?>
                        $(nRow).find('.campusApprove').css({
                            'display': 'none'
                        });
                    <?php endif; ?>
                }
            });
            ctable.on('draw', function() {
                var body = $(ctable.table().body());
                body.unhighlight();
                body.highlight(ctable.search());
            })
        });
    </script>
    <script>
        var state = false;

        function viewCode() {
            state = !state;
            if (state === true) {
                $('#clickcode').html('click to hide code');
                $('#viewcode').css({
                    "background": "white",
                    "color": "black",
                })
            } else {
                $('#clickcode').html('click to show code');
                $('#viewcode').css({
                    "background": "gray",
                    "color": "gray",
                })
            }
        }

        function campusInfoFn(record_id) {
            // $("#informationmodal").modal('show');
            $.get("/show_campusStore" + '/' + record_id, function(data) {
                $.each(data.campus, function(key, value) {
                    $("#incoming_info").html(data.campus.item_no);
                    $("#receiption_info").html(data.campus.receiption);
                    $("#sku_info").html(data.campus.sku);
                    $("#supplier_info").html(data.campus.supplier);
                    $("#date_created_info").html(data.campus.date_created);
                    $("#created_by").html(data.cr.username);
                    $("#updated_by").html(data.ur.username);
                    //var st = data.zone.status;
                    var ca = new Date(data.campus.created_at);

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_clinic')): ?>
                        $('#viewcode').html(data.campus.code);
                    <?php endif; ?>
                    $("#created_at").html(data.crdate);

                    if (data.ur !== "") {
                        $("#updated_at").html(data.upgdate);
                    }
                });
            });

            $('#productdetailtbl').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                searchHighlight: true,
                dom: 'lBfrtip', // Add l before B to include lengthMenu
                buttons: [{
                        extend: 'copy',
                        title: 'Your Title Here' // Title for the 'copy' button
                    },
                    {
                        extend: 'csv',
                        title: 'Your Title Here' // Title for the 'csv' button
                    },
                    {
                        extend: 'excel',
                        title: 'Your Title Here' // Title for the 'excel' button
                    },
                    {
                        extend: 'pdf',
                        title: 'Your Title Here' // Title for the 'pdf' button
                    },
                    {
                        extend: 'print',
                        title: 'Yout title here'
                    }
                ],
                lengthMenu: [
                    [10, 25, 50, 500, -1],
                    [10, 25, 50, 500, "All"]
                ],
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: '/campusInfo/' + record_id,
                    type: 'DELETE',
                    dataType: "json",
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },

                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'expired_date',
                        name: 'expired_date',
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return '<p class="rem"></p>';
                        },
                        orderable: true,
                        searchable: true
                    },
                    {
                        data: 'seriel_number',
                        name: 'seriel_number',
                    },
                    {
                        data: 'product.item_name',
                        name: 'product.item_name',
                    },
                    {
                        data: 'product.category.name',
                        name: 'product.category.name',
                    },
                    {
                        data: 'unit',
                        name: 'unit',
                    },
                    {
                        data: 'total_quantity',
                        name: 'total_quantity',
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return '<a class="btn btn-info productInfo" onclick="productInfoFn(' +
                                data.id +
                                ')" id="dtinfobtn" title="Open product information page" data-id = "' +
                                data.id +
                                '"><span> Detail </span></a> ';
                        },
                        orderable: false,
                        searchable: false
                    }
                ],
                "fnRowCallback": function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                    if (aData.product.item_expiration_status == '1') {
                        diff = calculateRemainingDays(aData.expired_date);
                        if (diff == "1") {
                            $(nRow).find('.rem').html('None');
                        } else if (diff > 0) {
                            $(nRow).find('.rem').html(diff);
                        } else if (diff === 0) {
                            $(nRow).find('.rem').html("Product expires today.");
                        } else {
                            $(nRow).find('.rem').html("Product has expired.");
                        }
                    } else {
                        $(nRow).find('.rem').html('None');
                    }

                }
            });
            $(".collapse").collapse('show');
            $('#informationModal').modal('show');
        }

        function calculateRemainingDays(expireDate) {
            if (expireDate == "Has No Expired Date") {
                var exprt = "1";
                return exprt;
            }
            // Parse the expiration date string to Date object
            const expiryDate = new Date(expireDate);

            // Get current date
            const currentDate = new Date();

            // Calculate difference in milliseconds
            const differenceMs = expiryDate.getTime() - currentDate.getTime();
            // Convert milliseconds to days
            const remainingDays = Math.ceil(differenceMs / (1000 * 60 * 60 * 24));
            return remainingDays;


        }

        function productInfoFn(rec_id) {
            $.get("/productDetail" + '/' + rec_id, function(data) {
                if (data.store) {

                    $('#quantity_info').html(data.quantity);
                    var unit_price = parseFloat(data.store.unit_price).toLocaleString('en-US', {
                        style: 'decimal',
                        maximumFractionDigits: 2,
                        minimumFractionDigits: 2
                    });
                    var total_price = parseFloat(data.store.total_price).toLocaleString('en-US', {
                        style: 'decimal',
                        maximumFractionDigits: 2,
                        minimumFractionDigits: 2
                    });
                    $('#unitprice_info').html(unit_price + ' Birr');
                    $('#total_info').html(total_price + ' Birr');
                    $('#seriel_info').html(data.store.seriel_number);
                    if (data.product.item_expiration_status == '1') {
                        $('#expired_info').html(data.store.expired_date);
                    } else {
                        $('#expired_info').html('Not Expired');
                    }
                    $('#quality_info').html(data.store.quality.name);
                    $('#capacity_info').html(data.product.unit.capacity);
                    $('#voucher_info').html(data.store.voucher_no);
                }
                if (data.product) {
                    $('#product_info').html(data.product.item_name);
                    $('#category_info').html(data.product.category.name);
                    $('#unit_info').html(data.product.unit.name + " (" + data.product.unit.package + ")");
                }
                if (data.product.item_expiration_status == '1') {
                    diff = calculateRemainingDays(data.store.expired_date);
                    if (diff > 0) {
                        $('#remaining_info').html(diff);
                    } else if (diff === 0) {
                        $('#remaining_info').html("Product expires today.");
                    } else {
                        $('#remaining_info').html("Product has expired.");
                    }
                } else {
                    $('#remaining_info').html('Not Expired!');
                }


            });
            $('#infoModal').modal('show');
        }

        function requestFn(record_id) {
            $.get("/checkApprove" + '/' + record_id, function(data) {
                if (data.success) {
                    $('#request_id').val(record_id);
                    $('#requestModal').modal('show');

                } else {
                    alert_toast('There is no request', 'error');
                }
            });

        }

        $(document).on('click', '.send_request', function() {
            var requestData = $('#request_approval');
            var formData = requestData.serialize();
            $.ajax({
                url: '/approveRequest',
                type: 'post',
                data: formData,
                beforeSend: function() {
                    $('.send_request').text('Submitting...');
                },
                success: function(data) {
                    if (data.success) {
                        $('#requestModal').modal('hide');
                        $('.send_request').html('Submit');
                        alert_toast('Successfully Decision is submitted!', 'success');
                        var cTable = $('#laravel-datatable-campus').dataTable();
                        cTable.fnDraw(false);
                    } else {
                        $('.send_request').html('Submit');
                        alert_toast('Something wrong!', 'error');
                    }
                }
            });
        });

        function calculateRemainingDays(expireDate) {
            // Parse the expiration date string to Date object
            const expiryDate = new Date(expireDate);

            // Get current date
            const currentDate = new Date();

            // Calculate difference in milliseconds
            const differenceMs = expiryDate.getTime() - currentDate.getTime();

            // Convert milliseconds to days
            const remainingDays = Math.ceil(differenceMs / (1000 * 60 * 60 * 24));

            return remainingDays;
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Werabe University Project\Werabe University Project\resources\views\campus-request\pending.blade.php ENDPATH**/ ?>