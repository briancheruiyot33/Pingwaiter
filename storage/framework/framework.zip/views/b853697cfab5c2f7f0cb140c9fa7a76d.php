<?php $__env->startSection('title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="app-content content">
        <section id="responsive-datatable" style="font-size: 12px;">
            <div class="row">
                <div class="col-12">
                    <!-- Your HTML content goes here -->
                    <div class="card">
                        <div class="card-header border-bottom">
                            <h3 class="card-title">Emergency Patients</h3>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_doctor')): ?>
                                <button type="button" class="btn btn-gradient-info btn-sm add">Add</button>
                            <?php endif; ?>
                        </div>
                        <div class="card-datatable">
                            <div style="width:98%; margin-left:1%;">
                                <div class="table-responsive">

                                    <table id="laravel-datatable-patient"
                                        class="display table-bordered table-striped table-hover dt-responsive mb-0 dataTable no-footer"
                                        style="width: 100%;" role="grid" aria-describedby="laravel-datatable-user">

                                        <thead>
                                            <tr role="row">
                                                <th scope="col" width="1%">#</th>
                                                <th nowrap>Date</th>
                                                <th nowrap="1">Full Name</th>
                                                <th nowrap="1">Occupation</th>
                                                <th nowrap="1">Sex</th>
                                                <th nowrap="1">Age</th>
                                                <th nowrap="1">description</th>
                                                <th nowrap="1">Prescriped By</th>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_clinic_leader')): ?>
                                                <?php else: ?>
                                                    <th nowrap="1">Action</th>
                                                <?php endif; ?>
                                            </tr>
                                        </thead>
                                        <tbody></tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
    <!-- BEGIN: Emergency Add modal  -->
    <div class="modal fade text-left" id="inlineForm" data-keyboard="false" data-backdrop="static" tabindex="-1"
        role="dialog" aria-labelledby="patientlbl" aria-hidden="true" style="overflow-y: scroll;">
        <div class="modal-dialog modal-xl" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="patientlbl">Add patient</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="closeModal()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="Register">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="edit_id" id="edit_id">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-4">
                                <label strong style="font-size: 16px;">Full Name</label><label
                                    style="color: red; font-size:16px;">*</label>
                                <div class="form-group">
                                    <input type="text" placeholder="Write Patient Name here" class="form-control"
                                        name="name" id='name' autofocus onkeyup="removeNameValidation()" />
                                    <span class="text-danger">
                                        <strong id="name-error"></strong>
                                    </span>
                                </div>

                            </div>
                            <div class="col-md-4">
                                <label strong style="font-size: 16px;">Occupation</label><label
                                    style="color: red; font-size:16px;">*</label>
                                <div class="form-group">
                                    <input type="text" placeholder="Write Occupation here" class="form-control"
                                        name="occupation" id='occupation' autofocus
                                        onkeyup="removeOccupationValidation()" />
                                    <span class="text-danger">
                                        <strong id="occupation-error"></strong>
                                    </span>
                                </div>

                            </div>
                            <div class="col-md-4">
                                <label strong style="font-size: 16px;">Age</label>
                                <label style="color: red; font-size:16px;">*</label>
                                <div class="form-group">
                                    <input type="number" placeholder="Write Age here" class="form-control" name="age"
                                        id='age' autofocus onkeyup="removeAgeValidation()" />
                                    <span class="text-danger">
                                        <strong id="age-error"></strong>
                                    </span>
                                </div>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <label strong style="font-size: 16px;">Sex</label><label
                                    style="color: red; font-size:16px;">*</label>

                                <div class="form-group">
                                    <div>
                                        <select class="custom-select browser-default select2" name="sex" id="sex"
                                            onchange="removeSexValidation()">
                                            <option value=""></option>
                                            <option value="Male">Male</option>
                                            <option value="Female">Female</option>
                                        </select>
                                        <span class="text-danger">
                                            <strong id="sex-error"></strong>
                                        </span>
                                    </div>
                                </div>

                            </div>
                            <div class="col-md-4">
                                <label strong style="font-size: 16px;">Description</label><label
                                    style="color: red; font-size:16px;">*</label>
                                <div class="form-group">
                                    <div>
                                        <textarea placeholder="Write description here.." name="description" id="description" class="form-control"
                                            onkeyup="removeDescriptionValidation()"></textarea>
                                        <span class="text-danger">
                                            <strong id="description-error"></strong>
                                        </span>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button id="savebutton" type="button" class="btn btn-info">Save & Close</button>
                        <button id="closebutton" type="button" class="btn btn-danger" onclick="closeModal()"
                            data-dismiss="modal">Close</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- BEGIN: Info modal -->
    <div class="modal fade text-left" id="detailModal" data-keyboard="false" data-backdrop="static" tabindex="-1"
        role="dialog" aria-labelledby="myModalLabel133" aria-hidden="true" style="overflow-y: scroll;">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Patient detail</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <table style="width: 100%;">
                        <tbody>
                            <tr>
                                <td style="width: 40%">
                                    <label style="font-size: 14px;">Full Name: </label>
                                </td>
                                <td style="width: 60%">
                                    <label id="name_info" style="font-size: 14px; font-weight: bold;"></label>
                                </td>
                            </tr>
                            <tr>
                                <td style="width: 40%">
                                    <label style="font-size: 14px;">Occupation: </label>
                                </td>
                                <td style="width: 60%">
                                    <label id="occupation_info" style="font-size: 14px; font-weight: bold;"></label>
                                </td>
                            </tr>
                            <tr>
                                <td style="width: 40%">
                                    <label style="font-size: 14px;">Age: </label>
                                </td>
                                <td style="width: 60%">
                                    <label id="age_info" style="font-size: 14px; font-weight: bold;"></label>
                                </td>
                            </tr>
                            <tr>
                                <td style="width: 40%">
                                    <label style="font-size: 14px;">Sex: </label>
                                </td>
                                <td style="width: 60%">
                                    <label id="sex_info" style="font-size: 14px; font-weight: bold;"></label>
                                </td>
                            </tr>
                            <tr>
                                <td style="width: 40%">
                                    <label style="font-size: 14px;">Doctor Description: </label>
                                </td>
                                <td style="width: 60%">
                                    <label id="description_info" style="font-size: 14px; font-weight: bold;"></label>
                                </td>
                            </tr>
                            <tr>
                                <td style="width: 40%">
                                    <label style="font-size: 14px;">Pharmacy Desription: </label>
                                </td>
                                <td style="width: 60%">
                                    <label id="pharmacy_info" style="font-size: 14px; font-weight: bold;"></label>
                                </td>
                            </tr>
                            <tr>
                                <td style="width: 40%">
                                    <label style="font-size: 14px;">Labratory Desription: </label>
                                </td>
                                <td style="width: 60%">
                                    <label id="labratory_info" style="font-size: 14px; font-weight: bold;"></label>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2">
                                    <div class="divider newext">
                                        <div class="divider-text">Action Information</div>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label style="font-size: 14px;">Created By</label>
                                </td>
                                <td>
                                    <label id="createdby_info" style="font-size: 14px; font-weight: bold;"></label>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label style="font-size: 14px;">Created Date</label>
                                </td>
                                <td>
                                    <label id="createdat_info" style="font-size: 14px; font-weight: bold;"></label>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="modal-footer">
                    <button id="closebuttonk" type="button" class="btn btn-danger waves-effect waves-float waves-light"
                        data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade text-left" id="pharmacyModal" data-keyboard="false" data-backdrop="static" tabindex="-1"
        role="dialog" aria-labelledby="phar" aria-hidden="true" style="overflow-y: scroll;">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="appointbl">Send to pharmacy</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="cll()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <input type="hidden" name="pharmacy_id" id="pharmacy_id">
                <div class="modal-body">

                    <label strong>Do you really want to
                        send to pharmacy?</label>
                </div>
                <div class="modal-footer">
                    <button id="sendPharmacy" type="button" class="btn btn-info">Send</button>
                    <button id="closebutton" type="button" class="btn btn-danger" onclick="closeModal()"
                        data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade text-left" id="labratoryModal" data-keyboard="false" data-backdrop="static" tabindex="-1"
        role="dialog" aria-labelledby="phar" aria-hidden="true" style="overflow-y: scroll;">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="appointbl">Send to labratory</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="cll()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <input type="hidden" name="labratory_id" id="lab_id">
                <div class="modal-body">
                    <label strong>Do you really want to
                        send to labratory?</label>
                </div>
                <div class="modal-footer">
                    <button id="sendLabratory" type="button" class="btn btn-info">Send</button>
                    <button id="closebutton" type="button" class="btn btn-danger" onclick="closeModal()"
                        data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>


    <div class="modal fade text-left" id="actionLabratoryModal" data-keyboard="false" data-backdrop="static"
        tabindex="-1" role="dialog" aria-labelledby="phar" aria-hidden="true" style="overflow-y: scroll;">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="appointbl">write description</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="cll()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <input type="hidden" name="lb_id" id="lb_id">
                <div class="modal-body">
                    <div class="form-group">
                        <label strong>Remark</label>
                        <textarea name="description" id="lab_description" class="form-control" required placeholder="write remark here"></textarea>
                    </div>

                </div>
                <div class="modal-footer">
                    <button id="actionLabratory" type="button" class="btn btn-info">Save</button>
                    <button id="closebutton" type="button" class="btn btn-danger" onclick="closeModal()"
                        data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade text-left" id="actionPharmacyModal" data-keyboard="false" data-backdrop="static"
        tabindex="-1" role="dialog" aria-labelledby="phar" aria-hidden="true" style="overflow-y: scroll;">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="appointbl">Write remark</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="cll()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-body">
                    <input type="hidden" name="ph_id" id="ph_id">
                    <label strong>Remark</label>
                    <textarea name="description" id="pharmacy_description" class="form-control" required
                        placeholder="write description here"></textarea>
                </div>
                <div class="modal-footer">
                    <button id="actionPharmacy" type="button" class="btn btn-info">Save</button>
                    <button id="closebutton" type="button" class="btn btn-danger" onclick="closeModal()"
                        data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        var current_date = moment();
        var current_date = current_date.format('MMMM D, YYYY');
        $('#date').val(current_date);
        var errorcolor = "#ffcccc";
        $(function() {
            cardSection = $('#page-block');
        });
        /* BEGIN: Display zone table using yajra datatable */
        $(document).ready(function() {
            var ctable = $('#laravel-datatable-patient').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                searchHighlight: true,
                dom: 'lBfrtip', // Add l before B to include lengthMenu
                buttons: [{
                        extend: 'copy',
                        title: 'Your Title Here' // Title for the 'copy' button
                    },
                    {
                        extend: 'csv',
                        title: 'Your Title Here' // Title for the 'csv' button
                    },
                    {
                        extend: 'excel',
                        title: 'Your Title Here' // Title for the 'excel' button
                    },
                    {
                        extend: 'pdf',
                        title: 'Your Title Here' // Title for the 'pdf' button
                    },
                    {
                        extend: 'print',
                        title: 'Yout title here'
                    }
                ],
                lengthMenu: [
                    [10, 25, 50, 500, -1],
                    [10, 25, 50, 500, "All"]
                ],
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: '/getemergency',
                    type: 'DELETE',
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'created_at',
                        name: 'created_at'
                    },
                    {
                        data: 'name',
                        name: 'name'
                    },
                    {
                        data: 'occupation',
                        name: 'occupation'
                    },
                    {
                        data: 'sex',
                        name: 'sex'
                    },
                    {
                        data: 'age',
                        name: 'age'
                    },
                    {
                        data: 'description',
                        name: 'description'
                    },
                    {
                        data: 'user.name',
                        name: 'user.name'
                    },
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_doctor')): ?>
                        {
                            data: null,
                            render: function(data, type, full, meta) {
                                return '<div class="btn-group dropleft"><button type="button" class="btn btn-sm dropdown-toffle hide-arrow" data-toggle="dropdown" arial-haspopup="true" arial-expanded="false"><i class="fa fa-ellipsis-v"></i></button><div class = "dropdown-menu" > ' +
                                    '<a class = "dropdown-item categoryEdit" onclick = "viewDetail(' +
                                    data
                                    .id +
                                    ')" id = "dteditbtn" title = "View Detail" data - id = "' +
                                    data.id +
                                    '"><i class="fa fa-eye"></i><span> View detail </span></a>' +
                                    '<a class = "dropdown-item categoryEdit" onclick = "sendPharmacy(' +
                                    data
                                    .id +
                                    ')" id = "dteditbtn" title = "send to pharmacy" data - id = "' +
                                    data.id +
                                    '"><i class="fa fa-paper-plane"></i><span> Send to pharmacy </span></a>' +
                                    '<a class = "dropdown-item categoryEdit" onclick = "sendLabratory(' +
                                    data
                                    .id +
                                    ')" id = "dteditbtn" title = "send to labratory" data - id = "' +
                                    data.id +
                                    '"><i class="fa fa-paper-plane"></i><span> Send to labratory </span></a>' +
                                    '</div></div> ';
                            },
                            orderable: false,
                            searchable: false
                        }
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_pharmacy')): ?>
                        {
                            data: null,
                            render: function(data, type, full, meta) {
                                return '<div class="btn-group dropleft"><button type="button" class="btn btn-sm dropdown-toffle hide-arrow" data-toggle="dropdown" arial-haspopup="true" arial-expanded="false"><i class="fa fa-ellipsis-v"></i></button><div class = "dropdown-menu" > ' +
                                    '<a class = "dropdown-item categoryEdit" onclick = "viewDetail(' +
                                    data
                                    .id +
                                    ')" id = "dteditbtn" title = "View Detail" data - id = "' +
                                    data.id +
                                    '"><i class="fa fa-eye"></i><span> View detail </span></a>' +
                                    '<a class = "dropdown-item pharmacy" onclick = "addActionPharmacy(' +
                                    data
                                    .id +
                                    ')" id = "dteditbtn" title = "add operation" data - id = "' +
                                    data.id +
                                    '"><i class="fa fa-paper-plane"></i><span> Add operation </span></a>' +
                                    '</div></div> ';
                            },
                            orderable: false,
                            searchable: false
                        }
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_labratory')): ?>
                        {
                            data: null,
                            render: function(data, type, full, meta) {
                                return '<div class="btn-group dropleft"><button type="button" class="btn btn-sm dropdown-toffle hide-arrow" data-toggle="dropdown" arial-haspopup="true" arial-expanded="false"><i class="fa fa-ellipsis-v"></i></button><div class = "dropdown-menu" > ' +
                                    '<a class = "dropdown-item categoryEdit" onclick = "viewDetail(' +
                                    data
                                    .id +
                                    ')" id = "dteditbtn" title = "View Detail" data - id = "' +
                                    data.id +
                                    '"><i class="fa fa-eye"></i><span> View detail </span></a>' +
                                    '<a class = "dropdown-item lab" onclick = "addActionLabratory(' +
                                    data
                                    .id +
                                    ')" id = "dteditbtn" title = "add operation" data - id = "' +
                                    data.id +
                                    '"><i class="fa fa-paper-plane"></i><span> Add operation </span></a>' +
                                    '</div></div> ';
                            },
                            orderable: false,
                            searchable: false
                        }
                    <?php endif; ?>
                ],
                "fnRowCallback": function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                    if (aData.pharmacy_description == null || aData.pharmacy_description == "") {
                        $(nRow).find('.pharmacy').css({
                            "display": "flex",
                        });
                    } else {
                        $(nRow).find('.pharmacy').css({
                            "display": "none",
                        });
                    }
                    if (aData.lab_description == null || aData.lab_description == "") {
                        $(nRow).find('.lab').css({
                            "display": "flex",
                        });
                    } else {
                        $(nRow).find('.lab').css({
                            "display": "none",
                        });
                    }
                }
            });

            /* End: Yajra data table*/
            $('#laravel-datatable-patient tbody').on('click', 'tr', function() {
                if ($(this).hasClass('selected')) {
                    $(this).removeClass('selected');
                } else {
                    $('tr.selected').removeClass('selected');
                    $(this).addClass('selected');
                }
            });

            $('#status').select2({
                minimumResultsForSearch: -1
            });
        });
        ctable.on('draw', function() {
            var body = $(ctable.table().body());
            body.unhighlight();
            body.highlight(ctable.search());
        })

        function viewHistoryFn(record_id) {
            $('#historyModal').modal('show');
        }
    </script>
    <script>
        $('.add').click(function() {
            $('#name').val('');
            $('#description').val('');
            $('#occupation').val('');
            $('#age').val('');
            $('#name-error').html('');
            $('#occupation-error').html('');
            $('#age-error').html('');
            $('#description-error').html('');
            $('#savebutton').html('Save & Close');
            $('#sex').select2({
                placeholder: "Select Sex here",
            });
            $('#inlineForm').modal('show');
        });
        $('#savebutton').click(function() {
            var categoryForm = $('#Register');
            var formData = categoryForm.serialize();
            $.ajax({
                url: '/createupdateemergency',
                type: 'post',
                data: formData,
                beforeSend: function() {
                    cardSection.block({
                        message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                        css: {
                            backgroundColor: 'transparent',
                            color: '#fff',
                            border: '0'
                        },
                        overlayCSS: {
                            opacity: 0.5
                        }
                    });
                    $('#savebutton').text('Savining...');
                    $('#savebutton').prop("disabled", true);

                },
                complete: function() {
                    cardSection.block({
                        message: '',
                        timeout: 1,
                        css: {
                            backgroundColor: '',
                            color: '',
                            border: ''
                        },
                    });
                },
                success: function(data) {
                    if (data.errors) {
                        if (data.errors.name) {
                            $('#name-error').html(data.errors.name[0]);
                        }
                        if (data.errors.occupation) {
                            $('#occupation-error').html(data.errors.occupation[0]);
                        }
                        if (data.errors.sex) {
                            $('#sex-error').html(data.errors.sex[0]);
                        }
                        if (data.errors.description) {
                            $('#description-error').html(data.errors.description[0]);
                        }
                        if (data.errors.age) {
                            $('#age-error').html(data.errors.age[0]);
                        }
                        $('#savebutton').text('Save & Close');
                        alert_toast('Check your input?', 'error');
                        $('#savebutton').prop("disabled", false);
                    } else if (data.success) {
                        alert_toast(data.success, 'success');
                        var cTable = $('#laravel-datatable-patient').dataTable();
                        cTable.fnDraw(false);
                        $('#savebutton').html('Save & Close');
                        $('#savebutton').prop("disabled", false);
                        $('#inlineForm').modal('hide');
                    }
                }

            });
        });

        function viewDetail(record_id) {
            $('#name_info').html('');
            $('#occupation_info').html('');
            $('#age_info').html('');
            $('#sex_info').html('');
            $('#description_info').html('');
            $('#pharmacy_info').html('');
            $('#labratory_info').html('');
            $('#createdby_info').html('');
            $.get("/emergencyDetail" + '/' + record_id, function(data) {
                if (data.emergency) {
                    $("#name_info").html(data.emergency.name);
                    $("#occupation_info").html(data.emergency.occupation);
                    $("#age_info").html(data.emergency.age);
                    $("#sex_info").html(data.emergency.sex);
                    $("#description_info").html(data.emergency.description);
                    $("#pharmacy_info").html(data.emergency.pharmacy_description);
                    $("#labratory_info").html(data.emergency.lab_description);
                    $('#createdby_info').html(data.cr.username);
                    $('#createdat_info').html(data.crdate);
                }
            });
            $('#detailModal').modal('show');
        }

        function sendPharmacy(record_id) {
            $('#pharmacy_id').val(record_id);
            $('#pharmacyModal').modal('show');
        }

        function sendLabratory(record_id) {
            $('#lab_id').val(record_id);
            $('#labratoryModal').modal('show');
        }

        function addActionPharmacy(record_id) {
            $('#pharmacy_description').val('');
            $('#ph_id').val(record_id);
            $('#actionPharmacyModal').modal('show');
        }

        function addActionLabratory(record_id) {
            $('#lab_description').val('');
            $('#lb_id').val(record_id);
            $('#actionLabratoryModal').modal('show');
        }


        $('#actionPharmacy').click(function() {
            $('#actionPharmacy').html('saving...');
            var description = $('#pharmacy_description').val();
            $.get('/actionEmergencyPharmacy/' + $('#ph_id').val() + '/' + description, function(data) {
                if (data.success) {
                    $('#actionPharmacy').html('Save');
                    alert_toast('Successfully Saved.', 'success');
                    $('#actionPharmacyModal').modal('hide');
                    var cTable = $('#laravel-datatable-patient').dataTable();
                    cTable.fnDraw(false);
                } else {
                    $('#actionPharmacy').html('Save');
                    alert_toast('An error occured please try again', 'error');
                }
            });
        });

        $('#actionLabratory').click(function() {
            $('#actionLabratory').html('saving...');
            var description = $('#lab_description').val();
            $.get('/actionEmergencyLabratory/' + $('#lb_id').val() + '/' + description, function(data) {
                if (data.success) {
                    $('#actionLabratory').html('Save');
                    alert_toast('Successfully Saved', 'success');
                    $('#actionLabratoryModal').modal('hide');
                    var cTable = $('#laravel-datatable-patient').dataTable();
                    cTable.fnDraw(false);
                } else {
                    $('#actionLabratory').html('Save');
                    alert_toast('An error occured please try again', 'error');
                }
            });
        });
        $('#sendPharmacy').click(function() {
            $('#sendPharmacy').html('sending...');
            $.get('/sendEmergencyPharmacy/' + $('#pharmacy_id').val(), function(data) {
                if (data.success) {
                    $('#sendPharmacy').html('Send');
                    alert_toast('Successfully sent...', 'success');
                    $('#pharmacyModal').modal('hide');
                } else {
                    $('#sendPharmacy').html('Send');
                    alert_toast('An error occured please try again', 'error');
                }
            });
        });
        $('#sendLabratory').click(function() {
            $('#sendLabratory').html('sending...');
            $.get('/sendEmergencyLabratory/' + $('#lab_id').val(), function(data) {
                if (data.success) {
                    $('#sendLabratory').html('Send');
                    alert_toast('Successfully sent...', 'success');
                    $('#labratoryModal').modal('hide');
                } else {
                    $('#sendLabratory').html('Send');
                    alert_toast('An error occured please try again', 'error');
                }
            });
        });
    </script>
    <script>
        function removeNameValidation() {
            $('#name-error').html('');
        }

        function removeDescriptionValidation() {
            $('#description-error').html('');
        }

        function removeOccupationValidation() {
            $('#occupation-error').html('');
        }

        function removeAgeValidation() {
            $('#age-error').html('');
        }

        function removeSexValidation() {
            $('#sex-error').html('');
        }

        function closeModal() {
            $('#name-error').html('');
            $('#status-error').html('');
            $('#name').val('');
            $('#status').val('').trigger('change');
            $('#savenewbutton').css('display', 'flex');
            $('#savebutton').html('Save & Close');
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Werabe University Project\Werabe University Project\resources\views\patients\emergency.blade.php ENDPATH**/ ?>