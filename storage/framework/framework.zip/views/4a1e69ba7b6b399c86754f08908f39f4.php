<?php $__env->startSection('content'); ?>
    <div class="app-content content">
        <section id="responsive-datatable" style="font-size: 11px;">
            <div class="content py-5 px-3 w-100 bg-gradient-primary col-md-12 ml-0"
                style="border-radius: 8px; text-align: center;">
                <h2 style="color: white;">Stock Specific Report</h2>
            </div>
            <div id="success_message" style="padding: 13px 20px;"></div>
            <div class="row">
                <div class="col-12">
                    <!-- Your HTML content goes here -->
                    <div class="card">
                        <div class="card-header border-bottom">
                            <h3 class="card-title" id="report-title">Specific Report</h3>
                            <ul class="nav nav-tabs" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="in-tab" data-toggle="tab" href="#in"
                                        onclick="showIn()" aria-controls="in" role="tab"
                                        aria-selected="true">Received</a>
                                </li>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_pharmacy')): ?>
                                    <li class="nav-item">
                                        <a class="nav-link" id="out-tab" data-toggle="tab" href="#out" onclick="showOut()"
                                            aria-controls="out" role="tab" aria-selected="true">Issued</a>
                                    </li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_clinic_leader')): ?>
                                    <li class="nav-item">
                                        <a class="nav-link" id="out-tab" data-toggle="tab" href="#out" onclick="showOut()"
                                            aria-controls="out" role="tab" aria-selected="true">Issued</a>
                                    </li>
                                <?php endif; ?>
                                <li class="nav-item">
                                    <a class="nav-link" id="loss-tab" data-toggle="tab" href="#loss" onclick="showLoss()"
                                        aria-controls="loss" role="tab" aria-selected="true">Loss/Adj</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="stock-tab" data-toggle="tab" href="#stock"
                                        onclick="showStock()" aria-controls="stock" role="tab"
                                        aria-selected="true">Balance</a>
                                </li>
                            </ul>
                            <div class="col-md-4" id="daterangein" style="display: none;">
                                <div class="float-end"
                                    style="padding: 5px 10px; text-align: center; background: #fff; width: 100%; curson: pointer; border: 1px solid #ccc; margin: 10px -20px;">
                                    <i class="fa fa-calendar"></i>&nbsp;
                                    <span></span><i class="fa fa-caret-down"></i>
                                </div>
                            </div>

                            <div class="col-md-4" id="daterangeout" style="display: none;">
                                <div class="float-end"
                                    style="padding: 5px 10px; text-align: center; background: #fff; width: 100%; curson: pointer; border: 1px solid #ccc; margin: 10px -20px;">
                                    <i class="fa fa-calendar"></i>&nbsp;
                                    <span></span><i class="fa fa-caret-down"></i>
                                </div>
                            </div>
                            <div class="col-md-4" id="daterangestock" style="display: none;">
                                <div class="float-end"
                                    style="padding: 5px 10px; text-align: center; background: #fff; width: 100%; curson: pointer; border: 1px solid #ccc; margin: 10px -20px;">
                                    <i class="fa fa-calendar"></i>&nbsp;
                                    <span></span><i class="fa fa-caret-down"></i>
                                </div>
                            </div>

                            <div class="col-md-4" id="daterangeloss" style="display: none;">
                                <div class="float-end"
                                    style="padding: 5px 10px; text-align: center; background: #fff; width: 100%; curson: pointer; border: 1px solid #ccc; margin: 10px -20px;">
                                    <i class="fa fa-calendar"></i>&nbsp;
                                    <span></span><i class="fa fa-caret-down"></i>
                                </div>
                            </div>
                        </div>
                        <div class="card-datatable">
                            <div class="tab-content">
                                <div class="tab-pane" id="in" aria-labelledby="in-tab" role="tabpanel"
                                    style="display: none;">
                                    <div style="width:98%; margin-left:1%;">
                                        <div class="table-responsive">

                                            <table id="laravel-datatable-in"
                                                class="display table-bordered table-striped table-hover dt-responsive mb-0 dataTable"
                                                style="overflow-x: scroll;" role="grid"
                                                aria-describedby="laravel-datatable-in">
                                                <thead>
                                                    <tr>
                                                        <th rowspan="2">#</th>
                                                        <th nowrap rowspan="2">Date Received</th>
                                                        <th nowrap rowspan="2">Received From</th>
                                                        <th nowrap rowspan="2">Received To</th>
                                                        <th nowrap rowspan="2">Received By</th>
                                                        <th nowrap rowspan="2">Item Name</th>
                                                        <th nowrap rowspan="2">Category</th>
                                                        <th nowrap rowspan="2">Unit</th>
                                                        <th nowrap colspan="4" style="text-align: center;">Quantity
                                                        </th>
                                                        <th nowrap rowspan="2">Batch No</th>
                                                        <th nowrap rowspan="2">Expired Date</th>
                                                    </tr>
                                                    <tr>
                                                        <th nowrap>Received</th>
                                                        <th nowrap>Issued</th>
                                                        <th nowrap>Loss</th>
                                                        <th nowrap>Balance</th>
                                                    </tr>
                                                </thead>
                                                <tbody></tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>

                                <div class="tab-pane" id="out" aria-labelledby="out-tab" role="tabpanel"
                                    style="display: none;">
                                    <div style="width:98%; margin-left:1%;">
                                        <div class="table-responsive">

                                            <table id="laravel-datatable-out"
                                                class="display table-bordered table-striped table-hover dt-responsive mb-0 dataTable no-footer"
                                                style="width: 100%;" role="grid"
                                                aria-describedby="laravel-datatable-out">
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th nowrap>Date</th>
                                                        <th nowrap>Withdraw From</th>
                                                        <th nowrap>Withdraw By</th>
                                                        <th nowrap>Received By</th>
                                                        <th nowrap>Item Name</th>
                                                        <th nowrap>Category</th>
                                                        <th nowrap>Unit</th>
                                                        <th nowrap>Quantity</th>
                                                        <th nowrap>Batch No</th>
                                                        <th nowrap>Expired Date</th>
                                                    </tr>
                                                </thead>
                                                <tbody></tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>

                                <div class="tab-pane" id="loss" aria-labelledby="loss-tab" role="tabpanel"
                                    style="display: none;">

                                    <div style="width:98%; margin-left:1%;">
                                        <div class="table-responsive">

                                            <table id="laravel-datatable-loss"
                                                class="display table-bordered table-striped table-hover dt-responsive mb-0 dataTable no-footer"
                                                style="width: 100%;" role="grid"
                                                aria-describedby="laravel-datatable-lose">
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th nowrap>Date</th>
                                                        <th nowrap>Disposed From</th>
                                                        <th nowrap>Disposed By</th>
                                                        <th nowrap>Type</th>
                                                        <th nowrap>Reason</th>
                                                        <th nowrap>Item Name</th>
                                                        <th nowrap>Category</th>
                                                        <th nowrap>Unit</th>
                                                        <th nowrap>Quantity</th>
                                                        <th nowrap>Batch No</th>
                                                        <th nowrap>Expired Date</th>
                                                    </tr>
                                                </thead>
                                                <tbody></tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane" id="stock" aria-labelledby="stock-tab" role="tabpanel"
                                    style="display: none;">
                                    <div style="width:98%; margin-left:1%;">
                                        <div class="table-responsive">

                                            <table id="laravel-datatable-stock"
                                                class="display table-bordered table-striped table-hover dt-responsive mb-0 dataTable no-footer"
                                                style="width: 100%;" role="grid"
                                                aria-describedby="laravel-datatable-stock">
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th nowrap>Date</th>
                                                        <th nowrap>Received From</th>
                                                        <th nowrap>Received To</th>
                                                        <th nowrap>Received by</th>
                                                        <th nowrap>Item Name</th>
                                                        <th nowrap>Category</th>
                                                        <th nowrap>Unit</th>
                                                        <th nowrap>Quantity</th>
                                                        <th nowrap>Batch No</th>
                                                        <th nowrap>Expired Date</th>
                                                        <th>Remaining exp date</th>
                                                    </tr>
                                                </thead>
                                                <tbody></tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        var start_date = moment().subtract(1, 'M');
        var end_date = moment();
        var start = start_date.format('MMMM D, YYYY');
        var end = end_date.format('MMMM D, YYYY');
        $('#daterangein span').html(start_date.format('MMMM D, YYYY') + '-' + end_date.format('MMMM D, YYYY'));
        $('#daterangein').daterangepicker({
            startDate: start_date,
            endDate: end_date
        }, function(start_date, end_date) {
            $('#daterangein span').html(start_date.format('MMMM D, YYYY') + '-' + end_date.format('MMMM D, YYYY'));
            var cTable = $('#laravel-datatable-in').dataTable();
            cTable.fnDraw(false);
            start = start_date.format('MMMM D, YYYY');
            end = end_date.format('MMMM D, YYYY');
        });

        $('#daterangeout span').html(start_date.format('MMMM D, YYYY') + '-' + end_date.format('MMMM D, YYYY'));
        $('#daterangeout').daterangepicker({
            startDate: start_date,
            endDate: end_date
        }, function(start_date, end_date) {
            $('#daterangeout span').html(start_date.format('MMMM D, YYYY') + '-' + end_date.format('MMMM D, YYYY'));
            var oTable = $('#laravel-datatable-out').dataTable();
            oTable.fnDraw(false);
            start = start_date.format('MMMM D, YYYY');
            end = end_date.format('MMMM D, YYYY');
        });
        $('#daterangestock span').html(start_date.format('MMMM D, YYYY') + '-' + end_date.format('MMMM D, YYYY'));
        $('#daterangestock').daterangepicker({
            startDate: start_date,
            endDate: end_date
        }, function(start_date, end_date) {
            $('#daterangestock span').html(start_date.format('MMMM D, YYYY') + '-' + end_date.format(
                'MMMM D, YYYY'));
            var oTable = $('#laravel-datatable-stock').dataTable();
            oTable.fnDraw(false);
            start = start_date.format('MMMM D, YYYY');
            end = end_date.format('MMMM D, YYYY');
        });

        $('#daterangeloss span').html(start_date.format('MMMM D, YYYY') + '-' + end_date.format('MMMM D, YYYY'));
        $('#daterangeloss').daterangepicker({
            startDate: start_date,
            endDate: end_date
        }, function(start_date, end_date) {
            $('#daterangeloss span').html(start_date.format('MMMM D, YYYY') + '-' + end_date.format(
                'MMMM D, YYYY'));
            var oTable = $('#laravel-datatable-loss').dataTable();
            oTable.fnDraw(false);
            start = start_date.format('MMMM D, YYYY');
            end = end_date.format('MMMM D, YYYY');
        });
        var errorcolor = "#ffcccc";
        $(function() {
            cardSection = $('#page-block');
        });

        /* BEGIN: Display In Report table using yajra datatable */
        $(document).ready(function() {
            var t = 0;
            var ctable = $('#laravel-datatable-in').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                searchHighlight: true,
                dom: 'lBfrtip', // Add l before B to include lengthMenu
                buttons: [{
                        extend: 'copy',
                        title: 'Stock Received Report', // Title for the 'copy' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,
                                9, 10, 11, 12, 13
                            ] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'csv',
                        title: 'Stock Received Report', // Title for the 'csv' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,
                                9, 10, 11, 12, 13
                            ] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'excel',
                        title: 'Stock Received Report', // Title for the 'excel' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,
                                9, 10, 11, 12, 13
                            ] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'pdf',
                        title: 'Stock Received Report',
                        orientation: 'landscape', // Set orientation: 'landscape' or 'portrait'
                        pageSize: 'A4', // Set page size
                        customize: function(doc) {
                            // Customize header, footer, and body style
                            doc.styles.tableHeader = {
                                fillColor: '#4CAF50',
                                color: 'white',
                                alignment: 'center'
                            };
                            doc.styles.title = {
                                fontSize: 14,
                                alignment: 'center'
                            };
                            doc.defaultStyle.fontSize = 10; // Change default font size
                            doc.content[1].table.widths = '*'.repeat(doc.content[1].table.body[0]
                                .length).split(''); // Automatically adjust column widths
                            doc.pageMargins = [10, 10, 10, 10]; // Adjust page margins
                            doc.pageSize = 'A4'; // Ensure the page size is A4
                            doc.content[1].layout = {
                                hLineWidth: function(i, node) {
                                    return (i === 0 || i === node.table.body.length) ? 2 :
                                        1;
                                },
                                vLineWidth: function(i, node) {
                                    return (i === 0 || i === node.table.widths.length) ? 2 :
                                        1;
                                },
                                hLineColor: function(i, node) {
                                    return (i === 0 || i === node.table.body.length) ?
                                        'black' : 'gray';
                                },
                                vLineColor: function(i, node) {
                                    return (i === 0 || i === node.table.widths.length) ?
                                        'black' : 'gray';
                                },
                                paddingLeft: function(i, node) {
                                    return 4;
                                },
                                paddingRight: function(i, node) {
                                    return 4;
                                },
                                paddingTop: function(i, node) {
                                    return 2;
                                },
                                paddingBottom: function(i, node) {
                                    return 2;
                                },
                            };
                        },
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,
                                9, 10, 11, 12, 13
                            ] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'print',
                        title: 'Stock Received Report',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,
                                9, 10, 11, 12, 13
                            ] // Indexes of the columns you want to include
                        }
                    }
                ],
                lengthMenu: [
                    [10, 25, 50, 500, -1],
                    [10, 25, 50, 500, "All"]
                ],
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: "/pharmacyinreport",
                    data: function(data) {
                        data.from_date = $('#daterangein').data('daterangepicker').startDate.format(
                            'YYYY-MM-DD');
                        data.to_date = $('#daterangein').data('daterangepicker').endDate.format(
                            'YYYY-MM-DD');
                    },
                    type: 'delete',
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'date_received',
                        name: 'date_received'
                    },
                    {
                        data: 'store.campusstore.receiver.name',
                        name: 'store.campusstore.receiver.name'
                    },
                    {
                        data: 'role',
                        name: 'role'
                    },
                    {
                        data: 'user.name',
                        name: 'user.name'
                    },
                    {
                        data: 'product.item_name',
                        name: 'product.item_name'
                    },
                    {
                        data: 'product.category.name',
                        name: 'product.category.name'
                    },
                    {
                        data: 'unit',
                        name: 'unit'
                    },
                    {
                        data: 'total_quantity',
                        name: 'total_quantity'
                    },
                    {
                        data: 'issued',
                        name: 'issued'
                    },
                    {
                        data: 'loss',
                        name: 'loss'
                    },
                    {
                        data: 'balance',
                        name: 'balance'
                    },
                    {
                        data: 'store.seriel_number',
                        name: 'store.seriel_number'
                    },
                    {
                        data: 'expired_date',
                        name: 'expired_date'
                    },
                ],
            });
            ctable.on('draw', function() {
                var body = $(ctable.table().body());
                body.unhighlight();
                body.highlight(ctable.search());
            })
        });
        var created_at = 0;
        /* BEGIN: Display Out Report table using yajra datatable */
        $(document).ready(function() {
            t = 0;
            var ctable = $('#laravel-datatable-out').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                searchHighlight: true,
                dom: 'lBfrtip', // Add l before B to include lengthMenu
                buttons: [{
                        extend: 'copy',
                        title: 'Stock Issued Report', // Title for the 'copy' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,
                                9, 10
                            ] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'csv',
                        title: 'Stock Issued Report', // Title for the 'csv' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,
                                9, 10
                            ] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'excel',
                        title: 'Stock Issued Report', // Title for the 'excel' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,
                                9, 10
                            ] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'pdf',
                        title: 'Stock Issued Report',
                        orientation: 'landscape', // Set orientation: 'landscape' or 'portrait'
                        pageSize: 'A4', // Set page size
                        customize: function(doc) {
                            // Customize header, footer, and body style
                            doc.styles.tableHeader = {
                                fillColor: '#4CAF50',
                                color: 'white',
                                alignment: 'center'
                            };
                            doc.styles.title = {
                                fontSize: 14,
                                alignment: 'center'
                            };
                            doc.defaultStyle.fontSize = 10; // Change default font size
                            doc.content[1].table.widths = '*'.repeat(doc.content[1].table.body[0]
                                .length).split(''); // Automatically adjust column widths
                            doc.pageMargins = [10, 10, 10, 10]; // Adjust page margins
                            doc.pageSize = 'A4'; // Ensure the page size is A4
                            doc.content[1].layout = {
                                hLineWidth: function(i, node) {
                                    return (i === 0 || i === node.table.body.length) ? 2 :
                                        1;
                                },
                                vLineWidth: function(i, node) {
                                    return (i === 0 || i === node.table.widths.length) ? 2 :
                                        1;
                                },
                                hLineColor: function(i, node) {
                                    return (i === 0 || i === node.table.body.length) ?
                                        'black' : 'gray';
                                },
                                vLineColor: function(i, node) {
                                    return (i === 0 || i === node.table.widths.length) ?
                                        'black' : 'gray';
                                },
                                paddingLeft: function(i, node) {
                                    return 4;
                                },
                                paddingRight: function(i, node) {
                                    return 4;
                                },
                                paddingTop: function(i, node) {
                                    return 2;
                                },
                                paddingBottom: function(i, node) {
                                    return 2;
                                },
                            };
                        },
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,
                                9, 10
                            ] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'print',
                        title: 'Stock Issued Report',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,
                                9, 10
                            ] // Indexes of the columns you want to include
                        }
                    }
                ],
                lengthMenu: [
                    [10, 25, 50, 500, -1],
                    [10, 25, 50, 500, "All"]
                ],
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: "/pharmacyoutreport",
                    data: function(data) {
                        data.from_date = $('#daterangeout').data('daterangepicker').startDate.format(
                            'YYYY-MM-DD');
                        data.to_date = $('#daterangeout').data('daterangepicker').endDate.format(
                            'YYYY-MM-DD');
                    },
                    type: 'delete',
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'created_at',
                        name: 'created_at'
                    },
                    {
                        data: 'role',
                        name: 'role'
                    },
                    {
                        data: 'user.name',
                        name: 'user.name'
                    },
                    {
                        data: 'patient.student.student_id',
                        name: 'patient.student.student_id'
                    },
                    {
                        data: 'product.item_name',
                        name: 'product.item_name'
                    },
                    {
                        data: 'product.category.name',
                        name: 'product.category.name'
                    },
                    {
                        data: 'unit',
                        name: 'unit'
                    },
                    {
                        data: 'quantity',
                        name: 'quantity'
                    },
                    {
                        data: 'storerequest.store.seriel_number',
                        name: 'storerequest.store.seriel_number'
                    },
                    {
                        data: 'expired_date',
                        name: 'expired_date'
                    },
                ],
            });
            ctable.on('draw', function() {
                var body = $(ctable.table().body());
                body.unhighlight();
                body.highlight(ctable.search());
            })
        });

        /* BEGIN: Display Stock Report table using yajra datatable */
        $(document).ready(function() {
            t = 0;
            var ctable = $('#laravel-datatable-stock').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                searchHighlight: true,
                dom: 'lBfrtip', // Add l before B to include lengthMenu
                buttons: [{
                        extend: 'copy',
                        title: 'Available Stock Report', // Title for the 'copy' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,
                                9, 10
                            ] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'csv',
                        title: 'Available Stock Report', // Title for the 'csv' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,
                                9, 10
                            ] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'excel',
                        title: 'Available Stock Report', // Title for the 'excel' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,
                                9, 10
                            ] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'pdf',
                        title: 'Available Stock Report',
                        orientation: 'landscape', // Set orientation: 'landscape' or 'portrait'
                        pageSize: 'A4', // Set page size
                        customize: function(doc) {
                            // Customize header, footer, and body style
                            doc.styles.tableHeader = {
                                fillColor: '#4CAF50',
                                color: 'white',
                                alignment: 'center'
                            };
                            doc.styles.title = {
                                fontSize: 14,
                                alignment: 'center'
                            };
                            doc.defaultStyle.fontSize = 10; // Change default font size
                            doc.content[1].table.widths = '*'.repeat(doc.content[1].table.body[0]
                                .length).split(''); // Automatically adjust column widths
                            doc.pageMargins = [10, 10, 10, 10]; // Adjust page margins
                            doc.pageSize = 'A4'; // Ensure the page size is A4
                            doc.content[1].layout = {
                                hLineWidth: function(i, node) {
                                    return (i === 0 || i === node.table.body.length) ? 2 :
                                        1;
                                },
                                vLineWidth: function(i, node) {
                                    return (i === 0 || i === node.table.widths.length) ? 2 :
                                        1;
                                },
                                hLineColor: function(i, node) {
                                    return (i === 0 || i === node.table.body.length) ?
                                        'black' : 'gray';
                                },
                                vLineColor: function(i, node) {
                                    return (i === 0 || i === node.table.widths.length) ?
                                        'black' : 'gray';
                                },
                                paddingLeft: function(i, node) {
                                    return 4;
                                },
                                paddingRight: function(i, node) {
                                    return 4;
                                },
                                paddingTop: function(i, node) {
                                    return 2;
                                },
                                paddingBottom: function(i, node) {
                                    return 2;
                                },
                            };
                        },
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,
                                9, 10
                            ] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'print',
                        title: 'Available Stock Report',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,
                                9, 10
                            ] // Indexes of the columns you want to include
                        }
                    }
                ],
                lengthMenu: [
                    [10, 25, 50, 500, -1],
                    [10, 25, 50, 500, "All"]
                ],
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: "/pharmacystockreport",
                    data: function(data) {
                        data.from_date = $('#daterangestock').data('daterangepicker').startDate.format(
                            'YYYY-MM-DD');
                        data.to_date = $('#daterangestock').data('daterangepicker').endDate.format(
                            'YYYY-MM-DD');
                    },
                    type: 'delete',
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'date_received',
                        name: 'date_received'
                    },
                    {
                        data: 'store.campusstore.receiver.name',
                        name: 'store.campusstore.receiver.name'
                    },
                    {
                        data: 'role',
                        name: 'role'
                    },
                    {
                        data: 'user.name',
                        name: 'user.name'
                    },
                    {
                        data: 'product.item_name',
                        name: 'product.item_name'
                    },
                    {
                        data: 'product.category.name',
                        name: 'product.category.name'
                    },
                    {
                        data: 'unit',
                        name: 'unit'
                    },
                    {
                        data: 'quantity',
                        name: 'quantity'
                    },
                    {
                        data: 'store.seriel_number',
                        name: 'store.seriel_number'
                    },
                    {
                        data: 'expired_date',
                        name: 'expired_date'
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return '<p class="rem"></p>';
                        },
                        orderable: true,
                        searchable: true
                    },
                ],
                "fnRowCallback": function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                    if (aData.product.item_expiration_status == '1') {
                        diff = calculateRemainingDays(aData.expired_date);
                        if (diff == "1") {
                            $(nRow).find('.rem').html('None');
                        } else if (diff > 0) {
                            $(nRow).find('.rem').html(diff);
                        } else if (diff === 0) {
                            $(nRow).find('.rem').html("Product expires today.");
                        } else {
                            $(nRow).find('.rem').html("Product has expired.");
                        }
                    } else {
                        $(nRow).find('.rem').html('None');
                    }

                }
            });
            ctable.on('draw', function() {
                var body = $(ctable.table().body());
                body.unhighlight();
                body.highlight(ctable.search());
            })
        });

        function calculateRemainingDays(expireDate) {
            // Parse the expiration date string to Date object
            const expiryDate = new Date(expireDate);

            // Get current date
            const currentDate = new Date();

            // Calculate difference in milliseconds
            const differenceMs = expiryDate.getTime() - currentDate.getTime();

            // Convert milliseconds to days
            const remainingDays = Math.ceil(differenceMs / (1000 * 60 * 60 * 24));

            return remainingDays;
        }
        /* BEGIN: Display Stock Report table using yajra datatable */
        $(document).ready(function() {
            t_stock = 0;
            tquantity_stock = 0;
            var sttable = $('#laravel-datatable-loss').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                searchHighlight: true,
                dom: 'lBfrtip', // Add l before B to include lengthMenu
                buttons: [{
                        extend: 'copy',
                        title: 'Stock Loss Report', // Title for the 'copy' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,
                                9, 10, 11
                            ] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'csv',
                        title: 'Stock Loss Report', // Title for the 'csv' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,
                                9, 10, 11
                            ] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'excel',
                        title: 'Stock Loss Report', // Title for the 'excel' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,
                                9, 10, 11
                            ] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'pdf',
                        title: 'Stock Loss Report',
                        orientation: 'landscape', // Set orientation: 'landscape' or 'portrait'
                        pageSize: 'A4', // Set page size
                        customize: function(doc) {
                            // Customize header, footer, and body style
                            doc.styles.tableHeader = {
                                fillColor: '#4CAF50',
                                color: 'white',
                                alignment: 'center'
                            };
                            doc.styles.title = {
                                fontSize: 14,
                                alignment: 'center'
                            };
                            doc.defaultStyle.fontSize = 10; // Change default font size
                            doc.content[1].table.widths = '*'.repeat(doc.content[1].table.body[0]
                                .length).split(''); // Automatically adjust column widths
                            doc.pageMargins = [10, 10, 10, 10]; // Adjust page margins
                            doc.pageSize = 'A4'; // Ensure the page size is A4
                            doc.content[1].layout = {
                                hLineWidth: function(i, node) {
                                    return (i === 0 || i === node.table.body.length) ? 2 :
                                        1;
                                },
                                vLineWidth: function(i, node) {
                                    return (i === 0 || i === node.table.widths.length) ? 2 :
                                        1;
                                },
                                hLineColor: function(i, node) {
                                    return (i === 0 || i === node.table.body.length) ?
                                        'black' : 'gray';
                                },
                                vLineColor: function(i, node) {
                                    return (i === 0 || i === node.table.widths.length) ?
                                        'black' : 'gray';
                                },
                                paddingLeft: function(i, node) {
                                    return 4;
                                },
                                paddingRight: function(i, node) {
                                    return 4;
                                },
                                paddingTop: function(i, node) {
                                    return 2;
                                },
                                paddingBottom: function(i, node) {
                                    return 2;
                                },
                            };
                        },
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,
                                9, 10, 11
                            ] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'print',
                        title: 'Stock Loss Report',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,
                                9, 10, 11
                            ] // Indexes of the columns you want to include
                        }
                    }
                ],
                lengthMenu: [
                    [10, 25, 50, 500, -1],
                    [10, 25, 50, 500, "All"]
                ],
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: "/pharmacylossreport",
                    data: function(data) {
                        data.from_date = $('#daterangeloss').data('daterangepicker').startDate.format(
                            'YYYY-MM-DD');
                        data.to_date = $('#daterangeloss').data('daterangepicker').endDate.format(
                            'YYYY-MM-DD');
                    },
                    type: 'delete',
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'created_at',
                        name: 'created_at'
                    },
                    {
                        data: 'role',
                        name: 'role'
                    },
                    {
                        data: 'user.name',
                        name: 'user.name'
                    },
                    {
                        data: 'disposed_type',
                        name: 'disposed_type'
                    },
                    {
                        data: 'reason',
                        name: 'reason'
                    },
                    {
                        data: 'storerequest.product.item_name',
                        name: 'storerequest.product.item_name'
                    },
                    {
                        data: 'storerequest.product.category.name',
                        name: 'storerequest.product.category.name'
                    },
                    {
                        data: 'unit',
                        name: 'unit'
                    },
                    {
                        data: 'disposed_quantity',
                        name: 'disposed_quantity'
                    },
                    {
                        data: 'storerequest.store.seriel_number',
                        name: 'storerequest.store.seriel_number'
                    },
                    {
                        data: 'expired_date',
                        name: 'expired_date'
                    },
                ],
                "fnRowCallback": function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                    if (aData.disposed_type == "used") {
                        $(nRow).find('td:eq(4)').css({
                            "color": "#4CAF50",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #4CAF50"
                        });
                    }
                    if (aData.disposed_type == "disposed") {
                        $(nRow).find('td:eq(4)').css({
                            "color": "#f44336",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #f44336"
                        });
                    }
                }
            });
            ctable.on('draw', function() {
                var body = $(ctable.table().body());
                body.unhighlight();
                body.highlight(ctable.search());
            })
        });
    </script>
    <script>
        $('#in').show();
        $('#daterangein').show();
        $('#report-title').html('Received Report');

        function showIn() {
            $('#report-title').html('Received Report');
            $('#in').show();
            $('#daterangein').show();
            $('#daterangeout').hide();
            $('#out').hide();
            $('#daterangeloss').hide();
            $('#loss').hide();
            $('#daterangestock').hide();
            $('#stock').hide();
            var rTable = $('#laravel-datatable-in').dataTable();
            rTable.fnDraw(false);
        }

        function showOut() {
            $('#report-title').html('Issued Report');
            $('#in').hide();
            $('#daterangein').hide();
            $('#daterangeout').show();
            $('#out').show();
            $('#daterangeloss').hide();
            $('#loss').hide();
            $('#daterangestock').hide();
            $('#stock').hide();
            var otTable = $('#laravel-datatable-out').dataTable();
            otTable.fnDraw(false);
        }

        function showLoss() {
            $('#report-title').html('Loss Report');
            $('#in').hide();
            $('#daterangeloss').show();
            $('#loss').show();
            $('#daterangein').hide();
            $('#daterangestock').hide();
            $('#stock').hide();
            $('#daterangeout').hide();
            $('#out').hide();
            var otTable = $('#laravel-datatable-loss').dataTable();
            otTable.fnDraw(false);
        }

        function showStock() {
            $('#report-title').html('Balance Report');
            $('#in').hide();
            $('#daterangeloss').hide();
            $('#loss').hide();
            $('#daterangein').hide();
            $('#daterangestock').show();
            $('#stock').show();
            $('#daterangeout').hide();
            $('#out').hide();
            var otTable = $('#laravel-datatable-stock').dataTable();
            otTable.fnDraw(false);
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Werabe University Project\Werabe University Project\resources\views\report\pharmacy-report.blade.php ENDPATH**/ ?>