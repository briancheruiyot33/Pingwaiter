<?php $__env->startSection('content'); ?>
    <div class="app-content content">
        <section id="responsive-datatable" style="font-size: 12px;">
            <!-- Pie Chart -->
            <div class="row">
                <!-- Area Chart -->
                <div class="col-xl-8 col-lg-7">
                    <div class="card shadow mb-2">
                        <!-- Card Header - Dropdown -->
                        <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                            <h6 class="m-0 font-weight-bold text-primary">Patients Overview</h6>
                            <h6 class="m-0 font-weight-bold text-primary">Total Patients: <span><?php echo e($male + $female); ?></span>
                            </h6>
                            <select name="selYear" id="selYear" class="form-control col-md-3" onchange="getYear()">
                                <option value="<?php echo e($currentYear); ?>"><?php echo e($currentYear); ?></option>
                                <option value="2024">2024</option>
                                <option value="2025">2025</option>
                                <option value="2026">2026</option>
                                <option value="2027">2027</option>
                                <option value="2028">2028</option>
                            </select>
                        </div>
                        <!-- Card Body -->
                        <div class="card-body">
                            <div class="chart-area">
                                <canvas id="myAreaChart"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-0">
                    <div class="card shadow mb-0">
                        <!-- Card Header - Dropdown -->
                        <div class="card-header py-2 d-flex flex-row align-items-center justify-content-between">
                            <h6 class="m-0 font-weight-bold text-primary">Total Patients: <span><?php echo e($male + $female); ?></span>
                            </h6>
                            <div class="dropdown no-arrow">
                                <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink"
                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                                </a>
                            </div>
                        </div>
                        <!-- Card Body -->
                        <div class="card-body">
                            <div class="chart-pie pt-0 pb-0">
                                <canvas id="myPieChart"></canvas>
                            </div>
                            <div class="mt-2 text-center small">
                                <span class="mr-2">
                                    <i class="fas fa-circle text-primary"></i> Male
                                </span>
                                <span class="mr-2">
                                    <i class="fas fa-circle text-info"></i> Female
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="success_message" style="padding: 13px 20px;"></div>
            <div class="row">
                <div class="col-12">
                    <!-- Your HTML content goes here -->
                    <div class="card">
                        <div class="card-header border-bottom">
                            <h3 class="card-title" id="report-title">Patient Report</h3>
                            <div class="col-md-4" id="daterangein">
                                <div class="float-end"
                                    style="padding: 5px 10px; text-align: center; background: #fff; width: 100%; curson: pointer; border: 1px solid #ccc; margin: 10px -20px;">
                                    <i class="fa fa-calendar"></i>&nbsp;
                                    <span></span><i class="fa fa-caret-down"></i>
                                </div>
                            </div>
                        </div>
                        <div class="card-datatable">
                            <div class="tab-content">
                                <div class="tab-pane" id="in" aria-labelledby="in-tab" role="tabpanel">
                                    <div style="width:98%; margin-left:1%;">
                                        <div class="table-responsive">

                                            <table id="laravel-datatable-in"
                                                class="display table-bordered table-striped table-hover dt-responsive mb-0 dataTable"
                                                style="overflow-x: scroll;" role="grid"
                                                aria-describedby="laravel-datatable-in">
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th nowrap>Date</th>
                                                        <th nowrap>Full Name</th>
                                                        <th nowrap>Student Id</th>
                                                        <th nowrap>Sex</th>
                                                        <th nowrap>Register</th>
                                                        <th nowrap>Doctor</th>
                                                        <th nowrap>Pharmacy</th>
                                                        <th nowrap>Labratory</th>
                                                        <th nowrap>Referance</th>
                                                        <th nowrap>Active</th>
                                                    </tr>
                                                </thead>
                                                <tbody></tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <input type="hidden" id="num1" value="<?php echo e($male); ?>">
            <input type="hidden" id="num2" value="<?php echo e($female); ?>">
            <input type="hidden" id="jun" value="<?php echo e($jun); ?>">
            <input type="hidden" id="feb" value="<?php echo e($feb); ?>">
            <input type="hidden" id="mar" value="<?php echo e($mar); ?>">
            <input type="hidden" id="app" value="<?php echo e($app); ?>">
            <input type="hidden" id="may" value="<?php echo e($may); ?>">
            <input type="hidden" id="june" value="<?php echo e($june); ?>">
            <input type="hidden" id="july" value="<?php echo e($july); ?>">
            <input type="hidden" id="aug" value="<?php echo e($aug); ?>">
            <input type="hidden" id="sep" value="<?php echo e($sep); ?>">
            <input type="hidden" id="oct" value="<?php echo e($oct); ?>">
            <input type="hidden" id="nev" value="<?php echo e($nev); ?>">
            <input type="hidden" id="dec" value="<?php echo e($dec); ?>">
            
            <div class="modal fade text-left" id="doctorModal" data-keyboard="false" data-backdrop="static"
                tabindex="-1" role="dialog" aria-labelledby="lbl" aria-hidden="true" style="overflow-y: scroll;">
                <div class="modal-dialog modal-xl" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="pharmacylbl">OPD Operation performed
                            </h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                                onclick="closeModal()">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">

                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Patient's Full Name:</label>
                                        <input type="text" id="fname_opd" value="" class="form-control"
                                            readonly>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>USER ID:</label>
                                        <input type="text" id="user_id_opd" value="" readonly
                                            class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Gender:</label>
                                        <input type="text" id="gender_opd" readonly class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Age:</label>
                                        <input type="text" id="age_opd" class="form-control" readonly>
                                    </div>
                                </div>
                            </div>
                            <div class="row">

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Doctor:</label>
                                        <input type="text" id="opd_name" class="form-control" readonly>
                                    </div>
                                </div>
                            </div>
                            <div class="card" id="cleared">
                                <div class="card-header text-danger">Patient has been cleared</div>
                                <div class="card-body">
                                    <label for="">Description given by opd</label>
                                    <textarea id="opd_description" class="form-control" placeholder="no description given" readonly></textarea>
                                </div>
                            </div>
                            <div class="card" id="opd_appointed">
                                <div class="card-header text-danger">Patient is appointment detail</div>
                                <div class="card-body">
                                    <div class="row col-md-12">
                                        <div class="form-group col-md-6">
                                            <label for="">Star date</label>
                                            <input type="date" name="" id="start_date" class="form-control"
                                                readonly>
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label for="">End date</label>
                                            <input type="date" name="" id="end_date" class="form-control"
                                                readonly>
                                        </div>

                                    </div>
                                    <div class="row col-md-12">
                                        <div class="form-group col-md-12">
                                            <label for="">Description</label>
                                            <textarea id="appointment_description" class="form-control" placeholder="no appointment description given" readonly></textarea>
                                        </div>

                                    </div>

                                </div>
                            </div>
                            <div class="card" id="opd_referance">
                                <div class="card-header text-danger">OPD WRITE REFERANCE FOR THIS PATIENT</div>
                                <div class="card-body">
                                    <div class="top">
                                        <div class="date" style="display: flex;margin-left: 75%;">
                                            <p>ቀን </p>
                                            <p style=" margin-left: 10px;"> <span
                                                    style="border-bottom: 1px dashed black;"><?php echo date('d-m-y'); ?>GC</span>
                                            </p>
                                        </div>
                                        <h2><span class="title">Waraba Comprehensive Specialized Hospital</span></h2>
                                        <h2><span style="border-bottom:  1px solid black;">Werabe</span></h2>
                                        <h3 style="margin-left: 20%;">Matter:- <span
                                                style="border-bottom: 1px solid black;">Considers credit treatment</span>
                                        </h3>
                                        <p>at Warabe University <span
                                                style="border-bottom: 1px dashed black;">Werabe</span>
                                            College
                                            <span style="border-bottom: 1px dashed black;" class="dep"></span>&nbsp;
                                            Department ID no <span style="border-bottom: 1px dashed black;"
                                                class="stud_id"></span>
                                            A student who studies <span style="border-bottom: 1px dashed black;"
                                                class="stud_name"></span>
                                            with your hospital
                                            <?php echo date('d-m-y'); ?>GC
                                            We would like to thank you in advance for your usual cooperation as we send
                                            him/her to get medical services according to the contract we entered into.
                                        </p>
                                        <p style="margin-top: 70px; margin-bottom: 70px;">የላከው በላሙያ
                                            ስም..........................................ፍርማ.........................</p>
                                    </div>
                                    <div class="bottom">
                                        <div class="date" style="display: flex;margin-left: 75%;">
                                            <p>ቀን </p>
                                            <p style=" margin-left: 10px;"><span
                                                    style="border-bottom: 1px dashed black;"><?php echo date('d-m-y'); ?>GC</span>
                                            </p>
                                        </div>
                                        <h2><span class="title">ለወራቤ ኮምፕሬንሄቭ ስፔስሻላዝድ ሆስፒታል</span></h2>
                                        <h2><span style="border-bottom:  1px solid black;">ወራቤ</span></h2>
                                        <h3 style="margin-left: 20%;">ጉዳይ:- <span
                                                style="border-bottom: 1px solid black;">የዱቤ
                                                ህክምና
                                                ይመለከታል</span></h3>
                                        <p>በወራቤ ዩንቨርሲቲ በ <span style="border-bottom: 1px dashed black;">ወራቤ</span> ኮሌጅ
                                            <span style="border-bottom: 1px dashed black;" class="dep"></span>
                                            ዲፓርትመንት በአይድ
                                            ቁጥር <span style="border-bottom: 1px dashed black;" class="stud_id"></span>
                                            የሚማር
                                            /የምትማር ተማሪ
                                            <span style="border-bottom: 1px dashed black;" class="stud_name"></span>
                                            ከሆስፒታላችሁ
                                            ጋር በ
                                            <?php echo date('d-m-y'); ?>GC በገባነው ውል መሰረት የህክምና አገልግሎት እንዲያገኝ /እንድታገኝ መላካችን እየገልፅን
                                            ለተለመደው
                                            ትብብራቹሁ
                                            ምስጋናችን በመስቀደም
                                            ነው።
                                        </p>
                                        <p style="margin-top: 70px; margin-bottom: 70px;">የላከው በላሙያ
                                            ስም..........................................ፍርማ.........................</p>
                                    </div>
                                </div>
                            </div>
                            <div class="card" id="opd_labratory">
                                <div class="card-header text-danger">Opd send patient to labratory with the following
                                    priscription
                                </div>
                                <div class="card-body">
                                    <div class="t1">
                                        <table border="1px" class="ttt w-100">
                                            <tr>
                                                <th>STOOL</th>
                                                <th>UNINALYSIS</th>
                                                <th colspan="2">HEAMATOLOGY</th>
                                                <th colspan="2">SEROLOGY</th>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <div class="c1">APP <input type="checkbox" name="app"
                                                            id="app1" class="c2">
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="c1">color<input type="checkbox" id="color1"
                                                            name="color" class="c2">
                                                    </div>
                                                </td>
                                                <td colspan="2">
                                                    <div class="c1">Hg <p><input type="text" name="mg"
                                                                id="hg1" class="form-control" readonly>Mg/di</p>
                                                    </div>
                                                </td>
                                                <td rowspan="3" align="center">Widal <br>& <br>Weil Flex</td>
                                                <td>
                                                    <div class="c1">'O'<input type="checkbox" name="o"
                                                            id="o1" class="c2">
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <div class="c1">Cons<input type="checkbox" name="cons"
                                                            id="cons1" class="c2">
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="c1">Leucocyte<input type="checkbox" name="leurcocyte"
                                                            id="leurcocyte1" class="c2"></div>
                                                </td>
                                                <td colspan="2">
                                                    <div class="c1">Hct<p><input type="number" name="hct"
                                                                id="hct1" class="form-control" readonly>%</p>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="c1">'H'<input type="checkbox" name="h"
                                                            id="h1" class="c2">
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <div class="c1">OIP<input type="checkbox" name="oip"
                                                            id="oip1" class="c2">
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="c1">nitrite<input type="checkbox" name="nitrate"
                                                            id="nitrate1" class="c2">
                                                    </div>
                                                </td>
                                                <td colspan="2">
                                                    <div class="c1">WBC<p><input type="text" name="wbc1"
                                                                id="wbc11" class="form-control" readonly>Mm3</p>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="c1">'Ox'<input type="checkbox" name="ox"
                                                            id="ox1" class="c2">
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td rowspan="10"></td>
                                                <td>
                                                    <div class="c1">Urobilinogen<input type="checkbox"
                                                            name="urobilinogen" id="urobilinogen1" class="c2"></div>
                                                </td>
                                                <td rowspan="5" class="bottom" align="center">Diff Count</td>
                                                <td>
                                                    <div class="c1">Netrophils<p><input type="number"
                                                                name="netrophils" id="netrophils1" class="form-control"
                                                                readonly>%
                                                        </p>
                                                    </div>
                                                </td>
                                                <td colspan="2">
                                                    <div class="c1">RPR<input type="checkbox" name="rbr"
                                                            id="rbr1" class="c2">
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <div class="c1">Protein<input type="checkbox" name="protein"
                                                            id="protein1" class="c2">
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="c1">Basophils<p><input type="number"
                                                                name="basophils" id="basophils1" class="form-control"
                                                                readonly>%
                                                        </p>
                                                    </div>
                                                </td>
                                                <td colspan="2">
                                                    <div class="c1">Rheumatoid factor<input type="checkbox"
                                                            name="theumatoid" id="theumatoid1" class="c2"></div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <div class="c1">PH<input type="checkbox" name="ph"
                                                            id="ph1" class="c2">
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="c1">Eosinophils<p><input type="number"
                                                                name="eosinophils" id="eosinophils1" class="form-control"
                                                                readonly>%</p>
                                                    </div>
                                                </td>
                                                <td colspan="2">
                                                    <div class="c1">HCG<input type="checkbox" name="hcg"
                                                            id="hcg1" class="c2">
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <div class="c1">Blood<input type="checkbox" name="blood"
                                                            id="blood1" class="c2">
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="c1">Monocytes<p><input type="number"
                                                                name="monocytes" id="monocytes1" class="form-control"
                                                                readonly>%</p>
                                                    </div>
                                                </td>
                                                <td colspan="2">
                                                    <div class="c1">FBC/RBS<input type="checkbox" name="fbc"
                                                            id="fbc1" class="c2">
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <div class="c1">Spec. gravity<input type="checkbox"
                                                            name="spec" id="spec1" class="c2"></div>
                                                </td>
                                                <td>
                                                    <div class="c1">Lymphocyted<p><input type="number"
                                                                name="lymphocyted" id="lymphocyted1" class="form-control"
                                                                readonly>%</p>
                                                    </div>
                                                </td>
                                                <td colspan="2">
                                                    <div class="c1">Bactreglology<input type="checkbox"
                                                            name="bactreglology" id="bactreglology1" class="c2">
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <div class="c1">Ketones<input type="checkbox" name="ketones"
                                                            id="ketones1" class="c2">
                                                    </div>
                                                </td>
                                                <td colspan="2">
                                                    <div class="c1">ESR<p><input type="text" name="esr"
                                                                class="form-control" id="esr1" readonly>mm/hr</p>
                                                    </div>
                                                </td>
                                                <td colspan="2">
                                                    <div class="c1">Gram stan<input type="checkbox" name="gram_stan"
                                                            id="gram_stan1" class="c2"></div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <div class="c1">Bilirubin<input type="checkbox" name="bilirubin"
                                                            id="bilirubin1" class="c2"></div>
                                                </td>
                                                <td colspan="2">
                                                    <div class="c1">Blood Film<input type="checkbox"
                                                            name="blood_film" id="blood_film1" class="c2"></div>
                                                </td>
                                                <td colspan="2">
                                                    <div class="c1">A+B<input type="checkbox" name="ab"
                                                            id="ab1" class="c2">
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <div class="c1">Glucose<input type="checkbox" name="glucose"
                                                            id="glucose1" class="c2">
                                                    </div>
                                                </td>
                                                <td colspan="2">
                                                    <div class="c1">IMUNOHEAMATOLOGY<input type="checkbox"
                                                            name="imunohematology" id="imunohematology1" class="c2">
                                                    </div>
                                                </td>
                                                <td colspan="2">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <div class="c1">RBC/HPF<input type="checkbox" name="rbc"
                                                            id="rbc1" class="c2">
                                                    </div>
                                                </td>
                                                <td colspan="2">
                                                    <div class="c1">BLOOD group & RH<input type="checkbox"
                                                            name="blood_group" id="blood_group1" class="c2"></div>
                                                </td>
                                                <td colspan="2"></td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <div class="c1">WBC/HPF<input type="checkbox" name="wbc"
                                                            id="wbc1" class="c2"></div>
                                                </td>
                                                <td colspan="2"></td>
                                                <td colspan="2"></td>
                                            </tr>
                                            <tr>
                                                <td colspan="6">
                                                    <div class="c1">
                                                        <textarea class="form-control" name="other" id="other1" placeholder="No description given" readonly></textarea>
                                                        <textarea class="form-control" name="other_lab" id="other_lab1" placeholder="No result given" readonly></textarea>
                                                    </div>
                                                </td>
                                            </tr>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="card" id="send_to_pharmacy">
                                <div class="card-header text-danger">Patient send to pharmacy with the following
                                    priscription</div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-xl-12 col-lg-12">
                                            <div class="table-responsive">
                                                <table id="dynamicTable_opd" class="mb-0 rtable  dt-responsive"
                                                    style="width: 100%">
                                                    <thead>
                                                        <tr>
                                                            <th>#</th>

                                                            <th>
                                                                Drug Name<b style="color: red;"> *</b>
                                                            </th>
                                                            <th>
                                                                Strength, Dosage Form, Dose, Frequency, Duration,
                                                                Quantity, How
                                                                to use &
                                                                other information
                                                                <b style="color: red;"> *</b>
                                                            </th>
                                                            <th style="width: 3%"></th>
                                                        </tr>
                                                    </thead>
                                                    <tbody></tbody>
                                                </table>
                                                <span class="text-danger">
                                                    <strong id="table-error"></strong>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button id="closebutton" type="button" class="btn btn-danger" onclick="closeModal()"
                                data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>

            </div>
            
            <div class="modal fade text-left" id="pharmacyModal" data-keyboard="false" data-backdrop="static"
                tabindex="-1" role="dialog" aria-labelledby="lbl" aria-hidden="true" style="overflow-y: scroll;">
                <div class="modal-dialog modal-xl" role="document" style="font-size: 11px;">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="pharmacylbl">Pharmacy Operation performed
                            </h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                                onclick="closeModal()">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="card">
                                <div class="card-header">Pharmacy perform the following operation</div>
                                <div class="card-body">
                                    <div class="row">
                                        <input type="hidden" name="patient_id" id="patient_id">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>Patient's Full Name:</label>
                                                <input type="text" id="ph_name" value="" class="form-control"
                                                    readonly>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>USER ID:</label>
                                                <input type="text" id="ph_id" value="" readonly
                                                    class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>Gender:</label>
                                                <input type="text" id="ph_gender" readonly class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>Age:</label>
                                                <input type="text" id="age_number" class="form-control" readonly>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>Doctor:</label>
                                                <input type="text" id="opd_by" class="form-control" readonly>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>Pharmacy:</label>
                                                <input type="text" id="phar_by" class="form-control" readonly>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-xl-12 col-lg-12 col-md-12">
                                            <div class="table-responsive">
                                                <table id="pharmacyTable">
                                                    <thead>
                                                        <tr>
                                                            <th style="width: 3%; text-align: center;">#</th>

                                                            <th nowrap>
                                                                Drug|Category|Type|Unit<b style="color: red;"> *</b>
                                                            </th>
                                                            <th nowrap>Description
                                                                <b style="color: red;"> *</b>
                                                            </th>
                                                            <th>Quantity</th>
                                                            <th nowrap>Withdraw</th>
                                                            <th nowrap>Cancel</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody></tbody>
                                                </table>
                                                <span class="text-danger">
                                                    <strong id="table-error"></strong>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="modal-footer">
                            <p style="color: green;" id="withp">Withdraw Completed</p>
                            <button id="closebutton" type="button" class="btn btn-danger" onclick="closeModal()"
                                data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="modal fade text-left" id="labratoryModal" data-keyboard="false" data-backdrop="static"
                tabindex="-1" role="dialog" aria-labelledby="lbl" aria-hidden="true" style="overflow-y: scroll;">
                <div class="modal-dialog modal-xl" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="pharmacylbl">Werabe University Student Clinic
                                LABORATORY REQUEST</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                                onclick="closeModal()">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>FULL NAME:</label>
                                        <input type="text" name="fname" id="fullname" class="form-control"
                                            readonly>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>AGE:</label>
                                        <input type="number" name="age" id="new_age" readonly
                                            class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Gender:</label>
                                        <input type="text" name="gender" id="new_sex" readonly
                                            class="form-control">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>USER ID:</label>
                                        <input type="text" name="student_id" id="stud_id" class="form-control"
                                            readonly>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Doctor </label>
                                        <input type="text" name="pname" id="pname" readonly
                                            class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Labratoriest</label>
                                        <input type="text" name="lname" id="lname" readonly
                                            class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Date</label>
                                        <input type="text" name="date" id="date_from" readonly
                                            class="form-control">
                                    </div>
                                </div>
                            </div>
                            <form id="labratory-form">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="id">
                                <input type="hidden" name="lab_id" id="lab_id">
                                <div class="t1">
                                    <table border="1px" class="ttt w-100">
                                        <tr>
                                            <th>STOOL</th>
                                            <th>UNINALYSIS</th>
                                            <th colspan="2">HEAMATOLOGY</th>
                                            <th colspan="2">SEROLOGY</th>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="c1">APP <input type="checkbox" name="app"
                                                        id="app" class="c2">
                                                </div>
                                            </td>
                                            <td>
                                                <div class="c1">color<input type="checkbox" id="color"
                                                        name="color" class="c2">
                                                </div>
                                            </td>
                                            <td colspan="2">
                                                <div class="c1">Hg <p><input type="text" name="mg"
                                                            id="hg" class="form-control" readonly>Mg/di</p>
                                                </div>
                                            </td>
                                            <td rowspan="3" align="center">Widal <br>& <br>Weil Flex</td>
                                            <td>
                                                <div class="c1">'O'<input type="checkbox" name="o"
                                                        id="o" class="c2">
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="c1">Cons<input type="checkbox" name="cons"
                                                        id="cons" class="c2">
                                                </div>
                                            </td>
                                            <td>
                                                <div class="c1">Leucocyte<input type="checkbox" name="leurcocyte"
                                                        id="leurcocyte" class="c2"></div>
                                            </td>
                                            <td colspan="2">
                                                <div class="c1">Hct<p><input type="number" name="hct"
                                                            id="hct" class="form-control" readonly>%</p>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="c1">'H'<input type="checkbox" name="h"
                                                        id="h" class="c2">
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="c1">OIP<input type="checkbox" name="oip"
                                                        id="oip" class="c2">
                                                </div>
                                            </td>
                                            <td>
                                                <div class="c1">nitrite<input type="checkbox" name="nitrate"
                                                        id="nitrate" class="c2">
                                                </div>
                                            </td>
                                            <td colspan="2">
                                                <div class="c1">WBC<p><input type="text" name="wbc1"
                                                            id="wbc1" class="form-control" readonly>Mm3</p>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="c1">'Ox'<input type="checkbox" name="ox"
                                                        id="ox" class="c2">
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td rowspan="10"></td>
                                            <td>
                                                <div class="c1">Urobilinogen<input type="checkbox"
                                                        name="urobilinogen" id="urobilinogen" class="c2"></div>
                                            </td>
                                            <td rowspan="5" class="bottom" align="center">Diff Count</td>
                                            <td>
                                                <div class="c1">Netrophils<p><input type="number" name="netrophils"
                                                            id="netrophils" class="form-control" readonly>%
                                                    </p>
                                                </div>
                                            </td>
                                            <td colspan="2">
                                                <div class="c1">RPR<input type="checkbox" name="rbr"
                                                        id="rbr" class="c2">
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="c1">Protein<input type="checkbox" name="protein"
                                                        id="protein" class="c2">
                                                </div>
                                            </td>
                                            <td>
                                                <div class="c1">Basophils<p><input type="number" name="basophils"
                                                            id="basophils" class="form-control" readonly>%
                                                    </p>
                                                </div>
                                            </td>
                                            <td colspan="2">
                                                <div class="c1">Rheumatoid factor<input type="checkbox"
                                                        name="theumatoid" id="theumatoid" class="c2"></div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="c1">PH<input type="checkbox" name="ph"
                                                        id="ph" class="c2">
                                                </div>
                                            </td>
                                            <td>
                                                <div class="c1">Eosinophils<p><input type="number"
                                                            name="eosinophils" id="eosinophils" class="form-control"
                                                            readonly>%</p>
                                                </div>
                                            </td>
                                            <td colspan="2">
                                                <div class="c1">HCG<input type="checkbox" name="hcg"
                                                        id="hcg" class="c2">
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="c1">Blood<input type="checkbox" name="blood"
                                                        id="blood" class="c2">
                                                </div>
                                            </td>
                                            <td>
                                                <div class="c1">Monocytes<p><input type="number" name="monocytes"
                                                            id="monocytes" class="form-control" readonly>%</p>
                                                </div>
                                            </td>
                                            <td colspan="2">
                                                <div class="c1">FBC/RBS<input type="checkbox" name="fbc"
                                                        id="fbc" class="c2">
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="c1">Spec. gravity<input type="checkbox" name="spec"
                                                        id="spec" class="c2"></div>
                                            </td>
                                            <td>
                                                <div class="c1">Lymphocyted<p><input type="number"
                                                            name="lymphocyted" id="lymphocyted" class="form-control"
                                                            readonly>%</p>
                                                </div>
                                            </td>
                                            <td colspan="2">
                                                <div class="c1">Bactreglology<input type="checkbox"
                                                        name="bactreglology" id="bactreglology" class="c2"></div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="c1">Ketones<input type="checkbox" name="ketones"
                                                        id="ketones" class="c2">
                                                </div>
                                            </td>
                                            <td colspan="2">
                                                <div class="c1">ESR<p><input type="text" name="esr"
                                                            class="form-control" id="esr" readonly>mm/hr</p>
                                                </div>
                                            </td>
                                            <td colspan="2">
                                                <div class="c1">Gram stan<input type="checkbox" name="gram_stan"
                                                        id="gram_stan" class="c2"></div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="c1">Bilirubin<input type="checkbox" name="bilirubin"
                                                        id="bilirubin" class="c2"></div>
                                            </td>
                                            <td colspan="2">
                                                <div class="c1">Blood Film<input type="checkbox" name="blood_film"
                                                        id="blood_film" class="c2"></div>
                                            </td>
                                            <td colspan="2">
                                                <div class="c1">A+B<input type="checkbox" name="ab"
                                                        id="ab" class="c2">
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="c1">Glucose<input type="checkbox" name="glucose"
                                                        id="glucose" class="c2">
                                                </div>
                                            </td>
                                            <td colspan="2">
                                                <div class="c1">IMUNOHEAMATOLOGY<input type="checkbox"
                                                        name="imunohematology" id="imunohematology" class="c2"></div>
                                            </td>
                                            <td colspan="2">
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="c1">RBC/HPF<input type="checkbox" name="rbc"
                                                        id="rbc" class="c2">
                                                </div>
                                            </td>
                                            <td colspan="2">
                                                <div class="c1">BLOOD group & RH<input type="checkbox"
                                                        name="blood_group" id="blood_group" class="c2"></div>
                                            </td>
                                            <td colspan="2"></td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="c1">WBC/HPF<input type="checkbox" name="wbc"
                                                        id="wbc" class="c2"></div>
                                            </td>
                                            <td colspan="2"></td>
                                            <td colspan="2"></td>
                                        </tr>
                                        <tr>
                                            <td colspan="6">
                                                <div class="c1">
                                                    <textarea class="form-control" name="other" id="other" placeholder="No description given" readonly></textarea>
                                                    <textarea class="form-control" name="other_lab" id="other_lab" placeholder="No result given" readonly></textarea>
                                                </div>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button id="savelabratory" type="button"
                                class="btn btn-info waves-effect waves-float waves-light">Save</button>
                            <button id="closebutton" type="button" class="btn btn-danger" onclick="closeModal()"
                                data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="modal fade text-left" id="referanceModal" data-keyboard="false" data-backdrop="static"
                tabindex="-1" role="dialog" aria-labelledby="lbl" aria-hidden="true" style="overflow-y: scroll;">
                <div class="modal-dialog modal-xl" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="referencelbl">Reference Written for this patient</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                                onclick="closeModal()">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="card">
                                <div class="card-heade">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Name of Prescriber's </label>
                                            <input type="text" name="pname" id="refrance_pname" readonly
                                                class="form-control">
                                        </div>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <input type="hidden" id="print_id">
                                    <div class="ref_container" id="div_print">
                                        <div class="top">
                                            <div class="date" style="display: flex;margin-left: 75%;">
                                                <p>ቀን </p>
                                                <p style=" margin-left: 10px;"> <span
                                                        style="border-bottom: 1px dashed black;"><?php echo date('d-m-y'); ?>GC</span>
                                                </p>
                                            </div>
                                            <h2><span class="title">ለወራቤ ኮምፕሬንሄስቭ ስፔስሻላዝድ ሆስፒታል</span></h2>
                                            <h2><span style="border-bottom:  1px solid black;">ወራቤ</span></h2>
                                            <h3 style="margin-left: 20%;">ጉዳይ:- <span
                                                    style="border-bottom: 1px solid black;">የዱቤ
                                                    ህክምና
                                                    ይመለከታል</span></h3>
                                            <p>በወራቤ ዩንቨርሲቲ በ <span style="border-bottom: 1px dashed black;">ወራቤ</span> ኮሌጅ
                                                <span style="border-bottom: 1px dashed black;" class="dep"></span>
                                                ዲፓርትመንት
                                                በአይድ
                                                ቁጥር <span style="border-bottom: 1px dashed black;" class="stud_id"></span>
                                                የሚማር
                                                /የምትማር
                                                ተማሪ <span style="border-bottom: 1px dashed black;"
                                                    class="stud_name"></span>
                                                ከሆስፒታላችሁ ጋር በ
                                                <?php echo date('d-m-y'); ?>GC
                                                በገባነው ውል መሰረት የህክምና አገልግሎት እንዲያገኝ /እንድታገኝ መላካችን እየገልፅን ለተለመደው ትብብራቹሁ ምስጋናችን
                                                በመስቀደም
                                                ነው።
                                            </p>
                                            <p style="margin-top: 70px; margin-bottom: 70px;">የላከው በላሙያ
                                                ስም..........................................ፍርማ.........................</p>
                                        </div>
                                        <div class="bottom">
                                            <div class="date" style="display: flex;margin-left: 75%;">
                                                <p>ቀን </p>
                                                <p style=" margin-left: 10px;"><span
                                                        style="border-bottom: 1px dashed black;"><?php echo date('d-m-y'); ?>GC</span>
                                                </p>
                                            </div>
                                            <h2><span class="title">ለወራቤ ኮምፕሬንሄቭ ስፔስሻላዝድ ሆስፒታል</span></h2>
                                            <h2><span style="border-bottom:  1px solid black;">ወራቤ</span></h2>
                                            <h3 style="margin-left: 20%;">ጉዳይ:- <span
                                                    style="border-bottom: 1px solid black;">የዱቤ
                                                    ህክምና
                                                    ይመለከታል</span></h3>
                                            <p>በወራቤ ዩንቨርሲቲ በ <span style="border-bottom: 1px dashed black;">ወራቤ</span> ኮሌጅ
                                                <span style="border-bottom: 1px dashed black;" class="dep"></span>
                                                ዲፓርትመንት በአይድ
                                                ቁጥር <span style="border-bottom: 1px dashed black;" class="stud_id"></span>
                                                የሚማር
                                                /የምትማር ተማሪ
                                                <span style="border-bottom: 1px dashed black;" class="stud_name"></span>
                                                ከሆስፒታላችሁ
                                                ጋር በ
                                                <?php echo date('d-m-y'); ?>GC በገባነው ውል መሰረት የህክምና አገልግሎት እንዲያገኝ /እንድታገኝ መላካችን እየገልፅን
                                                ለተለመደው
                                                ትብብራቹሁ
                                                ምስጋናችን በመስቀደም
                                                ነው።
                                            </p>
                                            <p style="margin-top: 70px; margin-bottom: 70px;">የላከው በላሙያ
                                                ስም..........................................ፍርማ.........................</p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="modal-footer">
                            <button id="closebutton" type="button" class="btn btn-danger" onclick="closeModal()"
                                data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        function getYear() {
            window.location = '/report-patient/' + $('#selYear').val();
        }
        var start_date = moment().subtract(1, 'M');
        var end_date = moment();
        var start = start_date.format('MMMM D, YYYY');
        var end = end_date.format('MMMM D, YYYY');
        $('#daterangein span').html(start_date.format('MMMM D, YYYY') + '-' + end_date.format('MMMM D, YYYY'));
        $('#daterangein').daterangepicker({
            startDate: start_date,
            endDate: end_date
        }, function(start_date, end_date) {
            $('#daterangein span').html(start_date.format('MMMM D, YYYY') + '-' + end_date.format('MMMM D, YYYY'));
            var cTable = $('#laravel-datatable-in').dataTable();
            cTable.fnDraw(false);
            start = start_date.format('MMMM D, YYYY');
            end = end_date.format('MMMM D, YYYY');
        });
        var errorcolor = "#ffcccc";
        $(function() {
            cardSection = $('#page-block');
        });

        /* BEGIN: Display In Report table using yajra datatable */
        $(document).ready(function() {
            var t = 0;
            var ctable = $('#laravel-datatable-in').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                searchHighlight: true,
                dom: 'lBfrtip', // Add l before B to include lengthMenu
                buttons: [{
                        extend: 'copy',
                        title: 'Your Title Here' // Title for the 'copy' button
                    },
                    {
                        extend: 'csv',
                        title: 'Your Title Here' // Title for the 'csv' button
                    },
                    {
                        extend: 'excel',
                        title: 'Your Title Here' // Title for the 'excel' button
                    },
                    {
                        extend: 'pdf',
                        title: 'Patient report' // Title for the 'pdf' button
                    },
                    {
                        extend: 'print',
                        title: '<p style="text-align: center; padding-bottom: 20px;">Campus Store Report From: ' +
                            start + ' To: ' + end + '</p>'
                    }
                ],
                lengthMenu: [
                    [10, 25, 50, 500, -1],
                    [10, 25, 50, 500, "All"]
                ],
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: "/getpatientreport",
                    data: function(data) {
                        data.from_date = $('#daterangein').data('daterangepicker').startDate.format(
                            'YYYY-MM-DD');
                        data.to_date = $('#daterangein').data('daterangepicker').endDate.format(
                            'YYYY-MM-DD');
                    },
                    type: 'delete',
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'created_at',
                        name: 'created_at',
                    },
                    {
                        data: 'student.full_name',
                        name: 'student.full_name',
                    },
                    {
                        data: 'student.student_id',
                        name: 'student.student_id',
                    },
                    {
                        data: 'student.sex',
                        name: 'student.sex',
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return data.register == '0' ?
                                '<i class="fa fa-circle text-danger"></i>' :
                                ' <i class="fa fa-check-circle text-success"></i>';
                        },
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return data.doctor == '0' ?
                                '<i class="fa fa-circle text-danger"></i>' :
                                ' <i class="fa fa-check-circle text-success"></i>';
                        },
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return data.pharmacy == '0' ?
                                '<i class="fa fa-circle text-danger"></i>' :
                                ' <i class="fa fa-check-circle text-success"></i>';
                        },
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return data.labratory == '0' ?
                                '<i class="fa fa-circle text-danger"></i>' :
                                ' <i class="fa fa-check-circle text-success"></i>';
                        },
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return data.referance == '0' ?
                                '<i class="fa fa-circle text-danger"></i>' :
                                ' <i class="fa fa-check-circle text-success"></i>';
                        },
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return '<div class="btn-group dropleft"><button type="button" class="btn btn-sm dropdown-toffle hide-arrow" data-toggle="dropdown" arial-haspopup="true" arial-expanded="false"><i class="fa fa-ellipsis-v"></i></button><div class = "dropdown-menu" > ' +
                                '<a class = "dropdown-item doctor" style="display: none;" onclick = "viewDoctor(' +
                                data
                                .id +
                                ')" id = "dteditbtn" title = "view doctor detail" data - id = "' +
                                data.id +
                                '"><i class="fa fa-info"></i>&nbsp;<span> View doctor </span></a>' +
                                '<a class = "dropdown-item pharmacy" style="display: none;" onclick = "viewPharmacy(' +
                                data
                                .id +
                                ')" id = "dteditbtn" title = "view pharmacy detail" data - id = "' +
                                data.id +
                                '"><i class="fa fa-info"></i>&nbsp;<span> View Pharmacy </span></a>' +
                                '<a class = "dropdown-item labratory" style="display: none;" onclick = "viewLabratory(' +
                                data
                                .id +
                                ')" id = "dteditbtn" title = "view labratory detail" data - id = "' +
                                data.id +
                                '"><i class="fa fa-info"></i>&nbsp;<span> View Labratory </span></a>' +
                                '<a class = "dropdown-item referance" style="display: none;" onclick = "viewReferance(' +
                                data
                                .id +
                                ')" id = "dteditbtn" title = "view referance detail" data - id = "' +
                                data.id +
                                '"><i class="fa fa-info"></i>&nbsp;<span> View Referance </span></a>' +
                                '<a class = "dropdown-item detail" onclick = "viewDetail(' +
                                data
                                .id +
                                ')" id = "dteditbtn" title = "view detail" data - id = "' +
                                data.id +
                                '"><i class="fa fa-info"></i>&nbsp;<span> No operation done </span></a>' +
                                '</div></div> ';
                        },
                        orderable: false,
                        searchable: false
                    }
                ],
                "fnRowCallback": function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                    if (aData.pharmacy == "1") {
                        $(nRow).find('.pharmacy').css({
                            "display": "flex"
                        });
                        $(nRow).find('.detail').css({
                            "display": "none"
                        });
                    }
                    if (aData.referance == "1") {
                        $(nRow).find('.referance').css({
                            "display": "flex"
                        });
                        $(nRow).find('.detail').css({
                            "display": "none"
                        });
                    }
                    if (aData.labratory == "1") {
                        $(nRow).find('.labratory').css({
                            "display": "flex"
                        });
                        $(nRow).find('.detail').css({
                            "display": "none"
                        });
                    }
                    if (aData.doctor == "1") {
                        $(nRow).find('.doctor').css({
                            "display": "flex"
                        });
                        $(nRow).find('.detail').css({
                            "display": "none"
                        });
                    }
                }
            });
            ctable.on('draw', function() {
                var body = $(ctable.table().body());
                body.unhighlight();
                body.highlight(ctable.search());
            })
        });
    </script>
    <script>
        $('#in').show();
        $('#daterangein').show();
        $('#report-title').html('Patient Report');

        function viewDoctor(record_id) {
            $.get('/viewDoctorPatient/' + record_id, function(data) {
                if (data.success) {
                    $('#fname_opd').val(data.patient.student.full_name);
                    $('#user_id_opd').val(data.patient.student.student_id);
                    if (data.patient.referance == null || data.patient.referance == "") {
                        $('#opd_referance').css({
                            "display": "none"
                        });
                    } else {
                        $('#opd_referance').css({
                            "display": "block"
                        });
                        $('.dep').html(data.patient.student.department);
                        $('.stud_id').html(data.patient.student.student_id);
                        $('.stud_name').html(data.patient.student.full_name);
                    }

                    $('#gender_opd').val(data.patient.student.sex);
                    $('#age_opd').val(data.patient.student.age);
                    $('#opd_name').val(data.patient.user.name);
                    if (data.patient.remark == null || data.patient.remark == "") {
                        $('#cleared').css({
                            "display": "none"
                        });
                    } else {
                        $('#cleared').css({
                            "display": "block"
                        });
                        $('#opd_description').html(data.patient.remark);
                    }
                    if (data.appointment == null || data.appointment == "") {
                        $('#opd_appointed').css({
                            "display": "none"
                        });
                    } else {
                        $('#opd_appointed').css({
                            "display": "block"
                        });
                        $('#start_date').html(data.appointment.start_date);
                        $('#end_date').html(data.appointment.end_date);
                        $('#appointment_description').html(data.appointment.description);
                    }
                    var nTable = $('#dynamicTable_opd').DataTable({
                        destroy: true,
                        processing: true,
                        serverSide: true,
                        searchHighlight: true,
                        dom: 'lBfrtip', // Add l before B to include lengthMenu
                        buttons: [{
                            extend: 'copy',
                            title: 'Your Title Here' // Title for the 'copy' button
                        }, ],
                        lengthMenu: [
                            [10, 25, 50, 500, -1],
                            [10, 25, 50, 500, "All"]
                        ],
                        language: {
                            search: '',
                            searchPlaceholder: "Search here"
                        },
                        ajax: {
                            headers: {
                                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                            },
                            url: '/patientpharmacyreport/' + record_id,
                            type: 'DELETE',
                            dataType: "json",
                            beforeSend: function() {
                                cardSection.block({
                                    message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                                    css: {
                                        backgroundColor: 'transparent',
                                        color: '#fff',
                                        border: '0'
                                    },
                                    overlayCSS: {
                                        opacity: 0.5
                                    }
                                });
                            },
                            complete: function() {
                                cardSection.block({
                                    message: '',
                                    timeout: 1,
                                    css: {
                                        backgroundColor: '',
                                        color: '',
                                        border: ''
                                    },
                                });
                            },
                        },

                        columns: [{
                                data: 'DT_RowIndex',
                                name: 'DT_RowIndex',
                                orderable: false,
                                searchable: false
                            },
                            {
                                data: 'product.item_name',
                                name: 'product.item_name',
                            },
                            {
                                data: 'description',
                                name: 'description',
                            },
                        ],
                    });
                    if (data.labratory == null || data.labratory == "") {
                        $('#opd_labratory').css({
                            "display": "none"
                        });
                    } else {
                        $('#opd_labratory').css({
                            "display": "block"
                        });
                        $('#other1').val(data.labratory.other);
                        $('#other_lab1').val(data.labratory.other_lab);
                        $('#labratory_id1').val(data.labratory.id);
                        $('#hg1').val(data.labratory.hg);
                        $('#hct1').val(data.labratory.hct);
                        $('#wbc11').val(data.labratory.wbc1);
                        $('#netrophils1').val(data.labratory.netrophils);
                        $('#basophils1').val(data.labratory.basophils);
                        $('#eosinophils1').val(data.labratory.eosinophils);
                        $('#monocytes1').val(data.labratory.monocytes);
                        $('#lymphocyted1').val(data.labratory.lymphocyted);
                        $('#esr1').val(data.labratory.esr);
                        data.labratory.app == 'on' ? $('#app1').prop('checked', true) : $('#app1').prop(
                            'checked',
                            false);
                        data.labratory.cons == 'on' ? $('#cons1').prop('checked', true) : $('#cons1')
                            .prop('checked',
                                false);
                        data.labratory.oip == 'on' ? $('#oip1').prop('checked', true) : $('#oip1').prop(
                            'checked',
                            false);
                        data.labratory.color == 'on' ? $('#color1').prop('checked', true) : $('#color1')
                            .prop('checked',
                                false);
                        data.labratory.leurcocyte == 'on' ? $('#leurcocyte1').prop('checked', true) : $(
                                '#leurcocyte1')
                            .prop('checked', false);
                        data.labratory.blood == 'on' ? $('#blood1').prop('checked', true) : $('#blood1')
                            .prop('checked', false);
                        data.labratory.nitrate == 'on' ? $('#nitrate1').prop('checked', true) : $(
                                '#nitrate1')
                            .prop('checked', false);
                        data.labratory.urobilinogen == 'on' ? $('#urobilinogen1').prop('checked',
                                true) : $(
                                '#urobilinogen1')
                            .prop('checked', false);
                        data.labratory.protein == 'on' ? $('#protein1').prop('checked', true) : $(
                                '#protein1')
                            .prop('checked', false);
                        data.labratory.ph == 'on' ? $('#ph1').prop('checked', true) : $('#ph1')
                            .prop('checked', false);
                        data.labratory.spec == 'on' ? $('#spec1').prop('checked', true) : $('#spec1')
                            .prop('checked', false);
                        data.labratory.ketones == 'on' ? $('#ketones1').prop('checked', true) : $(
                                '#ketones1')
                            .prop('checked', false);
                        data.labratory.bilirubin == 'on' ? $('#bilirubin1').prop('checked', true) : $(
                                '#bilirubin1')
                            .prop('checked', false);
                        data.labratory.glucose == 'on' ? $('#glucose1').prop('checked', true) : $(
                                '#glucose1')
                            .prop('checked', false);
                        data.labratory.rbc == 'on' ? $('#rbc1').prop('checked', true) : $('#rbc1')
                            .prop('checked', false);
                        data.labratory.wbc == 'on' ? $('#wbc1').prop('checked', true) : $('#wbc1')
                            .prop('checked', false);
                        data.labratory.blood_film == 'on' ? $('#blood_film1').prop('checked', true) : $(
                                '#blood_film1')
                            .prop('checked', false);
                        data.labratory.imunohematology == 'on' ? $('#imunohematology1').prop('checked',
                                true) : $(
                                '#imunohematology1')
                            .prop('checked', false);
                        data.labratory.blood_group == 'on' ? $('#blood_group1').prop('checked', true) :
                            $(
                                '#blood_group1')
                            .prop('checked', false);
                        data.labratory.o == 'on' ? $('#o1').prop('checked', true) : $('#o1')
                            .prop('checked', false);
                        data.labratory.h == 'on' ? $('#h1').prop('checked', true) : $('#h1')
                            .prop('checked', false);
                        data.labratory.ox == 'on' ? $('#ox1').prop('checked', true) : $('#ox1')
                            .prop('checked', false);
                        data.labratory.rbr == 'on' ? $('#rbr1').prop('checked', true) : $('#rbr1')
                            .prop('checked', false);
                        data.labratory.theumatoid == 'on' ? $('#theumatoid1').prop('checked', true) : $(
                                '#theumatoid1')
                            .prop('checked', false);
                        data.labratory.hcg == 'on' ? $('#hcg1').prop('checked', true) : $('#hcg1')
                            .prop('checked', false);
                        data.labratory.fbc == 'on' ? $('#fbc1').prop('checked', true) : $('#fbc1')
                            .prop('checked', false);
                        data.labratory.bactreglology == 'on' ? $('#bactreglology1').prop('checked',
                                true) : $(
                                '#bactreglology1')
                            .prop('checked', false);
                        data.labratory.gram_stan == 'on' ? $('#gram_stan1').prop('checked', true) : $(
                                '#gram_stan1')
                            .prop('checked', false);
                        data.labratory.ab == 'on' ? $('#ab1').prop('checked', true) : $(
                                '#ab1')
                            .prop('checked', false);
                    }
                }
            });

            $('#doctorModal').modal('show');

            $('#doctorModal').modal('show');
        }

        function viewLabratory(record_id) {
            $('#savelabratory').css({
                "display": "none"
            });
            $.get('/getLabratory/' + record_id, function(data) {
                if (data.student) {
                    $('#fullname').val(data.student.full_name);
                    $('#stud_id').val(data.student.student_id);
                    $('#new_sex').val(data.student.sex);
                    $('#new_age').val(data.student.age);
                    $('#pname').val(data.patient.user.name)
                    $('#lname').val(data.lab)
                    $('#date_from').val(data.labratory.created_at)
                    $('#lab_id').val(record_id);
                    $('#sendModal').modal('hide');
                    $('#labratoryModal').modal('show');
                }
                if (data.labratory) {
                    $('#other').val(data.labratory.other);
                    $('#other_lab').val(data.labratory.other_lab);
                    $('#labratory_id').val(data.labratory.id);
                    $('#hg').val(data.labratory.hg);
                    $('#hct').val(data.labratory.hct);
                    $('#wbc1').val(data.labratory.wbc1);
                    $('#netrophils').val(data.labratory.netrophils);
                    $('#basophils').val(data.labratory.basophils);
                    $('#eosinophils').val(data.labratory.eosinophils);
                    $('#monocytes').val(data.labratory.monocytes);
                    $('#lymphocyted').val(data.labratory.lymphocyted);
                    $('#esr').val(data.labratory.esr);
                    data.labratory.app == 'on' ? $('#app').prop('checked', true) : $('#app').prop('checked', false);
                    data.labratory.cons == 'on' ? $('#cons').prop('checked', true) : $('#cons').prop('checked',
                        false);
                    data.labratory.oip == 'on' ? $('#oip').prop('checked', true) : $('#oip').prop('checked', false);
                    data.labratory.color == 'on' ? $('#color').prop('checked', true) : $('#color').prop('checked',
                        false);
                    data.labratory.leurcocyte == 'on' ? $('#leurcocyte').prop('checked', true) : $('#leurcocyte')
                        .prop('checked', false);
                    data.labratory.blood == 'on' ? $('#blood').prop('checked', true) : $('#blood')
                        .prop('checked', false);
                    data.labratory.nitrate == 'on' ? $('#nitrate').prop('checked', true) : $('#nitrate')
                        .prop('checked', false);
                    data.labratory.urobilinogen == 'on' ? $('#urobilinogen').prop('checked', true) : $(
                            '#urobilinogen')
                        .prop('checked', false);
                    data.labratory.protein == 'on' ? $('#protein').prop('checked', true) : $('#protein')
                        .prop('checked', false);
                    data.labratory.ph == 'on' ? $('#ph').prop('checked', true) : $('#ph')
                        .prop('checked', false);
                    data.labratory.spec == 'on' ? $('#spec').prop('checked', true) : $('#spec')
                        .prop('checked', false);
                    data.labratory.ketones == 'on' ? $('#ketones').prop('checked', true) : $('#ketones')
                        .prop('checked', false);
                    data.labratory.bilirubin == 'on' ? $('#bilirubin').prop('checked', true) : $('#bilirubin')
                        .prop('checked', false);
                    data.labratory.glucose == 'on' ? $('#glucose').prop('checked', true) : $('#glucose')
                        .prop('checked', false);
                    data.labratory.rbc == 'on' ? $('#rbc').prop('checked', true) : $('#rbc')
                        .prop('checked', false);
                    data.labratory.wbc == 'on' ? $('#wbc').prop('checked', true) : $('#wbc')
                        .prop('checked', false);
                    data.labratory.blood_film == 'on' ? $('#blood_film').prop('checked', true) : $('#blood_film')
                        .prop('checked', false);
                    data.labratory.imunohematology == 'on' ? $('#imunohematology').prop('checked', true) : $(
                            '#imunohematology')
                        .prop('checked', false);
                    data.labratory.blood_group == 'on' ? $('#blood_group').prop('checked', true) : $('#blood_group')
                        .prop('checked', false);
                    data.labratory.o == 'on' ? $('#o').prop('checked', true) : $('#o')
                        .prop('checked', false);
                    data.labratory.h == 'on' ? $('#h').prop('checked', true) : $('#h')
                        .prop('checked', false);
                    data.labratory.ox == 'on' ? $('#ox').prop('checked', true) : $('#ox')
                        .prop('checked', false);
                    data.labratory.rbr == 'on' ? $('#rbr').prop('checked', true) : $('#rbr')
                        .prop('checked', false);
                    data.labratory.theumatoid == 'on' ? $('#theumatoid').prop('checked', true) : $('#theumatoid')
                        .prop('checked', false);
                    data.labratory.hcg == 'on' ? $('#hcg').prop('checked', true) : $('#hcg')
                        .prop('checked', false);
                    data.labratory.fbc == 'on' ? $('#fbc').prop('checked', true) : $('#fbc')
                        .prop('checked', false);
                    data.labratory.bactreglology == 'on' ? $('#bactreglology').prop('checked', true) : $(
                            '#bactreglology')
                        .prop('checked', false);
                    data.labratory.gram_stan == 'on' ? $('#gram_stan').prop('checked', true) : $(
                            '#gram_stan')
                        .prop('checked', false);
                    data.labratory.ab == 'on' ? $('#ab').prop('checked', true) : $(
                            '#ab')
                        .prop('checked', false);
                }
            });
        }

        function viewReferance(record_id) {

            $('#print_id').val(record_id);
            $.get('/getReference/' + record_id, function(data) {
                if (data.student) {
                    $('.dep').html(data.student.department);
                    $('.stud_id').html(data.student.student_id);
                    $('.stud_name').html(data.student.full_name);
                    $('#refrance_pname').val(data.patient.user.name);
                    $('#referanceModal').modal('show');
                }
            });
        }

        function viewPharmacy(record_id) {

            $.get('/sendPharmacy/' + record_id, function(data) {
                if (data.student) {
                    $('#ph_name').val(data.student.full_name);
                    $('#ph_id').val(data.student.student_id);
                    $('#ph_gender').val(data.student.sex);
                    $('#age_number').val(data.student.age);
                    $('#opd_by').val(data.patient.user.name);
                    $('#phar_by').val(data.patient.pharmacy_user.name);
                    if (data.patient.state == '1') {
                        $('#checkwithdraw').css({
                            "display": "none"
                        });
                        $('#withp').css({
                            "display": "flex"
                        });
                    } else {
                        $('#checkwithdraw').css({
                            "display": "flex"
                        });
                        $('#withp').css({
                            "display": "none"
                        });
                    }
                    $('#sendModal').modal('hide');
                    $('#pharmacyModal').modal('show');
                }
            });
            var nTable = $('#pharmacyTable').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                searchHighlight: true,
                dom: 'lBfrtip', // Add l before B to include lengthMenu
                buttons: [{
                        extend: 'copy',
                        title: 'Your Title Here' // Title for the 'copy' button
                    },
                    {
                        extend: 'csv',
                        title: 'Your Title Here' // Title for the 'csv' button
                    },
                    {
                        extend: 'excel',
                        title: 'Your Title Here' // Title for the 'excel' button
                    },
                    {
                        extend: 'pdf',
                        title: 'Your Title Here' // Title for the 'pdf' button
                    },
                    {
                        extend: 'print',
                        title: 'Yout title here'
                    }
                ],
                lengthMenu: [
                    [10, 25, 50, 500, -1],
                    [10, 25, 50, 500, "All"]
                ],
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: '/pharmacyInfo/' + record_id,
                    type: 'DELETE',
                    dataType: "json",
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },

                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'select_column',
                        name: 'select_column',
                    },
                    {
                        data: 'description',
                        name: 'description',
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return '<input type="text" class="quan' + data.id + ' form-control">';
                        },
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return ' <p class="done">Completed</p><a class="btn btn-info withdraw" onclick="withdrawFn(' +
                                data.id +
                                ')" id="dtinfobtn" title="Withdraw Product" data-id = "' +
                                data.id +
                                '"><span> Withdraw </span></a> ';
                        },
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return ' <p class="cancled">Cancled</p><a class="btn btn-danger cancel" onclick="checkCancel(' +
                                data.id +
                                ')" id="dtinfobtn" title="Cancel Withdraw" data-id = "' +
                                data.id +
                                '"><span> Cancel </span></a> ';
                        },
                        orderable: false,
                        searchable: false
                    }
                ],
                "fnRowCallback": function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {

                    if (aData.status == "1") {
                        $(nRow).find('.quan').prop('readonly',
                            false);
                        $(nRow).find('.done').css({
                            "display": "none"
                        });
                        $(nRow).find('.cancled').css({
                            "display": "none"
                        });
                        $(nRow).find('.withdraw').css({
                            "display": "flex"
                        });
                        $(nRow).find('.cancel').css({
                            "display": "flex"
                        });
                        $(nRow).find('.quan' + aData.id + '').val(aData.quantity * aData.product.unit.capacity);
                    } else if (aData.status == "3") {
                        $(nRow).find('.quan' + aData.id + '').prop('readonly',
                            true);
                        $(nRow).find('.quan' + aData.id + '').val(aData.quantity * aData.product.unit.capacity);
                        $(nRow).find('.cancled').css({
                            "display": "flex",
                            "color": "red",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #4CAF50"
                        });
                        $(nRow).find('.withdraw').css({
                            "display": "none"
                        });
                        $(nRow).find('.cancel').css({
                            "display": "none"
                        });
                        $(nRow).find('.done').html('No');
                    } else {
                        $(nRow).find('.quan' + aData.id + '').prop('readonly',
                            true);
                        $(nRow).find('.quan' + aData.id + '').val(aData.quantity * aData.product.unit.capacity);
                        $(nRow).find('.done').css({
                            "display": "flex",
                            "color": "green",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #4CAF50"
                        });
                        $(nRow).find('.withdraw').css({
                            "display": "none"
                        });
                        $(nRow).find('.cancel').css({
                            "display": "none"
                        });
                        $(nRow).find('.cancled').html('No')
                    }

                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Werabe University Project\Werabe University Project\resources\views\report\patientReport.blade.php ENDPATH**/ ?>