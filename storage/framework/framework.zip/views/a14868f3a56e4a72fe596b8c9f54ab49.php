<?php $__env->startSection('title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="app-content content">
        <section id="responsive-datatable">
            <div class="row">
                <div class="col-12">
                    <!-- Your HTML content goes here -->
                    <div class="card">
                        <div class="card-header border-bottom">
                            <h3 class="card-title">Receiptions</h3>

                            <button type="button" class="btn btn-gradient-info btn-sm add">Add</button>

                        </div>
                        <div class="card-datatable">
                            <div style="width:98%; margin-left:1%;">
                                <div class="table-responsive">

                                    <table id="laravel-datatable-receiption"
                                        class="display table-bordered table-striped table-hover dt-responsive mb-0 dataTable no-footer"
                                        style="width: 100%;" role="grid" aria-describedby="laravel-datatable-receiption">

                                        <thead>
                                            <tr role="row">
                                                <th scope="col" width="1%">#</th>
                                                <th scope="col" width="40%">Name</th>
                                                <th scope="col" width="40%">Status</th>
                                                <th scope="col" width="40%">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody></tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- BEGIN: Category Add modal  -->
        <div class="modal fade text-left" id="inlineForm" data-keyboard="false" data-backdrop="static" tabindex="-1"
            role="dialog" aria-labelledby="lbl" aria-hidden="true" style="overflow-y: scroll;">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="lbl">Add Receiption</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                            onclick="closeModal()">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form id="Register">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="edit_id" id="edit_id">
                        <div class="modal-body">
                            <label strong style="font-size: 16px;">Receiption Name</label><label
                                style="color: red; font-size:16px;">*</label>
                            <div class="form-group">
                                <input type="text" placeholder="Write Receiption Name here" class="form-control"
                                    name="name" id='name' onkeyup="removeNameValidation()" autofocus />
                                <span class="text-danger">
                                    <strong id="name-error"></strong>
                                </span>
                            </div>
                            <label strong style="font-size: 16px;">Status</label><label
                                style="color: red; font-size:16px;">*</label>
                            <div class="form-group">
                                <div>
                                    <select class="custom-select browser-default select2" name="status" id="status"
                                        onclick="removeStatusValidation()">
                                        <option value="Active">Active</option>
                                        <option value="Inactive">Inactive</option>
                                    </select>
                                    <span class="text-danger">
                                        <strong id="status-error"></strong>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button id="savenewbutton" type="button" class="btn btn-info">Save &
                                New</button>
                            <button id="savebutton" type="button" class="btn btn-info">Save & Close</button>
                            <button id="closebutton" type="button" class="btn btn-danger" onclick="closeModal()"
                                data-dismiss="modal">Close</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    
    <div class="modal fade" id="DeleteModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Delete Receiption Data</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                        onclick="closeModalWithClearValidation()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" style="background-color:#e74a3b">
                    <label strong style="font-size: 16px;font-weight:bold;color:white;">Do you really want to
                        delete this receiption?</label>
                    <input type="hidden" id="deleteing_id">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-info delete_receiption">Delete</button>
                    <button id="closebutton" type="button" class="btn btn-danger"
                        onclick="closeModalWithClearValidation()" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        var errorcolor = "#ffcccc";
        $(function() {
            cardSection = $('#page-block');
        });
        /* BEGIN: Display zone table using yajra datatable */
        $(document).ready(function() {
            var ctable = $('#laravel-datatable-receiption').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                searchHighlight: true,
                "pagingType": "simple",
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                "dom": "<'row'<'col-lg-10 col-md-10 col-xs-8'f><'col-lg-2 col-md-2 col-xs-8'>>" +
                    "<'row'<'col-sm-12'tr>>" +
                    "<'row'<'col-sm-12 col-md-3'l><'col-sm-12 col-md-5'i><'col-sm-12 col-md-3'p>>",
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: '/getreceiptions',
                    type: 'DELETE',
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'name',
                        name: 'name'
                    },
                    {
                        data: 'status',
                        name: 'status'
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return '<div class="btn-group dropleft"><button type="button" class="btn btn-sm dropdown-toffle hide-arrow" data-toggle="dropdown" arial-haspopup="true" arial-expanded="false"><i class="fa fa-ellipsis-v"></i></button><div class = "dropdown-menu" > ' +
                                '<a class = "dropdown-item receiptionEdit" onclick = "receiptionEditFn(' +
                                data
                                .id +
                                ')" id = "dteditbtn" title = "Open receiption update page" data - id = "' +
                                data.id +
                                '"><i class="fa fa-edit"></i><span> Edit </span></a>' +
                                '<a class = "dropdown-item" onclick = "receiptionDeleteFn(' +
                                data
                                .id +
                                ')" id = "dtdeletebtn" title = "Delete" data-id = "' +
                                data.id +
                                '"><i class="fa fa-trash"></i><span> Delete </span></a></div></div> ';
                        },
                        orderable: false,
                        searchable: false
                    }
                ],
                "fnRowCallback": function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                    if (aData.status == "Active") {
                        $(nRow).find('td:eq(2)').css({
                            "color": "#4CAF50",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #4CAF50"
                        });
                    } else if (aData.status == "Inactive") {

                        $(nRow).find('td:eq(2)').css({
                            "color": "#f44336",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #f44336"
                        });
                    }
                }
            });
            ctable.on('draw', function() {
                var body = $(ctable.table().body());
                body.unhighlight();
                body.highlight(ctable.search());
            })
        });
    </script>
    <script>
        $('.add').click(function() {
            $('#name').val('');
            $('#status').val('Active').trigger('change');
            $('#name-error').html('');
            $('#status-error').html('');
            $('#savenewbutton').css('display', 'flex');
            $('#savebutton').html('Save & Close');
            $('#savenewbutton').html('Save & New');
            $('#inlineForm').modal('show');
        });
        $('#savebutton').click(function() {
            var receiptionForm = $('#Register');
            var formData = receiptionForm.serialize();
            var id = $('#edit_id').val();
            $.ajax({
                url: '/createupdatereceiption/' + id,
                type: 'post',
                data: formData,
                beforeSend: function() {
                    cardSection.block({
                        message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                        css: {
                            backgroundColor: 'transparent',
                            color: '#fff',
                            border: '0'
                        },
                        overlayCSS: {
                            opacity: 0.5
                        }
                    });
                    if (id != "" && id != null) {
                        $('#savebutton').text('Updating...');
                        $('#savebutton').prop("disabled", true);
                    } else {
                        $('#savebutton').text('Saving...');
                        $('#savebutton').prop("disabled", true);
                    }

                },
                complete: function() {
                    cardSection.block({
                        message: '',
                        timeout: 1,
                        css: {
                            backgroundColor: '',
                            color: '',
                            border: ''
                        },
                    });
                },
                success: function(data) {
                    if (data.errors) {
                        if (data.errors.name) {
                            $('#name-error').html(data.errors.name[0]);
                        }
                        if (data.errors.status) {
                            $('#status-error').html(data.errors.status[0]);
                        }
                        if (id != "" && id != null) {
                            $('#savebutton').text('Update');
                        } else {
                            $('#savebutton').text('Save & Close');
                        }
                        $('#savebutton').prop("disabled", false);
                    } else if (data.success) {
                        alert_toast(data.success, 'success');
                        var cTable = $('#laravel-datatable-receiption').dataTable();
                        cTable.fnDraw(false);
                        $('#savebutton').html('Save & Close');
                        $('#savebutton').prop("disabled", false);
                        $('#inlineForm').modal('hide');
                    }
                }

            });
        });

        $('#savenewbutton').click(function() {
            var typeForm = $('#Register');
            var formData = typeForm.serialize();
            var id = $('#edit_id').val();
            $.ajax({
                url: '/createupdatereceiption/' + id,
                type: 'post',
                data: formData,
                beforeSend: function() {
                    cardSection.block({
                        message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                        css: {
                            backgroundColor: 'transparent',
                            color: '#fff',
                            border: '0'
                        },
                        overlayCSS: {
                            opacity: 0.5
                        }
                    });
                    $('#savenewbutton').text('Saving...');
                    $('#savenewbutton').prop("disabled", true);
                },
                complete: function() {
                    cardSection.block({
                        message: '',
                        timeout: 1,
                        css: {
                            backgroundColor: '',
                            color: '',
                            border: ''
                        },
                    });
                },
                success: function(data) {
                    if (data.errors) {
                        if (data.errors.name) {
                            $('#name-error').html(data.errors.name[0]);
                        }
                        if (data.errors.status) {
                            $('#status-error').html(data.errors.status[0]);
                        }
                        $('#savenewbutton').text('Save & New');
                        $('#savenewbutton').prop("disabled", false);
                    } else if (data.success) {
                        alert_toast(data.success, 'success');
                        var cTable = $('#laravel-datatable-receiption').dataTable();
                        cTable.fnDraw(false);
                        $('#savenewbutton').html('Save & New');
                        $('#name').val('');
                        $('#savenewbutton').prop("disabled", false);
                        $('#inlineForm').modal('show');
                    }
                }

            });
        });

        function receiptionEditFn(record_id) {
            $('#edit_id').val(record_id);
            $('#savenewbutton').css('display', 'none');
            $('#savebutton').html('Update');
            $.get('/editreceiption/' + record_id, function(data) {
                $('#name').val(data.receiption.name);
                $('#status').val(data.receiption.status).trigger('change');
            });
            $('#inlineForm').modal('show');
        }

        function receiptionDeleteFn(record_id) {
            $('#deleteing_id').val(record_id);
            $('#DeleteModal').modal('show');
        }
        $('.delete_receiption').click(function() {
            var delete_id = $('#deleteing_id').val();
            $.ajax({
                url: '/deletereceiption/' + delete_id,
                type: 'get',
                beforeSend: function() {
                    $('.delete_receiption').text('Deleteing...');
                },
                success: function(data) {
                    if (data.errors) {
                        $('.delete_receiption').text('Delete');
                        alert('an error occured');
                    } else if (data.success) {
                        $('.delete_receiption').text('Delete');
                        alert_toast(data.success, 'success')
                        var cTable = $('#laravel-datatable-receiption').dataTable();
                        cTable.fnDraw(false);
                        $('#DeleteModal').modal('hide');
                    }
                }
            });
        });
    </script>
    <script>
        function removeNameValidation() {
            $('#name-error').html('');
        }

        function removeStatusValidation() {
            $('#status-error').html('');
        }

        function closeModal() {
            $('#name-error').html('');
            $('#status-error').html('');
            $('#name').val('');
            $('#status').val('').trigger('change');
            $('#savenewbutton').css('display', 'flex');
            $('#savebutton').html('Save & Close');
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Werabe University Project\Werabe University Project\resources\views\registry\receiptions.blade.php ENDPATH**/ ?>