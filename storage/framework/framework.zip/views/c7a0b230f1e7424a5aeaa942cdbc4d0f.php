<?php $__env->startSection('content'); ?>
    <div class="app-content content">
        <section id="responsive-datatable" style="font-size: 11px;">
            <div id="success_message" style="padding: 13px 20px;"></div>
            <div class="row">
                <div class="col-12">
                    <!-- Your HTML content goes here -->
                    <div class="card">
                        <div class="card-header border-bottom">
                            <h3 class="card-title">Out Deliver Requests</h3>


                        </div>
                        <div class="card-datatable">
                            <div style="width:98%; margin-left:1%;">
                                <div class="table-responsive">

                                    <table id="laravel-datatable-campus"
                                        class="display table-bordered table-striped table-hover dt-responsive mb-0 dataTable no-footer"
                                        style="width: 100%;" role="grid" aria-describedby="laravel-datatable-crud_info">
                                        <thead>
                                            <tr role="row">
                                                <th style="width:7%;">#</th>
                                                <th>Expired Date</th>
                                                <th>Batch No</th>
                                                <th>Item Name</th>
                                                <th>Category</th>
                                                <th>Type</th>
                                                <th>UoM</th>
                                                <th>Requested From</th>
                                                <th>Requested By</th>
                                                <th>Quantity</th>
                                                <th>Status</th>
                                                <th style="width:5%;">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody></tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="modal fade" id="deliverModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel"></h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                                onclick="closeModalWithClearValidation()">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form id="request_deliver">
                            <?php echo e(csrf_field()); ?>

                            <div class="modal-body">
                                <div class="modal-header">Authenticate Receiver (Are you sure you have received the
                                    product?)</div>
                                <div class="form-group">
                                    <label for="">Authentication code</label>
                                    <input type="code" name="code" placeholder="Write authentication code here..."
                                        class="form-control" id="code">
                                </div>
                                <input type="hidden" id="deliver_id" name="deliver_id">
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-info deliver_request">Submit</button>
                                <button id="closebutton" type="button" class="btn btn-danger"
                                    onclick="closeModalWithClearValidation()" data-dismiss="modal">Close</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            
            <div class="modal fade" id="codeModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="code"></h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                                onclick="closecode()">

                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <p style="font-size: 20px;">Code: <span id="viewcode"></span></p>
                        </div>
                        <div class="modal-footer">
                            <button id="closebutton" type="button" class="btn btn-danger"
                                onclick="closeModalWithClearValidation()" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        var state = false;

        function viewCode() {
            state = !state;
            if (state === true) {
                $('#clickcode').html('click to hide code');
                $('#viewcode').css({
                    "background": "white",
                    "color": "black",
                })
            } else {
                $('#clickcode').html('click to show code');
                $('#viewcode').css({
                    "background": "gray",
                    "color": "gray",
                })
            }
        }
        var errorcolor = "#ffcccc";
        $(function() {
            cardSection = $('#page-block');
        });
        /* BEGIN: Display zone table using yajra datatable */
        $(document).ready(function() {
            var ctable = $('#laravel-datatable-campus').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                searchHighlight: true,
                dom: 'lBfrtip', // Add l before B to include lengthMenu
                buttons: [{
                        extend: 'copy',
                        title: 'Stock', // Title for the 'copy' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,
                                9
                            ] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'csv',
                        title: 'Stock', // Title for the 'csv' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,
                                9
                            ] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'excel',
                        title: 'Stock', // Title for the 'excel' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,
                                9
                            ] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'pdf',
                        title: 'Stock',
                        orientation: 'landscape', // Set orientation: 'landscape' or 'portrait'
                        pageSize: 'A4', // Set page size
                        customize: function(doc) {
                            // Customize header, footer, and body style
                            doc.styles.tableHeader = {
                                fillColor: '#4CAF50',
                                color: 'white',
                                alignment: 'center'
                            };
                            doc.styles.title = {
                                fontSize: 14,
                                alignment: 'center'
                            };
                            doc.defaultStyle.fontSize = 10; // Change default font size
                            doc.content[1].table.widths = '*'.repeat(doc.content[1].table.body[0]
                                .length).split(''); // Automatically adjust column widths
                            doc.pageMargins = [10, 10, 10, 10]; // Adjust page margins
                            doc.pageSize = 'A4'; // Ensure the page size is A4
                            doc.content[1].layout = {
                                hLineWidth: function(i, node) {
                                    return (i === 0 || i === node.table.body.length) ? 2 :
                                        1;
                                },
                                vLineWidth: function(i, node) {
                                    return (i === 0 || i === node.table.widths.length) ? 2 :
                                        1;
                                },
                                hLineColor: function(i, node) {
                                    return (i === 0 || i === node.table.body.length) ?
                                        'black' : 'gray';
                                },
                                vLineColor: function(i, node) {
                                    return (i === 0 || i === node.table.widths.length) ?
                                        'black' : 'gray';
                                },
                                paddingLeft: function(i, node) {
                                    return 4;
                                },
                                paddingRight: function(i, node) {
                                    return 4;
                                },
                                paddingTop: function(i, node) {
                                    return 2;
                                },
                                paddingBottom: function(i, node) {
                                    return 2;
                                },
                            };
                        },
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,
                                9
                            ] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'print',
                        title: 'Stock',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6, 7, 8,
                                9
                            ] // Indexes of the columns you want to include
                        }
                    }
                ],
                lengthMenu: [
                    [10, 25, 50, 500, -1],
                    [10, 25, 50, 500, "All"]
                ],
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: '/getpharmacyrequest/' + 2,
                    type: 'DELETE',
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'store.expired_date',
                        name: 'store.expired_date',
                    },
                    {
                        data: 'store.seriel_number',
                        name: 'store.seriel_number',
                    },
                    {
                        data: 'store.product.item_name',
                        name: 'store.product.item_name'
                    },
                    {
                        data: 'store.product.category.name',
                        name: 'store.product.category.name'
                    },
                    {
                        data: 'item_type',
                        name: 'item_type'
                    },
                    {
                        data: 'unit',
                        name: 'unit'
                    },
                    {
                        data: 'request_from',
                        name: 'request_from'
                    },
                    {
                        data: 'user.name',
                        name: 'user.name'
                    },
                    {
                        data: 'quantity',
                        name: 'quantity'
                    },
                    {
                        data: 'status',
                        name: 'status'
                    },

                    {
                        data: null,
                        render: function(data, type, full, meta) {

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('allow_clinic')): ?>
                                return '<a class = "btn btn-warning campusDeliver" onclick = "deliverFn(' +
                                    data
                                    .id +
                                    ')" id = "deliver" title = "request" data-id = "' +
                                    data.id +
                                    '"><span> Deliver </span></a>';
                            <?php else: ?>
                                return '<div class="btn btn-info" onclick="viewCode(' + data.id +
                                    ')">Code</div>';
                            <?php endif; ?>
                        },
                        orderable: false,
                        searchable: false
                    }

                ],
                "fnRowCallback": function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                    if (aData.status == "2") {
                        $(nRow).find('td:eq(10)').html('Ready for Delivery');
                        $(nRow).find('td:eq(10)').css({
                            "color": "green",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #f44336"
                        });
                    }
                }
            });
            ctable.on('draw', function() {
                var body = $(ctable.table().body());
                body.unhighlight();
                body.highlight(ctable.search());
            })
        });
    </script>
    <script>
        function viewCode(record_id) {
            $.get("/viewcode" + '/' + record_id, function(data) {
                if (data.code) {
                    $('#viewcode').html(data.code);
                    $('#codeModal').modal('show');

                } else {
                    $('#viewcode').html('There no code');
                }
            });
        }

        function deliverFn(record_id) {
            $('#code').val('');
            $.get("/deliverpharmacyProduct" + '/' + record_id, function(data) {
                if (data.success) {
                    $('#deliver_id').val(record_id);
                    $('#deliverModal').modal('show');

                } else {
                    alert_toast('There is no request', 'error');
                }
            });

        }
        $(document).on('click', '.deliver_request', function() {
            var deliverData = $('#request_deliver');
            var formData = deliverData.serialize();
            $.ajax({
                url: '/deliverpharmacyRequest',
                type: 'post',
                data: formData,
                beforeSend: function() {
                    $('.deliver_request').text('Submitting...');
                },
                success: function(data) {
                    if (data.success) {
                        $('#code').val('');
                        $('#deliverModal').modal('hide');
                        $('.deliver_request').html('Submit');
                        alert_toast('Successfully request Delivered!', 'success');
                        var cTable = $('#laravel-datatable-campus').dataTable();
                        cTable.fnDraw(false);
                    } else {
                        $('.deliver_request').html('Submit');
                        alert_toast(data.error, 'error');
                    }
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Werabe University Project\Werabe University Project\resources\views\pharmacy-request\out.blade.php ENDPATH**/ ?>