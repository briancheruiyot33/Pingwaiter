<?php $__env->startSection('content'); ?>
    <div class="app-content content">
        <section id="responsive-datatable">
            <div id="success_message" style="padding: 13px 20px;"></div>
            <div class="row">
                <div class="col-12">
                    <!-- Your HTML content goes here -->
                    <div class="card">
                        <div class="card-header border-bottom">
                            <h3 class="card-title">Campus Store</h3>

                        </div>
                        <div class="card-datatable">
                            <div style="width:98%; margin-left:1%;">
                                <div class="table-responsive">

                                    <table id="laravel-datatable-campus"
                                        class="display table-bordered table-striped table-hover dt-responsive mb-0 dataTable no-footer"
                                        style="width: 100%;" role="grid" aria-describedby="laravel-datatable-crud_info">
                                        <thead>
                                            <tr role="row">
                                                <th style="width:7%;">#</th>
                                                <th>Date Received</th>
                                                <th>SKU</th>
                                                <th>Supplier Name</th>
                                                <th>Receiption Name</th>
                                                <th>Item No</th>
                                                <th>Status</th>
                                                <th style="width:5%;">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody></tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php echo $__env->make('clinics.request', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        var errorcolor = "#ffcccc";
        $(function() {
            cardSection = $('#page-block');
        });
        /* BEGIN: Display zone table using yajra datatable */
        $(document).ready(function() {
            var ctable = $('#laravel-datatable-campus').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                searchHighlight: true,
                dom: 'lBfrtip', // Add l before B to include lengthMenu
                buttons: [{
                        extend: 'copy',
                        title: 'Your Title Here' // Title for the 'copy' button
                    },
                    {
                        extend: 'csv',
                        title: 'Your Title Here' // Title for the 'csv' button
                    },
                    {
                        extend: 'excel',
                        title: 'Your Title Here' // Title for the 'excel' button
                    },
                    {
                        extend: 'pdf',
                        title: 'Your Title Here' // Title for the 'pdf' button
                    },
                    {
                        extend: 'print',
                        title: 'Yout title here'
                    }
                ],
                lengthMenu: [
                    [10, 25, 50, 500, -1],
                    [10, 25, 50, 500, "All"]
                ],
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: '/get-campus',
                    type: 'DELETE',
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'date_created',
                        name: 'date_created'
                    },
                    {
                        data: 'sku',
                        name: 'sku'
                    },
                    {
                        data: 'supplier.name',
                        name: 'supplier.name'
                    },
                    {
                        data: 'receiption.name',
                        name: 'receiption.name'
                    },
                    {
                        data: 'item_no',
                        name: 'item_no'
                    },
                    {
                        data: 'status',
                        name: 'status'
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return ' <a class="btn btn-info campusInfo" style="padding: 5px 5px; width: 100%;" onclick="campusInfoFn(' +
                                data.id +
                                ')" id="dtinfobtn" title="Open campus information page" data-id = "' +
                                data.id +
                                '"><span> View Detail </span></a>';
                        },
                        orderable: false,
                        searchable: false
                    }
                ],
                "fnRowCallback": function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                    if (aData.status == "1") {
                        $(nRow).find('td:eq(6)').html('Campus');
                        $(nRow).find('td:eq(6)').css({
                            "color": "orange",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #4CAF50"
                        });
                    } else if (aData.status == "5") {
                        $(nRow).find('td:eq(6)').html('Waiting Clinic Leader');
                        $(nRow).find('td:eq(6)').css({
                            "color": "blue",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #4CAF50"
                        });
                    }
                }
            });
            ctable.on('draw', function() {
                var body = $(ctable.table().body());
                body.unhighlight();
                body.highlight(ctable.search());
            })
        });
    </script>
    <script>
        function campusInfoFn(record_id) {
            $('#request_id').val(record_id);
            // $("#informationmodal").modal('show');
            $.get("/show_campusStore" + '/' + record_id, function(data) {
                $.each(data.campus, function(key, value) {
                    $("#incoming_info").html(data.campus.incoming_goods);
                    $("#stock_info").html(data.campus.stock);
                    $("#store_info").html(data.campus.store_no);
                    $("#shelf_info").html(data.campus.shelf_no);
                    $("#receiption_info").html(data.campus.receiption_id);
                    $("#sku_info").html(data.campus.sku);
                    $("#supplier_info").html(data.campus.supplier_id);
                    $("#date_created_info").html(data.campus.date_created);
                    //$("#created_by").html(data.cr.username);
                    //$("#updated_by").html(data.ur.username);
                    //var st = data.zone.status;
                    var ca = new Date(data.campus.created_at);

                    $("#created_at").html(data.crdate);

                    if (data.ur !== "") {
                        $("#updated_at").html(data.upgdate);
                    }
                });
                if (data.campus.status == '2') {
                    $('#send_request').css({
                        "display": "none"
                    });
                    $('#state').html('Pending');
                }
                <?php $__currentLoopData = auth()->user()->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($role->name == 'clinic'): ?>
                        if (data.campus.status == '5') {
                            $('#send_request').css({
                                "display": "none"
                            });
                            $('#approve_request').css({
                                "display": "none"
                            });
                            $('#state').html('Request Is Waiting to be approved by Clinic Leader');
                        }
                        if (data.campus.status == '1') {
                            $('#approve_request').css({
                                "display": "none"
                            });
                            $('#send_request').css({
                                "display": "flex"
                            });
                            $('#state').html('');
                        }
                    <?php endif; ?>
                    <?php if($role->name == 'clinic_leader'): ?>
                        if (data.campus.status == '5') {
                            $('#send_request').css({
                                "display": "none"
                            });
                            $('#approve_request').css({
                                "display": "flex"
                            });
                        }
                        if (data.campus.status == '1') {
                            $('#approve_request').css({
                                "display": "none"
                            });
                            $('#send_request').css({
                                "display": "none"
                            });
                            $('#state').html('');
                        }
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                if (data.campus.status == '3') {
                    $('#approve_request').css({
                        "display": "none"
                    });
                    $('#send_request').css({
                        "display": "none"
                    });
                    $('#state').html('Ready For Delivery');
                }
                if (data.campus.status == '4') {
                    $('#approve_request').css({
                        "display": "none"
                    });
                    $('#send_request').css({
                        "display": "none"
                    });
                    $('#state').html('Delivered!');
                }
                if (data.receiption_name) {
                    $('#receiption_info').html(data.receiption_name);
                }
                if (data.supplier_name) {
                    $('#supplier_info').html(data.supplier_name);
                }
            });

            $('#productdetailtbl').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                searchHighlight: true,
                dom: 'lBfrtip', // Add l before B to include lengthMenu
                buttons: [{
                        extend: 'copy',
                        title: 'Your Title Here' // Title for the 'copy' button
                    },
                    {
                        extend: 'csv',
                        title: 'Your Title Here' // Title for the 'csv' button
                    },
                    {
                        extend: 'excel',
                        title: 'Your Title Here' // Title for the 'excel' button
                    },
                    {
                        extend: 'pdf',
                        title: 'Your Title Here' // Title for the 'pdf' button
                    },
                    {
                        extend: 'print',
                        title: 'Yout title here'
                    }
                ],
                lengthMenu: [
                    [10, 25, 50, 500, -1],
                    [10, 25, 50, 500, "All"]
                ],
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: '/campusInfo/' + record_id,
                    type: 'DELETE',
                    dataType: "json",
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },

                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'expired_date',
                        name: 'expired_date',
                    },
                    {
                        data: 'seriel_number',
                        name: 'seriel_number',
                    },
                    {
                        data: 'product.product',
                        name: 'product.product',
                    },
                    {
                        data: 'quantity',
                        name: 'quantity',
                    },
                    {
                        data: 'unit_price',
                        name: 'unit_price',
                    },
                    {
                        data: 'total_price',
                        name: 'total_price',
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return '<a class="btn btn-info productInfo" onclick="productInfoFn(' +
                                data.id +
                                ')" id="dtinfobtn" title="Open product information page" data-id = "' +
                                data.id +
                                '"><span> Detail </span></a> ';
                        },
                        orderable: false,
                        searchable: false
                    }
                ],
            });
            $(".collapse").collapse('show');
            $('#informationModal').modal('show');
        }

        function productInfoFn(rec_id) {
            $.get("/productDetail" + '/' + rec_id, function(data) {
                if (data.store) {
                    $('#quantity_info').html(data.store.quantity);
                    var unit_price = parseFloat(data.store.unit_price).toLocaleString('en-US', {
                        style: 'decimal',
                        maximumFractionDigits: 2,
                        minimumFractionDigits: 2
                    });
                    var total_price = parseFloat(data.store.total_price).toLocaleString('en-US', {
                        style: 'decimal',
                        maximumFractionDigits: 2,
                        minimumFractionDigits: 2
                    });
                    $('#unitprice_info').html(unit_price + ' Birr');
                    $('#total_info').html(total_price + ' Birr');
                    $('#seriel_info').html(data.store.seriel_number);
                    $('#expired_info').html(data.store.expired_date);
                }
                if (data.product) {
                    $('#product_info').html(data.product);
                }
                if (data.category) {
                    $('#category_info').html(data.category);
                }
                if (data.type) {
                    $('#type_info').html(data.type);
                }
                if (data.unit) {
                    $('#unit_info').html(data.unit);
                }
                if (data.num_days) {
                    $('#remaining_info').html(data.num_days + ' Days');
                }

            });
            $('#infoModal').modal('show');
        }
    </script>
    <script>
        $('#send_request').click(function() {
            $('#requestModal').modal('show');
        });
        $('#approve_request').click(function() {
            $('#approveModal').modal('show');
        });
        $(document).on('click', '.send_request', function() {
            var request_id = $('#request_id').val();
            $('.send_request').html('Submitting...');
            $.get("/sendRequest" + '/' + request_id, function(data) {
                if (data.success) {
                    $('#requestModal').modal('hide');
                    $('#informationModal').modal('hide');
                    $('#request_id').val('');
                    $('.send_request').html('Yes');
                    var cTable = $('#laravel-datatable-campus').dataTable();
                    cTable.fnDraw(false);
                    alert_toast('Successfully request is submitted!', 'success');
                } else {
                    $('.send_request').html('Yes');
                    alert_toast('Something wrong!', 'error');
                }
            });
        });
        $(document).on('click', '.approve_request', function() {
            var request_id = $('#request_id').val();
            var approve_id = $('#select_id').val();
            $('.approve_request').html('Submitting...');
            $.get("/appRequest" + '/' + request_id + '/' + approve_id, function(data) {
                if (data.success) {
                    $('#approveModal').modal('hide');
                    $('#informationModal').modal('hide');
                    $('.approve_request').html('Submit');
                    var cTable = $('#laravel-datatable-campus').dataTable();
                    cTable.fnDraw(false);
                    alert_toast('Successfully request is Approved!', 'success');
                } else {
                    $('.approve_request').html('Submit');
                    alert_toast('Something wrong!', 'error');
                }
            });
        });

        function closeModal() {
            $('#send_request').css({
                'display': 'flex'
            });
            $('#state').html('');
            $('#request_id').val('');
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Werabe University Project\Werabe University Project\resources\views\clinics\index.blade.php ENDPATH**/ ?>