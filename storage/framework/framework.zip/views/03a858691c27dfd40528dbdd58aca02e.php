<?php $__env->startSection('content'); ?>
    <div class="app-content content">
        <section id="responsive-datatable">
            <div id="success_message" style="padding: 13px 20px;"></div>
            <div class="row">
                <div class="col-12">
                    <!-- Your HTML content goes here -->
                    <div class="card">
                        <div class="card-header border-bottom">
                            <h3 class="card-title">Store</h3>

                        </div>
                        <div class="card-datatable">
                            <div style="width:98%; margin-left:1%;">
                                <div class="table-responsive">

                                    <table id="laravel-datatable-campus"
                                        class="display table-bordered table-striped table-hover dt-responsive mb-0 dataTable no-footer"
                                        style="width: 100%;" role="grid" aria-describedby="laravel-datatable-crud_info">
                                        <thead>
                                            <tr role="row">
                                                <th style="width:1%;" rowspan="2">#</th>
                                                <th nowrap rowspan="2">Item Name</th>
                                                <th nowrap rowspan="2">Category</th>
                                                <th nowrap rowspan="2">Unit</th>
                                                <th nowrap colspan="4" style="text-align: center;">Quantity</th>
                                                <th style="width: 5%;" rowspan="2">Action</th>
                                            </tr>
                                            <tr>
                                                <th nowrap>Received</th>
                                                <th nowrap>Issued</th>
                                                <th nowrap>Loss/Adj</th>
                                                <th nowrap>Balance</th>
                                            </tr>
                                        </thead>
                                        <tbody></tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- BEGIN: Campus Store Show Information Modal -->
            <div class="modal fade" id="inlineForm" data-keyboard="false" data-backdrop="static" tabindex="-1"
                role="dialog" aria-labelledby="myModalLabel35" aria-hidden="true" style="overflow-y: scroll;">
                <div class="modal-dialog modal-xl" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title">Stock Information</h4>
                            <div class="row">
                                <div style="text-align: right" id="statusdisplay"></div>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                        aria-hidden="true">×</span></button>
                            </div>
                        </div>
                        <form id="InformationForm">
                            <input type="hidden" name="_token" value="bEE2UUJ5zm8YDMuIHSOQT8ZRMeUGaxv9eDaOVNb1">
                            <div class="modal-body">
                                <section id="input-mask-wrapper">
                                    <div class="col-md-12">
                                        <table id="productdetailtbl"
                                            class="display table-bordered table-striped table-hover dt-responsive mb-0"
                                            style="width: 100%; max-width: 100%; overflow-x: scroll;">
                                            <thead>
                                                <tr>
                                                    <th rowspan="2">#</th>
                                                    <th nowrap rowspan="2">Date Received</th>
                                                    <th nowrap rowspan="2">Received By</th>
                                                    <th nowrap rowspan="2">Received From</th>
                                                    <th nowrap rowspan="2">Item Name</th>
                                                    <th nowrap colspan="4" style="text-align: center;">Quantity</th>
                                                    <th nowrap rowspan="2">Batch No</th>
                                                    <th nowrap rowspan="2">Expired Date</th>
                                                    <th rowspan="2">Remaining Exp Days</th>
                                                    <th nowrap rowspan="2">Dispose</th>
                                                </tr>
                                                <tr>
                                                    <th nowrap>Received</th>
                                                    <th nowrap>Issued</th>
                                                    <th nowrap>Loss</th>
                                                    <th nowrap>Balance</th>
                                                </tr>
                                            </thead>
                                        </table>
                                    </div>
                                </section>
                            </div>
                            <div class="modal-footer">
                                <button id="closebuttonk" type="button"
                                    class="btn btn-danger waves-effect waves-float waves-light"
                                    data-dismiss="modal">Close</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- BEGIN: Disposed modal  -->
            <div class="modal fade text-left" id="disposedModal" data-keyboard="false" data-backdrop="static" tabindex="-1"
                role="dialog" aria-labelledby="disposedlbl" aria-hidden="true" style="overflow-y: scroll;">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="appointbl">Dispose Items</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                                onclick="closeDisposedModal()">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form id="disposed-form">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="disposed_store" id="disposed_store">
                            <div class="modal-body">
                                <label strong style="font-size: 16px;">Disposed quantity</label><label
                                    style="color: red; font-size:16px;">*</label>
                                <div class="form-group">
                                    <input type="number" name="disposed_quantity" id="disposed_quantity"
                                        placeholder="write Disposed quantity here..." class="form-control"
                                        onkeyup="removeDisposedQuantity()">
                                    <span class="text-danger">
                                        <strong id="disposed-quantity-error"></strong>
                                    </span>
                                </div>
                                <label strong style="font-size: 16px;">Type</label><label
                                    style="color: red; font-size:16px;">*</label>
                                <div class="form-group">
                                    <select name="disposed_type" id="disposed_type" class="form-control">
                                        <option value="">Select Type</option>
                                        <option value="used">Used</option>
                                        <option value="disposed">Disposed</option>
                                    </select>
                                    <span class="text-danger">
                                        <strong id="disposed_type-quantity-error"></strong>
                                    </span>
                                </div>
                                <label strong style="font-size: 16px;">Reason</label><label
                                    style="color: red; font-size:16px;">*</label>
                                <div class="form-group">
                                    <textarea name="reason" id="reason" placeholder="write reason here..." class="form-control"
                                        onkeyup="removeReason()"></textarea>
                                    <span class="text-danger">
                                        <strong id="reason-error"></strong>
                                    </span>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button id="disposebutton" type="button" class="btn btn-info">Submit</button>
                                <button id="closebutton" type="button" class="btn btn-danger"
                                    onclick="closeDisposedModal()" data-dismiss="modal">Close</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        var errorcolor = "#ffcccc";
        $(function() {
            cardSection = $('#page-block');
        });
        /* BEGIN: Display zone table using yajra datatable */
        $(document).ready(function() {
            var ctable = $('#laravel-datatable-campus').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                searchHighlight: true,
                dom: 'lBfrtip', // Add l before B to include lengthMenu
                buttons: [{
                        extend: 'copy',
                        title: 'Stock', // Title for the 'copy' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6,
                                7
                            ] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'csv',
                        title: 'Stock', // Title for the 'csv' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6,
                                7
                            ] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'excel',
                        title: 'Stock', // Title for the 'excel' button
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6,
                                7
                            ] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'pdf',
                        title: 'Stock',
                        orientation: 'landscape', // Set orientation: 'landscape' or 'portrait'
                        pageSize: 'A4', // Set page size
                        customize: function(doc) {
                            // Customize header, footer, and body style
                            doc.styles.tableHeader = {
                                fillColor: '#4CAF50',
                                color: 'white',
                                alignment: 'center'
                            };
                            doc.styles.title = {
                                fontSize: 14,
                                alignment: 'center'
                            };
                            doc.defaultStyle.fontSize = 10; // Change default font size
                            doc.content[1].table.widths = '*'.repeat(doc.content[1].table.body[0]
                                .length).split(''); // Automatically adjust column widths
                            doc.pageMargins = [10, 10, 10, 10]; // Adjust page margins
                            doc.pageSize = 'A4'; // Ensure the page size is A4
                            doc.content[1].layout = {
                                hLineWidth: function(i, node) {
                                    return (i === 0 || i === node.table.body.length) ? 2 :
                                        1;
                                },
                                vLineWidth: function(i, node) {
                                    return (i === 0 || i === node.table.widths.length) ? 2 :
                                        1;
                                },
                                hLineColor: function(i, node) {
                                    return (i === 0 || i === node.table.body.length) ?
                                        'black' : 'gray';
                                },
                                vLineColor: function(i, node) {
                                    return (i === 0 || i === node.table.widths.length) ?
                                        'black' : 'gray';
                                },
                                paddingLeft: function(i, node) {
                                    return 4;
                                },
                                paddingRight: function(i, node) {
                                    return 4;
                                },
                                paddingTop: function(i, node) {
                                    return 2;
                                },
                                paddingBottom: function(i, node) {
                                    return 2;
                                },
                            };
                        },
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6,
                                7
                            ] // Indexes of the columns you want to include
                        }
                    },
                    {
                        extend: 'print',
                        title: 'Stock',
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4, 5, 6,
                                7
                            ] // Indexes of the columns you want to include
                        }
                    }
                ],
                lengthMenu: [
                    [10, 25, 50, 500, -1],
                    [10, 25, 50, 500, "All"]
                ],
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: '/getPharmacy',
                    type: 'DELETE',
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'product.item_name',
                        name: 'product.item_name'
                    },
                    {
                        data: 'product.category.name',
                        name: 'product.category.name'
                    },
                    {
                        data: 'unit',
                        name: 'unit'
                    },
                    {
                        data: 'total_quantity',
                        name: 'total_quantity'
                    },
                    {
                        data: 'issued',
                        name: 'issued'
                    },
                    {
                        data: 'loss',
                        name: 'loss'
                    },
                    {
                        data: 'balance',
                        name: 'balance'
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return ' <a class="btn btn-success" style="padding: 5px 5px; width: 100%;" onclick="productFn(' +
                                data.product.id +
                                ')" id="dtinfobtn" title="Open clinic information page" data-id = "' +
                                data.product.id +
                                '"><span> Detail </span></a>';
                        },
                        orderable: false,
                        searchable: false
                    }
                ],
            });
            ctable.on('draw', function() {
                var body = $(ctable.table().body());
                body.unhighlight();
                body.highlight(ctable.search());
            })
        });
    </script>
    <script>
        var nowDate = moment();
        nowDate = nowDate.format('YYYY-MM-DD');
        var diff = 0;

        function productFn(record_id) {
            $(".collapse").collapse('show');
            $('#inlineForm').modal('show');
            $('#productdetailtbl').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                searchHighlight: true,
                dom: 'lBfrtip', // Add l before B to include lengthMenu
                buttons: [{
                        extend: 'copy',
                        title: 'Your Title Here' // Title for the 'copy' button
                    },
                    {
                        extend: 'csv',
                        title: 'Your Title Here' // Title for the 'csv' button
                    },
                    {
                        extend: 'excel',
                        title: 'Your Title Here' // Title for the 'excel' button
                    },
                    {
                        extend: 'pdf',
                        title: 'Your Title Here' // Title for the 'pdf' button
                    },
                    {
                        extend: 'print',
                        title: 'Yout title here'
                    }
                ],
                lengthMenu: [
                    [10, 25, 50, 500, -1],
                    [10, 25, 50, 500, "All"]
                ],
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                scrollY: '55vh',
                scrollX: true,
                scrollCollapse: true,
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: '/pharmacyDetail/' + record_id,
                    type: 'DELETE',
                    dataType: "json",
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },

                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'date_received',
                        name: 'date_received',
                    },
                    {
                        data: 'user.name',
                        name: 'user.name',
                    },
                    {
                        data: 'store.campusstore.receiver.name',
                        name: 'store.campusstore.receiver.name',
                    },
                    {
                        data: 'store.product.item_name',
                        name: 'store.product.item_name',
                    },
                    {
                        data: 'total_quantity',
                        name: 'total_quantity',
                    },
                    {
                        data: 'issued',
                        name: 'issued',
                    },
                    {
                        data: 'loss',
                        name: 'loss',
                    },
                    {
                        data: 'balance',
                        name: 'balance',
                    },
                    {
                        data: 'store.seriel_number',
                        name: 'store.seriel_number',
                    },
                    {
                        data: 'expired_date',
                        name: 'expired_date',
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return '<p class="rem"></p>';
                        },
                        orderable: true,
                        searchable: true
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return ' <p class="dispose">Disposed</p><a class="btn btn-success disp" style="padding: 5px 5px; width: 100%;" onclick="checkdispose(' +
                                data.id +
                                ')" id="dtinfobtn" title="Dispose products" data-id = "' +
                                data.id +
                                '"><span> Disposed </span></a>';
                        },
                        orderable: false,
                        searchable: false
                    },
                ],
                "fnRowCallback": function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                    if (aData.disposed == '1') {
                        $(nRow).find('.dispose').css({
                            "display": "flex",
                            "color": "red",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #4CAF50"
                        });
                        $(nRow).find('.disp').css({
                            "display": "none"
                        });
                    } else {
                        $(nRow).find('.disp').css({
                            "display": "flex"
                        });
                        $(nRow).find('.dispose').css({
                            "display": "none"
                        });
                    }
                    if (aData.store.product.item_expiration_status == '1') {
                        diff = calculateRemainingDays(aData.store.expired_date);
                        if (diff > 0) {
                            $(nRow).find('.rem').html(diff);
                        } else if (diff === 0) {
                            $(nRow).find('.rem').html("Product expires today.");
                        } else {
                            $(nRow).find('.rem').html("Product has expired.");
                        }
                    } else {
                        $(nRow).find('.rem').html('None');
                    }

                }
            });
        }

        function checkdispose(record_id) {
            $('#disposed_store').val(record_id);
            $('#disposedModal').modal('show');
        }

        $('#disposebutton').click(function() {
            var disposedData = $('#disposed-form');
            var formData = disposedData.serialize();
            $.ajax({
                url: '/disposePharmacyProduct',
                type: 'post',
                data: formData,
                beforeSend: function() {
                    cardSection.block({
                        message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                        css: {
                            backgroundColor: 'transparent',
                            color: '#fff',
                            border: '0'
                        },
                        overlayCSS: {
                            opacity: 0.5
                        }
                    });
                    $('#disposebutton').text('removing...');
                    $('#disposebutton').prop("disabled", true);
                },
                complete: function() {
                    cardSection.block({
                        message: '',
                        timeout: 1,
                        css: {
                            backgroundColor: '',
                            color: '',
                            border: ''
                        },
                    });
                },

                success: function(data) {
                    if (data.quantity_error) {
                        $('#disposebutton').html('Dispose');
                        $('#disposebutton').prop("disabled", false);
                        alert_toast(data.quantity_error,
                            "error");
                        $('#disposed_quantity').val('');
                        $('#disposed-quantity-error').html('Must less available quantity')
                    } else if (data.errors) {
                        if (data.errors.disposed_quantity) {
                            $('#disposed-quantity-error').html(data.errors.disposed_quantity[0])
                        }
                        if (data.errors.reason) {
                            $('#reason-error').html(data.errors.reason[0])
                        }
                        if (data.errors.disposed_type) {
                            $('#disposed_type-error').html(data.errors.disposed_type[0])
                        }
                        $('#disposebutton').html('Submit');
                        $('#disposebutton').prop("disabled", false);
                        alert_toast("An error occured!",
                            "error");
                    } else if (data.success) {
                        $('#disposedModal').modal('hide');
                        $('#disposed_store').val('');
                        $('#disposed_quantity').val('');
                        $('#reason').val('');
                        $('#disposebutton').html('Submit');
                        $('#disposebutton').prop("disabled", false);
                        alert_toast('Item disposed Sucessfully!', 'success');
                        var aTable = $('#productdetailtbl').dataTable();
                        aTable.fnDraw(false);
                    } else {
                        alert('new error')
                        $('#disposebutton').html('Submit');
                        $('#disposebutton').prop("disabled", false);
                    }
                }
            });


            /* $.get('disposePharmacyProduct/' + record_id, function(data) {
                 if (data.success) {
                     toastrMessage('success', 'success', 'Product disposed successfully!');
                     var dTable = $('#productdetailtbl').dataTable();
                     dTable.fnDraw(false);
                 } else {
                     toastrMessage('error', 'error', 'An Error Occured!');
                 }
             });*/
        });

        function removeDisposedQuantity() {
            $('#disposed-quantity-error').html('');
        }

        function removeReason() {
            $('#reason-error').html('');
        }

        function closeDisposedModal() {
            $('#reason-error').html('');
            $('#disposed-quantity-error').html('');
            $('#disposed_quantity').val('');
            $('#reason').val('');
            $('#disposed_store').val('');
        }

        function calculateRemainingDays(expireDate) {
            // Parse the expiration date string to Date object
            const expiryDate = new Date(expireDate);

            // Get current date
            const currentDate = new Date();

            // Calculate difference in milliseconds
            const differenceMs = expiryDate.getTime() - currentDate.getTime();

            // Convert milliseconds to days
            const remainingDays = Math.ceil(differenceMs / (1000 * 60 * 60 * 24));

            return remainingDays;
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Werabe University Project\Werabe University Project\resources\views\pharmacy\index1.blade.php ENDPATH**/ ?>