<?php $__env->startSection('title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="app-content content">

        <section id="responsive-datatable">
            <div class="row">
                <div class="col-12">
                    <!-- Your HTML content goes here -->
                    <div class="card">
                        <div class="card-header border-bottom">
                            <h3 class="card-title">Patients</h3>
                            <button class="btn btn-primary" id="student">Find Student</button>

                        </div>
                        <div class="card-datatable">
                            <div style="width:98%; margin-left:1%;">
                                <div class="table-responsive">
                                    <table id="laravel-datatable-patient"
                                        class="display table-bordered table-striped table-hover dt-responsive mb-0 dataTable no-footer"
                                        style="width: 100%;" role="grid" aria-describedby="laravel-datatable-user">

                                        <thead>
                                            <tr role="row">
                                                <th scope="col" width="1%">#</th>
                                                <th nowrap="1">Full Name</th>
                                                <th nowrap="1">Student Id</th>
                                                <th nowrap="1">Sex</th>
                                                <th nowrap="1">Phone</th>
                                                <th nowrap="1">Age</th>
                                                <th nowrap="1">Room</th>
                                                <th nowrap="1">Doctor</th>
                                                <th nowrap="1">Status</th>
                                            </tr>
                                        </thead>
                                        <tbody></tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
    
    <div class="modal fade text-left" id="studentModal" data-keyboard="false" data-backdrop="static" tabindex="-1"
        role="dialog" aria-labelledby="lbl" aria-hidden="true" style="overflow-y: scroll;">
        <div class="modal-dialog modal-xl" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="categorylbl">Student List</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="closeModal()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div style="justify-content: space-between; display: flex; margin-bottom: 10px;" class="w-100">
                        <h1 style="color: white;">Students</h1>
                    </div>
                    <div style="width:98%; margin-left:1%;">
                        <div class="table-responsive">
                            <table id="laravel-datatable-student"
                                class="display table-bordered table-striped table-hover dt-responsive mb-0 dataTable no-footer"
                                style="width: 100%;" role="grid" aria-describedby="laravel-datatable-student">

                                <thead>
                                    <tr role="row">
                                        <th scope="col" width="1%">#</th>
                                        <th nowrap="1">Full Name</th>
                                        <th nowrap="1">Student Id</th>
                                        <th nowrap="1">Sex</th>
                                        <th nowrap="1">Phone</th>
                                        <th nowrap="1">Age</th>
                                        <th nowrap="1">Department</th>
                                        <th nowrap="1">Action</th>
                                    </tr>
                                </thead>
                                <tbody></tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button id="closebutton" type="button" class="btn btn-danger" onclick="closeModal()"
                        data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    
    <div class="modal fade" id="sendModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Select from OPD Memebers</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                        onclick="closeModalWithClearValidation()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="sendForm">
                    <?php echo e(csrf_field()); ?>

                    <div class="modal-body">
                        <div class="form-group">
                            <label for="">Select Room</label>
                            <select class="custom-select browser-default select2" name="doctor_room" id="doctor_room"
                                onchange="removeRoomValidation()">
                                <option value=""></option>
                                <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($room->id); ?>"><?php echo e($room->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <span class="text-danger">
                                <strong id="room-error"></strong>
                            </span>
                        </div>
                        <div class="form-group">
                            <label for="">Select OPD</label>
                            <select class="custom-select browser-default" name="opd_by" id="opd_by"
                                onchange="removeOpdValidation()">
                                <option value=""></option>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($role->name == 'doctor'): ?>
                                            <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <span class="text-danger">
                                <strong id="doctor-error"></strong>
                            </span>
                        </div>
                        <input type="hidden" name="send_id" id="send_id">

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-info send">Send</button>
                        <button id="closebutton" type="button" class="btn btn-danger"
                            onclick="closeModalWithClearValidation()" data-dismiss="modal">Close</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        function search() {
            var search = $('#search').val();
            var sTable = $('#laravel-datatable-student').dataTable();
            sTable.fnDraw(false);
        }
        var errorcolor = "#ffcccc";
        $(function() {
            cardSection = $('#page-block');
        });
        /* BEGIN: Display zone table using yajra datatable */
        $(document).ready(function() {
            var ctable = $('#laravel-datatable-patient').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                searchHighlight: true,
                dom: 'lBfrtip', // Add l before B to include lengthMenu
                buttons: [{
                        extend: 'copy',
                        title: 'Your Title Here' // Title for the 'copy' button
                    },
                    {
                        extend: 'csv',
                        title: 'Your Title Here' // Title for the 'csv' button
                    },
                    {
                        extend: 'excel',
                        title: 'Your Title Here' // Title for the 'excel' button
                    },
                    {
                        extend: 'pdf',
                        title: 'Your Title Here' // Title for the 'pdf' button
                    },
                    {
                        extend: 'print',
                        title: 'Yout title here'
                    }
                ],
                lengthMenu: [
                    [10, 25, 50, 500, -1],
                    [10, 25, 50, 500, "All"]
                ],
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: '/getpatients',
                    type: 'DELETE',
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'student.full_name',
                        name: 'student.full_name'
                    },
                    {
                        data: 'student.student_id',
                        name: 'student.student_id'
                    },
                    {
                        data: 'student.sex',
                        name: 'student.sex'
                    },
                    {
                        data: 'student.phone',
                        name: 'student.phone'
                    },
                    {
                        data: 'student.age',
                        name: 'student.age'
                    },
                    {
                        data: 'room.name',
                        name: 'room.name'
                    },
                    {
                        data: 'user.name',
                        name: 'user.name'
                    },
                    {
                        data: 'state',
                        name: 'state'
                    },
                ],
                "fnRowCallback": function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                    if (aData.state == "1") {
                        $(nRow).find('td:eq(8)').html('Pending');
                        $(nRow).find('td:eq(8)').css({
                            "color": "blue",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #4CAF50"
                        });
                    } else {
                        $(nRow).find('td:eq(8)').html('Pending');
                        $(nRow).find('td:eq(8)').css({
                            "color": "blue",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #4CAF50"
                        });
                    }
                }
            });
            /* End: Yajra data table*/
            $('#laravel-datatable-patient tbody').on('click', 'tr', function() {
                if ($(this).hasClass('selected')) {
                    $(this).removeClass('selected');
                } else {
                    $('tr.selected').removeClass('selected');
                    $(this).addClass('selected');
                }
            });

            $('#status').select2({
                minimumResultsForSearch: -1
            });
        });
        /* BEGIN: Display zone table using yajra datatable */
        $(document).ready(function() {
            var sttable = $('#laravel-datatable-student').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                searchHighlight: true,
                paging: false,
                language: {
                    search: '',
                    searchPlaceholder: "",
                },
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: "/getstudentsregister",
                    type: 'DELETE',
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'full_name',
                        name: 'full_name'
                    },
                    {
                        data: 'student_id',
                        name: 'student_id'
                    },
                    {
                        data: 'sex',
                        name: 'sex'
                    },
                    {
                        data: 'phone',
                        name: 'phone'
                    },
                    {
                        data: 'age',
                        name: 'age'
                    },
                    {
                        data: 'department',
                        name: 'department'
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return '<button class="btn btn-success list" onclick = "sendFn(' +
                                data
                                .id +
                                ')"><span> Send </span></button>';
                        },
                    },
                ],
                "fnRowCallback": function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {


                }
            });
            /* End: Yajra data table*/
            $('#laravel-datatable-student tbody').on('click', 'tr', function() {
                if ($(this).hasClass('selected')) {
                    $(this).removeClass('selected');
                } else {
                    $('tr.selected').removeClass('selected');
                    $(this).addClass('selected');
                }
            });
        });
        sttable.on('draw', function() {
            var body = $(sttable.table().body());
            body.unhighlight();
            body.highlight(sttable.search());
        })
    </script>
    <script>
        function sendFn(record_id) {
            $('#send_id').val(record_id);
            $('#doctor_room').val('');
            $('#opd_by').val('');
            $('#doctor_room').select2({
                placeholder: "Select Room here",
            });
            $('#opd_by').select2({
                placeholder: "Select Opd here",
            });
            $('#sendModal').modal('show');
        }
        $('#student').click(function() {

            $('#studentModal').modal('show');
        });
        $('.send').click(function() {
            var sendForm = $('#sendForm');
            var formData = sendForm.serialize();
            $.ajax({
                url: '/sendstudent',
                type: 'post',
                data: formData,
                beforeSend: function() {
                    $('.send').text('Sending...');
                    $('.send').prop("disabled", true);
                },
                success: function(data) {
                    if (data.errors) {
                        $('.send').text('Send');
                        $('.send').prop("disabled", false);
                        if (data.errors.doctor_room) {
                            $('#room-error').html(data.errors.doctor_room[0])
                        }
                        if (data.errors.opd_by) {
                            $('#doctor-error').html(data.errors.opd_by[0])
                        }
                        alert_toast(data.errors, 'error');
                    } else if (data.success) {
                        $('.send').text('Send');
                        $('.send').prop("disabled", false);
                        alert_toast(data.success, 'success')
                        var cTable = $('#laravel-datatable-patient').dataTable();
                        cTable.fnDraw(false);
                        $('#sendModal').modal('hide');
                        $('#studentModal').modal('hide');
                    }
                }
            });
        });
    </script>
    <script>
        function removeRoomValidation() {
            $('#room-error').html('');
        }

        function removeOpdValidation() {
            $('#doctor-error').html('');
        }

        function closeModal() {
            $('#name-error').html('');
            $('#status-error').html('');
            $('#name').val('');
            $('#status').val('').trigger('change');
            $('#savenewbutton').css('display', 'flex');
            $('#savebutton').html('Save & Close');
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Werabe University Project\Werabe University Project\resources\views\patients\register.blade.php ENDPATH**/ ?>