<?php $__env->startSection('title'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="app-content content">
        <section id="responsive-datatable">
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">

                        <label for="">filter by block</label>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('proctor')): ?>
                            <select name="filter_block" id="filter_block" class="custom-select browser-default" readonly>
                                <?php $__currentLoopData = $block; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block_filter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(auth()->user()->block == $block_filter->block_name): ?>
                                        <option value="<?php echo e($block_filter->block_name); ?>"><?php echo e($block_filter->block_name); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        <?php else: ?>
                            <label for="">filter by block</label>
                            <select name="filter_block" id="filter_block" class="custom-select browser-default select2"
                                onchange="filterBlock()">
                                <option value=""></option>
                                <?php $__currentLoopData = $block; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block_filter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($block_filter->block_name); ?>"><?php echo e($block_filter->block_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="">filter by dorm</label>
                        <select name="filter_dorm" id="filter_dorm" class="custom-select browser-default select2"
                            onchange="filterDorm()">

                        </select>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="form-group" style="display: none;" id="commonservice">
                        <label for="" style="opacity: 0">common services</label>
                        <button class="btn btn-success" id="common">Services</button>
                        </select>
                    </div>
                </div>

            </div>
            <div class="row">
                <div class="col-12">
                    <!-- Your HTML content goes here -->
                    <div class="card">
                        <div class="card-header border-bottom">
                            <h3 class="card-title"><?php echo e(__('students.students')); ?></h3>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dormstudent.import')): ?>
                                <form id="importForm" enctype="multipart/form-data">
                                    <?php echo e(csrf_field()); ?>

                                    <input id="fileInput" type="file" name="file">
                                    <button class="btn btn-warning" type="submit"
                                        id="import"><?php echo e(__('students.import')); ?></button>
                                </form>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dormstudent.createupdate')): ?>
                                <button type="button"
                                    class="btn btn-gradient-info btn-sm add"><?php echo e(__('students.add')); ?></button>
                            <?php endif; ?>

                        </div>
                        <div class="card-datatable">
                            <div id="message" class="w-100"></div>
                            <div style="width:98%; margin-left:1%;">
                                <div class="table-responsive">

                                    <table id="laravel-datatable-student"
                                        class="display table-bordered table-striped table-hover dt-responsive mb-0 dataTable no-footer"
                                        style="width: 100%;" role="grid" aria-describedby="laravel-datatable-student">

                                        <thead>
                                            <tr role="row">
                                                <th scope="col" width="1%">#</th>
                                                <th nowrap="1"><?php echo e(__('students.full_name')); ?></th>
                                                <th nowrap="1"><?php echo e(__('students.student_id')); ?></th>
                                                <th nowrap="1"><?php echo e(__('students.sex')); ?></th>
                                                <th nowrap="1"><?php echo e(__('students.department')); ?></th>
                                                <th nowrap="1"><?php echo e(__('students.entry_year')); ?></th>
                                                <th nowrap="1">Block</th>
                                                <th nowrap="1">Dorm</th>
                                                <th nowrap="1"><?php echo e(__('students.status')); ?></th>
                                                <th nowrap="1"><?php echo e(__('students.actions')); ?></th>
                                            </tr>
                                        </thead>
                                        <tbody></tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- BEGIN: Student Add modal  -->
        <div class="modal fade text-left" id="inlineForm" data-keyboard="false" data-backdrop="static" tabindex="-1"
            role="dialog" aria-labelledby="patientlbl" aria-hidden="true" style="overflow-y: scroll;">
            <div class="modal-dialog modal-xl" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="studentlbl"><?php echo e(__('students.add_student')); ?></h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                            onclick="closeModal()">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form id="Register">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="edit_id" id="edit_id">
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-md-3">
                                    <label strong style="font-size: 16px;"><?php echo e(__('students.full_name')); ?></label><label
                                        style="color: red; font-size:16px;">*</label>
                                    <div class="form-group">
                                        <input type="text" placeholder="<?php echo e(__('students.name_placeholder')); ?>"
                                            class="form-control" name="full_name" id='full_name' autofocus
                                            onkeyup="removeNameValidation()" />
                                        <span class="text-danger">
                                            <strong id="full_name-error"></strong>
                                        </span>
                                    </div>

                                </div>
                                <div class="col-md-3">
                                    <label strong style="font-size: 16px;"><?php echo e(__('students.student_id')); ?></label><label
                                        style="color: red; font-size:16px;">*</label>
                                    <div class="form-group">
                                        <input type="text" placeholder="<?php echo e(__('students.student_id_placeholder')); ?>"
                                            class="form-control" name="student_id" id='student_id' autofocus
                                            onkeyup="removeStudentValidation()" />
                                        <span class="text-danger">
                                            <strong id="student_id-error"></strong>
                                        </span>
                                    </div>

                                </div>

                                <div class="col-md-3">
                                    <label strong style="font-size: 16px;"><?php echo e(__('students.department')); ?></label><label
                                        style="color: red; font-size:16px;">*</label>
                                    <div class="form-group">
                                        <input type="text" placeholder="<?php echo e(__('students.department_placeholder')); ?>"
                                            class="form-control" name="department" id='department' autofocus
                                            onkeyup="removeDepartmentValidation()" />
                                        <span class="text-danger">
                                            <strong id="department-error"></strong>
                                        </span>
                                    </div>

                                </div>

                                <div class="col-md-3">
                                    <label strong style="font-size: 16px;"><?php echo e(__('students.entry_year')); ?></label><label
                                        style="color: red; font-size:16px;">*</label>
                                    <div class="form-group">
                                        <select class="custom-select browser-default select2" name="entry_year"
                                            id="entry_year" onchange="removeYearValidation()">
                                            <option value=""></option>
                                            <option value="2013">2013</option>
                                            <option value="2014">2014</option>
                                            <option value="2015">2015</option>
                                            <option value="2016">2016</option>
                                            <option value="2017">2017</option>
                                            <option value="2018">2018</option>
                                            <option value="2019">2019</option>
                                            <option value="2020">2020</option>
                                        </select>
                                        <span class="text-danger">
                                            <strong id="entry_year-error"></strong>
                                        </span>
                                    </div>

                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3">
                                    <label strong style="font-size: 16px;"><?php echo e(__('students.sex')); ?></label><label
                                        style="color: red; font-size:16px;">*</label>

                                    <div class="form-group">
                                        <select class="custom-select browser-default select2" name="sex"
                                            id="sex" onchange="removeSexValidation()">
                                            <option value=""></option>
                                            <option value="Male">Male</option>
                                            <option value="Female">Female</option>
                                        </select>
                                        <span class="text-danger">
                                            <strong id="sex-error"></strong>
                                        </span>
                                    </div>

                                </div>
                                <div class="col-md-3">
                                    <label for="">Block</label>
                                    <select name="block" id="block" class="form-control"
                                        onchange="removeBlockValidation()">
                                        <option value="">Select block here</option>
                                        <?php $__currentLoopData = $block; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $block): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($block->block_name); ?>"><?php echo e($block->block_name); ?> |
                                                <?php echo e($block->block_type); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <span class="text-danger">
                                        <strong id="block-error"></strong>
                                    </span>
                                </div>
                                <div class="col-md-3">
                                    <label for="">Dorm</label>
                                    <select name="dorm" id="dorm" class="custom-select browser-default select2">

                                    </select>
                                    <span class="text-danger">
                                        <strong id="dorm-error"></strong>
                                    </span>
                                </div>
                                <div class="col-md-3">
                                    <label strong style="font-size: 16px;"><?php echo e(__('students.status')); ?></label><label
                                        style="color: red; font-size:16px;">*</label>
                                    <div class="form-group">
                                        <select class="custom-select browser-default select2" name="status"
                                            id="status" onchange="removeStatusValidation()">
                                            <option value="Active">Active</option>
                                            <option value="Inactive">Inactive</option>
                                        </select>
                                        <span class="text-danger">
                                            <strong id="status-error"></strong>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            
                            <button id="savestudent" type="button"
                                class="btn btn-info"><?php echo e(__('dormitory.saveblock')); ?></button>
                            <button id="closebutton" type="button" class="btn btn-danger" onclick="closeModal()"
                                data-dismiss="modal"><?php echo e(__('dormitory.close')); ?></button>
                        </div>
                </div>
                </form>
            </div>
        </div>
    </div>
    <!-- BEGIN: Info modal -->
    <div class="modal fade" id="infoModal" data-keyboard="false" data-backdrop="static" tabindex="-1" role="dialog"
        aria-labelledby="myModalLabel35" aria-hidden="true" style="overflow-y: scroll;">
        <div class="modal-dialog modal-xl" role="document" style="font-size: 11px;">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title"><?php echo e(__('dorm.dorm_information')); ?></h4>
                    <div class="row">
                        <div style="text-align: right" id="statusdisplay"></div>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                aria-hidden="true">×</span></button>
                    </div>
                </div>
                <form id="InformationForm">
                    <input type="hidden" name="_token" value="bEE2UUJ5zm8YDMuIHSOQT8ZRMeUGaxv9eDaOVNb1">
                    <div class="modal-body">
                        <section id="input-mask-wrapper">
                            <div class="col-xl-12">
                                <div class="row">
                                    <div class="col-md-4 col-sm-12">
                                        <div class="card">
                                            <div class="card-header">
                                                <h4 class="card-title"><?php echo e(__('dorm.basic_information')); ?></h4>
                                                <div class="heading-elements">
                                                    <ul class="list-inline mb-0">

                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="card-content collapse show">
                                                <div class="card-body">
                                                    <div class="row">
                                                        <table style="width: 100%;">
                                                            <tbody>

                                                                <tr>
                                                                    <td><label strong=""
                                                                            style="font-size: 14px;">Full Name
                                                                        </label>
                                                                    </td>
                                                                    <td><label id="full_name_info" strong=""
                                                                            style="font-size:14px;font-weight:bold;"></label>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td><label strong=""
                                                                            style="font-size: 14px;">Student Id:
                                                                        </label>
                                                                    </td>
                                                                    <td><label id="student_id_info" strong=""
                                                                            style="font-size:14px;font-weight:bold;"></label>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td><label strong=""
                                                                            style="font-size: 14px;">Department:
                                                                        </label>
                                                                    </td>
                                                                    <td><label id="department_info" strong=""
                                                                            style="font-size:14px;font-weight:bold;"></label>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td><label strong=""
                                                                            style="font-size: 14px;">Entry Year:
                                                                        </label>
                                                                    </td>
                                                                    <td><label id="entry_year_info" strong=""
                                                                            style="font-size:14px;font-weight:bold;"></label>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td style="width: 43%"><label strong=""
                                                                            style="font-size: 14px;">Sex</label>
                                                                    </td>
                                                                    <td style="width: 57%"><label id="sex_info"
                                                                            strong=""
                                                                            style="font-size:14px;font-weight:bold;"></label>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td style="width: 43%"><label strong=""
                                                                            style="font-size: 14px;">Block</label>
                                                                    </td>
                                                                    <td style="width: 57%"><label id="block_info"
                                                                            strong=""
                                                                            style="font-size:14px;font-weight:bold;"></label>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td style="width: 43%"><label strong=""
                                                                            style="font-size: 14px;">Dorm</label>
                                                                    </td>
                                                                    <td style="width: 57%"><label id="dorm_info"
                                                                            strong=""
                                                                            style="font-size:14px;font-weight:bold;"></label>
                                                                    </td>
                                                                </tr>

                                                                <tr>
                                                                    <td style="width: 43%"><label strong=""
                                                                            style="font-size: 14px;"><?php echo e(__('dorm.status')); ?></label>
                                                                    </td>
                                                                    <td style="width: 57%"><label id="status_info"
                                                                            strong=""
                                                                            style="font-size:14px;font-weight:bold;"><?php echo e(__('dorm.occupied')); ?></label>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                    <div class="divider newext">
                                                        <div class="divider-text"><?php echo e(__('dorm.action_information')); ?>

                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <table style="width: 100%;">
                                                            <tbody>
                                                                <tr>
                                                                    <td style="width: 35%"><label strong=""
                                                                            style="font-size: 14px;"><?php echo e(__('dorm.created_by')); ?></label>
                                                                    </td>
                                                                    <td style="width: 65%"><label id="createdby_info"
                                                                            strong=""
                                                                            style="font-size:14px;font-weight:bold;"></label>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td><label strong=""
                                                                            style="font-size: 14px;"><?php echo e(__('dorm.created_date')); ?></label>
                                                                    </td>
                                                                    <td><label id="createdat_info" strong=""
                                                                            style="font-size:14px;font-weight:bold;"></label>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td><label strong=""
                                                                            style="font-size: 14px;"><?php echo e(__('dorm.last_edited_by')); ?></label>
                                                                    </td>
                                                                    <td><label id="updatedby_info" strong=""
                                                                            style="font-size:14px;font-weight:bold;"></label>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td><label strong=""
                                                                            style="font-size: 14px;"><?php echo e(__('dorm.last_edited_date')); ?></label>
                                                                    </td>
                                                                    <td><label id="updatedat_info" strong=""
                                                                            style="font-size:14px;font-weight:bold;"></label>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-8 col-sm-12">
                                        <div class="card">
                                            <div class="card-header">
                                                <h4 class="card-title"><?php echo e(__('dorm.services')); ?></h4>
                                                <div class="heading-elements">
                                                    <ul class="list-inline mb-0">

                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="card-content collapse show">
                                                <div class="card-body">
                                                    <table id="dormservicetbl"
                                                        class="display table-bordered table-striped table-hover dt-responsive mb-0">
                                                        <thead>
                                                            <tr role="row">
                                                                <th scope="col" width="1%">#</th>
                                                                <th nowrap><?php echo e(__('dorm.images')); ?></th>
                                                                <th nowrap><?php echo e(__('dorm.service_name')); ?></th>
                                                                <th nowrap><?php echo e(__('dorm.quantity')); ?></th>
                                                                <th nowrap><?php echo e(__('dorm.unit_price')); ?></th>
                                                                <th nowrap><?php echo e(__('dorm.remark')); ?></th>
                                                                <th nowrap><?php echo e(__('dorm.status')); ?></th>
                                                                <th nowrap><?php echo e(__('dorm.actions')); ?></th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                        <br>
                                        <div class="card">
                                            <div class="card-header">
                                                <h4 class="card-title">Transfer Detail</h4>
                                                <div class="heading-elements">
                                                    <ul class="list-inline mb-0">

                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="card-content collapse show">
                                                <div class="card-body">
                                                    <table id="transferdetailtbl"
                                                        class="display table-bordered table-striped table-hover dt-responsive mb-0">
                                                        <thead>
                                                            <tr role="row">
                                                                <th scope="col" width="1%">#</th>
                                                                <th nowrap>Transfer Date</th>
                                                                <th nowrap>Block To</th>
                                                                <th nowrap>Dorm To</th>
                                                                <th nowrap>Reason</th>
                                                                <th nowrap>Transfered By</th>

                                                            </tr>
                                                        </thead>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                    <div class="modal-footer">
                        <button id="closebuttonk" type="button"
                            class="btn btn-danger waves-effect waves-float waves-light" data-dismiss="modal"
                            onclick="closeModal()"><?php echo e(__('dormitory.close')); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- BEGIN: service modal  -->

    <div class="modal fade text-left" id="serviceModal" data-keyboard="false" data-backdrop="static" tabindex="-1"
        role="dialog" aria-labelledby="lbl" aria-hidden="true" style="overflow-y: scroll;">
        <div class="modal-dialog modal-xl" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="service_student_id">Service detail</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                        onclick="closeModal()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div style="justify-content: space-between; display: flex; margin-bottom: 10px;" class="w-100">
                        <h1>Services</h1>
                        <button type="button" class="btn btn-warning btn-sm" id="clearance" disabled
                            onclick="makeClearance()">Clearance hasn't completed yet</button>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('assignservicetostudent')): ?>
                            <button type="button" class="btn btn-info btn-sm" onclick="assignService()">Assign
                                Service</button>
                        <?php endif; ?>
                    </div>
                    <div style="width:98%; margin-left:1%;">
                        <div class="table-responsive">

                            <table id="laravel-datatable-service"
                                class="display table-bordered table-striped table-hover dt-responsive mb-0 dataTable no-footer"
                                style="width: 100%;" role="grid" aria-describedby="laravel-datatable-history">

                                <thead>
                                    <tr role="row">
                                        <th scope="col" width="1%">#</th>
                                        <th nowrap="1">Photo</th>
                                        <th nowrap="1">Student Id</th>
                                        <th nowrap="1">Service Name</th>
                                        <th nowrap="1">Quantity</th>
                                        <th nowrap="1">Unit Price</th>
                                        <th nowrap="1">Remark</th>
                                        <th nowrap="1">Status</th>
                                        <th nowrap="1">Action</th>
                                    </tr>
                                </thead>
                                <tbody></tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button id="closebutton" type="button" class="btn btn-danger" onclick="closeModal()"
                        data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade text-left" id="commonServiceModal" data-keyboard="false" data-backdrop="static"
        tabindex="-1" role="dialog" aria-labelledby="lbl" aria-hidden="true" style="overflow-y: scroll;">
        <div class="modal-dialog modal-xl" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="commonlbl">Services</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                        onclick="closeModal()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div style="justify-content: space-between; display: flex; margin-bottom: 10px;" class="w-100">
                        <h5>Dorm Services</h3>
                    </div>
                    <div style="width:98%; margin-left:1%;">
                        <div class="table-responsive">

                            <table id="laravel-datatable-common"
                                class="display table-bordered table-striped table-hover dt-responsive mb-0 dataTable no-footer"
                                style="width: 100%;" role="grid" aria-describedby="laravel-datatable-history">

                                <thead>
                                    <tr role="row">
                                        <th scope="col" width="1%">#</th>
                                        <th nowrap="1">Photo</th>
                                        <th nowrap="1">Service Name</th>
                                        <th nowrap="1">Quantity</th>
                                        <th nowrap="1">Price</th>
                                        <th nowrap="1">Remark</th>
                                        <th nowrap="1">Service Type</th>
                                        <th nowrap="1">Action</th>
                                    </tr>
                                </thead>
                                <tbody></tbody>
                            </table>
                        </div>
                    </div>

                    <div style="justify-content: space-between; display: flex;" class="w-100">
                        <h5>Sent to Finance Department</h5>
                    </div>
                    <div style="width:98%; margin-left:1%;">
                        <div class="table-responsive">

                            <table id="laravel-datatable-commonfinance"
                                class="display table-bordered table-striped table-hover dt-responsive mb-0 dataTable no-footer"
                                style="width: 100%;" role="grid" aria-describedby="laravel-datatable-history">

                                <thead>
                                    <tr role="row">
                                        <th scope="col" width="1%">#</th>
                                        <th nowrap="1">Photo</th>
                                        <th nowrap="1">Service Name</th>
                                        <th nowrap="1">Quantity</th>
                                        <th nowrap="1">Price</th>
                                        <th nowrap="1">Remark</th>
                                        <th nowrap="1">Service Type</th>
                                        <th nowrap="1">Status</th>
                                        <th nowrap="1">Action</th>
                                    </tr>
                                </thead>
                                <tbody></tbody>
                            </table>
                        </div>
                    </div>
                    <div style="justify-content: space-between; display: flex;" class="w-100">
                        <h5>Individual Services</h5>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('assignservicetostudent')): ?>
                            <button type="button" class="btn btn-info btn-sm" onclick="assignIndividualService(1)">Assign
                                Service</button>
                        <?php endif; ?>
                    </div>
                    <div style="width:98%; margin-left:1%;">
                        <div class="table-responsive">

                            <table id="laravel-datatable-individual"
                                class="display table-bordered table-striped table-hover dt-responsive mb-0 dataTable no-footer"
                                style="width: 100%;" role="grid" aria-describedby="laravel-datatable-history">

                                <thead>
                                    <tr role="row">
                                        <th scope="col" width="1%">#</th>
                                        <th nowrap="1">Photo</th>
                                        <th nowrap="1">Student Id</th>
                                        <th nowrap="1">Service Name</th>
                                        <th nowrap="1">Quantity</th>
                                        <th nowrap="1">Price</th>
                                        <th nowrap="1">Remark</th>
                                        <th nowrap="1">Status</th>
                                        <th nowrap="1">Action</th>
                                    </tr>
                                </thead>
                                <tbody></tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button id="closebutton" type="button" class="btn btn-danger" onclick="closeModal()"
                        data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <!-- BEGIN: transfer modal  -->
    <div class="modal fade" id="transferModal" data-keyboard="false" data-backdrop="static" tabindex="-1"
        role="dialog" aria-labelledby="categorylbl" aria-hidden="true" style="overflow-y: scroll;">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Transfer To: </h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                        onclick="closeModal()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-body">
                    <form id="transferForm">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="stud_id" id="stud_id">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="">Block</label>
                                    <select name="transfer_block" id="transfer_block"
                                        class="custom-select browser-default select2" onchange="transferBlock()">
                                        <option value=""></option>
                                        <?php $__currentLoopData = $blockt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($bl->block_name); ?>"><?php echo e($bl->block_name); ?> |
                                                <?php echo e($bl->block_type); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select><span class="text-danger">
                                        <strong id="transfer-block-error"></strong>
                                    </span>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="">Dorm</label>
                                    <select name="transfer_dorm" id="transfer_dorm"
                                        class="custom-select browser-default select2" onchange="transferDorm()">

                                    </select>
                                    <span class="text-danger">
                                        <strong id="transfer-dorm-error"></strong>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="">Reason</label>
                            <textarea name="reason" id="reason" class="form-control" placeholder="Write reason here"></textarea>
                            <span class="text-danger">
                                <strong id="reason-error"></strong>
                            </span>
                        </div>
                    </form>
                </div>

                <div class="modal-footer">
                    
                    <button id="transferbutton" type="button" class="btn btn-info">Submit</button>
                    <button id="closebutton" type="button" class="btn btn-danger" onclick="closeModal()"
                        data-dismiss="modal"><?php echo e(__('dormitory.close')); ?></button>
                </div>
            </div>
        </div>
    </div>
    <!-- BEGIN: assign service modal  -->
    <div class="modal fade" id="assignServiceModal" data-keyboard="false" data-backdrop="static" tabindex="-1"
        role="dialog" aria-labelledby="categorylbl" aria-hidden="true" style="overflow-y: scroll;">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Assign service </h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"
                        onclick="closeModal()">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-body">
                    <form id="serviceForm">
                        <?php echo e(csrf_field()); ?>


                        <div class="row">
                            <input type="hidden" name="st_id" id="st_id">
                            <div class="col-md-12" id="individual_student">
                                <div class="form-group">
                                    <label for="">Student</label>
                                    <select name="individual_st_id" id="individual_st_id"
                                        class="custom-select browser-default select2"
                                        onchange="removeIndividualStudentValidation()">
                                        <option value=""></option>
                                    </select><span class="text-danger">
                                        <strong id="service-error"></strong>
                                    </span>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="">Service</label>
                                    <select name="service_id" id="service_id"
                                        class="custom-select browser-default select2" onchange="serviceBlock()">
                                        <option value=""></option>
                                    </select><span class="text-danger">
                                        <strong id="service-error"></strong>
                                    </span>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="">Quantity</label>
                                    <input type="number" name="quantity" id="quantity" placeholder="Type quantity"
                                        class="form-control" onkeyup="removeQuantity()">
                                    </input>
                                    <span class="text-danger">
                                        <strong id="quantity-error"></strong>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>

                <div class="modal-footer">
                    
                    <button id="assignbutton" type="button" class="btn btn-info">Submit</button>
                    <button id="closebutton" type="button" class="btn btn-danger" onclick="closeModal()"
                        data-dismiss="modal"><?php echo e(__('dormitory.close')); ?></button>
                </div>
            </div>
        </div>
    </div>

    <!-- BEGIN: Service Detail Info modal -->
    <div class="modal fade text-left" id="serviceDetailModal" data-keyboard="false" data-backdrop="static"
        tabindex="-1" role="dialog" aria-labelledby="myModalLabel133" aria-hidden="true" style="overflow-y: scroll;">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel133">Action Info</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="regionform">
                    <input type="hidden" class="_token">
                    <div class="modal-body">
                        <table style="width: 100%">
                            <tbody>
                                <tr>
                                    <td>
                                        <label style="font-size: 14px;">Assigned By: </label>
                                    </td>
                                    <td>
                                        <label id="assignedby_info" style="font-size: 14px; font-weight: bold;"></label>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label style="font-size: 14px;">Assigned Date: </label>
                                    </td>
                                    <td>
                                        <label id="assigneddate_info" style="font-size: 14px; font-weight: bold;"></label>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label style="font-size: 14px;">Cleared By: </label>
                                    </td>
                                    <td>
                                        <label id="clearedby_info" style="font-size: 14px; font-weight: bold;"></label>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 30%">
                                        <label style="font-size: 14px;">Cleared Date: </label>
                                    </td>
                                    <td style="width: 70%">
                                        <label id="cleareddate_info" style="font-size: 14px; font-weight: bold;"></label>
                                    </td>
                                </tr>

                                <tr>
                                    <td>
                                        <label style="font-size: 14px;">Sent to Finance By: </label>
                                    </td>
                                    <td>
                                        <label id="sendby_info" style="font-size: 14px; font-weight: bold;"></label>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 30%">
                                        <label style="font-size: 14px;">Sent to finance Date: </label>
                                    </td>
                                    <td style="width: 70%">
                                        <label id="senddate_info" style="font-size: 14px; font-weight: bold;"></label>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label style="font-size: 14px;">Paid By: </label>
                                    </td>
                                    <td>
                                        <label id="paidby_info" style="font-size: 14px; font-weight: bold;"></label>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 30%">
                                        <label style="font-size: 14px;">Paid Date: </label>
                                    </td>
                                    <td style="width: 70%">
                                        <label id="paiddate_info" style="font-size: 14px; font-weight: bold;"></label>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="modal-footer">
                        <button id="closebuttonk" type="button"
                            class="btn btn-danger waves-effect waves-float waves-light"
                            data-dismiss="modal">Close</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- BEGIN: Service Detail Info modal -->
    <div class="modal fade text-left" id="commonServiceDetailModal" data-keyboard="false" data-backdrop="static"
        tabindex="-1" role="dialog" aria-labelledby="myModalLabel133" aria-hidden="true" style="overflow-y: scroll;">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel133">Action Info</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="regionform">
                    <input type="hidden" class="_token">
                    <div class="modal-body">
                        <table style="width: 100%">
                            <tbody>
                                <tr>
                                    <td>
                                        <label style="font-size: 14px;">Sent to Finance By: </label>
                                    </td>
                                    <td>
                                        <label id="commonsentby_info" style="font-size: 14px; font-weight: bold;"></label>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label style="font-size: 14px;">Sent to Finance Date: </label>
                                    </td>
                                    <td>
                                        <label id="commonsentdate_info"
                                            style="font-size: 14px; font-weight: bold;"></label>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label style="font-size: 14px;">Paid By: </label>
                                    </td>
                                    <td>
                                        <label id="commonpaidby_info" style="font-size: 14px; font-weight: bold;"></label>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="width: 30%">
                                        <label style="font-size: 14px;">Paid Date: </label>
                                    </td>
                                    <td style="width: 70%">
                                        <label id="commonpaiddate_info"
                                            style="font-size: 14px; font-weight: bold;"></label>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="modal-footer">
                        <button id="closebuttonk" type="button"
                            class="btn btn-danger waves-effect waves-float waves-light"
                            data-dismiss="modal">Close</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        var errorcolor = "#ffcccc";
        $(function() {
            cardSection = $('#page-block');
        });
        /* BEGIN: Display zone table using yajra datatable */
        $(document).ready(function() {
            var ctable = $('#laravel-datatable-student').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                searchHighlight: true,
                dom: 'lBfrtip', // Add l before B to include lengthMenu
                buttons: [{
                    extend: 'print',
                    title: 'Student list detail',
                    exportOptions: {
                        columns: [0, 1, 2, 3, 4, 5, 6,
                            7, 8
                        ] // Indexes of the columns you want to include
                    }
                }],
                lengthMenu: [
                    [10, 25, 50, 500, -1],
                    [10, 25, 50, 500, "All"]
                ],
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: '/getdormstudent',
                    data: function(data) {
                        data.block = $('#filter_block').val();
                        data.dorm = $('#filter_dorm').val();
                    },
                    type: 'DELETE',
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'full_name',
                        name: 'full_name'
                    },
                    {
                        data: 'student_id',
                        name: 'student_id'
                    },
                    {
                        data: 'sex',
                        name: 'sex'
                    },
                    {
                        data: 'department',
                        name: 'department'
                    },
                    {
                        data: 'entry_year',
                        name: 'entry_year'
                    },
                    {
                        data: 'block',
                        name: 'block'
                    },
                    {
                        data: 'dorm',
                        name: 'dorm'
                    },
                    {
                        data: 'status',
                        name: 'status'
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return '<div class="btn-group dropleft"><button type="button" class="btn btn-sm dropdown-toffle hide-arrow" data-toggle="dropdown" arial-haspopup="true" arial-expanded="false"><i class="fa fa-ellipsis-v"></i></button><div class = "dropdown-menu" > ' +
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dormstudent.edit')): ?>
                                    '<a class = "dropdown-item edit" onclick = "studentEditFn(' +
                                    data
                                        .id +
                                        ')" id = "dteditbtn" title = "Open patient update page" data - id = "' +
                                        data.id +
                                        '"><i class="fa fa-edit"></i><span> <?php echo e(__('students.edit')); ?> </span></a>' +
                                <?php endif; ?>
                            '<a class = "dropdown-item service" onclick = "serviceFn(' +
                            data
                                .id +
                                ')" id = "dtViewbtn" title = "Open service page" data - id = "' +
                                data.id +
                                '"><i class="fa fa-box"></i><span> Services </span></a>' +
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dormstudent.transfer')): ?>
                                    '<a class = "dropdown-item transfer" onclick = "transferFn(' +
                                    data
                                        .id +
                                        ')" id = "dtViewbtn" title = "Open transfer page" data - id = "' +
                                        data.id +
                                        '"><i class="fa fa-paper-plane"></i><span> Transfer </span></a>' +
                                <?php endif; ?>
                            '<a class = "dropdown-item patientView" onclick = "studentInfoFn(' +
                            data
                                .id +
                                ')" id = "dtViewbtn" title = "Open detail page" data - id = "' +
                                data.id +
                                '"><i class="fa fa-inbox"></i><span> View detail </span></a>' +
                                '</div></div> ';
                        },
                        orderable: false,
                        searchable: false
                    }
                ],
                "fnRowCallback": function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                    if (aData.status == "Active") {
                        $(nRow).find('td:eq(8)').css({
                            "color": "#4CAF50",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #4CAF50"
                        });
                    } else if (aData.status == "Transfered") {
                        $(nRow).find('td:eq(8)').css({
                            "color": "orange",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #4CAF50"
                        });
                    } else if (aData.status == "Inactive") {
                        $(nRow).find('.service').css({
                            'display': 'none'
                        });
                        $(nRow).find('.transfer').css({
                            'display': 'none'
                        });
                        $(nRow).find('td:eq(8)').css({
                            "color": "#f44336",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #f44336"
                        });
                    } else if (aData.status == "Cleared") {
                        $(nRow).find('.transfer').css({
                            'display': 'none'
                        });
                        $(nRow).find('.service').css({
                            'display': 'none'
                        });
                        $(nRow).find('.edit').css({
                            'display': 'none'
                        });
                        $(nRow).find('td:eq(8)').css({
                            "color": "#f44336",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #f44336"
                        });
                    }
                }
            });
            /* End: Yajra data table*/
            $('#laravel-datatable-student tbody').on('click', 'tr', function() {
                if ($(this).hasClass('selected')) {
                    $(this).removeClass('selected');
                } else {
                    $('tr.selected').removeClass('selected');
                    $(this).addClass('selected');
                }
            });

            $('#status').select2({
                minimumResultsForSearch: -1
            });
        });
        ctable.on('draw', function() {
            var body = $(ctable.table().body());
            body.unhighlight();
            body.highlight(ctable.search());
        })
    </script>
    <script>
        $('.add').click(function() {
            $('#studentlbl').html('Add Student');
            $('#edit_id').val('');
            $('#full_name').val('');
            $('#student_id').val('');
            $('#department').val('');
            $('#entry_year').val('');
            $('#sex').val('');
            $('#age').val('');
            $('#block').val('');
            $('#address').val('');
            $('#full_name-error').html('');
            $('#student_id-error').html('');
            $('#department-error').html('');
            $('#entry_year-error').html('');
            $('#sex-error').html('');
            $('#age-error').html('');
            $('#phone-error').html('');
            $('#address-error').html('');

            $('#entry_year').select2({
                placeholder: "<?php echo e(__('students.entry_year_placeholder')); ?>",
            });
            $('#block').val('').attr('disabled', false);
            $('#dorm').empty();
            $('#dorm').select2({
                placeholder: "Select a dorm",
            });
            $('#sex').select2({
                placeholder: "<?php echo e(__('students.sex_placeholder')); ?>",
            });

            $('#status').val('Active').trigger('change');
            $('#status-error').html('');
            $('#savestudent').html('<?php echo e(__('dormitory.saveblock')); ?>');
            $('#inlineForm').modal('show');
        });
        $('#savestudent').click(function() {
            var categoryForm = $('#Register');
            var formData = categoryForm.serialize();
            var id = $('#edit_id').val();
            $.ajax({
                url: '/createupdatedormstudent/' + id,
                type: 'post',
                data: formData,
                beforeSend: function() {
                    cardSection.block({
                        message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                        css: {
                            backgroundColor: 'transparent',
                            color: '#fff',
                            border: '0'
                        },
                        overlayCSS: {
                            opacity: 0.5
                        }
                    });
                    if (id != "" && id != null) {
                        $('#savestudent').text('Updating...');
                        $('#savestudent').prop("disabled", true);
                    } else {
                        $('#savestudent').text('Saving...');
                        $('#savestudent').prop("disabled", true);
                    }

                },
                complete: function() {
                    cardSection.block({
                        message: '',
                        timeout: 1,
                        css: {
                            backgroundColor: '',
                            color: '',
                            border: ''
                        },
                    });
                },
                success: function(data) {
                    if (data.errors) {
                        if (data.errors.full_name) {
                            $('#full_name-error').html(data.errors.full_name[0]);
                        }
                        if (data.errors.student_id) {
                            $('#student_id-error').html(data.errors.student_id[0]);
                        }
                        if (data.errors.sex) {
                            $('#sex-error').html(data.errors.sex[0]);
                        }
                        if (data.errors.password) {
                            $('#password-error').html(data.errors.password[0]);
                        }
                        if (data.errors.entry_year) {
                            $('#entry_year-error').html(data.errors.entry_year[0]);
                        }
                        if (data.errors.block) {
                            $('#block-error').html(data.errors.block[0]);
                        }
                        if (data.errors.dorm) {
                            $('#dorm-error').html(data.errors.dorm[0]);
                        }
                        if (data.errors.department) {
                            $('#department-error').html(data.errors.department[0]);
                        }
                        if (data.errors.status) {
                            $('#status-error').html(data.errors.status[0]);
                        }
                        if (id != "" && id != null) {
                            $('#savestudent').text('Update');
                        } else {
                            $('#savestudent').text('Save & Close');
                        }
                        alert_toast('Check your input?', 'error');
                        $('#savestudent').prop("disabled", false);
                    } else if (data.success) {
                        alert_toast(data.success, 'success');
                        var cTable = $('#laravel-datatable-student').dataTable();
                        cTable.fnDraw(false);
                        $('#savestudent').html('Save & Close');
                        $('#savestudent').prop("disabled", false);
                        $('#inlineForm').modal('hide');
                    }
                }

            });
        });
        $('#transferbutton').click(function() {
            var transferForm = $('#transferForm');
            var formData1 = transferForm.serialize();
            $.ajax({
                url: '/transferstudent',
                type: 'post',
                data: formData1,
                beforeSend: function() {
                    cardSection.block({
                        message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                        css: {
                            backgroundColor: 'transparent',
                            color: '#fff',
                            border: '0'
                        },
                        overlayCSS: {
                            opacity: 0.5
                        }
                    });
                    $('#transferbutton').text('Submiting...');
                    $('#transferbutton').prop("disabled", true);

                },
                complete: function() {
                    cardSection.block({
                        message: '',
                        timeout: 1,
                        css: {
                            backgroundColor: '',
                            color: '',
                            border: ''
                        },
                    });
                },
                success: function(data) {
                    if (data.errors) {
                        if (data.errors.block) {
                            $('#transfer-block-error').html(data.errors.block[0]);
                        }
                        if (data.errors.dorm) {
                            $('#transfer-dorm-error').html(data.errors.dorm[0]);
                        }
                        if (data.errors.reason) {
                            $('#reason-error').html(data.errors.reason[0]);
                        }
                        $('#transferbutton').text('Submit');
                        alert_toast('Check your input?', 'error');
                        $('#transferbutton').prop("disabled", false);
                    } else if (data.error) {

                        $('#transferbutton').text('Submit');
                        alert_toast(data.error, 'error');
                        $('#transferbutton').prop("disabled", false);
                    } else if (data.success) {
                        var cTable = $('#laravel-datatable-student').dataTable();
                        cTable.fnDraw(false);
                        alert_toast(data.success, 'success');
                        $('#transferbutton').html('Submit');
                        $('#transferbutton').prop("disabled", false);
                        $('#transferModal').modal('hide');
                    }
                }

            });
        });

        $('#assignbutton').click(function() {
            var assignForm = $('#serviceForm');
            var formData2 = assignForm.serialize();
            $.ajax({
                url: '/saveservice',
                type: 'post',
                data: formData2,
                beforeSend: function() {
                    cardSection.block({
                        message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                        css: {
                            backgroundColor: 'transparent',
                            color: '#fff',
                            border: '0'
                        },
                        overlayCSS: {
                            opacity: 0.5
                        }
                    });
                    $('#assignbutton').text('Submiting...');
                    $('#assignbutton').prop("disabled", true);

                },
                complete: function() {
                    cardSection.block({
                        message: '',
                        timeout: 1,
                        css: {
                            backgroundColor: '',
                            color: '',
                            border: ''
                        },
                    });
                },
                success: function(data) {
                    if (data.errors) {
                        if (data.errors.service_id) {
                            $('#service-error').html(data.errors.service_id[0]);
                        }
                        if (data.errors.quantity) {
                            $('#quantity-error').html(data.errors.quantity[0]);
                        }
                        $('#assignbutton').text('Submit');
                        alert_toast('Check your input?', 'error');
                        $('#assignbutton').prop("disabled", false);
                    } else if (data.success) {
                        var cTable = $('#laravel-datatable-service').dataTable();
                        cTable.fnDraw(false);
                        var inTable = $('#laravel-datatable-individual').dataTable();
                        inTable.fnDraw(false);
                        alert_toast(data.success, 'success');
                        $('#assignbutton').html('Submit');
                        $('#assignbutton').prop("disabled", false);
                        $('#assignServiceModal').modal('hide');
                    } else if (data.quantity_error) {
                        alert_toast(data.quantity_error, 'error');
                        $('#assignbutton').html('Submit');
                        $('#assignbutton').prop("disabled", false);
                        $('#quantity').val('');
                    }
                }

            });
        });

        $(document).ready(function() {
            $('#importForm').submit(function(event) {
                event.preventDefault();

                var studentForm = new FormData($(this)[0]);
                $.ajax({
                    url: '/importDormStudent',
                    type: 'post',
                    data: studentForm,
                    processData: false,
                    contentType: false,
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                        $('#import').text('Importing...');
                        $('#import').prop("disabled", true);
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                    success: function(data) {
                        if (data.errors) {
                            $('#import').html('Import');
                            $('#import').prop("disabled", false);
                            alert_toast("An error occurred while processing the request.",
                                'error');
                            $('#message').html(data.errors);
                            $('#message').addClass('btn btn-danger');
                            $('#fileInput').val('');
                        } else if (data.success) {
                            $('#fileInput').val('');
                            $('#message').html(data.success, 'success');
                            $('#message').addClass('btn btn-success');
                            $('#import').html('Import');
                            $('#import').prop("disabled", false);
                            alert_toast(data.success, 'success');
                            var cTable = $('#laravel-datatable-student').dataTable();
                            cTable.fnDraw(false);
                        }
                    },

                });
            });
        });

        function studentEditFn(record_id) {
            $('#studentlbl').html('Edit Student');
            $('#edit_id').val(record_id);
            $('#savenewbutton').css('display', 'none');
            $('#savestudent').html('Update');
            $.get('/editdormstudent/' + record_id, function(data) {
                $('#full_name').val(data.student.full_name);
                $('#student_id').val(data.student.student_id);
                $('#block').val(data.student.block).attr('disabled', true);
                $('#dorm').empty();
                $('#dorm').append($('<option>', {
                    value: data.student.dorm, // Assuming dirn_id is the unique identifier
                    text: data.student.dorm,
                    selected: true, // Pre-selects the option
                    disabled: true // Makes it readonly
                }));
                $('#department').val(data.student.department);
                $('#status').val(data.student.status).trigger('change');
                $('#entry_year').val(data.student.entry_year).trigger('change');
                $('#sex').val(data.student.sex).trigger('change');
            });
            $('#inlineForm').modal('show');
        }

        function transferFn(record_id) {
            $('#transfer_block').val('');
            $('#transfer_dorm').val('');
            $('#reason').val('');
            $('#transfer_block').select2({
                placeholder: "Select a block",
            });
            $('#transfer_dorm').select2({
                placeholder: "Select a dorm",
            });
            $('#transfer-block-error').html('');
            $('#transfer-dorm-error').html('');
            $('#reason-error').html('');
            $('#stud_id').val(record_id);
            $('#transferModal').modal('show');
        }

        function serviceFn(record_id) {
            $('#st_id').val(record_id);
            $.get('/checkclearance/' + record_id, function(data) {
                if (data.success) {
                    $('#clearance').prop("disabled", false);
                    $('#clearance').html('Clear Student');
                } else {
                    $('#clearance').prop("disabled", true);
                    $('#clearance').html("Clearance hasn's completed yet.");
                }
            });

            var htable = $('#laravel-datatable-service').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                searchHighlight: true,
                dom: 'Bfrtip', // Add l before B to include lengthMenu
                buttons: [],
                lengthMenu: [
                    [10, 25, 50, 500, -1],
                    [10, 25, 50, 500, "All"]
                ],
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: '/getstudentservice/' + record_id,
                    type: 'DELETE',
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },
                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return '<img src="<?php echo url('uploads/dorm.jpg'); ?>" width="40" height="35" onclick="viewDormPhoto()">';
                        },
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'student.student_id',
                        name: 'student.student_id',
                    },
                    {
                        data: 'service.service_name',
                        name: 'service.service_name',
                    },
                    {
                        data: 'quantity',
                        name: 'quantity',
                    },
                    {
                        data: 'service.unit_price',
                        name: 'service.unit_price',
                    },
                    {
                        data: 'service.remark',
                        name: 'service.remark',
                    },
                    {
                        data: 'state',
                        name: 'state',
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return '<div class="btn-group dropleft"><button type="button" class="btn btn-sm dropdown-toffle hide-arrow" data-toggle="dropdown" arial-haspopup="true" arial-expanded="false"><i class="fa fa-ellipsis-v"></i></button><div class = "dropdown-menu" > ' +
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('clearservices')): ?>
                                    '<a class = "dropdown-item clear" onclick = "removeService(' +
                                    data
                                        .id +
                                        ')" id = "dteditbtn" title = "clear page" data - id = "' +
                                        data.id +
                                        '"><i class="fa fa-trash"></i><span> Clear </span></a>' +
                                <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sendservicetofinance')): ?>
                                '<a class = "dropdown-item finance" onclick = "sendFinance(' +
                                data
                                    .id +
                                    ')" id = "dteditbtn" title = "Send Finance Page" data - id = "' +
                                    data.id +
                                    '"><i class="fa fa-plane"></i><span> Send to Finance </span></a>' +
                            <?php endif; ?>
                            '<a class = "dropdown-item" onclick = "serviceDetail(' +
                            data
                                .id +
                                ')" id = "dteditbtn" title = "Detail Page" data - id = "' +
                                data.id +
                                '"><i class="fa fa-box"></i><span> Action Detail </span></a>' +
                                '</div></div> ';
                        },
                        orderable: false,
                        searchable: false
                    },
                ],
                "fnRowCallback": function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                    if (aData.state == "0") {
                        $(nRow).find('td:eq(7)').html('Active');
                        $(nRow).find('td:eq(7)').css({
                            "color": "#4CAF50",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #4CAF50"
                        });
                    } else if (aData.state == "1") {
                        $(nRow).find('.clear').css({
                            "display": "none"
                        });
                        $(nRow).find('.finance').css({
                            "display": "none"
                        });
                        $(nRow).find('td:eq(7)').html('Cleared');
                        $(nRow).find('td:eq(7)').css({
                            "color": "#f44336",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #f44336"
                        });
                    } else if (aData.state == "2") {
                        $(nRow).find('.finance').css({
                            "display": "none"
                        });
                        $(nRow).find('.clear').css({
                            "display": "none"
                        });
                        $(nRow).find('td:eq(7)').html('Pending Finance');
                        $(nRow).find('td:eq(7)').css({
                            "color": "blue",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #f44336"
                        });
                    } else if (aData.state == "3") {
                        $(nRow).find('.finance').css({
                            "display": "none"
                        });
                        $(nRow).find('.clear').css({
                            "display": "none"
                        });
                        $(nRow).find('td:eq(7)').html('Paid');
                        $(nRow).find('td:eq(7)').css({
                            "color": "green",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #f44336"
                        });
                    }
                }
            });
            $('#serviceModal').modal('show');
        }

        function makeClearance() {
            let check = confirm('Are you sure? you will going to clear this student');
            if (check === true) {
                $.get('/makeclearance/' + $('#st_id').val(), function(data) {
                    if (data.success) {
                        alert_toast(data.success, 'success');
                        var rfTable = $('#laravel-datatable-student').dataTable();
                        rfTable.fnDraw(false);
                        $('#serviceModal').modal('hide');
                    } else {
                        alert_toast('an error occured please try again', 'error');
                    }
                });
            }
        }

        function studentInfoFn(record_id) {
            $.get('/show_dorm_student/' + record_id, function(data) {
                if (data.student) {
                    $('#full_name_info').html(data.student.full_name);
                    $('#student_id_info').html(data.student.student_id);
                    $('#department_info').html(data.student.department);
                    $('#entry_year_info').html(data.student.entry_year);
                    $('#block_info').html(data.student.block);
                    $('#dorm_info').html(data.student.dorm);
                    $('#sex_info').html(data.student.sex);
                    $('#createdby_info').html(data.cr.username);
                    $('#updatedby_info').html(data.ur.username);
                    $('#createdat_info').html(data.crdate);
                    if (data.ur !== "") {
                        $('#updatedat_info').html(data.upgdate);
                    }
                    var st = data.student.status;

                    if (st == "Active") {
                        $("#status_info").html("<b style='color:#1cc88a'>" + data.student.status + "</b>");
                    }
                    if (st == "Inactive") {
                        $("#status_info").html("<b style='color:#e74a3b'>" + data.student.status + "</b>");
                    }
                }
            });

            $('#transferdetailtbl').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                searchHighlight: true,
                dom: 'lBfrtip', // Add l before B to include lengthMenu
                buttons: [{
                        extend: 'copy',
                        title: 'Your Title Here' // Title for the 'copy' button
                    },
                    {
                        extend: 'csv',
                        title: 'Your Title Here' // Title for the 'csv' button
                    },
                    {
                        extend: 'excel',
                        title: 'Your Title Here' // Title for the 'excel' button
                    },
                    {
                        extend: 'pdf',
                        title: 'Your Title Here' // Title for the 'pdf' button
                    },
                    {
                        extend: 'print',
                        title: 'Yout title here'
                    }
                ],
                lengthMenu: [
                    [10, 25, 50, 500, -1],
                    [10, 25, 50, 500, "All"]
                ],
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: '/transferinfo/' + record_id,
                    type: 'DELETE',
                    dataType: "json",
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },

                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'created_at',
                        name: 'created_at'
                    },
                    {
                        data: 'block',
                        name: 'block'
                    },
                    {
                        data: 'dorm',
                        name: 'dorm'
                    },
                    {
                        data: 'reason',
                        name: 'reason'
                    },
                    {
                        data: 'user.name',
                        name: 'user.name'
                    },
                ],
            });
            var servicedorm = $('#dormservicetbl').DataTable({
                destroy: true,
                processing: true,
                serverSide: true,
                searchHighlight: true,
                dom: 'lBfrtip', // Add l before B to include lengthMenu
                buttons: [{
                        extend: 'copy',
                        title: 'Your Title Here' // Title for the 'copy' button
                    },
                    {
                        extend: 'csv',
                        title: 'Your Title Here' // Title for the 'csv' button
                    },
                    {
                        extend: 'excel',
                        title: 'Your Title Here' // Title for the 'excel' button
                    },
                    {
                        extend: 'pdf',
                        title: 'Your Title Here' // Title for the 'pdf' button
                    },
                    {
                        extend: 'print',
                        title: 'Yout title here'
                    }
                ],
                lengthMenu: [
                    [10, 25, 50, 500, -1],
                    [10, 25, 50, 500, "All"]
                ],
                language: {
                    search: '',
                    searchPlaceholder: "Search here"
                },
                ajax: {
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    url: '/getservicedetail/' + record_id,
                    type: 'DELETE',
                    dataType: "json",
                    beforeSend: function() {
                        cardSection.block({
                            message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                            css: {
                                backgroundColor: 'transparent',
                                color: '#fff',
                                border: '0'
                            },
                            overlayCSS: {
                                opacity: 0.5
                            }
                        });
                    },
                    complete: function() {
                        cardSection.block({
                            message: '',
                            timeout: 1,
                            css: {
                                backgroundColor: '',
                                color: '',
                                border: ''
                            },
                        });
                    },
                },

                columns: [{
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return '<img src="<?php echo url('uploads/block1.jpg'); ?>" width="40" height="35" onclick="viewServicePhoto()">';
                        },
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'service.service_name',
                        name: 'service.service_name'
                    },
                    {
                        data: 'quantity',
                        name: 'quantity'
                    },
                    {
                        data: 'service.unit_price',
                        name: 'service.unit_price'
                    },
                    {
                        data: 'service.remark',
                        name: 'service.remark'
                    },
                    {
                        data: 'state',
                        name: 'state'
                    },
                    {
                        data: null,
                        render: function(data, type, full, meta) {
                            return '<div class="btn-group dropleft"><button type="button" class="btn btn-sm dropdown-toffle hide-arrow" data-toggle="dropdown" arial-haspopup="true" arial-expanded="false"><i class="fa fa-ellipsis-v"></i></button><div class = "dropdown-menu" > ' +
                                '<a class = "dropdown-item" onclick = "serviceDetail(' +
                                data
                                .id +
                                ')" id = "dteditbtn" title = "Detail Page" data - id = "' +
                                data.id +
                                '"><i class="fa fa-box"></i><span> Action Detail </span></a>' +
                                '</div></div> ';
                        },
                        orderable: false,
                        searchable: false
                    },
                ],
                "fnRowCallback": function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                    if (aData.state == "0") {
                        $(nRow).find('td:eq(6)').html('Active')
                        $(nRow).find('td:eq(6)').css({
                            "color": "orange",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #f44336"
                        });
                    } else if (aData.state == "1") {
                        $(nRow).find('td:eq(6)').html('Cleared');
                        $(nRow).find('td:eq(6)').css({
                            "color": "red",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #f44336"
                        });
                    } else if (aData.state == "2") {
                        $(nRow).find('td:eq(6)').html('Pending Finance');
                        $(nRow).find('td:eq(6)').css({
                            "color": "blue",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #f44336"
                        });
                    } else if (aData.state == "3") {
                        $(nRow).find('td:eq(6)').html('Paid');
                        $(nRow).find('td:eq(6)').css({
                            "color": "#4CAF50",
                            "font-weight": "bold",
                            "text-shadow": "1px 1px 10px #f44336"
                        });
                    }
                }
            });
            $('#infoModal').modal('show');
        }

        function assignService() {
            $('#individual_student').css({
                'display': 'none'
            });
            $.get('/assignservice/' + $('#st_id').val(), function(data) {
                // Clear existing options
                var selectElement3 = $('#service_id');
                selectElement3.empty();
                selectElement3.append($('<option>', {
                    value: '',
                    text: 'Select a service',
                    disabled: true,
                    selected: true
                }));
                // Append new options
                $.each(data.service, function(key, value) {
                    selectElement3.append($('<option>', {
                        value: value.id, // Assuming dirn_id is the unique identifier
                        text: value.service_name + " | " + value.remark
                    }));
                });
                // Initialize Select2 with placeholder
                selectElement3.select2({
                    placeholder: 'Select a service',
                    allowClear: true // Optional: allows clearing the selection
                });
            });

            $('#assignServiceModal').modal('show');
        }

        function assignIndividualService() {
            $('#individual_student').css({
                'display': 'grid'
            });
            $.get('/assignindividualservice/' + $('#filter_block').val() + '/' + $('#filter_dorm').val(), function(data) {
                // Clear existing options
                var selectElement3 = $('#service_id');
                selectElement3.empty();
                selectElement3.append($('<option>', {
                    value: '',
                    text: 'Select a service',
                    disabled: true,
                    selected: true
                }));
                // Clear existing options
                var selectElement4 = $('#individual_st_id');
                selectElement4.empty();
                selectElement4.append($('<option>', {
                    value: '',
                    text: 'Select a student',
                    disabled: true,
                    selected: true
                }));
                // Append new options
                $.each(data.service, function(key, value) {
                    selectElement3.append($('<option>', {
                        value: value.id, // Assuming dirn_id is the unique identifier
                        text: value.service_name + " | " + value.remark
                    }));
                });
                // Append new options
                $.each(data.student, function(key, value) {
                    selectElement4.append($('<option>', {
                        value: value.id, // Assuming dirn_id is the unique identifier
                        text: value.student_id
                    }));
                });
                // Initialize Select2 with placeholder
                selectElement3.select2({
                    placeholder: 'Select a service',
                    allowClear: true // Optional: allows clearing the selection
                });
                // Initialize Select2 with placeholder
                selectElement4.select2({
                    placeholder: 'Select a student',
                    allowClear: true // Optional: allows clearing the selection
                });
            });

            $('#assignServiceModal').modal('show');
        }

        function removeService(record_id) {
            var check = confirm('Are you sure to remove this service?');
            if (check === true) {
                $.get('/clearservice/' + record_id, function(data) {
                    if (data.success) {
                        alert_toast(data.success, 'success');
                        var cTable = $('#laravel-datatable-service').dataTable();
                        cTable.fnDraw(false);
                        var inTable = $('#laravel-datatable-individual').dataTable();
                        inTable.fnDraw(false);
                    } else {
                        alert_toast('An Error occured! please try again', 'error');
                    }
                });
            }
        }

        function serviceDetail(record_id) {
            $.get('/studentservicedetail/' + record_id, function(data) {
                if (data.success) {
                    $('#assignedby_info').html(data.cr.name);
                    $('#assigneddate_info').html(data.crdate);
                    $('#cleareddate_info').html(data.cldate);
                    $('#senddate_info').html(data.sndate);
                    $('#paiddate_info').html(data.pddate);
                    if (data.cl !== "") {
                        $('#clearedby_info').html(data.cl.name);
                    } else {
                        $('#clearedby_info').html('');
                    }
                    if (data.sn !== "") {
                        $('#sendby_info').html(data.sn.name);
                    } else {
                        $('#sendby_info').html('');
                    }
                    if (data.pd !== "") {
                        $('#paidby_info').html(data.pd.name);
                    } else {
                        $('#paidby_info').html('');
                    }
                    $('#serviceDetailModal').modal('show');
                } else {
                    $('#serviceDetailModal').modal('show');
                }
            });
        }

        function commonServiceDetail(record_id) {
            $.get('/studentcommonservicedetail/' + record_id, function(data) {
                if (data.success) {
                    $('#commonsentby_info').html(data.sn.name);
                    $('#commonsentdate_info').html(data.sndate);
                    $('#commonpaiddate_info').html(data.pddate);
                    if (data.pd !== "") {
                        $('#commonpaidby_info').html(data.pd.name);
                    } else {
                        $('#commonpaidby_info').html('');
                    }
                    $('#commonServiceDetailModal').modal('show');
                } else {
                    $('#commonServiceDetailModal').modal('show');
                }
            });
        }

        function sendFinance(record_id) {
            var check = confirm('Are you sure to send to finance for payment?');
            if (check === true) {
                $.get('/sendfinance/' + record_id, function(data) {
                    if (data.success) {
                        alert_toast(data.success, 'success');
                        var cTable = $('#laravel-datatable-service').dataTable();
                        cTable.fnDraw(false);
                        var inTable = $('#laravel-datatable-individual').dataTable();
                        inTable.fnDraw(false);
                    } else {
                        alert_toast('An Error occured! please try again', 'error');
                    }
                });
            }
        }

        function sendCommonFinance(record_id) {
            var check = prompt('Are you sure? Please enter quantity here');
            if (check == null || check == '') {
                alert_toast('ann error co')
            } else {
                $.get('/sendcommonfinance/' + record_id + '/' + check, function(data) {
                    if (data.success) {
                        alert_toast(data.success, 'success');
                        var fnTable = $('#laravel-datatable-commonfinance').dataTable();
                        fnTable.fnDraw(false);
                    } else {
                        alert_toast('An Error occured! please try again', 'error');
                    }
                });
            }

        }
    </script>
    <script>
        function removeNameValidation() {
            $('#full_name-error').html('');
        }

        function serviceBlock() {
            $('#service-error').html('');
        }

        function removeQuantity() {
            $('#quantity-error').html('');
        }

        function removeStudentValidation() {
            $('#student_id-error').html('');
        }

        function removeDepartmentValidation() {
            $('#department-error').html('');
        }

        function removeYearValidation() {
            $('#entry_year-error').html('');
        }

        function removeSexValidation() {
            $('#sex-error').html('');
        }

        function removeAgeValidation() {
            $('#age-error').html('');
        }

        function removePhoneValidation() {
            $('#phone-error').html('');
        }

        function removePasswordValidation() {
            $('#password-error').html('');
        }

        function removeAddressValidation() {
            $('#address-error').html('');
        }

        function removeStatusValidation() {
            $('#status-error').html('');
        }

        function removeBlockValidation() {
            $('#block-error').html('');
            $.get('/getdormlist/' + $('#block').val(), function(data) {

                // Clear existing options
                var selectElement = $('#dorm');
                selectElement.empty();
                selectElement.append($('<option>', {
                    value: '',
                    text: 'Select a dorm',
                    disabled: true,
                    selected: true
                }));
                // Append new options
                $.each(data.dorm, function(key, value) {
                    selectElement.append($('<option>', {
                        value: value.dorm_name, // Assuming dirn_id is the unique identifier
                        text: value.dorm_name
                    }));
                });
                // Initialize Select2 with placeholder
                selectElement.select2({
                    placeholder: 'Select a dorm',
                    allowClear: true // Optional: allows clearing the selection
                });
            });
        }

        $('#filter_block').select2({
            placeholder: "Select a block",
        });

        $('#filter_dorm').select2({
            placeholder: "Select a dorm",
        });
        $('#common').click(function() {
            let dorm = $('#filter_dorm').val();
            if (dorm == '' || dorm == null) {
                alert_toast('Please select dorm', 'error');
            } else {
                var cmtable = $('#laravel-datatable-common').DataTable({
                    destroy: true,
                    processing: true,
                    serverSide: true,
                    searchHighlight: true,
                    dom: 'Bfrtip', // Add l before B to include lengthMenu
                    buttons: [],
                    lengthMenu: [
                        [10, 25, 50, 500, -1],
                        [10, 25, 50, 500, "All"]
                    ],
                    language: {
                        search: '',
                        searchPlaceholder: "Search here"
                    },
                    ajax: {
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        url: '/commonservice/' + $('#filter_block').val() + '/' + $('#filter_dorm').val(),
                        type: 'DELETE',
                    },
                    columns: [{
                            data: 'DT_RowIndex',
                            name: 'DT_RowIndex',
                            orderable: false,
                            searchable: false
                        },
                        {
                            data: null,
                            render: function(data, type, full, meta) {
                                return '<img src="<?php echo url('uploads/dorm.jpg'); ?>" width="40" height="35" onclick="viewDormPhoto()">';
                            },
                            orderable: false,
                            searchable: false
                        },
                        {
                            data: 'service_name',
                            name: 'service_name',
                        },
                        {
                            data: 'quantity',
                            name: 'quantity',
                        },
                        {
                            data: 'unit_price',
                            name: 'unit_price',
                        },
                        {
                            data: 'remark',
                            name: 'remark',
                        },
                        {
                            data: 'status',
                            name: 'status',
                        },
                        {
                            data: null,
                            render: function(data, type, full, meta) {
                                return '<div class="btn-group dropleft"><button type="button" class="btn btn-sm dropdown-toffle hide-arrow" data-toggle="dropdown" arial-haspopup="true" arial-expanded="false"><i class="fa fa-ellipsis-v"></i></button><div class = "dropdown-menu" > ' +
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sendservicetofinance')): ?>
                                        '<a class = "dropdown-item finance" onclick = "sendCommonFinance(' +
                                        data
                                            .id +
                                            ')" id = "dteditbtn" title = "Send Finance Page" data - id = "' +
                                            data.id +
                                            '"><i class="fa fa-plane"></i><span> Send to Finance </span></a>' +
                                    <?php endif; ?>
                                '</div></div> ';
                            },
                            orderable: false,
                            searchable: false
                        },
                    ],
                    "fnRowCallback": function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                        if (aData.status == "Common") {
                            $(nRow).find('td:eq(6)').css({
                                "color": "#4CAF50",
                                "font-weight": "bold",
                                "text-shadow": "1px 1px 10px #4CAF50"
                            });
                        } else if (aData.status == "Individual") {
                            $(nRow).find('.clear').css({
                                'display': 'none',
                            });
                            $(nRow).find('.finance').css({
                                'display': 'none',
                            });
                            $(nRow).find('.detail').css({
                                'display': 'none',
                            });
                            $(nRow).find('td:eq(6)').css({
                                "color": "orange",
                                "font-weight": "bold",
                                "text-shadow": "1px 1px 10px #f44336"
                            });
                        }
                    }
                });

                var fntable = $('#laravel-datatable-commonfinance').DataTable({
                    destroy: true,
                    processing: true,
                    serverSide: true,
                    searchHighlight: true,
                    dom: 'Bfrtip', // Add l before B to include lengthMenu
                    buttons: [],
                    lengthMenu: [
                        [10, 25, 50, 500, -1],
                        [10, 25, 50, 500, "All"]
                    ],
                    language: {
                        search: '',
                        searchPlaceholder: "Search here"
                    },
                    ajax: {
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        url: '/commonfinanceservice/' + $('#filter_block').val() + '/' + $('#filter_dorm')
                            .val(),
                        type: 'DELETE',
                    },
                    columns: [{
                            data: 'DT_RowIndex',
                            name: 'DT_RowIndex',
                            orderable: false,
                            searchable: false
                        },
                        {
                            data: null,
                            render: function(data, type, full, meta) {
                                return '<img src="<?php echo url('uploads/dorm.jpg'); ?>" width="40" height="35" onclick="viewDormPhoto()">';
                            },
                            orderable: false,
                            searchable: false
                        },
                        {
                            data: 'service.service_name',
                            name: 'service.service_name',
                        },
                        {
                            data: 'quantity',
                            name: 'quantity',
                        },
                        {
                            data: 'service.unit_price',
                            name: 'service.unit_price',
                        },
                        {
                            data: 'service.remark',
                            name: 'service.remark',
                        },
                        {
                            data: 'service.status',
                            name: 'service.status',
                        },
                        {
                            data: 'state',
                            name: 'state',
                        },
                        {
                            data: null,
                            render: function(data, type, full, meta) {
                                return '<div class="btn-group dropleft"><button type="button" class="btn btn-sm dropdown-toffle hide-arrow" data-toggle="dropdown" arial-haspopup="true" arial-expanded="false"><i class="fa fa-ellipsis-v"></i></button><div class = "dropdown-menu" > ' +
                                    '<a class = "dropdown-item detail" onclick = "commonServiceDetail(' +
                                    data
                                    .id +
                                    ')" id = "dteditbtn" title = "Detail Page" data - id = "' +
                                    data.id +
                                    '"><i class="fa fa-box"></i><span> Action Detail </span></a>' +
                                    '</div></div> ';
                            },
                            orderable: false,
                            searchable: false
                        },
                    ],
                    "fnRowCallback": function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                        if (aData.service.status == "Common") {
                            $(nRow).find('td:eq(6)').css({
                                "color": "orange",
                                "font-weight": "bold",
                                "text-shadow": "1px 1px 10px #4CAF50"
                            });
                        }
                        if (aData.state == "0") {
                            $(nRow).find('td:eq(7)').html('Pending Finance');
                            $(nRow).find('td:eq(7)').css({
                                "color": "blue",
                                "font-weight": "bold",
                                "text-shadow": "1px 1px 10px #f44336"
                            });
                        } else if (aData.state == "1") {
                            $(nRow).find('td:eq(7)').html('Paid');
                            $(nRow).find('td:eq(7)').css({
                                "color": "#4CAF50",
                                "font-weight": "bold",
                                "text-shadow": "1px 1px 10px #f44336"
                            });
                        }
                    }
                });
                var htable = $('#laravel-datatable-individual').DataTable({
                    destroy: true,
                    processing: true,
                    serverSide: true,
                    searchHighlight: true,
                    dom: 'Bfrtip', // Add l before B to include lengthMenu
                    buttons: [],
                    lengthMenu: [
                        [10, 25, 50, 500, -1],
                        [10, 25, 50, 500, "All"]
                    ],
                    language: {
                        search: '',
                        searchPlaceholder: "Search here"
                    },
                    ajax: {
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        url: '/individualservice/' + $('#filter_block').val() + '/' + $('#filter_dorm')
                            .val(),
                        type: 'DELETE',
                        beforeSend: function() {
                            cardSection.block({
                                message: '<div class="d-flex justify-content-center align-items-center"><p class="mr-50 mb-50">Loading Please Wait...</p><div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                                css: {
                                    backgroundColor: 'transparent',
                                    color: '#fff',
                                    border: '0'
                                },
                                overlayCSS: {
                                    opacity: 0.5
                                }
                            });
                        },
                        complete: function() {
                            cardSection.block({
                                message: '',
                                timeout: 1,
                                css: {
                                    backgroundColor: '',
                                    color: '',
                                    border: ''
                                },
                            });
                        },
                    },
                    columns: [{
                            data: 'DT_RowIndex',
                            name: 'DT_RowIndex',
                            orderable: false,
                            searchable: false
                        },
                        {
                            data: null,
                            render: function(data, type, full, meta) {
                                return '<img src="<?php echo url('uploads/dorm.jpg'); ?>" width="40" height="35" onclick="viewDormPhoto()">';
                            },
                            orderable: false,
                            searchable: false
                        },
                        {
                            data: 'student.student_id',
                            name: 'student.student_id',
                        },
                        {
                            data: 'service.service_name',
                            name: 'service.service_name',
                        },
                        {
                            data: 'quantity',
                            name: 'quantity',
                        },
                        {
                            data: 'service.unit_price',
                            name: 'service.unit_price',
                        },
                        {
                            data: 'service.remark',
                            name: 'service.remark',
                        },
                        {
                            data: 'state',
                            name: 'state',
                        },
                        {
                            data: null,
                            render: function(data, type, full, meta) {
                                return '<div class="btn-group dropleft"><button type="button" class="btn btn-sm dropdown-toffle hide-arrow" data-toggle="dropdown" arial-haspopup="true" arial-expanded="false"><i class="fa fa-ellipsis-v"></i></button><div class = "dropdown-menu" > ' +
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('clearservices')): ?>
                                        '<a class = "dropdown-item clear" onclick = "removeService(' +
                                        data
                                            .id +
                                            ')" id = "dteditbtn" title = "clear page" data - id = "' +
                                            data.id +
                                            '"><i class="fa fa-trash"></i><span> Clear </span></a>' +
                                    <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sendservicetofinance')): ?>
                                    '<a class = "dropdown-item finance" onclick = "sendFinance(' +
                                    data
                                        .id +
                                        ')" id = "dteditbtn" title = "Send Finance Page" data - id = "' +
                                        data.id +
                                        '"><i class="fa fa-plane"></i><span> Send to Finance </span></a>' +
                                <?php endif; ?>
                                '<a class = "dropdown-item" onclick = "serviceDetail(' +
                                data
                                    .id +
                                    ')" id = "dteditbtn" title = "Detail Page" data - id = "' +
                                    data.id +
                                    '"><i class="fa fa-box"></i><span> Action Detail </span></a>' +
                                    '</div></div> ';
                            },
                            orderable: false,
                            searchable: false
                        },
                    ],
                    "fnRowCallback": function(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                        if (aData.state == "0") {
                            $(nRow).find('td:eq(7)').html('Active');
                            $(nRow).find('td:eq(7)').css({
                                "color": "#4CAF50",
                                "font-weight": "bold",
                                "text-shadow": "1px 1px 10px #4CAF50"
                            });
                        } else if (aData.state == "1") {
                            $(nRow).find('.clear').css({
                                "display": "none"
                            });
                            $(nRow).find('.finance').css({
                                "display": "none"
                            });
                            $(nRow).find('td:eq(7)').html('Cleared');
                            $(nRow).find('td:eq(7)').css({
                                "color": "#f44336",
                                "font-weight": "bold",
                                "text-shadow": "1px 1px 10px #f44336"
                            });
                        } else if (aData.state == "2") {
                            $(nRow).find('.finance').css({
                                "display": "none"
                            });
                            $(nRow).find('.clear').css({
                                "display": "none"
                            });
                            $(nRow).find('td:eq(7)').html('Pending Finance');
                            $(nRow).find('td:eq(7)').css({
                                "color": "blue",
                                "font-weight": "bold",
                                "text-shadow": "1px 1px 10px #f44336"
                            });
                        } else if (aData.state == "3") {
                            $(nRow).find('.finance').css({
                                "display": "none"
                            });
                            $(nRow).find('.clear').css({
                                "display": "none"
                            });
                            $(nRow).find('td:eq(7)').html('Paid');
                            $(nRow).find('td:eq(7)').css({
                                "color": "green",
                                "font-weight": "bold",
                                "text-shadow": "1px 1px 10px #f44336"
                            });
                        }
                    }
                });
                $('#commonServiceModal').modal('show');
            }
        });

        function filterDorm() {
            var cTable = $('#laravel-datatable-student').dataTable();
            cTable.fnDraw(false);
            $('#commonservice').css({
                'display': 'grid'
            });
        }

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('proctor')): ?>
            var cTable = $('#laravel-datatable-student').dataTable();
            cTable.fnDraw(false);
            $.get('/getdormlist/' + $('#filter_block').val(), function(data) {
                // Clear existing options
                var selectElement1 = $('#filter_dorm');
                selectElement1.empty();
                selectElement1.append($('<option>', {
                    value: '',
                    text: 'Select a dorm',
                    disabled: true,
                    selected: true
                }));
                // Append new options
                $.each(data.dorm, function(key, value) {
                    selectElement1.append($('<option>', {
                        value: value.dorm_name, // Assuming dirn_id is the unique identifier
                        text: value.dorm_name
                    }));
                });
                // Initialize Select2 with placeholder
                selectElement1.select2({
                    placeholder: 'Select a dorm',
                    allowClear: true // Optional: allows clearing the selection
                });
            });
        <?php endif; ?>

        function filterBlock() {
            var cTable = $('#laravel-datatable-student').dataTable();
            cTable.fnDraw(false);
            $.get('/getdormlist/' + $('#filter_block').val(), function(data) {
                // Clear existing options
                var selectElement1 = $('#filter_dorm');
                selectElement1.empty();
                selectElement1.append($('<option>', {
                    value: '',
                    text: 'Select a dorm',
                    disabled: true,
                    selected: true
                }));
                // Append new options
                $.each(data.dorm, function(key, value) {
                    selectElement1.append($('<option>', {
                        value: value.dorm_name, // Assuming dirn_id is the unique identifier
                        text: value.dorm_name
                    }));
                });
                // Initialize Select2 with placeholder
                selectElement1.select2({
                    placeholder: 'Select a dorm',
                    allowClear: true // Optional: allows clearing the selection
                });
            });


        }

        function transferDorm() {
            $('#transfer-dorm-error').html('');
        }

        function transferBlock() {
            $('#transfer-block-error').html('');
            $.get('/getdormlist/' + $('#transfer_block').val(), function(data) {
                // Clear existing options
                var selectElement2 = $('#transfer_dorm');
                selectElement2.empty();
                selectElement2.append($('<option>', {
                    value: '',
                    text: 'Select a dorm',
                    disabled: true,
                    selected: true
                }));
                // Append new options
                $.each(data.dorm, function(key, value) {
                    selectElement2.append($('<option>', {
                        value: value.dorm_name, // Assuming dirn_id is the unique identifier
                        text: value.dorm_name
                    }));
                });
                // Initialize Select2 with placeholder
                selectElement2.select2({
                    placeholder: 'Select a dorm',
                    allowClear: true // Optional: allows clearing the selection
                });
            });


        }

        function removeStatusValidation() {
            $('#status-error').html('');
        }

        function removeIndividualStudentValidation() {
            $('#st_id').val($('#individual_st_id').val());
        }

        function closeModal() {
            $('#name-error').html('');
            $('#status-error').html('');
            $('#name').val('');
            $('#status').val('').trigger('change');
            $('#savenewbutton').css('display', 'flex');
            $('#savebutton').html('Save & Close');
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Werabe University Project\Werabe University Project\resources\views\dormitory\students1.blade.php ENDPATH**/ ?>